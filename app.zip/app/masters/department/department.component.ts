import { Component, OnInit } from '@angular/core';
import { DepartmentType } from './departmentType';

import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DepartmentService } from './department.service';

import {TooltipPosition} from '@angular/material/tooltip';
import { Key } from 'protractor';



@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})

export class DepartmentComponent implements OnInit {

 //departmentObj: DepartmentType[];

tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

departmentObj: DepartmentType[] = [
  {  Description: 'Accounts Taxation', ShortName: '004'},
  {  Description: 'BSG IT', ShortName: '003'},
  {  Description: 'Head Office', ShortName: '001'},
  {  Description: 'Operations Team', ShortName: '002'},
  {  Description: 'Technical', ShortName: '004'}
];

departmentFilteredObj : DepartmentType[] = [];
//new DepartmentType

  departmentColumns: string[] = [  'View', 'Edit', 'Delete','Description', 'ShortName'];


  constructor( private departmentService: DepartmentService, private fb: FormBuilder) { }

  DepartmentForm: FormGroup;

  ngOnInit() {
    this. getDepartmentDetails();

    this.DepartmentForm = this.fb.group({

      SearchDescription: [''],
  
      ActionGroupDepartment : this.fb.group({
  
          Description: ['', Validators.required],
          ShortName: ['', Validators.required]
  
        })
  
  
    });


     this.onChanges();
  }
  onChanges() {
   // this.DepartmentForm.valueChanges.subscribe(x => console.log(JSON.stringify(x)));
  }

  onBtnSaveClick(){
    if(this.DepartmentForm.valid){
      
       // console.log(this.DepartmentForm.);
       console.log(this.DepartmentForm.controls.ActionGroupDepartment.value);

       
      
    }
  }
  onBtnResetClick(){
    this.DepartmentForm.reset();
  }

  getDepartmentDetails(): void {
   
    //  this.departmentService.getDepartmentDetails()
    //    .subscribe(departmentObj => this.departmentObj = departmentObj);
      //console.log(this.EmployeeObj);
   }

   btngvView_Click(a){
   // console.log("hi");
   //this.departmentFilteredObj = new DepartmentType[];
     this.departmentFilteredObj = this.departmentObj.filter( (unit) => unit.Description == a );

     console.log(this.departmentFilteredObj[0].Description);
    
    // console.log(this.departmentObj.filter( (unit) => unit.Description.indexOf(id) > -1 ).filter( (qwerty) => qwerty.Description ) );
  
    this.DepartmentForm = this.fb.group({

      SearchDescription: [''],
  
      ActionGroupDepartment : this.fb.group({
  
          Description: {value: this.departmentFilteredObj[0].Description, disabled: true},
          ShortName: {value: this.departmentFilteredObj[0].ShortName, disabled: true}
  
        })
  
  
    });


     this.DepartmentForm.patchValue({

    //  Description: this.departmentFilteredObj.filter( (unit) => unit.Description.indexOf(id) > -1 )
     });
   }

   consoleLogFn(val){
    console.log(val);
   }

  
}
