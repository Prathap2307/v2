import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MastersComponent } from './masters.component';
import { DepartmentComponent } from './department/department.component';
import { MasterPageComponent } from './..//master-page/master-page.component';
import { InsurerComponent } from './insurer/insurer.component';
const routes: Routes = [
 
  // {	
  //   path: 'masters',
  //    component: MastersComponent,
  //     children: [                         //<---- child components declared here
  //         {
  //             path:'department',
  //             component: DepartmentComponent
  //         },
  //         {
  //           path:'insurer',
  //           component: InsurerComponent
  //       }
  //       ]
  //   }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MastersRoutingModule { }
