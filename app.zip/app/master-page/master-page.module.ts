import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MasterPageRoutingModule } from './master-page-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MasterPageRoutingModule
  ]
})
export class MasterPageModule { }
