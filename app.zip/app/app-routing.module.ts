import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { MasterPageComponent } from './master-page/master-page.component';
import { MastersComponent } from './masters/masters.component';
import { DepartmentComponent } from './masters/department/department.component';
import { InsurerComponent } from './masters/insurer/insurer.component';
import { ZoneComponent } from './masters/zone/zone.component';
import { DivisionComponent } from './masters/division/division.component';
import { BranchComponent } from './masters/branch/branch.component';
import { OrganizationComponent } from './masters/organization/organization.component';
import { DesignationComponent } from './masters/designation/designation.component';
import { GradeComponent } from './masters/grade/grade.component';
const routes: Routes = [   
  {
    path: 'registration',
    component: RegistrationComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {	
    path: 'master-page',
    component: MasterPageComponent
  },
  {	
    path: 'masters',
    component: MastersComponent
  },
  // {	
  //   path: 'masters/department',
  //   component: DepartmentComponent
  // },
  {	
    path: 'masters/organization',
    component: OrganizationComponent
  },
  {	
    path: 'masters/designation',
    component: DesignationComponent
  },
  {	
    path: 'masters/grade',
    component: GradeComponent
  },
  // {	
  //   path: 'masters/insurer',
  //   component: InsurerComponent
  // },
  {	
    path: 'masters/zone',
    component: ZoneComponent
  },
  {	
    path: 'masters/division',
    component: DivisionComponent
  },
  {	
    path: 'masters/branch',
    component: BranchComponent
  },
   {	
    path: 'masters',
    // component: MastersComponent, 
      children: [                         //<---- child components declared here
          {
              path:'department',
              component: DepartmentComponent
          },
          {
            path:'insurer',
            component: InsurerComponent
        }
        ]
    },
  {	
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


 }
