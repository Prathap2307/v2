export interface Employee {
    ID: number;
    Name: string;
    Gender: string;
    StateName: string;
    DeptId: number;
}