export interface Hero {
 /*  id: number;
  description: string;
  isActive: boolean; */
  
   userId: number;
   id: number;
  title: string;
  body: string;
  
  
  //   name: string;
  // position: number;
  // weight: number;
  // symbol: string;
}
