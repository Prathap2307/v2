import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-master',
  templateUrl: './login-master.component.html',
  styleUrls: ['./login-master.component.css']
})
export class LoginMasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
