import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  LoginForm = new FormGroup({

    FirstName: new FormControl("", [Validators.required]),
    UserPassword: new FormControl("", [Validators.required])


  });

  onSubmit(){
    if(this.LoginForm.valid){
      let userCredential = this.LoginForm.value;
     // this.router.navigateByUrl('/master');
      this.router.navigate(['/masters/department']);
      console.log(userCredential);
    }
  }


}
