import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-insurer',
  templateUrl: './insurer.component.html',
  styleUrls: ['./insurer.component.css']
})
export class InsurerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  InsurerForm = new FormGroup({

    // Description: new FormControl('', [Validators.required]),
    MobileNumber: new FormControl('', [Validators.required, Validators.minLength(10), Validators.pattern('^[0-9]*$')]),
    PANNumber: new FormControl('', [Validators.required, Validators.minLength(10) , Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$') ])
    // , Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')
  });



  onSubmit() {

  }

  allowNumberFn(event) {
    const keyCode = event.keyCode;
    //console.log(keyCode);
    const excludedKeys = [8, 37, 39, 46];

    if (!((keyCode >= 48 && keyCode <= 57) ||
      (keyCode >= 96 && keyCode <= 105) ||
      (excludedKeys.includes(keyCode)))) {

      event.preventDefault();
    }
  }
  // fnPANNumber(e: any){
  //   //regex= 
    
  //  let iv = e.target.value;

  //  let regex = "^[A-Za-z]{5}[0-9]{4}[A-Za-z]$";

  //   if ( iv.match(regex) ) {
  //     // There was a match.
  //     console.log("hi");
  //   } else {
  //     // No match.
  //    // return false;
  //    console.log("false");
  //   } 
  // }

  // fnPANNumber(e: any) {

  //   var Key;
  //   var a = e.target.value;
  //   console.log(a);
  //   // if (window.event) {
  //   //     Key = window.event.keyCode; //IE 
  //   // }
  //   // else if (e.which) {
  //   //     Key = e.which; //firefox
  //   // }
  //   // else {
  //   //     Key = e.charCode; //Other browser
  //   // }
  //   if (e.which) {
  //     Key = e.which; //firefox
  //   }
  //   else {
  //     Key = e.charCode; //Other browser
  //   }

  //   if (!(Key == 8 || Key == 27 || Key == 0)) {
  //     var Ch = String.fromCharCode(Key)

  //     var l = 0;
  //     a = a + Ch;
  //     l = a.length;
  //     if (l > 0) {
  //       if (l <= 5) {
  //         eval("var regex1 = /^[A-Za-z]{" + l + "}?$/");
  //         if (regex3.test(a) == false) {
  //           return false;
  //         }
  //       }
  //       else if (l <= 9) {
  //         l = l - 5;
  //         eval("var regex2 = /^[A-Za-z]{5}\\d{" + l + "}?$/");
  //         if (regex3.test(a) == false) {
  //           return false;
  //         }
  //       }
  //       else {
  //         var regex3 = /^[A-Za-z]{5}\d{4}[A-Za-z]{1}$/;
  //         if (regex3.test(a) == false) {
  //           return false;
  //         }
  //       }
  //     }
  //     else {
  //       return true;
  //     }
  //   }
  //   else {
  //     return true;
  //   }
  // }


}
