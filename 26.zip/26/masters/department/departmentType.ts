export interface DepartmentType {
    Description: string;
    ShortName: string;
}