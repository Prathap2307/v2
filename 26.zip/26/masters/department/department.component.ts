import { Component, OnInit } from '@angular/core';
import { DepartmentType } from './departmentType';

import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DepartmentService } from './department.service';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})



export class DepartmentComponent implements OnInit {

  departmentObj: DepartmentType[];

  departmentColumns: string[] = ['qwerty', 'Description', 'ShortName'];


  constructor( private departmentService: DepartmentService) { }

  DepartmentForm = new FormGroup({

    Description: new FormControl('', [Validators.required]),
    ShortName: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$') ])

  });

  ngOnInit() {
    this. getDepartmentDetails();
  }

  onBtnSaveClick(){
    if(this.DepartmentForm.valid){
       // console.log("valid");
       // console.log(this.DepartmentForm.);
       // console.log(this.DepartmentForm.controls["ShortName"].value);
      
    }
  }
  onBtnResetClick(){
    this.DepartmentForm.reset();
  }

  getDepartmentDetails(): void {
    // console.log("hi");
     this.departmentService.getDepartmentDetails()
       .subscribe(departmentObj => this.departmentObj = departmentObj);
      //console.log(this.EmployeeObj);
   }

  
}
