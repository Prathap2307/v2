import { Injectable } from '@angular/core';
import { environment } from './../../../environments/environment';
import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';

import { DepartmentType } from './departmentType';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {
  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }


  departmentUrl = this.baseUrl + '/api/department';

  /* GET Department */
getDepartmentDetails (): Observable<DepartmentType[]> {
   
    return this.http.get<DepartmentType[]>(this.departmentUrl)
      .pipe();
} 
}
