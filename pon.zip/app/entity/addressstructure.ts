export class AddressStructure{
    description: string;
}