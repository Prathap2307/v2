export class Grade {
	description: string;
}	