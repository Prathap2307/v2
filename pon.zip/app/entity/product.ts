export class Product {
	product: string;
    productName: string;
    code: string;
    category: string;
}	