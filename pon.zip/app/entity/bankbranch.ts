export class BankBranch{
    bankName: number;
    bankCity: number;
    bankAddress: string;
    ifscCode: string;
    micrCode: string;
}