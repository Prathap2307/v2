export class MainChannel {
	mainChannelName: string;
	mainChannelCode: string;
}	

