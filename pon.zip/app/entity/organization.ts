export class Organization {
    organization: string;
    shortName: string;
	addressOne: number;
	addressTwo: number;
	addressThree: number;
	zipCode: number;
	country: string;
	state: string;
	district: string;
	postOffice: string;
	phoneNumber: number;
	mobileNumber: number;
	faxNumber: number;
	conferenceNumber: number;
	panNumber: number;
	emailId: string;
	gstIn: number;
	sacCode: number;
}