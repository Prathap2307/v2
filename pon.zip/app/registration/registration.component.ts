import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Register } from './registration';
import { RegistrationService } from './registration.service';
import { Hero } from './hero';
import { Employee } from './employee';
import { UsersType } from './usersType';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
  providers: [ RegistrationService ]
})
export class RegistrationComponent implements OnInit {

  constructor(private RegistrationService: RegistrationService) { }

  userObj: UsersType[] = [];
  EmployeeObj: Employee[];
  //publicDeals: Deal[] = [];
  // getHeroes(): void {
  //   this.RegistrationService.getHeroes()
  //     .subscribe(heroes => this.heroes = heroes);
     
  // }


  ngOnInit() {
    this.getEmployeeDetails();
  }


  // phoneNumber = "^(\+\d{1,3}[- ]?)?\d{10}$";

  RegisterForm = new FormGroup({

    FirstName: new FormControl("", [Validators.required]),
    MobileNumber: new FormControl(""),
    EmailID: new FormControl(""),
    UserPassword: new FormControl("", [Validators.required])

  });
 
  onSubmit(){
    //console.log(this.RegisterForm.value);

      // stop here if form is invalid
      if (!this.RegisterForm.invalid) {
            let user = this.RegisterForm.value;
           // console.log(user);
            this.RegistrationService
            .addNewUser(user)
            .subscribe(user => this.userObj.push(user));
        }

      //  console.log(this.RegisterForm.value)
  }

  
  getEmployeeDetails(): void {
   // console.log("hi");
    this.RegistrationService.getEmployeeDetails()
      .subscribe(EmployeeObj => this.EmployeeObj = EmployeeObj);
     //console.log(this.EmployeeObj);
  }

  consoleLogFn(val){
    console.log(val);
  }

}



  // "outputPath": "dist/LIC",
  // "outputPath": "../firstProject/firstProject/Bundles",