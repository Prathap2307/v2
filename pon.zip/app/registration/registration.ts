export interface Register{
  name: string;
  gender: number;
	dob: number;
	mobileNumber: number;
  email: string;
  city: string;
  password: string;
  confirmPassword: string;
	
}
