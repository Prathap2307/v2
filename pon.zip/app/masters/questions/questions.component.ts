import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {

  questionFormgroup: FormGroup;
  constructor(
    private fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.QuestiojnFormData();
  }
  QuestiojnFormData() {    
    this.questionFormgroup = this.fb.group({
      description: ['',[Validators.required]],
      shortdescription: ['',[Validators.required]],
    })
  }

  public hasError = (controlName: string, errorName:string)=>{
    return this.questionFormgroup.controls[controlName].hasError(errorName);
  }

  clearQuestion(){
    this.questionFormgroup.reset();
  }
}
