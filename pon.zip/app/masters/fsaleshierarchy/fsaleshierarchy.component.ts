import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fsaleshierarchy',
  templateUrl: './fsaleshierarchy.component.html',
  styleUrls: ['./fsaleshierarchy.component.css']
})
export class FsaleshierarchyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
