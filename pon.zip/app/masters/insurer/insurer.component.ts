import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { InsurerService } from './../../shared-service/insurer.service';
import { Insurer } from './../../entity/insurer';

@Component({
  selector: 'app-insurer',
  templateUrl: './insurer.component.html',
  styleUrls: ['./insurer.component.css']
})
export class InsurerComponent implements OnInit {

  constructor( private insurerService: InsurerService , private fb: FormBuilder) { }
  InsurerForm: FormGroup;
  ngOnInit() {
     this.InsurerForm = this.fb.group({

          zipCode: [''],
          mobileNumber: ['', [ Validators.required, Validators.minLength(10), Validators.pattern('^[0-9]*$') ]],
          panNumber: ['',[ Validators.required, Validators.minLength(10) , Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$') ] ]

    });
    
  }

  addressObj: Insurer[];
  getAddressDetails(e) {
// zipcode = 625203;
    console.log(e.target.value);
    this.insurerService.getAddressByIDzipCode(e.target.value)
      .subscribe(addressObj => {
        this.addressObj = addressObj;
      
      });

  }



  getErrorMessage() {
    // return this.email.hasError('required') ? 'You must enter a value' :
    //     this.email.hasError('email') ? 'Not a valid email' :
    //         '';
            if(this.InsurerForm.controls['panNumber'].hasError('required')){
              return 'PAN Number is required';
            }else if(this.InsurerForm.controls['panNumber'].hasError('pattern')){
              return 'Please enter valid PAN Number';
            }else if(this.InsurerForm.controls['panNumber'].hasError('minlength')){
              return '10 digits required';
            }

            
  }

  onSubmit() {

  }

  allowNumberFn(event) {
    const keyCode = event.keyCode;
    //console.log(keyCode);
    const excludedKeys = [8, 37, 39, 46];

    if (!((keyCode >= 48 && keyCode <= 57) ||
      (keyCode >= 96 && keyCode <= 105) ||
      (excludedKeys.includes(keyCode)))) {

      event.preventDefault();
    }
  }
  // fnPANNumber(e: any){
  //   //regex= 
    
  //  let iv = e.target.value;

  //  let regex = "^[A-Za-z]{5}[0-9]{4}[A-Za-z]$";

  //   if ( iv.match(regex) ) {
  //     // There was a match.
  //     console.log("hi");
  //   } else {
  //     // No match.
  //    // return false;
  //    console.log("false");
  //   } 
  // }

  // fnPANNumber(e: any) {

  //   var Key;
  //   var a = e.target.value;
  //   console.log(a);
  //   // if (window.event) {
  //   //     Key = window.event.keyCode; //IE 
  //   // }
  //   // else if (e.which) {
  //   //     Key = e.which; //firefox
  //   // }
  //   // else {
  //   //     Key = e.charCode; //Other browser
  //   // }
  //   if (e.which) {
  //     Key = e.which; //firefox
  //   }
  //   else {
  //     Key = e.charCode; //Other browser
  //   }

  //   if (!(Key == 8 || Key == 27 || Key == 0)) {
  //     var Ch = String.fromCharCode(Key)

  //     var l = 0;
  //     a = a + Ch;
  //     l = a.length;
  //     if (l > 0) {
  //       if (l <= 5) {
  //         eval("var regex1 = /^[A-Za-z]{" + l + "}?$/");
  //         if (regex3.test(a) == false) {
  //           return false;
  //         }
  //       }
  //       else if (l <= 9) {
  //         l = l - 5;
  //         eval("var regex2 = /^[A-Za-z]{5}\\d{" + l + "}?$/");
  //         if (regex3.test(a) == false) {
  //           return false;
  //         }
  //       }
  //       else {
  //         var regex3 = /^[A-Za-z]{5}\d{4}[A-Za-z]{1}$/;
  //         if (regex3.test(a) == false) {
  //           return false;
  //         }
  //       }
  //     }
  //     else {
  //       return true;
  //     }
  //   }
  //   else {
  //     return true;
  //   }
  // }
  consoleLogFn(val) {
    console.log(val);
  }

}
