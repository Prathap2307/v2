import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-addressstructure',
  templateUrl: './addressstructure.component.html',
  styleUrls: ['./addressstructure.component.css']
})
export class AddressstructureComponent implements OnInit {
  submitted = false;
  AddressStructureFrom: FormGroup;
  constructor(
    private fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.AddressStructureFrom = this.fb.group({
      description:
        [
          '',
          [Validators.required],
          [Validators.minLength(25)],
        ]
    })
  }

  onBtnSaveAddressStructureClick() {
    this.submitted = true;    
    this.AddressStructureFrom.markAllAsTouched();
    if (this.AddressStructureFrom.valid) {
      let val = this.AddressStructureFrom.value;
    }
  }
  onBtnClearAddressStructureClick() {
    this.AddressStructureFrom.reset();
  }
}
