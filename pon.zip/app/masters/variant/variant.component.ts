import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-variant',
  templateUrl: './variant.component.html',
  styleUrls: ['./variant.component.css']
})
export class VariantComponent implements OnInit {
  //typesOfBrands: string[] = [ 'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea' ,'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea' ,'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea'];
  
  constructor() { 
    
  }

  ngOnInit() {
  }

}
