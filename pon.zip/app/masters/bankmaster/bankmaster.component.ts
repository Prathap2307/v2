import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-bankmaster',
  templateUrl: './bankmaster.component.html',
  styleUrls: ['./bankmaster.component.css']
})
export class BankmasterComponent implements OnInit {

  submitted = false;
  bankmasterForm: any =  new FormGroup({});
  bankmasterFormAction: any =  new FormGroup({});
  // Button Variabke
  btnSaveBank: string = "";
  btnClearBank: string = "";

  constructor(
    private fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.BankmasterData();  
    this.btnSaveBank = 'Save';    
  }
  BankmasterData() {
    this.bankmasterForm = this.fb.group({
      searchDescription:[],
      bankmasterFormAction:this.fb.group({
        description:
        ['',
          [Validators.required,
          Validators.minLength(5),
          Validators.maxLength(25),
          Validators.pattern('^[a-zA-Z \-\']+')
          ]
        ],
      shortDescription:
        ['',
          [Validators.required,
          Validators.minLength(5),
          Validators.maxLength(25),
          Validators.pattern('^[a-zA-Z \-\']+')
          ]
        ]
      })      
    });
  }    
  OnBtnSaveBankMasterClick(){
    this.submitted = true;       
    this.bankmasterForm.controls.bankmasterFormAction.markAllAsTouched();   
    if (this.bankmasterForm.controls.bankmasterFormAction.valid) {
      let val = this.bankmasterForm.controls.bankmasterFormAction.value;      
    }
  }
  onBtnClearBankMasterClick() {
    this.bankmasterForm.controls.bankmasterFormAction.reset();    
  }
  onBtnSearchClearBankMasterClick(){
    this.bankmasterForm.reset();
  }

}
