import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-bankbranch',
  templateUrl: './bankbranch.component.html',
  styleUrls: ['./bankbranch.component.css']
})
export class BankbranchComponent implements OnInit {
  submitted = false; 
  BankBranchForm: FormGroup;
  BankBranchAction: FormGroup;
  
  bankName: any = ['IND', 'PNB', 'HDFC']
  bankCity: any = ['Koramangala', 'Indiranagar', 'Madiwala']
  constructor(
    private fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.BankBranchForm = this.fb.group({
      searchbankName: [],
      searchbankCity: [],
      searchbankAddress: [],
      searchifscCode: [],
      searchmicrCode: [],
      BankBranchAction: this.fb.group({
        bankName:
          ['',
            [Validators.required]
          ],
        bankCity:
          [
            '',
            [Validators.required]
          ],
        bankAddress:
          [
            '',
            [Validators.required]
          ],
        ifscCode:
          [
            '',
            [Validators.required]
          ],
        micrCode:
          [
            '',
            [Validators.required]
          ]
      })
    });
  }

  onBtnSaveBankBranchClick() {   
    this.submitted = true;       
    this.BankBranchForm.controls.BankBranchAction.markAllAsTouched();   
    if (this.BankBranchForm.controls.BankBranchAction.valid) {
      let val = this.BankBranchForm.controls.gradeFormAction.value;      
    }     
  }
  onBtnClearBankBranchClick() {
    this.BankBranchForm.controls.BankBranchAction.reset();    
  }
  onBtnSearchClearBankBranch(){
    this.BankBranchForm.reset();
  }
}
