import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorisedsignatory',
  templateUrl: './authorisedsignatory.component.html',
  styleUrls: ['./authorisedsignatory.component.css']
})
export class AuthorisedsignatoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
