import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Designation } from './../../entity/designation';
import { DesignationService } from './../../shared-service/designation.service';
import { TooltipPosition } from '@angular/material/tooltip';

import { DepartmentService } from './../../shared-service/department.service';
import { DepartmentType } from './../../entity/departmentType';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.css']
})
export class DesignationComponent implements OnInit {

  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

  submitted = false;
  designationForm: FormGroup;
  designationFormAction: FormGroup;
  
  departmentObj: DepartmentType[];

  constructor(private fb:FormBuilder, private designationService: DesignationService, private departmentService: DepartmentService ) { }

  designationObj: Designation[] = [];
  designationFilteredObj: Designation[] = [];
  designationColumns: string[] = ['View', 'Edit', 'Delete', 'departmentName', 'designationName'];

  ngOnInit() {

    this.getDesignationDetails();
    this.getDepartmentDetails();
    this.designationForm = this.fb.group({
      searchdepartmentName:[],
      searchdesignationName:[],
      designationFormAction: this.fb.group({
        designationId: [''],
        id:
        [
          '',
          [Validators.required]
        ],
        designationName:
        [
          '',
          [Validators.required]
        ]
      }) 
    })
  }
  onBtnSaveDesignation(){
    this.designationForm.controls.designationFormAction.markAllAsTouched();   
    if (this.designationForm.controls.designationFormAction.valid) {
     
      let a = this.designationForm.controls.designationFormAction.value;      
      console.log(this.designationForm.controls.designationFormAction.value);
      this.designationService.addDesignation(a)
      .subscribe(result => {this.getDesignationDetails()});
    }
  }  
  onBtnSearchClearDesignation(){        
    this.designationForm.reset();
  }
  onBtnClearDesignation(){    
    this.designationForm.controls.designationFormAction.reset();
  }
  getDesignationDetails(): void {

    this.designationService.getDesignationDetails()
      .subscribe(designationObj => {
        this.designationObj = designationObj;
      
      });

  }

  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => {
        this.departmentObj = departmentObj;
      
      });

  }

  btngvDelete_Click(a){
    this.designationService.deleteDesignation(a).subscribe(result => {this.getDesignationDetails()});
  }

  btngvView_Click(a) {

   
    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({

      designationFormAction: this.fb.group({
        designationId: { value: this.designationFilteredObj[0].designationId, disabled: true },
        id: { value: this.designationFilteredObj[0].id, disabled: true },
        designationName: { value: this.designationFilteredObj[0].designationName, disabled: true }

      })
    });
   
  }

  btngvEdit_Click(a) {

   
    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({

      designationFormAction: this.fb.group({
        designationId: { value: this.designationFilteredObj[0].designationId, disabled: false },
        id: { value: this.designationFilteredObj[0].id, disabled: false },
        designationName: { value: this.designationFilteredObj[0].designationName, disabled: false }

      })
    });
   
  }
  
  consoleLogFn(val) {
    console.log(val);
  }
}
