import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coverages',
  templateUrl: './coverages.component.html',
  styleUrls: ['./coverages.component.css']
})
export class CoveragesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
