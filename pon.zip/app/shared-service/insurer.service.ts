import { Injectable } from '@angular/core';
import { environment } from './../../environments/environment';
import { Observable } from 'rxjs';

import { HttpClient, HttpResponse } from '@angular/common/http';

import { Insurer } from './../entity/insurer';
import { tap, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class InsurerService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addressUrl = this.baseUrl + '/address';

   /* GET Address by ZIPCODE */
   getAddressByIDzipCode(zipCode: string): Observable<Insurer[]> {

    const departmentByIDUrl = this.baseUrl + `/address/${zipCode}`;

    // return this.http.get<Hero>(url).pipe(
    //   tap(_ => this.log(`fetched hero id=${id}`)),
    //   catchError(this.handleError<Hero>(`getHero id=${id}`))
    // );

    console.log(departmentByIDUrl);
    return this.http.get<Insurer[]>(departmentByIDUrl)
      .pipe();
  }
}
