package com.example.ProjectOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
