export interface departmentType {
    Description: string;
    ShortName: string;
}