import { Component, OnInit } from '@angular/core';
import { departmentType } from './departmentType';

import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})



export class DepartmentComponent implements OnInit {

  department: departmentType[];

  departmentColumns: string[] = ['qwerty', 'Description', 'ShortName'];


  constructor() { }

  DepartmentForm = new FormGroup({

    Description: new FormControl('', [Validators.required]),
    ShortName: new FormControl('', [Validators.required])

  });

  ngOnInit() {
    
  }

  onBtnSaveClick(){
    if(this.DepartmentForm.valid){
       // console.log("valid");
       // console.log(this.DepartmentForm.);
       // console.log(this.DepartmentForm.controls["ShortName"].value);
      
    }
  }
  onBtnResetClick(){
    this.DepartmentForm.reset();
  }
}
