import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Register } from './registration';
import { Hero } from './hero';
import { catchError } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import { environment } from './../../environments/environment';
import { Employee } from './employee';
import { UsersType } from './usersType';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json; charset=utf-8',
    // 'Authorization': 'my-auth-token'
  })
};


@Injectable({
  providedIn: 'root'
})

export class RegistrationService {
  baseUrl = environment.API_URL;
  //private heroesUrl = 'https://jsonplaceholder.typicode.com/posts'; 
  //private heroesUrl = 'http://localhost:4200/user/first'; 
  constructor( private http: HttpClient) {}

   /** GET heroes from the server */
  // getHeroes (): Observable<Hero[]> {

	// 	return this.http.get<Hero[]>(this.heroesUrl)
	// 		.pipe();
  // } 
  

  NewUserUrl = this.baseUrl + '/api/default1';  // URL to web api


  
/** POST: add a new hero to the database */
addNewUser (newuser: UsersType): Observable<UsersType> {
  console.log(newuser);
  return this.http.post<UsersType>(this.NewUserUrl, newuser)
    .pipe(
      //catchError(this.handleError('addHero', hero))
    );
}

// addHero (user: Register): Observable<Hero> {
//   return this.http.post<Hero>(this.heroesUrl, user)
//     .pipe(
//       //catchError(this.handleError('addHero', user))
//     );
// }
  // handleError(arg0: string, user: Register): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput<any> {
  //   throw new Error("Method not implemented.");
  // }
 

  employeeUrl = this.baseUrl + '/api/default1';

    /** GET heroes from the server */
  getEmployeeDetails (): Observable<Employee[]> {
     
		  return this.http.get<Employee[]>(this.employeeUrl)
		  	.pipe();
  } 





}
