import { Component, OnInit } from '@angular/core';
import { DepartmentType } from './departmentType';

import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DepartmentService } from './department.service';

import {TooltipPosition} from '@angular/material/tooltip';



@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})

export class DepartmentComponent implements OnInit {

 //departmentObj: DepartmentType[];

tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

departmentObj: DepartmentType[] = [
  {  Description: 'Accounts Taxation', ShortName: '004'},
  {  Description: 'BSG IT', ShortName: '003'},
  {  Description: 'Head Office', ShortName: '001'},
  {  Description: 'Operations Team', ShortName: '	002'},
  {  Description: 'Technical', ShortName: '004'}
];

departmentFilteredObj : DepartmentType[] = this.departmentObj;

  departmentColumns: string[] = [  'View', 'Edit', 'Delete','Description', 'ShortName'];


  constructor( private departmentService: DepartmentService) { }

  DepartmentForm = new FormGroup({

    Description: new FormControl('', [Validators.required]),
    ShortName: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$') ])

  });

  ngOnInit() {
    this. getDepartmentDetails();
  }

  onBtnSaveClick(){
    if(this.DepartmentForm.valid){
       // console.log("valid");
       // console.log(this.DepartmentForm.);
       console.log(this.DepartmentForm.controls["ShortName"].value);
      
    }
  }
  onBtnResetClick(){
    this.DepartmentForm.reset();
  }

  getDepartmentDetails(): void {
   
    //  this.departmentService.getDepartmentDetails()
    //    .subscribe(departmentObj => this.departmentObj = departmentObj);
      //console.log(this.EmployeeObj);
   }

   btngvView_Click(id){
    console.log("hi");
     this.departmentFilteredObj = this.departmentObj.filter( (unit) => unit.Description.indexOf(id) > -1 );
    
     console.log(this.departmentFilteredObj.filter( (unit) => unit.Description.indexOf(id) > -1 ));
   }

   consoleLogFn(val){
    console.log(val);
   }

  
}
