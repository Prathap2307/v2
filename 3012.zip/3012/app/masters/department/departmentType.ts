export interface DepartmentType {
    // DepartmentID: number;
    Description: string;
    ShortName: string;
}