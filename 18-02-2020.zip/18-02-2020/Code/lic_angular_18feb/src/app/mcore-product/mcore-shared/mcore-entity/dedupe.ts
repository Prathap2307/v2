export class Dedupe {
    dedupe: string;
    moduleName: string;
    fields: string;
	criteria: string;
	condition: string;
	priorityAssignment: string;
	
}