import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BankBranch } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';

@Injectable({
  providedIn: 'root'
})
export class BankbranchService {

  baseUrl = environment.API_URL;
  bankbranchUrl = this.baseUrl + '/bank';

  constructor(
    private http: HttpClient,
  ) { }

  // Get all Bank Branch
  getBankBranch() {
    return this.http.get(`${this.baseUrl}`);
  }
  
  // Error handling 
  errorMgmt(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
