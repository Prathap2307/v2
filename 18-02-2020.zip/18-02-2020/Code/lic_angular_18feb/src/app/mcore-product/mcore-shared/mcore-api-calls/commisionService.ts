import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';
@Injectable({
  providedIn: 'root'
})
export class CommissionService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }


  GetAllMainChannel(): Observable<any> {

    return this.http.get(this.baseUrl + '/GetAllMainChannel').pipe(tap((response) => response));
  }

  GetAllmainchannel(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllmainchannel' + data).pipe(tap((response) => response));
  }

  GetAllCommissionDetail(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetCommissionDetails').pipe(tap((response) => response));
  }

  IsCommissionDetailExist(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/IsCommssionDetailExists', data).pipe(tap((response) => response));
  }

  GetSubChannelByChannelID(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllSubChannelByChannelID?MainChannelID=' + id).pipe(tap((response) => response));
  }

  GetCommissionDetailByID(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetCommissionDetailsById?CommissionID=' + id).pipe(tap((response) => response));
  }

  InsertOrUpdatecommission(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/InsertOrUpdateCommision', data).pipe(tap((response) => response));
  }

  searchcommision(data) {
    return this.http.post(this.baseUrl + '/getGetCommissionWithSearch ', data).pipe(tap((response) => response));
  }
  DeleteCommision(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/DeleteCommission?CommissionID=' + id + '&DeletedBy=1').pipe(tap((response) => response));
  }

  GetCommissionSearch(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetCommissionSearch' + id).pipe(tap((response) => response));
  }
  GetAllSalesHierarchy(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllSalesHierarchy' ).pipe(tap((response) => response));
  }




}