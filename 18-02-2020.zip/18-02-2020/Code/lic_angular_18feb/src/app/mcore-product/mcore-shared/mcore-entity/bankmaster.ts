export class BankMaster{
    description: string;
    shortDescription: string;
}