import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class DesignationService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

  designationUrl = this.baseUrl + '/designation';

   /* GET Designation */
   getDesignationDetails(): Observable<Designation[]> {
    return this.http.get<Designation[]>(this.designationUrl)
      .pipe();
  }

  add(a: any): Observable<any> {
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    // console.log(departmentRow);
    return this.http.post<any>(this.baseUrl+ ' /', a, { headers: headers });
  }
}
