export interface Designation {
	departmentName: string;
    designationName: string;
}	