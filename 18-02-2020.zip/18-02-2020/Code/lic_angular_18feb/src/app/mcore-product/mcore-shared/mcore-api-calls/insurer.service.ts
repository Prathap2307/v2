import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Insurer } from 'src/app/mcore-product/mcore-shared/mcore-entity/insurer';
import { tap, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class InsurerService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addressUrl = this.baseUrl + '/address';

   /* GET Address by ZIPCODE */
   getAddressByIDzipCode(zipCode: string): Observable<Insurer[]> {

    const departmentByIDUrl = this.baseUrl + `/address/${zipCode}`;

    // return this.http.get<Hero>(url).pipe(
    //   tap(_ => this.log(`fetched hero id=${id}`)),
    //   catchError(this.handleError<Hero>(`getHero id=${id}`))
    // );

    console.log(departmentByIDUrl);
    return this.http.get<Insurer[]>(departmentByIDUrl)
      .pipe();
  }
  
    /* GET Address by ZIPCODE */
    getDepartmentInfoByDescription(zipCode: number): Observable<Insurer[]> {

      const departmentByIDUrl = this.baseUrl + `/address/${zipCode}`;
  
      // return this.http.get<Hero>(url).pipe(
      //   tap(_ => this.log(`fetched hero id=${id}`)),
      //   catchError(this.handleError<Hero>(`getHero id=${id}`))
      // );
  
      console.log(departmentByIDUrl);
      return this.http.get<Insurer[]>(departmentByIDUrl)
        .pipe();
    }
}
