export class PolicyAccountantStatement {
	clientName: string;
	masterPolicyNumber: string;	
	agreementNumber: number;
	fromDate: Date;
	toDate: Date;
}