export interface Insurer {
    insurerName: string;
    schemeCategory: string;
    shortName: string;
	dateOfCommencement: string;
	geographicalPresence: string;
	addressOne: number;
	addressTwo: number;
	addressThree: number;
	zipCode: string;
	country: string;
	state: string;
	district: string;
	postOffice: string;
	emailId: string;
	phoneNumber: number;
	mobileNumber: number;
	conferenceNumber: number;
	faxNumber: number;
	triggerLimitforStampDuty: string;
	intimationEmailAddressStampDuty: string;
	intimationMobileNumberStampDuty: string;
	panNumber: string;
	gstNumebr: string;
	logo: string;
	description: string;
	
}