export class User {
	userType: string;
	firstName: string;
	lastName: string;
	userName: string;
	reportingTo: string;
	initial: string;
	gender: string;
	branch: string;
	department: string;
	designation: string;
	grade: string;
	branchToAttached: string;
	mobileNumber: number;
	conferenceNumber: number;
	employeeNumber: number;
	emailId: string;
	isUnderWriter: string;
	employeePhoto: string;
	isAdminUser: string;
	password: string;
	confirmPassword: string;	
}	

