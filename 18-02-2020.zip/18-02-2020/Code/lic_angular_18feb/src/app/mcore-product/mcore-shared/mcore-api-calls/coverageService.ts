import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';
@Injectable({
    providedIn: 'root'
  })
  export class CoverageService {
  
    baseUrl = environment.API_URL;
    constructor(private http: HttpClient) { }
    

      IsCoverageExistNew(data:any): Observable<any>{
        return this.http.post(this.baseUrl + '/IsCoverageExistNew', data).pipe(tap((response) => response));
      }
  
      GetAllCoveragesByLineOfBusiness(name:any): Observable<any>{
        return this.http.get(this.baseUrl + '/GetAllCoveragesByLineOfBusiness' + name).pipe(tap((response) => response));
      }

      GetCoverageExclusionByCoverageID(id:any): Observable<any>{
        return this.http.get(this.baseUrl + '/GetCoverageExclusionByCoverageID' + id).pipe(tap((response) => response));
      }

      GetAllCoverageUINMapByCoverageID(id:any): Observable<any>{
        return this.http.get(this.baseUrl + '/GetAllCoverageUINMapByCoverageID' + id).pipe(tap((response) => response));
      }

      InsertOrUpdateCoverageNew(data:any): Observable<any>{
        console.log("data cove >>",data);
        return this.http.post(this.baseUrl + '/InsertOrUpdateCoverage' , data).pipe(tap((response) => response));
      }

      InsertOrUpdateCoverageUINMap(data:any): Observable<any>{
        console.log("data uin >>",data);
        return this.http.get(this.baseUrl + '/InsertOrUpdateCoverageUINMap' + data).pipe(tap((response) => response));
      }

      DeleteCoverage(id:any): Observable<any>{
        return this.http.get(this.baseUrl + '/DeleteCoverage' + id).pipe(tap((response) => response));
      }
  
     

     
      
    //   GetLineofBusinessMapByUserID
    //   GetAllProviderType
    //   GetNatureOfServiceByCoverageID

  
      
      
      
  }