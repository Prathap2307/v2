import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoreRoutingModule } from './core-routing.module';
import { ValidationComponent } from './master-page/validation/validation.component';



@NgModule({
  declarations: [  ValidationComponent, ],
  imports: [
    CommonModule,
    CoreRoutingModule
  ],
  exports:[
     ValidationComponent,
]
})
export class CoreModule { }
