import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-variant',
  templateUrl: './variant.component.html',
  styleUrls: ['./variant.component.css']
})
export class VariantComponent implements OnInit {
  //typesOfBrands: string[] = [ 'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea' ,'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea' ,'Puma', 'Nike', 'Addidas', 'Fila', 'Nivea'];
  data_i = [{ value: 'I1', viewValue: 'I1' }, { value: 'I2', viewValue: 'I2' }]
  data_v = [{ i: 'I1', v: 'akshay', pt: "PT1", vc: "VC1" }, { i: 'I2', v: 'ashish', pt: "PT2", vc: "VC2" },{ i: 'I2', v: 'sid', pt: "PT2", vc: "VC2" }]
  search: any;
  select: any;
  data_search: any
  data_select: any
  track: any;
  item: boolean = true;
  form:FormGroup
  // @ViewChild('myTable', {static: false}) nameInputRef: ElementRef;
  constructor(private fb: FormBuilder) {

  }

  ngOnInit() {
    this.form = this.fb.group({
      index: [{value: null, disabled:true}],
      v : ['', Validators.required],
    });
  }
  ngAfterViewInit() {

    console.log("afterinit");
    // console.log(this.elref.nativeElement)
    // console.log(this.elref.nativeElement.querySelector('.myTable').innerHTML)

  }
  // textSearch() {

  //   console.log(this.search)
  //   console.log(this.select)
  //   if (!this.search) { this.item = true }
  //   if (this.search) {
  //     let target = this.data_v.filter(
  //       (val)=> val['v'].includes(this.search))
  //     console.log(target)
  //     if (target.length>0)
  //       console.log(target)
  //     else {
  //       console.log("doesn't exists")
  //       this.item = false
  //       console.log(this.item)
  //     }

  //   }

  //   this.data_search = this.search
  //   this.data_select = this.select

  // }

  trackByFn(index, item) {
    // console.log(index)
    return index; // or item.id
  }
  // clear() {
  //   this.search = ''
  //   this.select = ''
  //   this.data_search = ''
  //   this.data_select = ''
  //   this.item = true

  // }
  // userEdit(user, i) {
  //   this.form.setValue({
  //     index: i,
  //     v: user.v
  //   })
  // }


}
