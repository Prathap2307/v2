import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import { MatSlideToggleChange } from '@angular/material/slide-toggle/typings/slide-toggle';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

@Component({
  selector: 'app-division',
  templateUrl: './division.component.html',
  styleUrls: ['./division.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    {provide: MAT_DATE_LOCALE, useValue: 'en-gb'},

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],
})
export class DivisionComponent implements OnInit {
  DivisionForm: FormGroup;
  saveBtnMode: boolean =true;
  DivisionHeading: string;
  textSaveBtn: string;
  divisionFilteredObj: any;
  submitted: boolean;
  Taluka: any[];
  District: any[];
  state: any[];
  country: any[];
  SearchDForm: FormGroup;
  display: string = "none";
  view: boolean = false;
  allDivision: any[];
  config: { itemsPerPage: number; currentPage: number; totalItems: number; };
  id: any;
  transaction: string;
  zone: any;



  constructor(private datePipe: DatePipe, private BranchService: BranchService, private fb: FormBuilder, ) { }

  ngOnInit() {
    this.getallDivision()
    this.Get_zBranch(1)
    this.GetAllcountries()
    this.DivisionHeading = 'Add New - Division';
    this.textSaveBtn = 'Save';
    this.formInit()

this.searchform()
  }

  searchform()
  {
    this.SearchDForm = this.fb.group({
      Description: [''],
      ShortName: [''],
      PageTypeID: ['2']
    })
  }
  get f() { return this.DivisionForm.controls; }
 formInit(){
   
  this.DivisionForm = this.fb.group({
    Description: ['', [Validators.required]],
    WorkingDate: ['', Validators.required],
    ShortName: ['', [Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
    // ParentBranchID: ['5',],
    Address1: ['', Validators.required],
    Address2: ['',],
    Address3: ['',],
    CountryID: ['', Validators.required],
    StateID: ['', Validators.required],
    DistrictID: ['', Validators.required],
    TalukID: ['',],
    ZipCode: ['', [Validators.required,Validators.pattern("[0-9 -()+]+$")]],
    PhoneNo: ['',],
    MobileNo: ['',  [Validators.pattern("[0-9 -()+]+$")]],
    Email: ['', [Validators.required, Validators.pattern("[A-za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-za-z0-9-]+(\.[A-za-z0-9-]+)*")]],
    ZonalID: [''],
    GSTNo: ['Null'],
    PanNo: ['Null'],
    LUTNo: ['Null']

  })
 }
  onBtnSaveClick() {
    this.DivisionForm.value["CreatedBy"] = 1
    this.DivisionForm.value["CreatedOn"] = null
    this.DivisionForm.value["OrganisationID"] = 1
    this.DivisionForm.value["IsActive"] = 1
    this.DivisionForm.value["PageTypeID"] = 2
    this.DivisionForm.value["RegionalID"] = 1
    this.DivisionForm.value["FaxNo"] = null
    if (this.textSaveBtn === 'Update') {
      this.DivisionForm.value["BranchID"] = this.id
    }
    this.submitted = true
    console.log(this.DivisionForm.value)
    if (this.DivisionForm.valid) {
      this.BranchService.add(this.DivisionForm.value)
        .subscribe(result => {
          console.log(result)
          if(result.data==0){
            this.transaction="Created"
          }
          else{
            this.transaction="Updated"
          }
          this.openModalDialog()
        });
    }

  }
  getallDivision() {
    let division = {
      "OrganisationID": 1,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 2
    }
    this.BranchService.GetAllBranches(division)
      .subscribe(result => {
        console.log(result)
        this.allDivision = result.data
        if (this.allDivision) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allDivision.length
          }
        }
      });
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  Search() {
    console.log(this.SearchDForm.value)
    this.BranchService.GetAllBranches(this.SearchDForm.value)
      .subscribe(result => {
        console.log(result)
        this.allDivision = result.data
        if (this.allDivision) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allDivision.length
          }
        }
      });
  }

  btngEdit_Click(a) {
    console.log(a)
    this.DivisionHeading = 'Edit - Division';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update'
    this.view = false
    this.id=a
    this.getBranchById(a)
  }
  activate(a) {
    let activate_d = {
      "OrganisationID": 1,
      "BranchID": a,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "isActive": 1,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 2
    }
    this.BranchService.Activate(activate_d)
    .subscribe(result => {
      console.log(result)
      })
      this.getallDivision() 

  }
  onChange(value, id) {
    console.log(value)
    let activate_d = {
      "OrganisationID": 1,
      "BranchID": id,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 2
    }
    if (value.checked === true) {
      activate_d["isActive"] = 1
      console.log(1);
    } else {
      activate_d["isActive"] = 0
      console.log(0);
    }
  }
  public toggle(event: MatSlideToggleChange, a) {
    console.log(a)
    this.BranchService.get_branchByid(a)
      .subscribe(result => {
        console.log(result)
        this.divisionFilteredObj = result.data

        if (this.divisionFilteredObj) {
          console.log(this.divisionFilteredObj)
          this.divisionFilteredObj["isActive"] = 2
        }
      })



  }
  getBranchById(a) {
    this.BranchService.get_branchByid(a)
      .subscribe(result => {
        console.log(result)
        this.divisionFilteredObj = result.data
        console.log(this.divisionFilteredObj)
        if (this.divisionFilteredObj) {
          this.GetAllStates(this.divisionFilteredObj.countryID)
          this.GetAllDistricts(this.divisionFilteredObj.stateID)
          this.GetTaluk(this.divisionFilteredObj.districtID)
          console.log(this.DivisionForm.value)
          this.DivisionForm = this.fb.group({
            BranchID: [{ value: this.divisionFilteredObj.branchId, disabled: false }],
            Description: [{ value: this.divisionFilteredObj.branchName, disabled: false }, Validators.required],
            WorkingDate: [{ value: this.divisionFilteredObj.workingDate, disabled: false }, Validators.required],
            ShortName: [{ value: this.divisionFilteredObj.shortName, disabled: false },[Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
            Address1: [{ value: this.divisionFilteredObj.address1, disabled: false }, Validators.required],
            Address2: [{ value: this.divisionFilteredObj.address2, disabled: false }],
            Address3: [{ value: this.divisionFilteredObj.address3, disabled: false }],
            CountryID: [{ value: this.divisionFilteredObj.countryID, disabled: false },Validators.required],
            StateID: [{ value: this.divisionFilteredObj.stateID, disabled: false },Validators.required],
            DistrictID: [{ value: this.divisionFilteredObj.districtID, disabled: false },Validators.required],
            TalukID: { value: this.divisionFilteredObj.talukID, disabled: false },
            ZipCode: [{ value: this.divisionFilteredObj.zipCode, disabled: false }, [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
            PhoneNo: [{ value: this.divisionFilteredObj.phoneNo, disabled: false }],
            MobileNo: [{ value: this.divisionFilteredObj.mobileNo, disabled: false }],
            Email: [{ value: this.divisionFilteredObj.email, disabled: false },[Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
            ZonalID: [{ value: this.divisionFilteredObj.zoneID, disabled: false }],
            GSTNo: [{ value: this.divisionFilteredObj.gstNo, disabled: false } ],
            PanNo: [{ value: this.divisionFilteredObj.panNo, disabled: false }],
            LUTNo:[ { value: this.divisionFilteredObj.lutNo, disabled: false }]

            // GSTNo: [{ value: this.divisionFilteredObj.gstNo, disabled: false },[Validators.required, Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
            // PanNo: [{ value: this.divisionFilteredObj.panNo, disabled: false }, Validators.required],
            // LUTNo:[ { value: this.divisionFilteredObj.lutNo, disabled: false },Validators.required]
          })
        }
        // this.GetAllStates(this.divisionFilteredObj.countryId)
        // this.GetAllDistricts(this.divisionFilteredObj.stateID)
        // this.GetTaluk(this.divisionFilteredObj.districtId)


      })
  }
  btngView_Click(a) {
    this.view = true
    this.DivisionHeading = 'View - Division';
    this.saveBtnMode = false;
    this.getBranchById(a)
  }
  Select_country(event: any) {
    console.log(event.target.value)

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)

    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)

    this.GetTaluk(event.target.value);
  }


  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }

  cancel() {
    this.DivisionForm.reset()
    this.formInit()
    console.log(this.submitted)
    this.submitted = false
    this.DivisionHeading = 'Add New - Division';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }

  }
  clearSearch() {
    this.SearchDForm.value["Description"] = " "
    this.SearchDForm.value["ShortName"] = " "
    this.SearchDForm.reset();
 this.searchform()
    this.getallDivision()
  }

  shortnumValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 3) {
        console.log(l)
      }
      else {
        event.preventDefault();
      }
    }
  }
  mobValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  pinValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  allowNumberFn(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      // State code
      if (l <= 1) {
        console.log(l)

        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN alphabets
      else if (l >= 2 && l <= 6) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN numeric
      else if (l > 6 && l <= 10) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      } // PAN alphabet
      else if (l >= 11 && l < 12) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 12 && l < 13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // alphabet
      else if (l >= 13 && l < 14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 14 && l < 15) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 15) {

        event.preventDefault();

      }

    }
  }
  get MobNoError() {
    if (this.DivisionForm.controls['MobileNo'].hasError('required')) {
      return 'Mobile Number is required';
    } else if (this.DivisionForm.controls['MobileNo'].hasError('pattern')) {
      return 'Please enter valid Mobile Number';
    } else if (this.DivisionForm.controls['MobileNo'].hasError('minlength')) {
      return 'Please enter valid 10 digits Mobile Number';
    }
  }
  get ShortNameError() {
    if (this.DivisionForm.controls['ShortName'].hasError('required')) {
      return 'Please enter the Division Code.';
    } else if (this.DivisionForm.controls['ShortName'].hasError('pattern')) {
      return 'Division Code should not be less 4 digits.';
    }
  }
  get EmailError() {
    if (this.DivisionForm.controls['Email'].hasError('required')) {
      return 'Please enter the E-Mail ID.';
    } else if (this.DivisionForm.controls['Email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }


  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    this.DivisionForm.reset()


  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.cancel()
    this.getallDivision()

  }
  Get_zBranch(ZonalID: any) {
    this.BranchService.get_zBranch(ZonalID)
      .subscribe(result => {
        console.log(result)
        this.zone = result.data
      });
  }

}



