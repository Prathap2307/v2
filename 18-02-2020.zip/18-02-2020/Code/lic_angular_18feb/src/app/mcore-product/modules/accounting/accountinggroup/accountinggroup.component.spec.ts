import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountinggroupComponent } from './accountinggroup.component';

describe('AccountinggroupComponent', () => {
  let component: AccountinggroupComponent;
  let fixture: ComponentFixture<AccountinggroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountinggroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountinggroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
