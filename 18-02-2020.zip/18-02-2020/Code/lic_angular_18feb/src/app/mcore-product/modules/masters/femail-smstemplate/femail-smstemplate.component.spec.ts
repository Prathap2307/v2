import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FEmailSMSTemplateComponent } from './femail-smstemplate.component';

describe('FEmailSMSTemplateComponent', () => {
  let component: FEmailSMSTemplateComponent;
  let fixture: ComponentFixture<FEmailSMSTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FEmailSMSTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FEmailSMSTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
