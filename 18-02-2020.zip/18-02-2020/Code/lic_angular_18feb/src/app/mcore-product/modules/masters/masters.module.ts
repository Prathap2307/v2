import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MastersComponent } from './masters.component';
import { InsurerComponent } from './insurer/insurer.component';
import { ZoneComponent } from './zone/zone.component';
import { DivisionComponent } from './division/division.component';
import { BranchComponent } from './branch/branch.component';
import { OrganizationComponent } from './organization/organization.component';
import { DesignationComponent } from './designation/designation.component';
import { GradeComponent } from './grade/grade.component';
import { DepartmentComponent } from './department/department.component';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableModule } from '@angular/material/table';
import { MatRadioModule } from '@angular/material/radio';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MasterPageComponent } from '../../mcore-common/core/master-page/master-page.component';
import {MatIconModule} from '@angular/material/icon';
import { MastersRoutingModule } from './masters-routing.module';
import {MatListModule} from '@angular/material/list';
import { ValidationComponent } from '../../mcore-common/core/master-page/validation/validation.component';
import { ProductComponent } from './product/product.component';
import { VariantComponent } from './variant/variant.component';
import { PremiumComponent } from './premium/premium.component';
import { PremiumpaymentfrequencyComponent } from './premiumpaymentfrequency/premiumpaymentfrequency.component';
import { LoadinganddiscountComponent } from './loadinganddiscount/loadinganddiscount.component';
import { FchannelComponent } from './fchannel/fchannel.component';
import { FsaleshierarchyComponent } from './fsaleshierarchy/fsaleshierarchy.component';
import { UserComponent } from './user/user.component';
import { GroupComponent } from './group/group.component';
import { PrivilegesComponent } from './privileges/privileges.component';
import { LookupComponent } from './lookup/lookup.component';
import { BankmasterComponent } from './bankmaster/bankmaster.component';
import { AddressstructureComponent } from './addressstructure/addressstructure.component';
import { DestinationdocumentuploadComponent } from './destinationdocumentupload/destinationdocumentupload.component';
import { BankbranchComponent } from './bankbranch/bankbranch.component';
import { CoveragesComponent } from './coverages/coverages.component';
import { QuestionsComponent } from './questions/questions.component';
import { TaxstructureComponent } from './taxstructure/taxstructure.component';
import { StampdutyComponent } from './stampduty/stampduty.component';
import { CommissionComponent } from './commission/commission.component';
import { AuthorisedsignatoryComponent } from './authorisedsignatory/authorisedsignatory.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { FilterPipe } from '../../mcore-shared/mcore-pipes/filter.pipe';
import { SearchPipe } from '../../mcore-shared/mcore-pipes/search.pipe';
import { ClientOrganizationComponent } from './client-organization/client-organization.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { FsubChannelComponent } from './fsub-channel/fsub-channel.component';
import { MasterPolicyComponent } from './master-policy/master-policy.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { FEmailSMSTemplateComponent } from './femail-smstemplate/femail-smstemplate.component';
import { AngularEditorModule } from '@kolkov/angular-editor';
// import {  RxReactiveFormsModule } from "@rxweb/reactive-form-validators";
@NgModule({
  declarations: [
    // MastersComponent,
    MasterPageComponent,
    DepartmentComponent,
    InsurerComponent,
    ZoneComponent,
    DivisionComponent,
    BranchComponent,
    OrganizationComponent,
    DesignationComponent,
    GradeComponent,
    ProductComponent,
    VariantComponent,
    PremiumComponent,
    PremiumpaymentfrequencyComponent,
    LoadinganddiscountComponent,
    FchannelComponent,
    FsaleshierarchyComponent,
    UserComponent,
    GroupComponent,
    PrivilegesComponent,
    LookupComponent,
    BankmasterComponent,
    AddressstructureComponent,
    DestinationdocumentuploadComponent,
    BankbranchComponent,
    CoveragesComponent,
    QuestionsComponent,
    TaxstructureComponent,
    StampdutyComponent,
    CommissionComponent,
    AuthorisedsignatoryComponent,
    FilterPipe,
    SearchPipe,
    ClientOrganizationComponent,
    FsubChannelComponent,
    MasterPolicyComponent,
    FEmailSMSTemplateComponent,
  ],
  imports: [
    CommonModule,
    MastersRoutingModule, 
    MatInputModule,
    // RxReactiveFormsModule ,
    MatSelectModule,
    MatDatepickerModule,
    MatSlideToggleModule,
    MatNativeDateModule,
    MatRippleModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatListModule,
    MatTableModule,
    NgxPaginationModule,
    MatIconModule,
    MatRadioModule,
    MatPaginatorModule,
    FormsModule,
    ReactiveFormsModule,
    AngularEditorModule 
  ],
  exports: [
    // MastersComponent,
    InsurerComponent,
    ZoneComponent,
    DivisionComponent,
    BranchComponent,
    OrganizationComponent,
    DesignationComponent,
    GradeComponent,
    MasterPageComponent
  ],
  providers:[DatePipe]   
})
export class MastersModule { }
