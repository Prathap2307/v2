import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { AccountingClassification } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingclassificatin';

import { AccountingClassificationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingclassification.service';

import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-accountingclassification',
  templateUrl: './accountingclassification.component.html',
  styleUrls: ['./accountingclassification.component.css']
})
export class AccountingclassificationComponent implements OnInit {



  createBtn: boolean;

  accountingclassificatinObj: AccountingClassification[] = [];
  acGridObj: AccountingClassification[] = [];
  accountingclassificatinFilterObj: AccountingClassification[] = [];
  saveBtnMode: boolean;
  textSaveBtn: string = '';
  dataSource = new MatTableDataSource<AccountingClassification>(this.acGridObj);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(private fb: FormBuilder, private accountingService: AccountingClassificationService) { }
  AccountingClassificationForm: FormGroup;
  AccountingClassificationSearch: FormGroup;
  // AccountingClassificationAction: FormGroup;
  actionHeading: string = '';

  fieldDisable: Boolean;
  ngOnInit() {
    this.saveBtnMode = true;

    this.textSaveBtn = 'Save';
    this.actionHeading = 'Add New - Accounting Classification Details';
    this.dataSource = new MatTableDataSource<AccountingClassification>(this.acGridObj);
    this.getAccountingClassificationDetails();

    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationSearch: this.fb.group({
        SearchCode: [''],
        Searchdescription: ['']

      }),

      AccountingClassificationAction: this.fb.group({
        accountClassificationID: [''],
        code: ['', [Validators.required]],
        description: ['', [Validators.required]],
        createdBy: ['']

      })
    });


  }







  getACDetailsBySearch() {
    if (this.AccountingClassificationForm.get('AccountingClassificationSearch').valid) {
      // let searchValue = this.AccountingClassificationForm.controls.searchBank.value;
      let a = 0;
      let b = this.AccountingClassificationForm.get('AccountingClassificationSearch.SearchCode').value;
      let c = this.AccountingClassificationForm.get('AccountingClassificationSearch.Searchdescription').value;
      
      if (b == "") {
        b = 0;
      }
      if (c == "") {
        c = 0;
      }

      this.accountingService.getACDetailsBySearch(a, b, c)
        .subscribe(a => {

          this.acGridObj = a;
          this.dataSource = new MatTableDataSource<AccountingClassification>(this.acGridObj);
          this.dataSource.data = this.acGridObj = a;
          this.dataSource.paginator = this.paginator;
        });
    }
  }

  AccountingClassificationtableColumns: string[] = ['View', 'Edit', 'code', 'description'];

  getAccountingClassificationDetails(): void {
    this.accountingService.getAccountingClassificationDetails().subscribe(a => {

      this.accountingclassificatinObj = a;
      this.acGridObj = a;
      this.dataSource = new MatTableDataSource<AccountingClassification>(this.acGridObj);
      this.dataSource.data = this.acGridObj = a;
      this.dataSource.paginator = this.paginator;


    });
  }

  onBtnSaveAccountingClassification() {


    if (this.createBtn) {
      this.AccountingClassificationForm.get('AccountingClassificationAction').patchValue({
        accountClassificationID: '0'
      });
    }


    this.AccountingClassificationForm.get('AccountingClassificationAction').markAllAsTouched();
    if (this.AccountingClassificationForm.get('AccountingClassificationAction').valid) {

      let a = this.AccountingClassificationForm.get('AccountingClassificationAction').value;

      this.accountingService.createAC(a)
        .subscribe(result => { this.getAccountingClassificationDetails() });

      this.onBtnClearAction();
    }

  }


  btngvView_Click(a) {
    this.saveBtnMode = false;
    this.fieldDisable = true;
    this.accountingclassificatinFilterObj = this.acGridObj.filter((unit) => unit.accountClassificationID == a);
    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationSearch: this.fb.group({
        SearchCode: [''],
        Searchdescription: ['']

      }),
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: this.accountingclassificatinFilterObj[0].accountClassificationID,
        code: this.accountingclassificatinFilterObj[0].code,
        description: this.accountingclassificatinFilterObj[0].description,
        createdBy: this.accountingclassificatinFilterObj[0].createdBy

      })
    });

    this.actionHeading = 'View - Accounting Classification Details';
  }

  btngvEdit_Click(a) {
    this.createBtn = false;
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.accountingclassificatinFilterObj = this.acGridObj.filter((unit) => unit.accountClassificationID == a);

    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationSearch: this.fb.group({
        SearchCode: [''],
        Searchdescription: ['']

      }),
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: this.accountingclassificatinFilterObj[0].accountClassificationID,
        code: this.accountingclassificatinFilterObj[0].code,
        description: this.accountingclassificatinFilterObj[0].description,
        createdBy: this.accountingclassificatinFilterObj[0].createdBy

      })
    });
    this.actionHeading = 'Edit - Accounting Classification Details';
    this.textSaveBtn = 'Update';
  }
  onBtnClearAction() {
    this.createBtn = true;
    this.actionHeading = 'Add New - Accounting Classification Details';
    this.saveBtnMode = true;
    this.fieldDisable = false;

    this.textSaveBtn = 'Save';
    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationSearch: this.fb.group({
        SearchCode: [''],
        Searchdescription: ['']

      }),
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: '',
        code: '',
        description: '',
        createdBy: ''

      })
    });
  }

  clearSearchAccountHead() {
    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationSearch: this.fb.group({
        SearchCode: [''],
        Searchdescription: ['']

      }),
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: '',
        code: '',
        description: '',
        createdBy: ''

      })
    });
    this.getAccountingClassificationDetails();
  }

  cfn(a) {
    console.log(a);
  }

}
