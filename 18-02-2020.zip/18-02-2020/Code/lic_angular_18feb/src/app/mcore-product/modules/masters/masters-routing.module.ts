import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentComponent } from './department/department.component';
import { InsurerComponent } from './insurer/insurer.component';
import { LookupComponent } from './lookup/lookup.component';
import { BankmasterComponent } from './bankmaster/bankmaster.component';
import { BankbranchComponent } from './bankbranch/bankbranch.component';
import { AddressstructureComponent } from './addressstructure/addressstructure.component';
import { DestinationdocumentuploadComponent } from './destinationdocumentupload/destinationdocumentupload.component';
import { OrganizationComponent } from './organization/organization.component';
import { DesignationComponent } from './designation/designation.component';
import { GradeComponent } from './grade/grade.component';
import { ZoneComponent } from './zone/zone.component';
import { DivisionComponent } from './division/division.component';
import { BranchComponent } from './branch/branch.component';
import { ProductComponent } from './product/product.component';
import { VariantComponent } from './variant/variant.component';
import { PremiumComponent } from './premium/premium.component';
import { PremiumpaymentfrequencyComponent } from './premiumpaymentfrequency/premiumpaymentfrequency.component';
import { LoadinganddiscountComponent } from './loadinganddiscount/loadinganddiscount.component';
import { FchannelComponent } from './fchannel/fchannel.component';
import { FsaleshierarchyComponent } from './fsaleshierarchy/fsaleshierarchy.component';
import { UserComponent } from './user/user.component';
import { GroupComponent } from './group/group.component';
import { PrivilegesComponent } from './privileges/privileges.component';
import { CoveragesComponent } from './coverages/coverages.component';
import { QuestionsComponent } from './questions/questions.component';
import { TaxstructureComponent } from './taxstructure/taxstructure.component';
import { StampdutyComponent } from './stampduty/stampduty.component';
import { CommissionComponent } from './commission/commission.component';
import { AuthorisedsignatoryComponent } from './authorisedsignatory/authorisedsignatory.component';
import { ClientOrganizationComponent } from './client-organization/client-organization.component';
import { FsubChannelComponent } from './fsub-channel/fsub-channel.component';
import { MasterPolicyComponent } from './master-policy/master-policy.component';
import { FEmailSMSTemplateComponent } from './femail-smstemplate/femail-smstemplate.component';


const routes: Routes = [
 
  {	
    path: 'masters',
 
    children: [   //<---- child components declared here
      {
        path: 'lookup',
        component: LookupComponent
      },
      {
        path: 'bankmaster',
        component: BankmasterComponent
      }, 
      {
        path: 'bankbranch',
        component: BankbranchComponent
      },  
      {
        path: 'addressstructure',
        component: AddressstructureComponent
      },
      {
        path: 'destinationdocumentupload',
        component: DestinationdocumentuploadComponent
      }  ,                    
      {
        path: 'department',
        component: DepartmentComponent
      },
      {
        path: 'insurer',
        component: InsurerComponent
      },
      {
        path: 'organization',
        component: OrganizationComponent
      },
      {
        path: 'designation',
        component: DesignationComponent
      },
      {
        path: 'grade',
        component: GradeComponent
      },
      {
        path: 'grade',
        component: GradeComponent
      },
      {
        path: 'zone',
        component: ZoneComponent
      },
      {
        path: 'division',
        component: DivisionComponent
      },
      {
        path: 'branch',
        component: BranchComponent
      }
      ,
      {
        path: 'product',
        component: ProductComponent
      } ,
      {
        path: 'product',
        component: ProductComponent
      },
      {
        path: 'variant',
        component: VariantComponent
      },
      {
        path: 'premium',
        component: PremiumComponent
      },
      {
        path: 'premiumpaymentfrequency',
        component: PremiumpaymentfrequencyComponent
      }
      ,
      {
        path: 'loadinganddiscount',
        component: LoadinganddiscountComponent
      },
      {
        path: 'fchannel',
        component: FchannelComponent
      },
      {
        path: 'fsaleshierarchy',
        component: FsaleshierarchyComponent
      }
      ,
      {
        path: 'user',
        component: UserComponent
      }
      ,
      {
        path: 'group',
        component: GroupComponent
      }
      ,
      {
        path: 'privileges',
        component: PrivilegesComponent
      },
      {
        path: 'branch',
        component: BranchComponent
      },
      {
        path: 'coverages',
        component: CoveragesComponent
      },
      {
        path: 'questions',
        component: QuestionsComponent
      },
      {
        path: 'taxstructure',
        component: TaxstructureComponent
      },
      {
        path: 'stampduty',
        component: StampdutyComponent
      },
      {
        path: 'commission',
        component: CommissionComponent
      },     
      {
        path: 'authorisedsignatory',
        component: AuthorisedsignatoryComponent
      },
      {
        path: 'FEmailSMSTemplate',
        component: FEmailSMSTemplateComponent
      },
      {
        path: 'ClientOrganizationComponent',
        component: ClientOrganizationComponent
      },
      {
        path: 'fsubchannel',
        component: FsubChannelComponent
      },
      {
        path: 'MasterPolicyComponent',
        component: MasterPolicyComponent
      }
    ]
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MastersRoutingModule { }
