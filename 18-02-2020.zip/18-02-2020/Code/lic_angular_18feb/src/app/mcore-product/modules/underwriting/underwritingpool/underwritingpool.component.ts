import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-underwritingpool',
  templateUrl: './underwritingpool.component.html',
  styleUrls: ['./underwritingpool.component.css']
})
export class UnderwritingpoolComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  underwritingPoolColumns: string[] = ['Select', 'masterpolicyNo', 'applicationNumber', 'employeeID', 'firstName', 'dateofBirth', 'age'];
  underwritingPoolPaymentColumns: string[] = ['BenefitRiders', 'SAaboveFCL'];
  underwritingMedicalRemarksColumns: string[] = ['Remarks'];
  dataSource;
  elements: string;
  constructor() { }

  ngOnInit() {
  }

}
