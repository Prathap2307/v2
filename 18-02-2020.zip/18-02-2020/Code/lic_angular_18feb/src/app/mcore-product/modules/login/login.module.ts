import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginRoutingModule } from './login-routing.module';
import { LoginMasterComponent } from './login-master/login-master.component';
import { LoginComponent } from './login/login.component';


@NgModule({
  declarations: [LoginMasterComponent],
  imports: [
    CommonModule,
    LoginRoutingModule,
 
  ],
  exports: [
    LoginMasterComponent,
    LoginComponent
  
  ],
})
export class LoginModule { }
