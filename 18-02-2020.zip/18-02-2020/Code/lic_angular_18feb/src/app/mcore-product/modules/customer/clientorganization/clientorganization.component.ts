import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TooltipPosition } from '@angular/material';

@Component({
  selector: 'app-clientorganization',
  templateUrl: './clientorganization.component.html',
  styleUrls: ['./clientorganization.component.css']
})
export class ClientorganizationComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  dummyObj: string[];
  dataObj;

  constructor() { }

  ngOnInit() {
  }

  clientColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];

}
