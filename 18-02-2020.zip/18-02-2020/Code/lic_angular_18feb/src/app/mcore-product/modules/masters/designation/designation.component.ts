import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
import { DesignationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/designation.service';
import { TooltipPosition } from '@angular/material/tooltip';

import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.css']
})
export class DesignationComponent implements OnInit {

  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

  submitted = false;
  saveBtnMode: boolean;
  designationForm: FormGroup;
  designationFormAction: FormGroup;
  
  departmentObj: DepartmentType[];
  fieldDisable: Boolean;

  constructor(private fb:FormBuilder, private designationService: DesignationService, private departmentService: DepartmentService ) { }

  designationObj: Designation[] = [];
  designationFilteredObj: Designation[] = [];
  designationColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];

  designationHeading: string = '';
  ngOnInit() {

    this.designationHeading = 'Add New - Designation';
    this.saveBtnMode = true;
    this.getDesignationDetails();
    this.getDepartmentDetails();
    this.designationForm = this.fb.group({
      searchId:[''],
      searchdesignationName:[''],
      searchdepartmentName:[''],
      designationFormAction: this.fb.group({
        designationId: [''],
        shortName:
        [
          '',
          [Validators.required]
        ],
        description:
        [
          '',
          [Validators.required]
        ],
		createdBy: ['1'],
		createdOn: [new Date()],
		deletedBy: ['1'],
		deletedOn: [new Date()]
      }) 
    })
  }

  getDetailsInfoBySearch(): void {


    
      //console.log(this.DepartmentForm.controls.SearchDescription.value);
      let searchdescription = this.designationForm.controls.searchdepartmentName.value;
      
      this.designationService.getDetailsInfoBySearch(searchdescription , null )
        .subscribe(designationObj => this.designationObj = designationObj);
    

  }

  onBtnSaveDesignation(){
    this.designationForm.get('designationFormAction').patchValue({
		createdBy:  '1',
			createdOn: new Date()
		});

		this.designationForm.controls.designationFormAction.markAllAsTouched();   
		if (this.designationForm.controls.designationFormAction.valid) {
		 
		  let a = this.designationForm.controls.designationFormAction.value;      
		  console.log(this.designationForm.controls.designationFormAction.value);
		  this.designationService.addDesignation(a)
		  .subscribe(result => {this.getDesignationDetails()});

		  this.designationHeading = 'Add New - Designation';
		}
  }  
  onBtnSearchClearDesignation(){        
    this.designationForm.reset();

    this.getDesignationDetails();
  }
  onBtnClearDesignation(){    
    this.fieldDisable = false;
    this.designationForm.controls.designationFormAction.reset();
    this.designationHeading = 'Add New - Designation';

    this.designationForm = this.fb.group({
      designationFormAction: this.fb.group({
        designationId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        shortName: { value: '', disabled: false },

      })


    });

    this.saveBtnMode = true;


  }
  getDesignationDetails(): void {

    this.designationService.getDesignationDetails( 0 , null )
      .subscribe(designationObj => {
        this.designationObj = designationObj;
      
      });

  }

  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => {
        this.departmentObj = departmentObj;
      
      });

  }

  btngvDelete_Click(a){
	this.designationForm = this.fb.group({
      searchId:[''],
      searchdesignationName:[''],
      searchdepartmentName:[''],
		designationFormAction: this.fb.group({
			searchdesignationName:[''],
      searchdepartmentName:[''],
			designationId: { value: a, disabled: false },
			description: { value: '', disabled: false },
			shortName: { value: '', disabled: false },
			createdBy: { value: '', disabled: false },
			createdOn: { value: '', disabled: false },
			deletedBy: '2',
			deletedOn: '2020-01-30'
		})
	}); 
	
	let c = this.designationForm.get('designationFormAction').value;
	
    this.designationService.deleteDesignation(c).subscribe(result => {this.getDesignationDetails()});
  }
 
  btngvView_Click(a) {
    this.saveBtnMode = false;
	this.fieldDisable = true;

    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({
      searchId:[''],
		searchdesignationName:[''],
      searchdepartmentName:[''],
      designationFormAction: this.fb.group({
        designationId: { value: this.designationFilteredObj[0].designationId, disabled: true },
        description: { value: this.designationFilteredObj[0].description, disabled: true},
        shortName: { value: this.designationFilteredObj[0].shortName, disabled: true },
		createdBy: { value: this.designationFilteredObj[0].createdBy, disabled: true },
		createdOn: { value: this.designationFilteredObj[0].createdOn, disabled: true }

      })
    });

    this.designationHeading = 'View - Designation';

  
   
  }

  btngvEdit_Click(a) {
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({
      searchId:[''],
		searchdesignationName:[''],
      searchdepartmentName:[''],
      designationFormAction: this.fb.group({
        designationId: { value: this.designationFilteredObj[0].designationId, disabled: false },
        description: { value: this.designationFilteredObj[0].description, disabled: false},
        shortName: { value: this.designationFilteredObj[0].shortName, disabled: false },
				createdBy: { value: this.designationFilteredObj[0].createdBy, disabled: false },
				createdOn: { value: this.designationFilteredObj[0].createdOn, disabled: false }

      })
    });

    this.designationHeading = 'Edit - Designation';
   
  }
  
  //disableSelect = new FormControl(false);

  //id = new FormControl(false);
 
  consoleLogFn(val) {
    console.log(val);
  }



  
}
