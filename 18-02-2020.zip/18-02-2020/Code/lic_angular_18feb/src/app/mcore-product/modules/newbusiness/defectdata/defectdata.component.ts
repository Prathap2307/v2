import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defectdata',
  templateUrl: './defectdata.component.html',
  styleUrls: ['./defectdata.component.css']
})
export class DefectdataComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
