import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import { MustMatch } from 'src/app/mcore-product/mcore-shared/mcore-helpers/must-matchvalidator';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';




@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],

  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    {provide: MAT_DATE_LOCALE, useValue: 'en-gb'},

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],
})
export class UserComponent implements OnInit {
  Searchuser: FormGroup;
  Adduser: FormGroup;
  UnderWriter: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  submitted3: boolean;
  saveBtnMode: boolean = true;
  view: boolean = false;
  Under_Writers: boolean=false;
  userheading:string='Add - New User'
  display: string='none';
  Addunderwriter: any=[];
  textSaveBtn: string='Save';

  dummyObj=
  [{ Id: '1', Name: 'abc'},
  { Id: '2', Name: 'abcd'},
  { Id: '3', Name: 'abc34'},
  { Id: '4', Name: 'abc4'}
]

userType=[

 
{ Id: '2', Name: 'Client Organisation User'},
{ Id: '3', Name: 'Agent User'},
{ Id: '4', Name: 'General User'}
]

Reporting_to=[

  { Id: '1', Name: '---select-----'},
]

Gender=[

  { Id: '2', Name: 'Male'},
  { Id: '3', Name: 'Female'},
  { Id: '4', Name: 'Transgender'}
  ]

  
Branch=[

  { Id: '2', Name: 'Bangalore'},
  { Id: '3', Name: 'Kolkata'},
  { Id: '4', Name: 'Mumbai'}
  ]
  Department=[

    { Id: '2', Name: 'Technical'},
    { Id: '3', Name: 'Account Taxatio'},
    { Id: '4', Name: 'Accounts Taxation'},
    { Id: '5', Name: 'BSG IT'},
    { Id: '6', Name: 'Head Office'},
    { Id: '7', Name: 'IT'},
    { Id: '7', Name: 'Operational Team'}
    ]

    designation=[
      { Id: '2', Name: 'No Result Found'},

    ]

    Grade=[

      { Id: '2', Name: 'GRADE II'},
      { Id: '3', Name: 'Grade III'},
      { Id: '4', Name: 'Grade IV'},
      { Id: '5', Name: 'Grade V'},
      { Id: '6', Name: 'Grade VI'},
      { Id: '7', Name: 'GRADE VII'},
    
      ]
  branchFilteredObj: any;


  constructor(private fb:FormBuilder,private _adapter: DateAdapter<any>,private user:UserService) {
    this._adapter.setLocale('en-gb');
   }

  ngOnInit() {

    this.Searchuser = this.fb.group({
      First_Name:[],
      Last_Name:[],
      User_Name:[],
      ReportingTo:[],
   
  
      }) 
      this.UnderwriterForm()
      this.UserForm()

  }
 UserForm()
 {
  this.Adduser = this.fb.group({
 
    First_Name:[],
    tittle:[''],
    Last_Name:[],
    Initial:[],
    Gender :[],
    Branch :[],
    Department :[],
    Designation :[],
    Grade :[],
    Reporting_To:[],
    BranchTowhichattached:[],
    Address:[],
    Mobile_Number :['', [Validators.pattern('\\d{10}')]],      
    Conference_Number :['', [Validators.pattern('[0-9]{11,12}')]],
    EmployeeNumber :[],
    Email_ID :['', [ Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")]],    
    Is_Under_Writer :[], 
    Employee_Photo :[],
    UserName :[],
    Is_Admin_User :[],
    Password :['',[Validators.required, Validators.pattern('(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$')]] ,    
    Confirm_Password :[],
    Under_Writer:this.fb.array([

        

    ]),
    },
    
    {
      validator: MustMatch('Password', 'Confirm_Password')
  }) 
 }
 


 UnderwriterForm()
 {
     
  this.UnderWriter=this.fb.group({
    Level:['', [Validators.required]], 
    Module:['', [Validators.required]],
    LOB:['', [Validators.required]],
    Plan:['', [Validators.required]],
    Level_Name:['', [Validators.required]],

  }) 
 }



 getBranchById( ) {
  this.user.GetUserModulesFeatureByUserID()
    .subscribe(result => {
      console.log(result)
      this.branchFilteredObj = result
      console.log(this.branchFilteredObj)
      if (this.branchFilteredObj) {
        // console.log(this.Adduser.value)
        this.Adduser = this.fb.group({
          First_Name: { value: this.branchFilteredObj.First_Name, disabled: false },
          tittle: [{ value: this.branchFilteredObj.tittle, disabled: true }],
          Last_Name: { value: this.branchFilteredObj.Last_Name, disabled: false },
          Initial: { value: this.branchFilteredObj.Initial, disabled: false },
          Gender: { value: this.branchFilteredObj.Gender, disabled: false },
          Branch: { value: this.branchFilteredObj.Branch, disabled: false },
          Department: { value: this.branchFilteredObj.Department, disabled: false },
          Designation: { value: this.branchFilteredObj.Designation, disabled: false },
          Grade: { value: this.branchFilteredObj.Grade, disabled: false },
          Reporting_To: { value: this.branchFilteredObj.Reporting_To, disabled: false },
          BranchTowhichattached: { value: this.branchFilteredObj.BranchTowhichattached, disabled: false },
          Address: { value: this.branchFilteredObj.Address, disabled: false },
          Mobile_Number: { value: this.branchFilteredObj.Mobile_Number, disabled: false },
          Conference_Number: { value: this.branchFilteredObj.Conference_Number, disabled: false },
          EmployeeNumber: { value: this.branchFilteredObj.EmployeeNumber, disabled: false },
          Email_ID: { value: this.branchFilteredObj.Email_ID, disabled: false },
          Is_Under_Writer: { value: this.branchFilteredObj.Is_Under_Writer, disabled: false },
          Employee_Photo: { value: this.branchFilteredObj.Employee_Photo, disabled: false },
          UserName: { value: this.branchFilteredObj.UserName, disabled: false },
          Is_Admin_User: { value: this.branchFilteredObj.Is_Admin_User, disabled: false },
          Password: { value: this.branchFilteredObj.Password, disabled: false },
          Confirm_Password: { value: this.branchFilteredObj.Confirm_Password, disabled: false },
          Under_Writer: { value: this.branchFilteredObj.Under_Writer, disabled: false }

        })
      }

      if(this.branchFilteredObj.Is_Under_Writer=true)
      {
        this.Under_Writers=true
      
        this.Addunderwriter=this.branchFilteredObj.Under_Writer;
        console.log(this.Addunderwriter)
        console.log(this.Under_Writers)
      }
     
    })
}

  Under_Writer()
  {
    if(this.Under_Writers==false && this.view==false)
    {
      this.Under_Writers=true
    }
    else{
      this.Under_Writers=false
    }
    
  }
  get a() { return this.Searchuser.controls; }
 
 searchUser() {
    this.submitted = true;
    console.log(this.Searchuser.value)
  }

  clearsearch()
  {
    this.Searchuser.reset();
  }

  get au() { return this.UnderWriter.controls; }


  AddUnderWriters() {

    this.submitted3 = true;
    console.log(this.UnderWriter.value)

    if(this.UnderWriter.valid)
    {
    this.Addunderwriter.push(this.UnderWriter.value);
    this.UnderWriter.reset();
    this.submitted3 = false;
    console.log(this.UnderWriter.value)
    console.log(this.Addunderwriter)
    }

  }
  cancelUnderWriters()
  {
         this.UnderWriter.reset();
         this.UnderwriterForm()
      this.submitted3 = false;
  }


  get am() { return this.Adduser.controls; }
 
  Addusers() {
    this.submitted1 = true;
    console.log(this.Adduser.value)
    this.Adduser.value.Under_Writer = this.Addunderwriter
    console.log(this.Adduser.value)

    if(this.Adduser.valid)
    {
      this.openModalDialog();
    }
   
  }

  CancelAddUser()
  
  {
    this.Adduser.reset();
    this.UserForm()
    // console.log(this.submitted)
    this.submitted1 = false
    this.userheading = 'Add - New User';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  btngEdit_Click() {

    this.userheading = 'Edit - User';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.getBranchById()
  }
  btngView_Click() {
    this.userheading = 'View - User';
    this.view = true
    this.Under_Writers=false
    console.log(this.view)
    this.saveBtnMode = false;
  }


  get MobNoError() {
  if (this.Adduser.controls['Mobile_Number'].hasError('pattern')) {
      return 'Mobile Number Should be 10 Digit';
    } 
  }

  get ConferenceNoError() {
    if (this.Adduser.controls['Conference_Number'].hasError('pattern')) {
        return 'Conference Number Should be 11 Digit or 12 Digit';
      } 
    }

  get EmailError() {
  if (this.Adduser.controls['Email_ID'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }

  get passwordError() {

    if (this.Adduser.controls['Password'].hasError('required')) {
      return 'Please enter the Password';
    } 
    else if (this.Adduser.controls['Password'].hasError('pattern')) {
        return 'Password must contain Minimum 8 Characters,Minimum 1 Alphabet,Minimum 1 Numeric,Minimum 1 Special Character and No Spaces';
      }
    }

    get confirmpasswordError() {

      if (this.Adduser.controls['Confirm_Password'].hasError('required')) {
        return 'Please confirm  the Password';
      } 
      else if (this.Adduser.controls['Confirm_Password'].hasError('mustMatch')) {
          return ' confirm password must match password';
        }
      }




  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted1 = false
    this.Adduser.reset()


  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
  }


  
}



// error on password field if entered wrong=====

// error msg

//  Password must contain Minimum 8 Characters,Minimum 1 Alphabet,
// Minimum 1 Numeric,Minimum 1 Special Character and No Spaces


// confirm password copy paste not allowed

// visually increase length of password

// on submit msg User Created Successfully


// mobile number only numbers allowed error  Mobile Number Should be 10 Digit

//   Conference Number Should be 11 Digit or 12 Digit.(number only numbers)

//   Please provide a valid email address


//   on click of Under Writer  UnderWriter form