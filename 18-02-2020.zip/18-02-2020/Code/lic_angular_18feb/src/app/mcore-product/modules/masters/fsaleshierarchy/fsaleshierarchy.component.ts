import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
// import moment from 'moment'
import * as moment from "moment"
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
// import moment = require('moment');
@Component({
  selector: 'app-fsaleshierarchy',
  templateUrl: './fsaleshierarchy.component.html',
  styleUrls: ['./fsaleshierarchy.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class FsaleshierarchyComponent implements OnInit {

  SearchMarketingHierarchy: FormGroup;
  AddMarketingHierarchy: FormGroup;
  // AddAddress: FormGroup;
  submitted1: boolean;
  submitted2: boolean;
  submitted: boolean;



  allDivision =
    [
      { id: '1', branchName: 'Manufacturer', shortName: 'abcd', isActive: '2' },
      { id: '2', branchName: 'Distributor ', shortName: 'abcd', isActive: '1' },
      { id: '3', branchName: 'Importer', shortName: 'abcd', isActive: '2' },
      { id: '4', branchName: 'Exporter', shortName: 'abcd', isActive: '2' },
      { id: '5', branchName: 'Stockist', shortName: 'abcd', isActive: '1' },
      { id: '6', branchName: 'Others', shortName: 'abcd', isActive: '1' },
      { id: '7', branchName: 'Manufacturer', shortName: 'abcd', isActive: '2' },
      { id: '8', branchName: 'Distributor ', shortName: 'abcd', isActive: '1' },
      { id: '9', branchName: 'Importer', shortName: 'abcd', isActive: '2' },
      { id: '10', branchName: 'Exporter', shortName: 'abcd', isActive: '2' },
      { id: '11', branchName: 'Stockist', shortName: 'abcd', isActive: '1' },
      { id: '12', branchName: 'Others', shortName: 'abcd', isActive: '1' },
      { id: '13', branchName: 'Manufacturer', shortName: 'abcd', isActive: '2' },
      { id: '14', branchName: 'Distributor ', shortName: 'abcd', isActive: '1' },
      { id: '15', branchName: 'Importer', shortName: 'abcd', isActive: '2' },
      { id: '16', branchName: 'Exporter', shortName: 'abcd', isActive: '2' },
      { id: '17', branchName: 'Stockist', shortName: 'abcd', isActive: '1' },
      { id: '18', branchName: 'Others', shortName: 'abcd', isActive: '1' },
      { id: '19', branchName: 'Manufacturer', shortName: 'abcd', isActive: '2' },
      { id: '20', branchName: 'Distributor ', shortName: 'abcd', isActive: '1' },
      { id: '21', branchName: 'Importer', shortName: 'abcd', isActive: '2' },
      { id: '22', branchName: 'Exporter', shortName: 'abcd', isActive: '2' },
      { id: '23', branchName: 'Stockist', shortName: 'abcd', isActive: '1' },
      { id: '24', branchName: 'Others', shortName: 'abcd', isActive: '1' },
      { id: '25', branchName: 'Manufacturer', shortName: 'abcd', isActive: '2' },
      { id: '26', branchName: 'Distributor ', shortName: 'abcd', isActive: '1' },
      { id: '27', branchName: 'Importer', shortName: 'abcd', isActive: '2' },
      { id: '28', branchName: 'Exporter', shortName: 'abcd', isActive: '2' },
      { id: '29', branchName: 'Stockist', shortName: 'abcd', isActive: '1' },
      { id: '30', branchName: 'Others', shortName: 'abcd', isActive: '1' },

    ]

  dummyObj = [{ Id: '1', Name: 'abc' },
  { Id: '2', Name: 'abcd' },
  { Id: '3', Name: 'abc34' },
  { Id: '4', Name: 'abc4' }
  ]
  config: any;
  SubchannelHeading: string = 'Add New - Marketing Hierarchy';
  saveBtnMode: boolean = true;
  AddAdressBtnMode: boolean = true;
  textSaveBtn: string = 'Save';

  checked = true
  view: boolean = false;
  AddressHeading: string = 'Add New - Address Details';
  adressSaveBtn: string = 'Add Address';
  country: any;
  state: any;
  District: any;
  add: any;
  allbranch: any;
  // Address: FormArray;
  address: FormGroup;
  Addressdata: any[] = [];
  id: any;
  isdob: boolean;
  isage: boolean;
  invalidsDob: boolean=false;
  invalidAge: boolean=false;
  display: string = 'none';
  validform: boolean;





  constructor(private fb: FormBuilder, private fchannelService: FchannelService, private BranchService: BranchService) {

    this.config = {
      itemsPerPage: 3,
      currentPage: 1,
      totalItems: this.allDivision.length
    };
  }

  pageChanged(event) {
    this.config.currentPage = event;
  }

  ngOnInit() {

    this.GetAllcountries()
    this.getallbranches()
    this.SearchMarketingHierarchy = this.fb.group({
      First_Name: [],
      Last_Name: [],
      Marketing_Officer_Code: [],
      Main_Channel: [],
      Sub_Channel: [],
      Reporting_To: []

    })
    this.AddMarketingHierarchy = this.fb.group({
      APPLICATIONDATE: [],
      DATEOFJOINING: [],
      AGENTLOCATION: ['', [Validators.required]],
      ORGANISATIONNAME: [],
      FIRSTNAME: ['', [Validators.required]],
      SALUTATIONID: ['', [Validators.required]],
      LASTNAME: [],
      GENDER: ['', [Validators.required]],
      DOB: [],
      PANCARD: ['', [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$')]],
      REGISTREDUNDER: [],
      REGISTRATIONDATE: [],
      MIAAGREEMENTDATE: [],
      CODEISSUANCEDATE: [],
      CODEEXPIREDATE: [],
      RENEWALDATE: [],
      EFFECTIVEDATE: [],
      EXPIREDATE: [],
      CODE: ['', [Validators.required]],
      CHANNELID: ['', [Validators.required]],
      SUBCHANNELID: ['', [Validators.required]],
      Reporting_To: [],
      ISEMPLOYEE: ['', [Validators.required]],
      DEPARTMENTID: ['', [Validators.required]],
      DESIGNATIONID: ['', [Validators.required]],
      BRANCHID: ['1', ],
      ISACTIVE: ['', [Validators.required]],
      REMARKS: [],
      REMARKSDATE: [],
      Address: this.fb.array([

      ])
    })
    this.address = this.fb.group({
      Address1: ['', [Validators.required]],
      Address2: ['',],
      Address3: [''],
      AddressType: ['', [Validators.required]],
      PinCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
      Country: ['', [Validators.required]],
      State: ['', [Validators.required]],
      District: ['', [Validators.required]],
      LandlineNumber: [],
      MobileNumber: [],
      ConferenceNumber: [],
      FaxNumber: [],
      OfficialEmailID: ['', Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")],
    })

  }

  addressform() {
    this.address = this.fb.group({
      Address1: ['', [Validators.required]],
      Address2: ['',],
      Address3: [''],
      AddressType: ['', [Validators.required]],
      PinCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
      Country: ['', [Validators.required]],
      State: ['', [Validators.required]],
      District: ['', [Validators.required]],
      LandlineNumber: [],
      MobileNumber: [],
      ConferenceNumber: [],
      FaxNumber: [],
      OfficialEmailID: ['', Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")],
    })

  }
  get m() { return this.SearchMarketingHierarchy.controls; }

  SearchMarket() {
    this.submitted = true;
    console.log(this.SearchMarketingHierarchy.value)
  }

  get am() { return this.AddMarketingHierarchy.controls; }
  get addr() { return this.address.controls }
  AddMarket() {
    this.submitted1 = true;
    this.AddMarketingHierarchy.get('Address').value.push(this.Addressdata)
    let m = new Date().getUTCMonth() + 1
    let y = new Date().getUTCFullYear()
    let d = new Date().getUTCDate()
    let fromvalue = moment(new Date(this.AddMarketingHierarchy.value["DOB"])).format('YYYY/MM/DD')
    let firstDate = moment(fromvalue);
    // let firstDate = moment(this.AddMarketingHierarchy.value["DOB"]._i.year + '/' + this.AddMarketingHierarchy.value["DOB"]._i.month + '/' + this.AddMarketingHierarchy.value["DOB"]._i.date);
    let secondDate = y + '/' + m + '/' + d;
    console.log(firstDate)
    let result = firstDate.diff(secondDate, 'years');
    console.log(result)
    if (result >= 0) {
      this.openModalDialog()
      this.invalidsDob = true
      console.log("DOB should not be greater than or equal to current date")
    }
    else if (result > -18 && result < 0) {
      this.openModalDialog()
      this.invalidAge = true
      console.log("Age should not be less than 18 years")
    }
   
    else if (this.AddMarketingHierarchy.valid && !this.invalidsDob && !this.invalidAge) {
      console.log(this.AddMarketingHierarchy.value)
      // this.fchannelService.addHierarchy(this.AddMarketingHierarchy.value)
      //   .subscribe(result => {
      //     console.log(result)
      //     this.validform=true
      //     this.openModalDialog()
      //     this.submitted1=false
      //   });
          this.validform=true
          this.openModalDialog()
          this.submitted1=false
    }
    console.log(this.invalidAge)
    console.log(this.invalidsDob)
  }
  getallbranches() {
    let branch = {
      "OrganisationID": 1,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
        if (this.allbranch) {
          console.log(this.allbranch)
        }
      });
  }
  get ad() { return this.AddMarketingHierarchy.controls.AddAddress; }


  AddAdress() {
    this.submitted2 = true;
    console.log(this.AddMarketingHierarchy.get('Address'))
    if (this.address.valid) {
      console.log(this.id)
      if (this.id === -1 || this.id === undefined) {
        this.Addressdata.push(this.address.value);
      } else {
        this.Addressdata[this.id] = this.address.value;
        console.log(this.Addressdata);
      }
      this.address.reset()
      this.Addresscancel()

    }


    // if (this.AddMarketingHierarchy.controls.AddAddress.valid) {
    //   let add = {};
    //   add = this.AddMarketingHierarchy.controls.AddAddress.value
    //   this.Addresslist.push( add);
    //   console.log(this.Addresslist);
    //   this.AddMarketingHierarchy.controls.Address.reset()
    //   this.submitted2 = false;
    //   this.AddMarketingHierarchy = this.fb.group({

    //     AddAddress: this.fb.group({
    //       Address1: ['', [Validators.required]],
    //       Address2: ['',],
    //       Address3: [''],
    //       AddressType: ['', [Validators.required]],
    //       PinCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
    //       Country: ['', [Validators.required]],
    //       State: ['', [Validators.required]],
    //       District: ['', [Validators.required]],
    //       LandlineNumber: [],
    //       MobileNumber: [],
    //       ConferenceNumber: [],
    //       FaxNumber: [],
    //       OfficialEmailID: ['', Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")],
    //     })
    //   })
    // }
  }

  removeaddress(id) {
    (<FormArray>this.AddMarketingHierarchy.get('Address')).removeAt(id)
  }
  btngEdit_Click() {

    this.SubchannelHeading = 'Edit - Marketing Hierarchy';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
  }
  btngView_Click() {
    this.SubchannelHeading = 'View - Marketing Hierarchy';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
  }
  cancel() {
    this.AddMarketingHierarchy.reset()
    console.log(this.submitted)
    this.submitted1 = false
    this.SubchannelHeading = 'Add New - Marketing Hierarchy';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  AddressEdit_Click(id) {
    console.log(id)
    this.AddressHeading = 'Edit - Address Details';
    this.AddAdressBtnMode = true;
    this.adressSaveBtn = 'Update Address'
    this.id = id
    this.address = this.fb.group({
      Address1: { value: this.Addressdata[id].Address1, disabled: false },
      Address2: { value: this.Addressdata[id].Address2, disabled: false },
      Address3: { value: this.Addressdata[id].Address3, disabled: false },
      AddressType: { value: this.Addressdata[id].AddressType, disabled: false },
      PinCode: { value: this.Addressdata[id].PinCode, disabled: false },
      Country: { value: this.Addressdata[id].Country, disabled: false },
      State: { value: this.Addressdata[id].State, disabled: false },
      District: { value: this.Addressdata[id].District, disabled: false },
      LandlineNumber: { value: this.Addressdata[id].LandlineNumber, disabled: false },
      MobileNumber: { value: this.Addressdata[id].MobileNumber, disabled: false },
      ConferenceNumber: { value: this.Addressdata[id].ConferenceNumber, disabled: false },
      FaxNumber: { value: this.Addressdata[id].FaxNumber, disabled: false },
      OfficialEmailID: { value: this.Addressdata[id].OfficialEmailID, disabled: false },
    })

  }

  Addresscancel() {
    this.address.reset()
    console.log(this.submitted2)
    this.submitted2 = false
    this.AddressHeading = 'Add New - Address Details';
    this.AddAdressBtnMode = true;
    this.adressSaveBtn = 'Add Address'
  }
  pinValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        console.log(l)
      }
      else {
        event.preventDefault();
      }
    }
  }
  Select_country(event: any) {
    console.log(event.target.value)

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)

    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)


  }


  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  dob(e: any) {
    console.log(e)
    console.log(this.AddMarketingHierarchy.value['Date_of_Birth'])
    if (this.AddMarketingHierarchy.value['Date_of_Birth'] > new Date()) {
      console.log("more")
    }
  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
        console.log(event.keyCode)
      }
      else if (l >= 5 && l <= 8) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  get PanError() {
    if (this.AddMarketingHierarchy.controls['PANCARD'].hasError('pattern')) {
      return 'Please enter Valid PAN Number';
    } else if (this.AddMarketingHierarchy.controls['PANCARD'].hasError('minlength')) {
      return 'Please Enter 10 digits of PAN Number.';
    }
  }

  openModalDialog() {
    console.log(this.display)
    this.display = 'block'; //Set block css
  
    
 
    // this.DivisionForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    if( this.invalidsDob){
      this.invalidsDob = false
    }
    else if(this.invalidAge){
      this.invalidAge = false
    }
    else if (this.submitted1 === false) {
      this.AddMarketingHierarchy.reset()
    }

  }
  // get pinError() {
  //   if (this.AddAddress.controls['PinCode'].hasError('required')) {
  //     return 'Please enter the Pin Code / Zip Code.';
  //   } else if (this.AddAddress.controls['PinCode'].hasError('pattern')) {
  //     return 'Please Enter Valid  Pin Code / Zip Code.';
  //   }
  // }


}
