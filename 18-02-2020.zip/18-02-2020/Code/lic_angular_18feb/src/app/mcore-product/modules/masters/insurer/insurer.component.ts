import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { InsurerService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/insurer.service';
import { Insurer } from 'src/app/mcore-product/mcore-shared/mcore-entity/insurer';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';

@Component({
  selector: 'app-insurer',
  templateUrl: './insurer.component.html',
  styleUrls: ['./insurer.component.css']
})
export class InsurerComponent implements OnInit {
  submitted: boolean;
  SearchIForm: FormGroup;
  insurerHeading: string;
  saveBtnMode: boolean=true;
  textSaveBtn: string='Save';
  country: any;
  state: any;
  District: any;
  Taluka: any;

  constructor(private insurerService: InsurerService, private BranchService: BranchService, private fb: FormBuilder) { }
  dummyObj = ['swdsd', 'asdasd']
  InsurerForm: FormGroup;
  ngOnInit() {
    this.GetAllcountries() 
    this.insurerHeading='Add New - Insurer'
    this.SearchIForm = this.fb.group({
      InsurerName: ['', [Validators.required]],
      LineOfBusinessID: ['', [Validators.required]],
    })
    this.InsurerForm = this.fb.group({
      CreatedBy: [1,],
      CreatedOn: [null,],
      OrganisationID: [1,],
      IsActive: [1,],
      id: [],
      InsurerName: ['', [Validators.required]],
      CollectionGLCode: [],
      PaymentGLCode: [],
      FreshGLCode: [],
      APOnlineGLCode: [],
      LICPremiumPaymentGLCode: [],
      RevivalGLCode: [],
      MedicalGLCode: [],
      ClaimGLCode: [],
      TriggerLimitforStampDuty: [],
      IntimationEmailaddressforStampDuty: [],
      IntimationMobileNumberforStampDuty: [],
      LineOfBusinessID: ['', Validators.required],
      DateOfCommencement: ['', Validators.required],
      GeographicalPresence: ['', [Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
      DistributionID: ['', [Validators.required]],
      LoGo: ['', [Validators.required]],
      Address1: ['', Validators.required],
      Address2: ['',],
      Address3: ['', ],
      CountryID: ['', Validators.required],
      StateID: ['', Validators.required],
      DistrictID: ['', Validators.required],
      TalukID: [''],
      ZipCode: ['', Validators.required],
      PhoneNo: ['',],
      FaxNumber: ['',],
      ConferenceNumber: ['',],
      MobileNo: ['', Validators.pattern("[0-9 -()+]+$") ],
      Email: ['', [ Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")]],
      GSTNo: ['', [ Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
      PANNo: ['', [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]]

    });

  }

  addressObj: Insurer[];
  getAddressDetails(e) {
    // zipcode = 625203;
    console.log(e.target.value);
    this.insurerService.getAddressByIDzipCode(e.target.value)
      .subscribe(addressObj => {
        this.addressObj = addressObj;

      });

  }
  get f() { return this.InsurerForm.controls; }


  onSubmit() {
    this.submitted = true;
    console.log(this.InsurerForm.value)
    // console.log(this.ZoneForm.value["GSTNo"].slice(2, 12))
   
    // this.insurerService.add(this.ZoneForm.value)
    //   .subscribe(result => { console.log(result) });
    // this.ZoneForm.reset()

  }
  
  btngEdit_Click() {

    this.insurerHeading = 'Edit - Insurer';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update';
  }
  btngView_Click() {
    this.insurerHeading = 'View - Insurer';
    this.saveBtnMode = false;

    // this.DivisionService.get_DivisionByid(a)
    // .subscribe(result => { console.log(result) 
    // this.DivisionFilteredObj=result

    // })
  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();

        }
        console.log(event.keyCode)
        // event.target.value = event.target.value.slice(0, 5).replace(/[^a-zA-Z]/g, "");
      }
      else if (l >= 5 && l <= 8) {

        console.log(l)
        console.log(charCode)
        // console.log(event.target.value.slice(5,9))
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }

        // event.target.value= event.target.value.slice(5, 9).replace(/[^0-9]/g, "");
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  GstnValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
        // State code
      if (l <= 1) {
        console.log(l)

          if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }  
      }
            // PAN alphabets
      else if (l >= 2 && l <=6 ) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\"))  {
          console.log(event.keyCode)
          event.preventDefault();
        } 
      }
        // PAN numeric
      else if (l > 6 && l <=10 ) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\"))  {
          console.log(event.keyCode)
          event.preventDefault();
        } 
      } // PAN alphabet
      else if (l >= 11 && l <12 ) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\"))  {
          console.log(event.keyCode)
          event.preventDefault();
        } 
      }
      // numeric
      else if (l >= 12 && l <13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)  || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        } 
      }
      // alphabet
      else if (l >= 13 && l <14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        } 
      }
         // numeric
         else if (l >= 14 && l <15) {
          console.log(l)
          console.log(charCode)
          if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
            console.log(event.keyCode)
            event.preventDefault();
          } 
        }
      // numeric
      else if (l >= 15 ) {
    
          event.preventDefault();
        
      }
    
    }
  }
  Select_country(event: any) {
    console.log(event.target.value)

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)

    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)

    this.GetTaluk(event.target.value);
  }


  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }


  get MobNoError() {
    if (this.InsurerForm.controls['MobileNo'].hasError('required')) {
      return 'Mobile Number is required';
    } else if (this.InsurerForm.controls['MobileNo'].hasError('pattern')) {
      return 'Please enter valid Mobile Number';
    } else if (this.InsurerForm.controls['MobileNo'].hasError('minlength')) {
      return 'Please enter valid 10 digits Mobile Number';
    }
  }

  get EmailError() {
    if (this.InsurerForm.controls['Email'].hasError('required')) {
      return 'Please enter the E-Mail ID.';
    } else if (this.InsurerForm.controls['Email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }
  get GstnError() {
    if (this.InsurerForm.controls['GSTNo'].hasError('pattern')) {
      return 'GSTIN should be 15 digits Master.';
    } 
    else if (this.InsurerForm.value["PanNo"] && this.InsurerForm.value["PanNo"]!=this.InsurerForm.value["GSTNo"].slice(2, 12).toUpperCase()) {
      console.log(this.InsurerForm.value["PanNo"])
      console.log(this.InsurerForm.value["GSTNo"].slice(2, 12).toUpperCase() )
      return 'PAN Mismatch in GSTIN.';
    }
    }

    get PanError() {
      // return this.email.hasError('required') ? 'You must enter a value' :
      //     this.email.hasError('email') ? 'Not a valid email' :
      //         '';
      if (this.InsurerForm.controls['PANNo'].hasError('required')) {
        return 'PAN Number is required';
      } else if (this.InsurerForm.controls['PANNo'].hasError('pattern')) {
        return 'Please enter valid PAN Number';
      } else if (this.InsurerForm.controls['PANNo'].hasError('minlength')) {
        return 'Please Enter 10 digits of PAN Number.';
      }
    }
  
      
  consoleLogFn(val) {
    console.log(val);
  }

}
