import { Component, OnInit, ViewChild, Renderer2, ElementRef, ViewChildren, QueryList } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { AccountingClassification } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingclassificatin';

import { AccountingClassificationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingclassification.service';
import { AccountingGroup, AccountingType, AccountingGrid, AccountTypeDropDown } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountinghead';
import { AccountingheadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountinghead.service';
import { MatTableDataSource } from '@angular/material/table';

import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-accountinghead',
  templateUrl: './accountinghead.component.html',
  styleUrls: ['./accountinghead.component.css']
})
export class AccountingheadComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  elements: string;

  accountingHeadColumns: string[] = ['View', 'Edit', 'code', 'accountHeadName', 'classification', 'groupName', 'isControlAC', 'isManualVoucher'];

  AccountingHeadForm: FormGroup;
  AccountingHeadFormSearch: FormGroup;
  AccountingHeadFormAction: FormGroup;

  accountGroupObj: AccountingGroup[];
  accountTypeObj: AccountingType[];

  accountGridObj: AccountingGrid[];

  AccountTypeObjDropDown: AccountTypeDropDown[] = [
    {
      "AccountTypeDropDownID": 1, "AccountTypeDropDownText": "Bank"
    },
    {
      "AccountTypeDropDownID": 2, "AccountTypeDropDownText": "Cash"
    },
    {
      "AccountTypeDropDownID": 3, "AccountTypeDropDownText": "Others"
    }
  ];

  accountGridFilterObj: AccountingGrid[];
  constructor(private fb: FormBuilder, private accountingService: AccountingClassificationService, private accountingHeadService: AccountingheadService, public renderer: Renderer2, private el: ElementRef) { }
  accountingclassificatinObj: AccountingClassification[] = [];
  dataSource = new MatTableDataSource<AccountingGrid>(this.accountGridObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  createBtn: boolean;

  //isControl: boolean;

  textSaveBtn: string;

  isControlV: number;
  isManualVoucherV: number;

  fieldDisable: Boolean;
  actionHeading: string = '';

  saveBtnMode: boolean = true;
  ngOnInit() {
    this.dataSource = new MatTableDataSource<AccountingGrid>(this.accountGridObj);
    this.actionHeading = 'Add New - Accounting Head';

    this.createBtn = true;
    this.textSaveBtn = 'Save';
    this.getAccountingClassificationDetails();
    this.getAccountingGroupDetails();
    this.getAccountingTypeDetails();
    this.getGridDetails(0, 0, 0, 0, 0, 0);

    this.AccountingHeadForm = this.fb.group({
      AccountingHeadFormSearch: this.fb.group({
        searchDescription: [''],
        searchGroupName: [''],
        searchAccountType: [''],
        searchAccountHeadCode: [''],
        searchAccountHeadName: ['']
      }),

      AccountingHeadFormAction: this.fb.group({
        accountHeadId: [''],
        accountClassificationID: ['', [Validators.required]],
        accountGroupID: ['', Validators.required],
        accountTypeID: ['', Validators.required],
        code: ['', Validators.required],
        accountHeadName: ['', Validators.required],
        isControlAC: [this.isControlV = 0],
        isManualVoucher: [this.isManualVoucherV = 0],
        createdBy: [''],
        isactive: ['']
      })
    });




  }

  btngvView_Click(a) {
    this.saveBtnMode = false;
    this.actionHeading = 'View - Accounting Head';
    this.fieldDisable = true;
    this.accountGridFilterObj = this.accountGridObj.filter((unit) => unit.accountHeadId == a);


    console.log(this.accountGridFilterObj[0]);
    this.AccountingHeadForm = this.fb.group({
      AccountingHeadFormSearch: this.fb.group({
        searchDescription: [''],
        searchGroupName: [''],
        searchAccountType: [''],
        searchAccountHeadCode: [''],
        searchAccountHeadName: ['']
      }),

      AccountingHeadFormAction: this.fb.group({
        accountHeadId: this.accountGridFilterObj[0].accountHeadId,
        accountClassificationID: this.accountGridFilterObj[0].accountClassificationID,
        accountGroupID: this.accountGridFilterObj[0].accountGroupID,
        accountTypeID: this.accountGridFilterObj[0].accountTypeID,
        code: this.accountGridFilterObj[0].code,
        accountHeadName: this.accountGridFilterObj[0].accountHeadName,
        isControlAC: this.accountGridFilterObj[0].isControlAC,
        isManualVoucher: this.accountGridFilterObj[0].isManualVoucher,
        createdBy: this.accountGridFilterObj[0].createdBy,
      })
    });
  }


  btngvEdit_Click(a) {
    this.saveBtnMode = true;
    this.actionHeading = 'Edit - Accounting Head';
    this.createBtn = false;
    this.fieldDisable = false;
    this.accountGridFilterObj = this.accountGridObj.filter((unit) => unit.accountHeadId == a);
    console.log(this.accountGridFilterObj[0]);
    this.AccountingHeadForm = this.fb.group({
      AccountingHeadFormSearch: this.fb.group({
        searchDescription: [''],
        searchGroupName: [''],
        searchAccountType: [''],
        searchAccountHeadCode: [''],
        searchAccountHeadName: ['']
      }),

      AccountingHeadFormAction: this.fb.group({
        accountHeadId: this.accountGridFilterObj[0].accountHeadId,
        accountClassificationID: this.accountGridFilterObj[0].accountClassificationID,
        accountGroupID: this.accountGridFilterObj[0].accountGroupID,
        accountTypeID: this.accountGridFilterObj[0].accountTypeID,
        code: this.accountGridFilterObj[0].code,
        accountHeadName: this.accountGridFilterObj[0].accountHeadName,
        isControlAC: this.accountGridFilterObj[0].isControlAC,
        isManualVoucher: this.accountGridFilterObj[0].isManualVoucher,
        createdBy: this.accountGridFilterObj[0].createdBy,
        isactive: this.accountGridFilterObj[0].isactive
      })
    });


  }


  getAccountingClassificationDetails() {
    this.accountingService.getAccountingClassificationDetails().subscribe(a => {

      this.accountingclassificatinObj = a;

    });
  }

  isControlACValue(event) {


    if (event.checked) {
      this.AccountingHeadForm.get('AccountingHeadFormAction').patchValue({
        isControlAC: this.isControlV = 1
      });
    } else {
      this.AccountingHeadForm.get('AccountingHeadFormAction').patchValue({
        isControlAC: this.isControlV = 0
      });
    }
  }


  isManualVoucherValue(event) {

    if (event.checked) {
      this.AccountingHeadForm.get('AccountingHeadFormAction').patchValue({
        isManualVoucher: this.isManualVoucherV = 1
      });
    } else {
      this.AccountingHeadForm.get('AccountingHeadFormAction').patchValue({
        isManualVoucher: this.isManualVoucherV = 0
      });
    }
  }


  onBtnClearAction() {

    this.fieldDisable = false;
    this.saveBtnMode = true;

    this.actionHeading = 'Add New - Accounting Head';

    this.AccountingHeadForm = this.fb.group({
      AccountingHeadFormSearch: this.fb.group({
        searchDescription: [''],
        searchGroupName: [''],
        searchAccountType: [''],
        searchAccountHeadCode: [''],
        searchAccountHeadName: ['']
      }),

      AccountingHeadFormAction: this.fb.group({
        accountHeadId: '',
        accountClassificationID: '',
        accountGroupID: '',
        accountTypeID: '',
        code: '',
        accountHeadName: '',
        isControlAC: this.isControlV = 0,
        isManualVoucher: this.isManualVoucherV = 0,
        createdBy: '1',
        isactive: '1'
      })
    });
    // this.AccountingHeadForm.get('AccountingHeadFormAction').enable();

  }

  getAccountingGroupDetails(): void {

    this.accountingHeadService.getAccountingGroupDetails().subscribe(a => {
      this.accountGroupObj = a;

    });


  }
  getAccountingTypeDetails(): void {

    this.accountingHeadService.getAccountingTypeDetails(0, 0).subscribe(a => {
      this.accountTypeObj = a;
    });


  }
  getAccountHeadDetailsBySearch() {

    //  if (this.AccountingHeadForm.get('AccountingHeadFormAction').valid) {
    //let a = this.AccountingHeadForm.get('AccountingHeadFormAction').value;
    let a = 0;
    let b = this.AccountingHeadForm.get('AccountingHeadFormSearch.searchDescription').value;
    let c = this.AccountingHeadForm.get('AccountingHeadFormSearch.searchGroupName').value;
    let d = this.AccountingHeadForm.get('AccountingHeadFormSearch.searchAccountType').value;
    let e = this.AccountingHeadForm.get('AccountingHeadFormSearch.searchAccountHeadCode').value;
    let f = this.AccountingHeadForm.get('AccountingHeadFormSearch.searchAccountHeadName').value;
    // if (a == "" && a === undefined) {
    //   a = 0;
    // }
    if (b == "") {
      b = 0;
    }
    if (c == "") {
      c = 0;
    }
    if (d == "") {
      d = 0;
    }
    if (e == "") {
      e = 0;
    }
    if (f == "") {
      f = 0;
    }


    console.log(a, b, c, d, e, f);
    this.getGridDetails(a, b, c, d, e, f);
    //} 

  }

  clearSearchAccountHead() {
    this.AccountingHeadForm = this.fb.group({
      AccountingHeadFormSearch: this.fb.group({
        searchDescription: [''],
        searchGroupName: [''],
        searchAccountType: [''],
        searchAccountHeadCode: [''],
        searchAccountHeadName: ['']
      }),

      AccountingHeadFormAction: this.fb.group({
        accountHeadId: '',
        accountClassificationID: '',
        accountGroupID: '',
        accountTypeID: '',
        code: '',
        accountHeadName: '',
        isControlAC: this.isControlV = 0,
        isManualVoucher: this.isManualVoucherV = 0,
        createdBy: '1',
        isactive: '1'
      })
    });
    this.getGridDetails(0, 0, 0, 0, 0, 0);
  }
  getGridDetails(a, b, c, d, e, f): void {
    this.accountingHeadService.getGridDetails(a, b, c, d, e, f).subscribe(a => {
      this.accountGridObj = a;
      this.dataSource = new MatTableDataSource<AccountingGrid>(this.accountGridObj);
      this.dataSource.data = this.accountGridObj = a;
      this.dataSource.paginator = this.paginator;
    });

  }

  onBtnSaveAccountHead() {
    this.AccountingHeadForm.get('AccountingHeadFormAction').markAllAsTouched();

    if (this.AccountingHeadForm.get('AccountingHeadFormAction').valid) {
      console.log('valid');
      if (this.createBtn) {
        this.AccountingHeadForm.get('AccountingHeadFormAction').patchValue({
          accountHeadId: '0',
          createdBy: '1',
          isactive: '1'
        });
      } else {
        this.AccountingHeadForm.get('AccountingHeadFormAction').patchValue({
          createdBy: '1'
        });
      }


      let a = this.AccountingHeadForm.get('AccountingHeadFormAction').value;
      console.log(a);
      this.accountingHeadService.createAccountingHead(a).subscribe(a => {

        this.getGridDetails(0, 0, 0, 0, 0, 0);
      });

      this.onBtnClearAction();

    }



  }



  cfn(a) {
    console.log(a);
  }

}
