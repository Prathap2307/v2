import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DayclosemonitorComponent } from './dayclosemonitor.component';

describe('DayclosemonitorComponent', () => {
  let component: DayclosemonitorComponent;
  let fixture: ComponentFixture<DayclosemonitorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DayclosemonitorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DayclosemonitorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
