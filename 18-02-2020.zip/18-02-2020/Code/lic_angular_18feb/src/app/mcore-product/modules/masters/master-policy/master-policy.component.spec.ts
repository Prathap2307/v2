import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterPolicyComponent } from './master-policy.component';

describe('MasterPolicyComponent', () => {
  let component: MasterPolicyComponent;
  let fixture: ComponentFixture<MasterPolicyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterPolicyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
