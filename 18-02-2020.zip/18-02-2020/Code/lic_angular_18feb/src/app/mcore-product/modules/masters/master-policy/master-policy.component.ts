import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-policy',
  templateUrl: './master-policy.component.html',
  styleUrls: ['./master-policy.component.css']
})
export class MasterPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
