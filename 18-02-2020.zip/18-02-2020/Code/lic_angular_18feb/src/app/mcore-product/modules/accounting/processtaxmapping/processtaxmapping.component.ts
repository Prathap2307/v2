import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material';
import { AccountingTaxMapping, AccountingTaxProcess, ModeObjDropDown, BasedOnObjDropDown, TaxStructure } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingtaxmapping';
import { MatTableDataSource } from '@angular/material/table';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { AccountingprocesstaxmappingService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingprocesstaxmapping.service';
@Component({
  selector: 'app-processtaxmapping',
  templateUrl: './processtaxmapping.component.html',
  styleUrls: ['./processtaxmapping.component.css']
})
export class ProcesstaxmappingComponent implements OnInit {

  dummyObj: string[];
  
  accountTaxProcessObj : AccountingTaxProcess [];
  AccountingTaxMappingForm: FormGroup;
 

  AccountingTaxStructureColumns: string[] = ['Edit', 'taxStructureName', 'description'];
  AccountingTaxMappingColumns: string[] = ['Edit', 'taxStructureDetailsName', 'parentTax'];

  get AccountingTaxMappingAction() {
    return this.AccountingTaxMappingForm.get('AccountingTaxMappingAction') as FormGroup;
  }

  accountTaxMappingGridObj: AccountingTaxMapping[] = [];
  accountTaxMappingFilterGridObj: AccountingTaxMapping[] = [];
  taxStructureGridObj: TaxStructure[] = [];
  taxStructureFilterGridObj: TaxStructure[] = [];
  dataTaxMap = new MatTableDataSource<AccountingTaxMapping>(this.accountTaxMappingGridObj);

  dataTaxStructure = new MatTableDataSource<TaxStructure>(this.taxStructureGridObj);

  constructor(private fb: FormBuilder, private accountingProcessTaxmappingService: AccountingprocesstaxmappingService) { }
  
  
  basedOnObjDropDown: BasedOnObjDropDown[] = [
    {
      "basedOnDropDownID": 1, "basedOnDropDownText": "Premium"
    }
  ];
  modeObjDropDown: ModeObjDropDown[] = [
    {
      "modeDropDownID": 1, "modeDropDownText": "Absolute"
    },
    {
      "modeDropDownID": 2, "modeDropDownText": "Percentage"
    }
  ];

  ngOnInit() {
    
  
    this.dataTaxStructure = new MatTableDataSource<TaxStructure>(this.taxStructureGridObj);
    this.dataTaxMap = new MatTableDataSource<AccountingTaxMapping>(this.accountTaxMappingGridObj);

    this.AccountingTaxMappingForm = this.fb.group({
      AccountingTaxMappingSearch: this.fb.group({
        searchTaxStructure: [''],
      }),
      AccountingTaxMappingAction: this.fb.group({
        taxProcessID: [''],
        taxStructureDetailsName: ['', [Validators.required]],
        parentTax: [''],
        modes: ['', [Validators.required]],
        taxValue: [''],
      })
    });
    this.getAllTaxProcess();
    this.getAllTaxStructure();
  }
  // Creates new user.
  createNewTaxMapping(id: number): AccountingTaxMapping {
    return {
      


      taxMappingID: 0,
      taxStructureID: 1,
      taxStructureDetailID: 1,
      taxProcessID: this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.taxProcessID').value,
      createdBy: 1,
      taxStructureDetailsName: this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.taxStructureDetailsName').value,
      taxStructureName: "",
      description: "",
      fromDate: new Date(),
      toDate: new Date(),
      exemptedInID: 1,
      parentsTaxStructure: 1,
      modes: 1,
      parentTax : this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.parentTax').value,modeName: "", 
      hierarchyID: 1,
      taxValue: 1,
      isReferred: 1

    };
  }
  btngvEdit_Click(a) {
    
        //this.saveBtnMode = true;
      // this.actionHeading = 'Edit - Accounting Head';
      // this.createBtn = false;
      // this.fieldDisable = false;
    this.taxStructureFilterGridObj = this.taxStructureGridObj.filter((unit) => unit.taxStructureID == a);
    let tid = this.taxStructureFilterGridObj[0].taxStructureID;
      //  console.log(this.taxStructureFilterGridObj[0].taxStructureID);
      this.accountingProcessTaxmappingService.getTaxProcessDetailsByID(tid).subscribe( o => {
        this.dataTaxMap.data = this.accountTaxMappingGridObj = o;
        
      } );
  }


  btngvEditTaxMap_Click(a) {
   //console.log(a);
   this.accountTaxMappingFilterGridObj = this.accountTaxMappingGridObj.filter((unit) => unit.taxMappingID == a);
   console.log(this.accountTaxMappingGridObj[0]);
   this.AccountingTaxMappingForm = this.fb.group({
    AccountingTaxMappingSearch: this.fb.group({
      searchTaxStructure: [''],
    }),
    AccountingTaxMappingAction: this.fb.group({
      taxProcessID: this.accountTaxMappingGridObj[0].taxProcessID,
      taxStructureDetailsName:  this.accountTaxMappingGridObj[0].taxStructureDetailsName,
      parentTax:  this.accountTaxMappingGridObj[0].parentTax,
      modes: this.accountTaxMappingGridObj[0].modes,
      taxValue: this.accountTaxMappingGridObj[0].taxValue,
    })
  });

}

  onBtnSaveProcessTaxMap() {
    this.AccountingTaxMappingForm.get('AccountingTaxMappingAction').markAllAsTouched();
    if(this.AccountingTaxMappingForm.get('AccountingTaxMappingAction').valid){
      this.dataTaxMap.data.push(this.createNewTaxMapping(this.dataTaxMap.data.length + 1));
      this.dataTaxMap.filter = "";
    }


  }

  onBtnSaveTaxStructure() {
   
    //console.log(this.dataTaxMap.data.forEach());
    //this.dataTaxMap.data.forEach()

    this.dataTaxMap.data.forEach((fe) => {
    
        fe.createdBy = 5
      
    });
    let a = this.dataTaxMap.data;
    console.log(this.dataTaxMap.data);
    this.accountingProcessTaxmappingService.createProcessTaxMap(a).subscribe(a => {

      //   //this.getAccountingGroupGridDetails();
    });

  }

  getAllTaxProcess() {
    this.accountingProcessTaxmappingService.getAllTaxProcess().subscribe(a => {
      this.accountTaxProcessObj = a;
    });

  }

  getAllTaxStructure() {
    this.AccountingTaxMappingAction.addControl("taxStructureName", new FormControl(''))
    //this.AccountingTaxMappingForm.get('AccountingTaxMappingAction.taxStructureName').patchValue('');
    let a = this.AccountingTaxMappingForm.get('AccountingTaxMappingAction').value;

    
   //console.log(a);
    this.accountingProcessTaxmappingService.getAllTaxStructure(a).subscribe(b => {
   //   this.dataTaxStructure = new MatTableDataSource<TaxStructure>(this.taxStructureGridObj);
      this.dataTaxStructure.data = this.taxStructureGridObj = b;
    });

  }


  onBtnClearTaxMap() {
    this.AccountingTaxMappingForm = this.fb.group({
      AccountingTaxMappingSearch: this.fb.group({
        searchTaxStructure: [''],
      }),
      AccountingTaxMappingAction: this.fb.group({
        taxProcessID: '',
        taxStructureDetailsName:  '',
        parentTax:  '',
        modes: '',
        taxValue: '',
      })
    });
   

  }

  onBtnClearTaxStructure(){
    
  }

  cfn(a) {
    console.log(a);
  }
}
