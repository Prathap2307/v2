import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-organization',
  templateUrl: './client-organization.component.html',
  styleUrls: ['./client-organization.component.css']
})
export class ClientOrganizationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
