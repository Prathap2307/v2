import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-glconfigurations',
  templateUrl: './glconfigurations.component.html',
  styleUrls: ['./glconfigurations.component.css']
})
export class GlconfigurationsComponent implements OnInit {
  dummyObj: string;
  dataSource;
	displayedColumns: string[] = ['View', 'Edit', 'PaymentMode', 'AccountingProcess', 'Variant', 'CreditGLCode', 'DebitGLCode', 'CreditNarration', 'DebitNarration' ];

  constructor() { }

  ngOnInit() {
  }

}
