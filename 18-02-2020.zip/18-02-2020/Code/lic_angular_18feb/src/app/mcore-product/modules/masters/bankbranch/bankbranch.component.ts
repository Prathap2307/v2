import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BankBranch } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';
import { BankbranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/bankbranch.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { typeWithParameters } from '@angular/compiler/src/render3/util';

@Component({
  selector: 'app-bankbranch',
  templateUrl: './bankbranch.component.html',
  styleUrls: ['./bankbranch.component.css']
})
export class BankbranchComponent implements OnInit {
  BankBranchForm: FormGroup;
  BankBranchFormAction: FormGroup;
  bankBranchObj: BankBranch[];
  bankBranchFilteredObj: BankBranch[] = [];
  bankBranchHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  bankBranchColumns: string[] = ['View', 'Edit', 'Delete', 'bankName', 'bankCityName', 'description', 'ifscCode', 'micrCode'];
  bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.bankBranchdataSource.paginator = this.paginator;
  }
  // bankName: any = ['IND', 'PNB', 'HDFC']
  // bankCity: any = ['Koramangala', 'Indiranagar', 'Madiwala']
  constructor(
    private fb: FormBuilder,
    private bankBranchService: BankbranchService
  ) { }

  ngOnInit() {
    // this.getBankBranchNameDetails();
    // this.getBankBranchCitydetails();
    this.getBankBranchDetails();
    this.onChanges();  
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        branchId: [''],
        bankId: [''],
        bankCityId: [''],
        bankName:
          [
            '',
            // [Validators.required]
          ],
        bankCityName:
          [
            '',
            //[Validators.required]
          ],
        description:
          ['',
            //[Validators.required]
          ],
        ifscCode:
          [
            '',
            //[Validators.required]
          ],
        micrCode:
          [
            '',
            //[Validators.required]
          ],
        createdBy: [1],
        createdOn: [new Date()],
      })
    });
  }
  onChanges() {
    // this.BankBranchForm.get('BankBranchFormAction').valueChanges.subscribe(val => {
    //   console.log(val);
    // });
  }
  getBankBranchDetails(): void {    
    this.bankBranchService.getBankBranchdetails(0, 0, 0, null, null, null ).subscribe(
      bankBranchObj => {
        this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
        this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
        this.bankBranchdataSource.paginator = this.paginator;
      });
  }

  // Grid View Button Events
  public btngvView_Click(a) {
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.bankId == a);
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        bankId: { value: this.bankBranchFilteredObj[0].bankId, disabled: true },
        bankCityId: { value: this.bankBranchFilteredObj[0].bankCityId, disabled: true },
        description: { value: this.bankBranchFilteredObj[0].description, disabled: true },
        ifscCode: {value: this.bankBranchFilteredObj[0].ifscCode, disabled: true},
        micrCode: {value: this.bankBranchFilteredObj[0].micrCode, disabled: true},
        createdBy: { value: this.bankBranchFilteredObj[0].createdBy, disabled: true },
        createdOn: { value: this.bankBranchFilteredObj[0].createdOn, disabled: true },
      })
    });
    this.bankBranchHeading = 'View - Bank Branch';
    this.btnModeSave = false;
    this.btnSaveText = '';
  }

  // Grid Edit Button Events
  public btngvEdit_Click(a) {
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.bankId == a);
    this.BankBranchForm = this.fb.group({
      ssearchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        bankId: { value: this.bankBranchFilteredObj[0].bankId, disabled: false },
        bankCityId: { value: this.bankBranchFilteredObj[0].bankCityId, disabled: false },
        description: { value: this.bankBranchFilteredObj[0].description, disabled: false },
        ifscCode: {value: this.bankBranchFilteredObj[0].ifscCode, disabled: false},
        micrCode: {value: this.bankBranchFilteredObj[0].micrCode, disabled: false},
        createdBy: { value: this.bankBranchFilteredObj[0].createdBy, disabled: false },
        createdOn: { value: this.bankBranchFilteredObj[0].createdOn, disabled: false },
        //isActive: { value: this.bankBranchFilteredObj[0].isActive, disabled: false },
      })
    });
    this.bankBranchHeading = 'Edit - Bank Branch';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
  }

  // Grid Delete Button Events
  public btngvDelete_Click(a) {
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        bankId: { value: a, disabled: false },
        bankCityId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: 1,
        createdOn: new Date(),
        deletedBy: 1,
        deletedOn: new Date(),
        isActive: 0,
      })
    });
    let v = this.BankBranchForm.get('BankBranchFormAction').value;
    console.log(v);
    //this.bankBranchService.deleteProduct(v).subscribe(result => { console.log(result); this.getProductDetails() });
  }

  getBankBranchCitydetails() {
    let bankId = this.BankBranchFormAction.controls.bankId.value;
    this.bankBranchService.getBankBranchCityDetails(bankId).subscribe(bankBranchObj => this.bankBranchObj = bankBranchObj);
  }
  getBankBranchNameDetails() {
    let bankId = this.BankBranchFormAction.controls.bankId.value;
    this.bankBranchService.getBankBranchNameDetails(bankId).subscribe(bankBranchObj => this.bankBranchObj = bankBranchObj);
  }

  onBtnSaveBankBranchClick() {    
    this.BankBranchForm.get('BankBranchFormAction').patchValue({
      createdBy: '1',
      createdOn: new Date(),
      isActive: '1',
    });
    this.BankBranchForm.controls.BankBranchFormAction.markAllAsTouched();
    if (this.BankBranchForm.controls.BankBranchFormAction.valid) {
      let a = this.BankBranchForm.controls.BankBranchFormAction.value;
      //this.bankBranchService.addBankBranch(a).subscribe(result => { this.getBankBranchDetails() });
      this.BankBranchForm.controls.BankBranchFormAction.reset();
    }
  }
  onBtnSearchBankBranchDetails(){
    // if (this.BankBranchForm.controls.searchPlanName.valid) {
    //   let searchValue = this.BankBranchForm.controls.searchPlanName.value;
    //   console.log(searchValue);
    //   this.productService.getProductBySearch(searchValue).subscribe(val => this.productObj = val);
    // }
    // else {
    // }
  }
  onBtnClearBankBranchClick() {   
    this.BankBranchForm.controls.BankBranchFormAction.reset();
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        bankId: { value: '', disabled: false },
        bankCityId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
        isActive: { value: '', disabled: false },
      })
    });
  }
  onBtnSearchClearBankBranch() {
    this.BankBranchForm.reset();
    this.getBankBranchDetails();
  }
}
