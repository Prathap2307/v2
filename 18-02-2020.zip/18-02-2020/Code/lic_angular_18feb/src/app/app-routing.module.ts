import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentComponent } from './mcore-product/modules/masters/department/department.component';
import { InsurerComponent } from './mcore-product/modules/masters/insurer/insurer.component';
import { ZoneComponent } from './mcore-product/modules/masters/zone/zone.component';
import { DivisionComponent } from './mcore-product/modules/masters/division/division.component';
import { BranchComponent } from './mcore-product/modules/masters/branch/branch.component';
import { OrganizationComponent } from './mcore-product/modules/masters/organization/organization.component';
import { DesignationComponent } from './mcore-product/modules/masters/designation/designation.component';
import { GradeComponent } from './mcore-product/modules/masters/grade/grade.component';

import { MastersComponent } from './mcore-product/modules/masters/masters.component';
import { MasterPageComponent } from './mcore-product/mcore-common/core/master-page/master-page.component';
import { RegistrationComponent } from './mcore-product/modules/registration/registration/registration.component';
import { LoginComponent } from './mcore-product/modules/login/login/login.component';

const routes: Routes = [   
  {
    path: 'registration',
    component: RegistrationComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  // {	
  //   path: 'master-page',
  //   component: MasterPageComponent
  // },
  // {	
  //   path: 'masters',
  //   component: MastersComponent
  // },
  // {	
  //   path: 'masters/department',
  //   component: DepartmentComponent
  // },
  // {	
  //   path: 'masters/organization',
  //   component: OrganizationComponent
  // },
  // {	
  //   path: 'masters/designation',
  //   component: DesignationComponent
  // },
  // {	
  //   path: 'masters/grade',
  //   component: GradeComponent
  // },
  // {	
  //   path: 'masters/insurer',
  //   component: InsurerComponent
  // },
  // {	
  //   path: 'masters/zone',
  //   component: ZoneComponent
  // },
  // {	
  //   path: 'masters/division',
  //   component: DivisionComponent
  // },
  // {	
  //   path: 'masters/branch',
  //   component: BranchComponent
  // },
  {	
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


 }
