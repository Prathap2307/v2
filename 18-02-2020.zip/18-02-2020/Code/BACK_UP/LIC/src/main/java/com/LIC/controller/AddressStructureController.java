package com.LIC.controller;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.entity.DistrictModal;
import com.LIC.entity.Response;
import com.LIC.entity.StateModal;
import com.LIC.entity.TalukaModal;
import com.LIC.entity.TransactionContext;
import com.LIC.service.BranchService;
import com.LIC.service.CountryService;
import com.LIC.service.DistrictService;
import com.LIC.service.RegionService;
import com.LIC.service.StateService;
import com.LIC.service.TalukService;
import com.LIC.utils.dataobject.ValueObject;

/**
 * @author Pradip/Rahul
 *
 *2019
 */

@RestController
public class AddressStructureController {
	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(AddressStructureController.class);
	
	@Autowired
	public AddressStructureController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	@Autowired 	BranchService 		branchService;
	@Autowired 	CountryService		countryService;
	@Autowired 	StateService		stateService;
	@Autowired 	DistrictService		districtService;
	@Autowired 	TalukService		talukService;
	@Autowired 	RegionService		regionService;

	
	@RequestMapping(value = "/GetAllCountries", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	 public ResponseEntity<Response> getAllCountries(@RequestHeader HttpHeaders httpHeader) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, countryService.getAllCountries(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	///for REgion
	@RequestMapping(value = "/getAllRegion", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	 public ResponseEntity<Response> getAllRegion(@RequestHeader HttpHeaders httpHeader) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, regionService.getAllRegion(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	//end 
	@RequestMapping(value = "/getAllStateByCountryId", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> getAllStateByCountryId(@RequestHeader HttpHeaders httpHeader,
			@RequestParam HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject			object			= null;
		List<StateModal>	stateModalList	= null;	
		
		try {
			
			object			= new ValueObject(allRequestParams);
			stateModalList	= stateService.getAllStateByCountryId(object.getLong("CountryId"));
			
			return responseGenerator.successResponse(context, stateModalList , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/getAllDistrictsByStaeId", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> getAllDistrictsByStaeId(@RequestHeader HttpHeaders httpHeader,
			@RequestParam HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject			object				= null;
		List<DistrictModal>	districtModalList	= null;	
		
		try {
			
			object				= new ValueObject(allRequestParams);
			districtModalList	= districtService.getAllDistrictByStateId(object.getLong("StateId"));
			
			return responseGenerator.successResponse(context, districtModalList , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/getAllTaluksByDistrictId", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Response> getAllTalukasByDistrictId(@RequestHeader HttpHeaders httpHeader,
			@RequestParam HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject			object				= null;
		List<TalukaModal>	talukaModalList		= null;	
		
		try {
			
			object				= new ValueObject(allRequestParams);
			talukaModalList		= talukService.getAllTalukasByDistrictId(object.getLong("DistrictId"));
			
			return responseGenerator.successResponse(context, talukaModalList , HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
}
