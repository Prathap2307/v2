package com.LIC.constant;

public class Constant {

	public static final String ERROR							= "Error";
	public static final String SUCCESS							= "Success";
}
