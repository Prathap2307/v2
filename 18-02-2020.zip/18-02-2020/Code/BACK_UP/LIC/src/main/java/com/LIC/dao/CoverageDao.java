package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.LIC.entity.CoverageExclusionNewModal;
import com.LIC.entity.CoverageModal;
import com.LIC.entity.CoverageUINMapModal;
import com.LIC.resource.ResourceManager;
import com.LIC.utils.dataobject.ValueObject;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class CoverageDao {
		
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryDao.class);
	
	
	public ValueObject InsertOrUpdateCoverage(CoverageModal coverageModal, List<CoverageUINMapModal> coverageUINMapModalList) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ValueObject				outObject			= null;
		long 					coverageID 			= 0;
		String 					errorSuccessMsg 	= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spInsertOrUpdateCoverageNew(?,?,?,?,?,?,?,?,?,?,?,?,?)");
			conn.setAutoCommit(false);
			outObject	= new ValueObject();
			
            if (coverageModal.getCoverageID() != 0) {
            	DeleteCoverageUINMap(coverageModal.getCoverageID(), conn);
            }
                      
            coverageID 		= InsertOrUpdateCoverageNew(coverageModal, conn);
                          System.out.println("coverageID >>"+coverageID);
            if(coverageUINMapModalList != null && coverageUINMapModalList.size() > 0 && coverageID > 0) {
            	for(CoverageUINMapModal modal : coverageUINMapModalList) {
            		
            		modal.setCoverageID(coverageID);
            		errorSuccessMsg	= InsertOrUpdateCoverageUINMap(modal, conn);
            	}
            }
          outObject.put("UINMapStatus", errorSuccessMsg);          
          outObject.put("CoverageID", coverageID);          
          conn.commit();
		} catch(Exception e) {
			e.printStackTrace();
			logger.error("fff >>" + e.getMessage(),  e);
			outObject.put("CoverageError", e.getMessage());
			conn.rollback();
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return outObject;
	}
		
	public long InsertOrUpdateCoverageNew(CoverageModal coverageModal, Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		ResultSet 				result 				= null;
		
		try {
			if(conn == null)
				conn   		= ResourceManager.getConnection();
			
			cstm 		= conn.prepareCall("call spInsertOrUpdateCoverageNew(?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			cstm.setLong(1, 		coverageModal.getCoverageID());
			cstm.setString(2, 		coverageModal.getCoverageName());
			cstm.setString(3, 		coverageModal.getDescription());
			cstm.setDouble(4, 		coverageModal.getHouseHoldLimitPerYear());
			cstm.setLong(5, 		coverageModal.getLineOfBusinessID());
			cstm.setLong(6, 		coverageModal.getSectionID());
			cstm.setLong(7, 		coverageModal.getCreatedBy());
			cstm.setTimestamp(8, 	coverageModal.getCreatedOn());
			cstm.setShort(9, 		coverageModal.getIsActive());
			cstm.setString(10, 		coverageModal.getCoverCode());
			cstm.setLong(11, 		coverageModal.getType());
			cstm.setDouble(12, 		coverageModal.getAmountPercentage());
			cstm.registerOutParameter(13, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(13);
			
			if(result != null) {
				while(result.next()) {
					return result.getLong("CoverageID");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			conn.rollback();
		} finally {
			cstm.close();
		}
		return 0;
	}

	public String InsertOrUpdateCoverageUINMap(CoverageUINMapModal coverageUINMapModal, Connection conn) throws Exception {
		CallableStatement		cstm				= null;
		
		try {
			
			if(conn == null) 
				conn   		= ResourceManager.getConnection();
			
			cstm 		= conn.prepareCall("call spInsertOrUpdateCoverageUINMap(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			cstm.setLong(1, 		coverageUINMapModal.getUinID());
			cstm.setString(2, 		coverageUINMapModal.getDescription());
			cstm.setLong(3, 		coverageUINMapModal.getCoverageID());
			cstm.setString(4, 		coverageUINMapModal.getUinNumber());
			cstm.setLong(5, 		coverageUINMapModal.getMaximumMaturityAge());
			cstm.setLong(6, 		coverageUINMapModal.getMaximumMaturityAgeType());
			cstm.setTimestamp(7, 	coverageUINMapModal.getUinEffectiveFrom());
			cstm.setTimestamp(8, 	coverageUINMapModal.getUinEffectiveTo());
			cstm.setLong(9, 		coverageUINMapModal.getMinimumEntryAge());
			cstm.setLong(10, 		coverageUINMapModal.getMinimumEntryAgeType());
			cstm.setLong(11, 		coverageUINMapModal.getMaximumEntryAge());
			cstm.setLong(12, 		coverageUINMapModal.getMaximumEntryAgeType());
			cstm.setDouble(13,  	coverageUINMapModal.getMinimumSumAssured());
			cstm.setLong(14, 		coverageUINMapModal.getMinimumSumAssuredType());
			cstm.setDouble(15, 		coverageUINMapModal.getMaximumSumAssured());
			cstm.setDouble(16, 		coverageUINMapModal.getMaximumSumAssuredType());
			cstm.setShort(17, 		coverageUINMapModal.getIsActive());
			cstm.setString(18, 		coverageUINMapModal.getVersionNo());
			cstm.setDouble(19, 		coverageUINMapModal.getMinimumFreeCoverLimit());
			cstm.setDouble(20, 		coverageUINMapModal.getMaximumFreeCoverLimit());
			cstm.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
			conn.rollback();
			
			logger.error("fff 123>>" + e.getMessage(),  e);
			return e.getMessage();
		} finally {
			cstm.close();
		}
		return "Success";
	}
	
	public boolean IsCoverageExistNew(long coverageID, String description, long lineOfBusinessID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn = ResourceManager.getConnection();
			cstm = conn.prepareCall("call spIsCoverageExistNew(?,?,?,?)");
			cstm.setLong(1, 	coverageID);
			cstm.setString(2, 	description);
			cstm.setLong(3, 	lineOfBusinessID);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(4);
			
			if(result != null) {
				if(result.next()) {
					return result.getInt("ExistCount") > 0 ? true : false; 
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;	
		}
		return false;
	}
	
	public List<CoverageExclusionNewModal> GetCoverageExclusionByCoverageID(long coverageID) throws Exception {
		CallableStatement					cstm							= null;
		Connection 							conn 							= null;
		ResultSet 							result 							= null;
		List<CoverageExclusionNewModal> 	coverageExclusionNewModalList	= null;
		CoverageExclusionNewModal 			coverageExclusionNew 			= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetCoverageExclusionByCoverageID(?,?)");
			cstm.setLong(1, coverageID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				coverageExclusionNewModalList	= new ArrayList<CoverageExclusionNewModal>();
				
				while(result.next()) 	{
					coverageExclusionNew = new CoverageExclusionNewModal();
					coverageExclusionNew.setCoverageExclusionID(result.getLong("ExclusionID"));
					coverageExclusionNew.setDescription(result.getString("Description"));
					coverageExclusionNewModalList.add(coverageExclusionNew);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return coverageExclusionNewModalList;
    }
	
	public List<CoverageUINMapModal> GetAllCoverageUINMapByCoverageID(long CoverageID) throws Exception {
		CallableStatement			cstm						= null;
		Connection 					conn 						= null;
		ResultSet 					result 						= null;
		List<CoverageUINMapModal> 	coverageUINMapModallList	= null;
		CoverageUINMapModal 		coverageUINMapModal 		= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllCoverageUINMapByCoverageID(?,?)");
			cstm.setLong(1, CoverageID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				coverageUINMapModallList	= new ArrayList<CoverageUINMapModal>();
				
				while(result.next()) {
					coverageUINMapModal = new CoverageUINMapModal();
					coverageUINMapModal.setUinID(result.getLong("UINId"));
					coverageUINMapModal.setDescription(result.getString("Description"));
					coverageUINMapModal.setCoverageID(result.getLong("CoverageID"));
					coverageUINMapModal.setUinNumber(result.getString("UINNumber"));
					coverageUINMapModal.setMaximumMaturityAge(result.getLong("MaximumMaturityAge"));
					coverageUINMapModal.setMaximumMaturityAgeType(result.getInt("MaximumMaturityAgeType"));
					coverageUINMapModal.setUinEffectiveFrom(result.getTimestamp("UINEffectiveFrom"));
					coverageUINMapModal.setUinEffectiveTo(result.getTimestamp("UINEffectiveTo"));
					coverageUINMapModal.setMinimumEntryAge(result.getInt("MinimumEntryAge"));
					coverageUINMapModal.setMinimumEntryAgeType(result.getInt("MinimumEntryAgeType"));
					coverageUINMapModal.setMaximumEntryAge(result.getInt("MaximumEntryAge"));
					coverageUINMapModal.setMaximumEntryAgeType(result.getInt("MaximumEntryAgeType"));
					coverageUINMapModal.setMinimumSumAssured(result.getInt("MinimumSumAssured"));
					coverageUINMapModal.setMinimumSumAssuredType(result.getInt("MinimumSumAssuredType"));
					coverageUINMapModal.setMaximumSumAssured(result.getInt("MaximumSumAssured"));
					coverageUINMapModal.setMaximumSumAssuredType(result.getInt("MaximumSumAssuredType"));
					coverageUINMapModal.setIsActive(result.getShort("IsActive"));
					coverageUINMapModal.setVersionNo(result.getString("VersionNo"));
					coverageUINMapModal.setMinimumFreeCoverLimit(result.getDouble("MinimumFreeCoverLimit"));
					coverageUINMapModal.setMaximumFreeCoverLimit(result.getDouble("MaximumFreeCoverLimit"));
					
					coverageUINMapModallList.add(coverageUINMapModal);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		return coverageUINMapModallList;
	}
	
	public String DeleteCoverage(long CoverageID, long DeletedBy) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		String					deletedStatus		= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteCoverage(?,?,?)");
			cstm.setLong(1, CoverageID);
			cstm.setLong(2, DeletedBy);
			cstm.registerOutParameter(3, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				if(result.next()) {
					deletedStatus = result.getString("DeletedStatus");
				}
			}
			 
			return deletedStatus;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return "Error";
	}
	
	public String DeleteCoverageExclusionNew(long CoverageID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		String					deletedStatus		= null;
		
		try {
			conn 		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteCoverageExclusionNew(?,?)");
			cstm.setLong(1, CoverageID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				if(result.next()) {
					deletedStatus = result.getString("DeletedStatus");
				}
			}
			 
			return deletedStatus;
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		return "ERROR";
	}
	
	public String DeleteCoverageUINMap(long CoverageID , Connection conn) throws Exception {
		
		CallableStatement		cstm				= null;
		ResultSet 				result 				= null;
		String					deletedStatus		= null;
		
		try {
			
			if(conn == null)
				conn   		= ResourceManager.getConnection();
				
			cstm 		= conn.prepareCall("call spDeleteCoverageUINMap(?,?)");
			cstm.setLong(1, CoverageID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				if(result.next()) {
					deletedStatus = result.getString("DeletedStatus");
				}
			}
			
			return deletedStatus;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
		}
		return "Error";
	}
	
	//pending all down :
	//pending Sp not get
	public List<CoverageExclusionNewModal> spGetAllExclusionByCoverageID(long CoverageID) throws Exception {
		
		CallableStatement					cstm							= null;
		Connection 							conn 							= null;
		ResultSet 							result 							= null;
		List<CoverageExclusionNewModal> 	coverageExclusionNewModalList	= null;
		CoverageExclusionNewModal 			coverageExclusionNew 			= null;
		
		try {

			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllExclusionByCoverageID(?,?)");
			cstm.setLong(1, CoverageID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				coverageExclusionNewModalList	= new ArrayList<CoverageExclusionNewModal>();
				
				while(result.next()) {
					coverageExclusionNew = new CoverageExclusionNewModal();
					
					coverageExclusionNewModalList.add(coverageExclusionNew);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm = null;
			ResourceManager.freeConnection(conn);
			conn = null;
		}
		
		return coverageExclusionNewModalList;
	}
	
	public List<CoverageModal> GetAllCoveragesByProductID(long userID, long lineOfBusinessID, String searchData) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<CoverageModal>  	coveragemodallist 	= null;
		CoverageModal 			coverage 			= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetFirePlanCoverageFactorMapping(?,?,?,?)");
			cstm.setLong(1, 	userID);
			cstm.setLong(2, 	lineOfBusinessID);
			cstm.setString(3, 	searchData);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(4);
			
			if(result != null) {
				coveragemodallist	= new ArrayList<CoverageModal>();
				
				while(result.next()) {
					coverage = new CoverageModal();
					coveragemodallist.add(coverage);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return coveragemodallist;
	}
		
	public List<CoverageModal> GetAllFireRateFactor(long lineOfBusinessID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<CoverageModal>  	coveragemodallist 	= null;
		CoverageModal 			coverage 			= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllFireRateFactor(?,?)");
			cstm.setLong(1, lineOfBusinessID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				coveragemodallist	= new ArrayList<CoverageModal>();
				
				while(result.next()) {
					coverage = new CoverageModal();
					coveragemodallist.add(coverage);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return coveragemodallist;
	}
	
	public boolean IsProductExsistforinsurance(long ProdcutID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spIsProductExistForInsurance(?,?)");
			cstm.setLong(1, ProdcutID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				int count = result.getRow();
				return count > 0 ? true : false;
			}
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return false;
	}
	
	public String DeleteFirePlanCoverageFactorMapping(long ID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteFirePlanCoverageFactorMapping(?,?) ");
			cstm.setLong(1,	ID);
            cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				if(result.next()) {
					return result.getString("");
				}
			}
            
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
		
	}
	
	public List<CoverageModal> GetAllFirePlanCoverageFactorRate(long lineOfBusinessID, long ProductID, long CoverageID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<CoverageModal>  	coveragemodallist 	= null;
		CoverageModal 			coverage 			= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllFirePlanCoverageFactorRateMapping(?,?,?,?)");
			cstm.setLong(1, lineOfBusinessID);
			cstm.setLong(2, ProductID);
			cstm.setLong(3, CoverageID);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(4);
			
			if(result != null) {
				coveragemodallist	= new ArrayList<CoverageModal>();
				
				while(result.next()) {
					coverage = new CoverageModal();
					
					coveragemodallist.add(coverage);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return coveragemodallist;
	}
	
	public List<CoverageModal> GetAllCoveragesByProductID(long ProductID) throws Exception  {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<CoverageModal> 	coverageModalList	= null;
		CoverageModal 			coverage 			= null;
		
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetCoverageByProductID(?,?)");
			cstm.setLong(1, ProductID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				coverageModalList	= new ArrayList<CoverageModal>();

				while(result.next()) {
					coverage = new CoverageModal();
					coverage.setDescription(result.getString("Description"));
					coverage.setCoverageID(result.getLong("ID"));
					coverage.setCoverageName(result.getString("CoverageName"));
					coverage.setIsBaseCoverage(result.getShort("IsBaseCoverage"));
					coverage.setIsSelectable(result.getShort("IsSelectable"));
					coverage.setTypeofCoverID(result.getLong("TypeofCoverID"));
					coverage.setTypeOfCover(result.getString("TypeofCover"));
					coverage.setCalculationID(result.getLong("CalculationID"));
					coverage.setPackageID(result.getLong("PackageID"));
					coverage.setPackages(result.getString("Package"));
					coverage.setPackageRate(result.getDouble("PackageRate"));
					coverage.setIsStampDutyApplicable(result.getShort("IsStampDutyApplicable"));
					coverage.setStamDutyType(result.getInt("StamdutyType"));
					coverage.setStampDutyRate(result.getDouble("StampDutyRate"));
					coverage.setEffectFromDate(result.getTimestamp("EffectFromDate"));
					coverage.setEffectToDate(result.getTimestamp("EffectToDate"));
					coverage.setProductId(result.getLong("ProductID"));
					coverageModalList.add(coverage);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return coverageModalList;
    }
	
	public List<CoverageModal> GetAllProductByLOB(long productID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<CoverageModal>  	coveragemodallist = null;
		CoverageModal 			coverage = null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllProductByLOB(?,?)");
			cstm.setLong(1, productID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				coveragemodallist	= new ArrayList<CoverageModal>();
				
				while(result.next()) {
					
					coverage = new CoverageModal();
					coverage.setProductId(result.getLong("ProductID"));
					coverage.setDescription(result.getString("Description"));
					coverage.setProductTypeID(result.getLong("ProductTypeID"));
					coverage.setDescription(result.getString("ProductType"));
					
					coveragemodallist.add(coverage);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return coveragemodallist;
	}
		
	public List<CoverageModal> GetAllNewBusinessLevelofDocument(long ProductID) throws Exception  {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<CoverageModal> 	coverageModalList	= null;
		CoverageModal 			coverage 			= null;
		
		try {
		 
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetCoverageByProductID(?,?)");
			cstm.setLong(1, ProductID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				coverageModalList	= new ArrayList<CoverageModal>();
				
				while(result.next()) {
					coverage = new CoverageModal();
					coverage.setDescription(result.getString("Description"));
					coverage.setCoverageID(result.getLong("CoverageID"));
					coverage.setCoverageName(result.getString("CoverageName"));
					coverage.setIsBaseCoverage(result.getShort("IsBaseCoverage"));
					coverage.setIsSelectable(result.getShort("IsSelectable"));
					coverage.setTypeofCoverID(result.getLong("TypeofCoverID"));
					coverage.setTypeOfCover(result.getString("TypeofCover"));
					coverage.setCalculationID(result.getLong("CalculationID"));
					coverage.setPackageID(result.getLong("PackageID"));
					coverage.setPackages(result.getString("Package"));
					coverage.setPackageRate(result.getDouble("PackageRate"));
					coverageModalList.add(coverage);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return coverageModalList;
    }
		
	public List<CoverageModal> GetCoverageCalculationByProductIDNew(long ProductID) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<CoverageModal> 	CoverageModalList	= null;
		CoverageModal 			coverage = null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetCoverageCalculationByProductIDNew(?,?)");
			cstm.setLong(1, ProductID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				CoverageModalList	= new ArrayList<CoverageModal>();
				while(result.next())
				{
					coverage = new CoverageModal();
					coverage.setDescription(result.getString("Description"));
					coverage.setCoverageID(result.getLong("CoverageID"));
					coverage.setCoverageName(result.getString("CoverageName"));
					coverage.setIsBaseCoverage(result.getShort("IsBaseCoverage"));
					coverage.setIsSelectable(result.getShort("IsSelectable"));
					coverage.setTypeofCoverID(result.getLong("TypeofCoverID"));
					coverage.setTypeOfCover(result.getString("TypeofCover"));
					coverage.setCalculationID(result.getLong("CalculationID"));
					coverage.setCalculationName(result.getString("CalculationName"));
					coverage.setCoverageID(result.getLong("CoverageID"));
					CoverageModalList.add(coverage);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return CoverageModalList;
    }
		
	
	
		
		
		/*
		 public void InsertOrUpdate(CoverageInfo objCoverageNewInfo, List<CoverageNatureOfServiceNewInfo> objCoverageNatureOfServiceNewInfoList, List<CoverageBenefitNewInfo> objCoverageBenefitNewDalList, List<CoverageExclusionNewInfo> objCoverageExclusionNewDalList, List<CoveragePrivilegeNewInfo> objCoveragePrivilegeNewDalList, List<CoverageUINMapInfo> objCoverageUINMapInfoList)
        {
            int CoverageId = -1;
            CoverageNatureOfServiceNewDAL prdNatObj = new CoverageNatureOfServiceNewDAL();
            CoverageBenefitNewDAL prdCovObj = new CoverageBenefitNewDAL();
            CoveragePrivilegeNewDAL prdPreObj = new CoveragePrivilegeNewDAL();
            CoverageExclusionNewDAL prdExeObj = new CoverageExclusionNewDAL();
            CoverageUINMapDAL objCoverageUINMapDAL = new CoverageUINMapDAL();
            try
            {
                if (objCoverageNewInfo != null)
                {
                    Database DB = DatabaseFactory.CreateDatabase("ConnectionString");

                    using (DbConnection dbConn = DB.CreateConnection())
                    {
                        dbConn.Open();
                        DbTransaction dbTrans = dbConn.BeginTransaction();

                        try
                        {
                            if (objCoverageNewInfo.ID != 0)
                            {
                                prdNatObj.Delete(objCoverageNewInfo.ID, DB, dbTrans);
                                prdCovObj.Delete(objCoverageNewInfo.ID, DB, dbTrans);
                                prdPreObj.Delete(objCoverageNewInfo.ID, DB, dbTrans);
                                prdExeObj.Delete(objCoverageNewInfo.ID, DB, dbTrans);
                                objCoverageUINMapDAL.Delete(objCoverageNewInfo.ID, DB, dbTrans);
                            }
                            using (DbCommand Cmd = DB.GetStoredProcCommand("spInsertOrUpdateCoverageNew"))
                            {
                                DB.AddInParameter(Cmd, "@CoverageID", DbType.Int32, objCoverageNewInfo.ID);
                                DB.AddInParameter(Cmd, "@CoverageName", DbType.String, objCoverageNewInfo.CoverageName);
                                DB.AddInParameter(Cmd, "@Description", DbType.String, objCoverageNewInfo.Description);
                                DB.AddInParameter(Cmd, "@CoverageHouseholdLimitPerYear", DbType.Decimal, objCoverageNewInfo.HouseHoldLimitPerYear);
                                DB.AddInParameter(Cmd, "@LineOfBusinessID", DbType.Int32, objCoverageNewInfo.LineOfBusiness.LineOfBusinessID);
                                DB.AddInParameter(Cmd, "@SectionID", DbType.Int32, objCoverageNewInfo.SectionID);
                                DB.AddInParameter(Cmd, "@CreatedBy", DbType.Int32, Convert.ToInt32(objCoverageNewInfo.CreatedBy));
                                DB.AddInParameter(Cmd, "@CreatedOn", DbType.DateTime, objCoverageNewInfo.CreatedOn);
                                DB.AddInParameter(Cmd, "@IsActive", DbType.Boolean, objCoverageNewInfo.Deleted);
                                DB.AddInParameter(Cmd, "@CoverCode", DbType.String, objCoverageNewInfo.CoverCode);
                                DB.AddInParameter(Cmd, "@Type", DbType.Int32, objCoverageNewInfo.Type);
                                DB.AddInParameter(Cmd, "@AmountPercentage", DbType.Decimal, objCoverageNewInfo.AmountPercentage);
                                CoverageId = Convert.ToInt32(DB.ExecuteScalar(Cmd, dbTrans));
                                objCoverageNewInfo.ID = CoverageId;

                                foreach (CoverageNatureOfServiceNewInfo NatureOfServiceNewInfo in objCoverageNatureOfServiceNewInfoList)
                                {
                                    prdNatObj.InsertOrUpdate(CoverageId, NatureOfServiceNewInfo, DB, dbTrans);
                                }
                                foreach (CoverageBenefitNewInfo BenefitNewInfo in objCoverageBenefitNewDalList)
                                {
                                    prdCovObj.InsertOrUpdate(CoverageId, BenefitNewInfo, DB, dbTrans);
                                }

                                foreach (CoverageExclusionNewInfo ExclusionNewInfo in objCoverageExclusionNewDalList)
                                {
                                    prdExeObj.InsertOrUpdate(CoverageId, ExclusionNewInfo, DB, dbTrans);
                                }

                                foreach (CoveragePrivilegeNewInfo PrivilegeNewInfo in objCoveragePrivilegeNewDalList)
                                {
                                    prdPreObj.InsertOrUpdate(CoverageId, PrivilegeNewInfo, DB, dbTrans);
                                }

                                foreach (CoverageUINMapInfo objCoverageUINMapInfo in objCoverageUINMapInfoList)
                                {
                                    objCoverageUINMapDAL.InsertOrUpdateCoverageUINMap(CoverageId, objCoverageUINMapInfo, DB, dbTrans);
                                }
                            }
                            dbTrans.Commit();
                        }
                        catch (Exception Exc)
                        {
                            dbTrans.Rollback();

                            Logger.Write(Exc.Message.ToString());
                        }
                    }

                }


            }
            catch (SqlException sqlExc)
            {
                Logger.Write(sqlExc.Message.ToString());
            }
        }
		 */
}
