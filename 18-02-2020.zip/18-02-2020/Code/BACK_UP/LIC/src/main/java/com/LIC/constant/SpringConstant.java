package com.LIC.constant;

public class SpringConstant {

	public static final String JDBCTEMPLATE_JDBC							= "jdbcTemplatejdbc";
	public static final String JDBCTEMPLATE_IVMASTER_POSTGRES				= "jdbcTemplateIVMasterPostgres";
	public static final String JDBCTEMPLATE_TRANSCARGO_SQLSERVER			= "jdbcTemplateTranscargoSQLServer";
	public static final String JDBCTEMPLATE_CARGO_SQLSERVER					= "jdbcTemplateCargoSQLServer";
	public static final String JDBCTEMPLATE_CARGO_FACT_POSTGRES				= "jdbcTemplateCargoFactPostgres";
	public static final String JDBCTEMPLATE_DASHBOARD_POSTGRES				= "jdbcTemplateDasboardPostgres";
	public static final String JDBCTEMPLATE_IV_TRANSCARGO_SQLSERVER 		= "jdbcTemplateIvTransCargoSQLServer";

	public static final String TRANSACTIONMANAGER_JDBC						= "transactionManagerjdbc";
	public static final String TRANSACTIONMANAGER_IVMASTER_POSTGRES			= "transactionManagerIVMasterPostgres";
	public static final String TRANSACTIONMANAGER_TRANSCARGO_SQLSERVER		= "transactionManagerTranscargoSQLServer";
	public static final String TRANSACTIONMANAGER_CARGO_SQLSERVER			= "transactionManagerCargoSQLServer";
	public static final String TRANSACTIONMANAGER_CARGO_FACT_POSTGRES		= "transactionManagerCargoFactPostgres";
	public static final String TRANSACTIONMANAGER_DASHBOARD_POSTGRES		= "transactionManagerDashboardPostgres";
	public static final String TRANSACTIONMANAGER_IV_TRANSCARGO_SQLSERVER   = "transactionManagerIvTransCargoSQLServer";

	public static final String JDBC_FILE_JDBC								= "classpath:jdbc.properties";
}
