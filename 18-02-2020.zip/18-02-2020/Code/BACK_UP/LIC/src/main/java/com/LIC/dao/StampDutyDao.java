package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.LIC.entity.StampDutyModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class StampDutyDao {
	 
	@Autowired						JdbcTemplate jdbcTemplate;
	private static final Logger logger = Logger.getLogger(StampDutyDao.class);
	
	public boolean IsStampDutyExistForNB(long  StampDutyID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spIsStampDutyExistForNB(?,?) ");
			cstm.setLong(1, StampDutyID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				if(result.next()) {
					return result.getInt("ExistCount") > 0 ? true : false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return false;
	}
   
	public boolean IsStampDutyExist(StampDutyModal  stampduty) throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spIsStampDutyExist(?,?,?,?,?) ");
			cstm.setLong(1, 		stampduty.getStampDutyID());
			cstm.setLong(2, 		stampduty.getProductID());
			cstm.setLong(3, 		stampduty.getCoverageID());
			cstm.setString(4, 		stampduty.getReceiptNumber());
			cstm.registerOutParameter(5, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(5);
			
			if(result != null) {
				if(result.next()) {
					return result.getInt("ExistCount") > 0 ? true : false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return false;
	}

	public void InsertUpdateStampDuty(StampDutyModal  stampduty) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		
		try {
			conn  			= ResourceManager.getConnection();
			
			cstm 			= conn.prepareCall("call spInsertUpdateStampDuty(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
			cstm.setLong(1, 		stampduty.getStampDutyID());
			cstm.setLong(2, 		stampduty.getProductID());
			cstm.setLong(3, 		stampduty.getCoverageID());
			cstm.setDouble(4,		stampduty.getStampDutyAmount());
			cstm.setString(5,		stampduty.getMudrakNumber());
			cstm.setString(6,		stampduty.getPayOrderNumber());
			cstm.setString(7,		stampduty.getReceiptNumber());
			cstm.setTimestamp(8, 	stampduty.getPaymentDate());
			cstm.setDouble(9, 		stampduty.getBalanceStampDutyAmount());
			cstm.setDouble(10, 		stampduty.getTriggerAmount());
			cstm.setLong(11, 		stampduty.getCreatedBy());
			cstm.setDouble(12, 		stampduty.getAdvanceDepositAmount());
			cstm.setLong(13, 		stampduty.getType());
            cstm.setTimestamp(14, 	stampduty.getChallanEndDate());
            cstm.setString(15, 		stampduty.getDefaceNumber());
            cstm.setTimestamp(16, 	stampduty.getDefaceDate());
            cstm.setString(17, 		stampduty.getCertificateNumber());
            cstm.setTimestamp(18, 	stampduty.getCertificateDate());
            cstm.setString(19, 		stampduty.getIntimationEmailAddress());
            cstm.setString(20, 		stampduty.getIntimationMobileNumber());
			
            cstm.execute();
            
		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
	}
	
	public List<StampDutyModal> GetStampDuty(long stampDutyID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<StampDutyModal>	stampDutyModallList = null;
		StampDutyModal 			stampDuty 			= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetStampDuty(?,?)");
			cstm.setLong(1, stampDutyID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				stampDutyModallList	= new ArrayList<StampDutyModal>();
				
				while(result.next()) {
					stampDuty = new StampDutyModal();
					stampDuty.setStampDutyID(result.getLong("StampDutyID"));
					stampDuty.setStampDutyAmount(result.getDouble("StampDutyAmount"));
				    stampDuty.setMudrakNumber(result.getString("MudrakNumber")); 
				    stampDuty.setPayOrderNumber(result.getString("PayOrderNumber"));
				    stampDuty.setReceiptNumber(result.getString("ReceiptNumber"));
				    stampDuty.setPaymentDate(result.getTimestamp("PaymentDate"));
				    stampDuty.setBalanceStampDutyAmount(result.getDouble("BalanceStampDutyAmount"));
				    stampDuty.setBalanceStampDutyAmount(result.getDouble("CurrentBalanceStampDutyAmount"));
				    stampDutyModallList.add(stampDuty);
				}
			}
			return stampDutyModallList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return null;
	}
	
	public List<StampDutyModal> GetAllStampDuty() throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		List<StampDutyModal>	stampDutyModallList = null;
		StampDutyModal 			stampDuty 			=null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllStampDuty(?)");
			cstm.registerOutParameter(1, OracleTypes.CURSOR);
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				stampDutyModallList	= new ArrayList<StampDutyModal>();
				
				while(result.next()) {
					stampDuty = new StampDutyModal();
					stampDuty.setStampDutyID(result.getLong("StampDutyID"));
					stampDuty.setStampDutyAmount(result.getDouble("StampDutyAmount"));
				    stampDuty.setMudrakNumber(result.getString("MudrakNumber")); 
				    stampDuty.setPayOrderNumber(result.getString("PayOrderNumber"));
				    stampDuty.setReceiptNumber(result.getString("ReceiptNumber"));
				    stampDuty.setPaymentDate(result.getTimestamp("PaymentDate"));
				    stampDuty.setBalanceStampDutyAmount(result.getDouble("BalanceStampDutyAmount"));
				    stampDuty.setTriggerAmount(result.getDouble("TriggerAmount"));
				    stampDuty.setStatus(result.getLong("Status"));
				    stampDuty.setProductID(result.getLong("ProductID"));
				    stampDuty.setCoverageID(result.getLong("CoverageID"));
				    stampDuty.setProductName(result.getString("ProductName"));
				    stampDuty.setCoverageName(result.getString("CoverageName"));
				    stampDuty.setAdvanceDepositAmount(result.getDouble("AdvanceDepositAmount"));
				    stampDuty.setType(result.getLong("Type"));
				    stampDuty.setChallanEndDate(result.getTimestamp("ChallanEndDate"));
				    stampDuty.setDefaceNumber(result.getString("DefaceNumber"));
				    stampDuty.setCertificateNumber(result.getString("CertificateNumber"));
				    stampDuty.setCertificateDate(result.getTimestamp("CertificateDate"));
				    stampDuty.setDefaceDate(result.getTimestamp("DefaceDate"));
				    stampDuty.setIntimationEmailAddress(result.getString("INTIMATIONEMAILADDRESS"));
				    stampDuty.setIntimationMobileNumber(result.getString("INTIMATIONMOBILENUMBER"));
					stampDutyModallList.add(stampDuty);
				}
			}
			return stampDutyModallList;
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		
		return null;
	}

	public String DeleteStampDuty(long stampDutyID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteStampDuty(?,?)");
			cstm.setLong(1, stampDutyID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				if(result.next()) {
					return result.getString("DeletedStatus");
				}
			}
					
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		
		return "Error";
	}

}
