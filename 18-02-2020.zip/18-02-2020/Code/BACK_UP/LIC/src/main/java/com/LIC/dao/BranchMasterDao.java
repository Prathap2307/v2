package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.entity.BranchModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class BranchMasterDao 
{
	
	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(BranchMasterDao.class);
	
	public List<BranchModal> GetParentBranch(long OrganisationID, long BranchID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		BranchModal				branchModal			= null;
		List<BranchModal>		branchModalList		= null;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetParentBranch(?,?,?) ");
			
			cstm.setLong(1, OrganisationID); 
			cstm.setLong(2, BranchID); 
			cstm.registerOutParameter(3, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);
			
			if(result != null) {
				
				branchModalList	= new ArrayList<BranchModal>();
				
				while(result.next()) {
					
					branchModal = new BranchModal();
					branchModal.setOrganisationId(OrganisationID);
					branchModal.setBranchId(result.getLong("BranchID"));
					branchModal.setBranchName(result.getString("BranchName"));
					branchModalList.add(branchModal);
				}
			}
			
			return branchModalList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return branchModalList;
	}
	
	public long InsertOrUpdate(BranchModal branch) throws Exception {

			CallableStatement		cstm				= null;
			Connection 				conn 				= null;
			long 					branchId 			= 0;
			
			try {

				//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
				conn   		= ResourceManager.getConnection();
				
				cstm 		= conn.prepareCall("call spInsertOrUpdateBranch(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
				
				 cstm.setLong(1,branch.getOrganisationId());
				 cstm.setLong(2,branch.getBranchId());
				 cstm.setString(3,branch.getShortName());
				 cstm.setString(4,branch.getBranchName());
				 cstm.setTimestamp(5, branch.getWorkingDate());
				 cstm.setLong(6,branch.getParentBranchId());
				 cstm.setLong(7,branch.getCreatedBy());
				 cstm.setTimestamp(8,branch.getCreatedOn());
				 cstm.setShort(9,branch.getIsActive());
				 cstm.setString(10,branch.getAddress1());
				 cstm.setString(11,branch.getAddress2());
				 cstm.setString(12,branch.getAddress3());
				 cstm.setString(13,branch.getAddress4());
				 cstm.setLong(14,branch.getCountryID());
				 cstm.setLong(15,branch.getStateID());
				 cstm.setLong(16,branch.getDistrictID());
				 cstm.setLong(17,branch.getTalukID());
				 cstm.setString(18,branch.getZipCode());
				 cstm.setString(19,branch.getPhoneNo());
				 cstm.setString(20,branch.getMobileNo());
				 cstm.setString(21,branch.getConferenceNo());
				 cstm.setString(22,branch.getFaxNo());
				 cstm.setString(23,branch.getEmail());
				 cstm.setLong(24,branch.getPageTypeID());
				 cstm.setLong(25,branch.getRegionalID());
				 cstm.setLong(26,branch.getZoneID());
				 cstm.setLong(27,branch.getDivisionID());
				 cstm.setString(28,branch.getGstNo());
				 cstm.setString(29,branch.getPanNo());
				 cstm.setString(30,branch.getLutNo());
				cstm.executeUpdate();
				
			
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage(), e);
			} finally {
				cstm.close();
				cstm	= null;
				ResourceManager.freeConnection(conn);
				conn	= null;
			}
			return branchId;
		}
	
	public BranchModal getBranchById(long branchid) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		BranchModal				branchModal			= null;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetBranchByID(?,?) ");
			
			cstm.setLong(1, branchid); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {
		    	
		    	while(result.next()) {
		    	
			    	branchModal = new BranchModal();
			    	
			    	branchModal.setOrganisationId(result.getLong("OrganisationID"));
			    	branchModal.setBranchId(result.getLong("BranchID"));
			    	branchModal.setShortName(result.getString("ShortName"));
			    	branchModal.setWorkingDate(result.getTimestamp("WorkingDate"));
			    	branchModal.setBranchName(result.getString("BranchName"));
			    	//branchModal.setParentBranchId(result.getLong("ParentBranchID"));
			    	branchModal.setIsActive(result.getShort("IsActive"));
			    	branchModal.setBranchTypeId(result.getShort("BranchTypeID"));
			    	branchModal.setAddress1(result.getString("Address1"));
			    	branchModal.setAddress2(result.getString("Address2"));
			    	branchModal.setAddress3(result.getString("Address3"));
			    	branchModal.setAddress4(result.getString("Address4"));
			    	branchModal.setCountryID(result.getLong("CountryID"));		    	
			    	branchModal.setCountryName(result.getString("Country"));	
			    	branchModal.setStateID(result.getLong("StateID"));
			    	branchModal.setStateName(result.getString("State"));
			    	branchModal.setDistrictID(result.getLong("DistrictID"));
			    	branchModal.setDistrictName(result.getString("District"));
			    	branchModal.setTalukID(result.getLong("TalukID"));	
			    	branchModal.setTalukaName(result.getString("Taluk"));
			    	branchModal.setZipCode(result.getString("ZipCode"));
			    	branchModal.setPhoneNo(result.getString("PhoneNo"));
			    	branchModal.setMobileNo(result.getString("MobileNo"));
			    	branchModal.setConferenceNo(result.getString("ConferenceNo"));
			    	branchModal.setFaxNo(result.getString("FaxNo"));
			    	branchModal.setEmail(result.getString("Email"));
			    	//branchModalsetInti(result.getLong("IntimationEmailID"));
			    	branchModal.setZoneID(result.getLong("Zonalid"));
			    	branchModal.setDivisionID(result.getLong("Divisionid"));
			    	System.out.println("dddd: "+result.getLong("parentBranchid"));
			    	branchModal.setParentBranchId(result.getLong("parentBranchid"));
			    	branchModal.setRegionalID(result.getLong("Regionalid"));
			    	branchModal.setGstNo(result.getString("GSTNo"));
			    	branchModal.setPanNo(result.getString("PanNo"));
			    	branchModal.setLutNo(result.getString("LUTNo"));
			    }
		    }
		
		    return branchModal;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return branchModal;
	}
	
	public List<BranchModal> getAllBranches(BranchModal branch) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		BranchModal				branchModal			= null;
		List<BranchModal>		branchModalList		= null;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllBranches(?,?,?,?,?,?,?,?,?) ");
			
			cstm.setString(1, branch.getShortName()); 
			cstm.setString(2, branch.getBranchName()); 
			cstm.setLong(3, branch.getParentBranchId()); 
			cstm.setLong(4, branch.getCountryID()); 
			cstm.setLong(5, branch.getStateID()); 
			cstm.setLong(6, branch.getDistrictID()); 
			cstm.setLong(7, branch.getOrganisationId()); 
			cstm.setLong(8, branch.getPageTypeID()); 
			cstm.registerOutParameter(9, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(9);
			
			if(result != null) {
				
				branchModalList	= new ArrayList<BranchModal>();
				
				while(result.next()) {
					
					branchModal = new BranchModal();
					branchModal.setBranchId(result.getLong("BranchID"));
					branchModal.setShortName(result.getString("ShortName"));
					branchModal.setBranchName(result.getString("BranchName"));
					branchModal.setParentBranchId(result.getLong("ParentBranchID"));
					branchModal.setParentBranch(result.getString("ParentBranch"));
					System.out.println("ddd>"+result.getShort("IsActive") + " > "+result.getString("BranchName"));
					branchModal.setIsActive(result.getShort("IsActive"));
					branchModalList.add(branchModal);
				}
			}
			
			return branchModalList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return branchModalList;
	}
	
	public List<BranchModal> getAllDivisionByZoanlID(long zonalId) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		BranchModal				branchModal			= null;
		List<BranchModal>		branchModalList		= null;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllDivisionByZoanlID(?,?) ");
			
			cstm.setLong(1, zonalId); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				
				branchModalList	= new ArrayList<BranchModal>();
				
				while(result.next()) {
					
					branchModal = new BranchModal();
					branchModal.setOrganisationId(result.getLong("OrganisationID"));
					branchModal.setBranchId(result.getLong("BranchID"));
					branchModal.setShortName(result.getString("ShortName"));
					branchModal.setBranchName(result.getString("BranchName"));
					branchModal.setWorkingDate(result.getTimestamp("WorkingDate"));
					branchModal.setParentBranchId(result.getLong("ParentBranchID"));
					branchModal.setAddressId(result.getLong("AddressID"));
					branchModal.setIsActive(result.getShort("IsActive"));
					branchModal.setBranchTypeId(result.getShort("BranchTypeID"));
					branchModal.setZoneID(result.getLong("ZonalID"));
					branchModal.setDivisionID(result.getLong("DivisionID"));
					branchModal.setPageTypeID(result.getLong("PageTypeID"));
					branchModalList.add(branchModal);
				}
			}
			
			return branchModalList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return branchModalList;
	}
	
	public boolean activateBranch(long branchid) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		boolean 				flag				= false;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spActivateBranch(?,?) ");
			
			cstm.setLong(1, branchid); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				
				while(result.next()) {
					
					flag = result.getInt("updatedRows") > 0 ? true  : false;
				}
			}
			return flag;
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return false;
	}
	
	public String deleteBranch(long branchid, int deletedBy) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		String					deletedStatus		= null;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spDeleteBranch(?,?,?) ");
			
			cstm.setLong(1, branchid); 
			cstm.setInt(2, deletedBy); 
			cstm.registerOutParameter(3, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(3);

			if(result != null) {
				if(result.next()) {
					deletedStatus = result.getString("DeletedStatus");
				}
			}
			
			return deletedStatus;
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return "ERROR";
	}
	
	public List<BranchModal> getAllBranchesByPageTypeID(long pageTypeId) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		BranchModal				branchModal			= null;
		List<BranchModal>		branchModalList		= null;
		
		try {
			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllBranchByPageTypeID(?,?) ");
			
			cstm.setLong(1, pageTypeId); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();

			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				
				branchModalList	= new ArrayList<BranchModal>();
				
				while(result.next()) {
					
					branchModal = new BranchModal();
					branchModal.setBranchId(result.getLong("BranchID"));
					branchModal.setBranchName(result.getString("Branch"));
					branchModal.setPageTypeID(pageTypeId);
					branchModalList.add(branchModal);
				}
			}
			
			return branchModalList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return branchModalList;
	}
}
