package com.LIC.controller;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LIC.entity.Response;
import com.LIC.entity.TransactionContext;
import com.LIC.service.ChannelService;
import com.LIC.utils.dataobject.ValueObject;

@RestController
public class ChannelManagementController {

	private ResponseGenerator responseGenerator;

	private static final Logger logger = Logger.getLogger(ConfigurationController.class);
	
	@Autowired
	public ChannelManagementController(ResponseGenerator responseGenerator) {
		this.responseGenerator = responseGenerator;
	}
	
	@Autowired 	ChannelService 		channelService;
	
	
	@GetMapping(value = "/GetAllMainChannel", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> getAlMainChannel(@RequestHeader HttpHeaders httpHeaders) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, channelService.GetMainChannel(), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetAllChannel", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> GetAllChannel(@RequestHeader HttpHeaders httpHeaders,
			@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, channelService.GetAllChannel(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetAllBranchesByOrganisionId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetAllBranchesByOrganisionId(@RequestHeader HttpHeaders httpHeaders,@RequestParam("OrganisationID") long orgId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeaders);
		
		try {
			
			return responseGenerator.successResponse(context, channelService.GetAllBranchesByOrgId(orgId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/InsertChannel", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertChannel(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, channelService.InsertChannel(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/InsertOrUpdateChannel", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertOrUpdateChannel(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, channelService.InsertOrUpdateChannel(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsChannelExist", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsChannelExist(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, channelService.IsChannelExist(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/DeleteChannel", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> DeleteChannel(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, channelService.DeleteChannel(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/IsSubChannelExist", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> IsSubChannelExist(@RequestHeader HttpHeaders httpHeader,
			@RequestBody HashMap<Object, Object> allRequestParams ) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, channelService.IsSubChannelExist(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/InsertSubChannel", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> InsertSubChannel(@RequestHeader HttpHeaders httpHeader,	@RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			return responseGenerator.successResponse(context, channelService.InsertSubChannel(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/GetSubChannel", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Response> GetSubchannel(@RequestHeader HttpHeaders httpHeader, @RequestBody HashMap<Object, Object> allRequestParams) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		ValueObject	object	= null;
		
		try {
			
			object	= new ValueObject(allRequestParams);
			
			return responseGenerator.successResponse(context, channelService.GetSubChannel(object), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetSubChannelDetailsbySubChannelID", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetSubChannelDetailsbySubChannelID(@RequestHeader HttpHeaders httpHeader,@RequestParam("SubChannelID") long subChannelId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, channelService.GetSubChannelDetailsbySubChannelID(subChannelId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/GetChannelById", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetChannelById(@RequestHeader HttpHeaders httpHeader,@RequestParam("ChannelID") long channelId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, channelService.GetChannelById(channelId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/DeleteSubChannel", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> DeleteSubChannel(@RequestHeader HttpHeaders httpHeader,@RequestParam("SubChannelID") long subChannelId) {
		
		TransactionContext context = responseGenerator.generateTransationContext(httpHeader);
		
		try {
			
			return responseGenerator.successResponse(context, channelService.DeleteSubChannel(subChannelId), HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return responseGenerator.errorResponse(context, e, HttpStatus.BAD_REQUEST);
		}
	}
}
