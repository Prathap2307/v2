package com.LIC.entity;

import java.io.Serializable;

public class CoverageNewModal implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private long 	coverageNewID;
	private long 	typeofCoverID;
	private long 	calculationID;
	private long 	coverageID;
	private String 	coverageName;
	private String 	coverCode;
	private String 	calculationName;
	private String 	typeofCover;
	private short 	isBaseCoverage;
	private short 	isSelectable;
	private double 	coverageMaxSumAssured;
	private double 	houseHoldLimitPerYear;
	private long 	packageID;
	private String 	packages;
	private double 	packageRate;
	
	
	public long getCoverageNewID() {
		return coverageNewID;
	}
	public long getTypeofCoverID() {
		return typeofCoverID;
	}
	public long getCalculationID() {
		return calculationID;
	}
	public long getCoverageID() {
		return coverageID;
	}
	public String getCoverageName() {
		return coverageName;
	}
	public String getCoverCode() {
		return coverCode;
	}
	public String getCalculationName() {
		return calculationName;
	}
	public String getTypeofCover() {
		return typeofCover;
	}
	public short getIsBaseCoverage() {
		return isBaseCoverage;
	}
	public short getIsSelectable() {
		return isSelectable;
	}
	public double getCoverageMaxSumAssured() {
		return coverageMaxSumAssured;
	}
	public double getHouseHoldLimitPerYear() {
		return houseHoldLimitPerYear;
	}
	public long getPackageID() {
		return packageID;
	}
	public String getPackages() {
		return packages;
	}
	public double getPackageRate() {
		return packageRate;
	}
	public void setCoverageNewID(long coverageNewID) {
		this.coverageNewID = coverageNewID;
	}
	public void setTypeofCoverID(long typeofCoverID) {
		this.typeofCoverID = typeofCoverID;
	}
	public void setCalculationID(long calculationID) {
		this.calculationID = calculationID;
	}
	public void setCoverageID(long coverageID) {
		this.coverageID = coverageID;
	}
	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}
	public void setCoverCode(String coverCode) {
		this.coverCode = coverCode;
	}
	public void setCalculationName(String calculationName) {
		this.calculationName = calculationName;
	}
	public void setTypeofCover(String typeofCover) {
		this.typeofCover = typeofCover;
	}
	public void setIsBaseCoverage(short isBaseCoverage) {
		this.isBaseCoverage = isBaseCoverage;
	}
	public void setIsSelectable(short isSelectable) {
		this.isSelectable = isSelectable;
	}
	public void setCoverageMaxSumAssured(double coverageMaxSumAssured) {
		this.coverageMaxSumAssured = coverageMaxSumAssured;
	}
	public void setHouseHoldLimitPerYear(double houseHoldLimitPerYear) {
		this.houseHoldLimitPerYear = houseHoldLimitPerYear;
	}
	public void setPackageID(long packageID) {
		this.packageID = packageID;
	}
	public void setPackages(String packages) {
		this.packages = packages;
	}
	public void setPackageRate(double packageRate) {
		this.packageRate = packageRate;
	}

	
}
