package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.bl.BranchBL;
import com.LIC.dao.BranchMasterDao;
import com.LIC.entity.BranchModal;
import com.LIC.utils.dataobject.ValueObject;

/**
 * @author Pradip/Rahul
 *
 *2019
 */
@Service
public class BranchService

{
	BranchBL 				branchBL 	= new BranchBL();
	BranchMasterDao 		branchDao 	= new BranchMasterDao();
	
	private static final Logger logger = Logger.getLogger(BranchService.class);
	
	public List<BranchModal>  GetParentBranch(long OrganisationID, long BranchID) throws Exception{
    	  
    	  try {
    		  
            	return branchDao.GetParentBranch(OrganisationID,BranchID);
    		  
    	  } catch(Exception e) {
    		  e.printStackTrace();
    		  logger.info("-- Error :"+e.getMessage());
    	  }
		return null;
      }
  
	public long InsertOrUpdateBranch(ValueObject branchObject)
    {
		BranchModal 		branch 			= null;
		
        try
        {
           branch 			= branchBL.createBranchInfoDto(branchObject);
           System.out.println("WORKINGDATE :"+branch);
           if(branch != null) {
        	   branchDao.InsertOrUpdate(branch);
           }
           
           return branch.getBranchId();
       
        } catch (Exception ex) {
            logger.info(ex.getLocalizedMessage());
        }
		return 0;
    }

      public BranchModal  GetBranchByIdSer(long BranchId) throws Exception{
		
    	  BranchModal 	branchModal		= null;
		
		try {
			
			branchModal  = branchDao.getBranchById(BranchId);
			System.out.println("branchModal >>"+branchModal.toString());
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		
		return branchModal;
	}
      
      public List<BranchModal>  getAllBranches(ValueObject branchObject) throws Exception{
    	  
    	  List<BranchModal> 	branchModalList		= null;
    	  BranchModal 			branchModal			= null;
    	  
    	  try {
    		  
    		  branchModal 			= branchBL.createBranchInfoDto(branchObject);
              
              if(branchModal != null) {
            	  
            	  branchModalList  = branchDao.getAllBranches(branchModal);
              }
    		  
    	  } catch(Exception e) {
    		  e.printStackTrace();
    		  logger.info("-- Error :"+e.getMessage());
    	  }
    	  
    	  return branchModalList;
      }
      
      public boolean activateBranch(long BranchId) throws Exception{
    	  
    	  try {
    		  
    		  return  branchDao.activateBranch(BranchId);
    		  
    	  } catch(Exception e) {
    		  e.printStackTrace();
    		  logger.info("-- Error :"+e.getMessage());
    	  }
		return false;
      }
      
      public List<BranchModal>  getAllDivisionByZoanlID(long zoanlID) throws Exception{
    	  
    	  List<BranchModal> 	branchModalList		= null;
    	  
    	  try {
              
            	branchModalList  = branchDao.getAllDivisionByZoanlID(zoanlID);
    		  
    	  } catch(Exception e) {
    		  e.printStackTrace();
    		  logger.info("-- Error :"+e.getMessage());
    	  }
    	  
    	  return branchModalList;
      }
      
      public List<BranchModal>  getAllBranchByPageTypeID(long pageTypeId) throws Exception{
    	  
    	  List<BranchModal> 	branchModalList		= null;
    	  
    	  try {
    		  
    		  branchModalList  = branchDao.getAllBranchesByPageTypeID(pageTypeId);
    		  
    	  } catch(Exception e) {
    		  e.printStackTrace();
    		  logger.info("-- Error :"+e.getMessage());
    	  }
    	  
    	  return branchModalList;
      }
      
      public String deleteBranchById(long branchId, int deletedby)  {
          
    	  try {
              String Status = branchDao.deleteBranch(branchId, deletedby);
              
              return Status;
          
          } catch (Exception ex) {
        	  ex.printStackTrace();
    		  logger.info("-- Error :"+ex.getMessage());
          }
          
          return "ERROR";
      }
}


