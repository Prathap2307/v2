package com.LIC.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.dao.CountryDao;
import com.LIC.entity.CountryModal;

/**
 * @author Pradip/Rahul
 *
 *2019
 */
@Service
public class CountryService

{

	@PersistenceContext
	EntityManager 			entityManager;
	
	CountryDao		countryMasterDao = new CountryDao();
	
	private static final Logger logger = Logger.getLogger(CountryService.class);

	public List<CountryModal>  getAllCountries() throws Exception{
		
		List<CountryModal>		countryList		= null;
		
		try {
			
			countryList = countryMasterDao.getAllCountries();
			
			return countryList;

		} catch(Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		
		return countryList;
	}
}