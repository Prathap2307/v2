package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.LIC.entity.MessageTemplateModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class MessageTemplateDao {
	@Autowired	JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryDao.class);
	
	public List<MessageTemplateModal> GetAllFeaturesForSMSEmail() throws Exception {
		
		CallableStatement				cstm						= null;
		Connection 						conn 						= null;
		ResultSet 						result 						= null;
		List<MessageTemplateModal>		messageTemplateModallist 	= null;
		MessageTemplateModal   			messageTemplateModal		= null;
		
		try {
			
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllFeaturesForSMSEmail(?)");
			cstm.registerOutParameter(1, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				messageTemplateModallist	= new ArrayList<MessageTemplateModal>();
				
				while(result.next()) {
					messageTemplateModal = new MessageTemplateModal();
					messageTemplateModal.setFeatureID(result.getLong("FeatureID"));
					messageTemplateModal.setFeatureName(result.getString("FeatureDescription"));
					messageTemplateModal.setCreatedBy(result.getLong("CreatedBy"));
					messageTemplateModal.setCreatedOn(result.getTimestamp("CreatedOn"));
					
					messageTemplateModallist.add(messageTemplateModal);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return messageTemplateModallist;
	}
	
	public int InsertOrUpdateMessageTemplates(MessageTemplateModal messageTemplate) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null; 
		ResultSet 				result 				= null;

		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spInsertMessageTemplates(?,?,?,?,?,?,?,?,?,?,?,?,?)");
			cstm.setLong(1, 	messageTemplate.getMessageTemplatesID());
			cstm.setLong(2, 	messageTemplate.getFeatureID());
			cstm.setLong(3, 	messageTemplate.getSmsIsActive());
			cstm.setLong(4, 	messageTemplate.getEmailIsActive());
			cstm.setString(5,	messageTemplate.getSmsTemplates());
			cstm.setString(6,	messageTemplate.getEmailTemplates());
			cstm.setString(7, 	messageTemplate.getSubject());
			cstm.setString(8, 	messageTemplate.getTemplateDescription());
		    cstm.setLong(9, 	messageTemplate.getEmailSMSTypeID());
		    cstm.setLong(10, 	messageTemplate.getWhatsAppIsActive());
		    cstm.setLong(11, 	messageTemplate.getTemplateTypeId());
		    cstm.setString(12, 	messageTemplate.getWhatsAppTemplates());
			cstm.registerOutParameter(13, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(13);
			if(result != null) {
				if(result.next()) {
					return result.getInt("OutParam");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;	
		}
		return 0;
	}
	
	public List<MessageTemplateModal> GetAllMessageTemplates() throws Exception {
		
		CallableStatement				cstm						= null;
		Connection 						conn 						= null;
		ResultSet 						result 						= null;
		MessageTemplateModal 			messageTemplateModal		= null;
		List<MessageTemplateModal>		messageTemplateModallist 	= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllMessageTemplates(?)");
			cstm.registerOutParameter(1, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);
			
			if(result != null) {
				messageTemplateModallist	= new ArrayList<MessageTemplateModal>();
				
				while(result.next()) {
					messageTemplateModal = new MessageTemplateModal();
					messageTemplateModal.setMessageTemplatesID(result.getLong("MessageTemplatesID"));
					messageTemplateModal.setMainMenuID(result.getLong("MAINMENUID"));
					messageTemplateModal.setMenuName(result.getString("MENUNAME"));
					messageTemplateModal.setFeatureID(result.getLong("FeatureID"));
					messageTemplateModal.setFeatureName(result.getString("FeatureName"));
					messageTemplateModal.setSmsIsActive(result.getShort("SMSISACTIVE"));
					messageTemplateModal.setEmailIsActive(result.getShort("EMAILISACTIVE"));
					messageTemplateModal.setSmsTemplates(result.getString("SMSTEMPLATES"));
					messageTemplateModal.setEmailTemplates(result.getString("EMAILTEMPLATES"));
					messageTemplateModal.setTemplateDescription(result.getString("TemplateDescription"));
					messageTemplateModal.setSubject(result.getString("SUBJECT"));
					messageTemplateModal.setWhatsAppTemplates(result.getString("WhatsAPPTemplates"));
					messageTemplateModal.setWhatsAppIsActive(result.getShort("WhatsAppIsActive"));
					messageTemplateModal.setTemplateTypeId(result.getLong("TemplateTypeId"));
					messageTemplateModal.setEmailSMSTypeID(result.getLong("EmailSMSTypeID"));
					messageTemplateModal.setEmailSMSTypeName(result.getString("EmailSMSType"));

					messageTemplateModallist.add(messageTemplateModal);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return messageTemplateModallist;
	}
	
	public List<MessageTemplateModal> GetAllMessageTemplatesByTemplateID(long TemplateID) throws Exception {
		CallableStatement				cstm						= null;
		Connection 						conn 						= null;
		ResultSet 						result 						= null;
		MessageTemplateModal 			messageTemplateModal 		= null;
		List<MessageTemplateModal>		messageTemplateModallist 	= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllMessageTemplatesByTemplateID(?,?)");
			cstm.setLong(1, TemplateID);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				messageTemplateModallist	= new ArrayList<MessageTemplateModal>();
				
				while(result.next()) {
					messageTemplateModal = new MessageTemplateModal();
					messageTemplateModal.setMessageTemplatesID(result.getLong("MessageTemplatesID"));
					messageTemplateModal.setMainMenuID(result.getLong("MAINMENUID"));
					messageTemplateModal.setMenuName(result.getString("MENUNAME"));
					messageTemplateModal.setFeatureID(result.getLong("FeatureID"));
					messageTemplateModal.setSmsIsActive(result.getShort("SMSISACTIVE"));
					messageTemplateModal.setEmailIsActive(result.getShort("EMAILISACTIVE"));
					messageTemplateModal.setSmsTemplates(result.getString("SMSTEMPLATES"));
					messageTemplateModal.setEmailTemplates(result.getString("EMAILTEMPLATES"));
					messageTemplateModal.setTemplateDescription(result.getString("TemplateDescription"));
					messageTemplateModal.setSubject(result.getString("SUBJECT"));
					messageTemplateModallist.add(messageTemplateModal);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		return messageTemplateModallist;
	}
	
	public List<MessageTemplateModal> GetAllMessageTemplatesByFeatureID(long featureId) throws Exception {
		CallableStatement				cstm						= null;
		Connection 						conn 						= null;
		ResultSet 						result 						= null;
		MessageTemplateModal 			messageTemplateModal 		= null;
		List<MessageTemplateModal>		messageTemplateModallist 	= null;
		
		try {
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllMessageTemplatesByFeatureID(?,?)");
			cstm.setLong(1, featureId);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);
			
			if(result != null) {
				messageTemplateModallist	= new ArrayList<MessageTemplateModal>();
				
				while(result.next()) {
					messageTemplateModal = new MessageTemplateModal();
					messageTemplateModal.setMessageTemplatesID(result.getLong("MessageTemplatesID"));
					messageTemplateModal.setMainMenuID(result.getLong("MAINMENUID"));
					messageTemplateModal.setMenuName(result.getString("MENUNAME"));
					messageTemplateModal.setFeatureID(result.getLong("FeatureID"));
					messageTemplateModal.setFeatureName(result.getString("FeatureName"));
					messageTemplateModal.setSmsIsActive(result.getShort("SMSISACTIVE"));
					messageTemplateModal.setEmailIsActive(result.getShort("EMAILISACTIVE"));
					messageTemplateModal.setSmsTemplates(result.getString("SMSTEMPLATES"));
					messageTemplateModal.setEmailTemplates(result.getString("EMAILTEMPLATES"));
					messageTemplateModal.setTemplateDescription(result.getString("TemplateDescription"));
					messageTemplateModal.setSubject(result.getString("SUBJECT"));
					messageTemplateModallist.add(messageTemplateModal);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		return messageTemplateModallist;
	}
	
	/*
	public List<MessageTemplateModal> GetAllMessageAttachments() throws Exception {
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		MessageTemplateModal messageTemplateModal = null;
		List<MessageTemplateModal>	messageTemplateModallist = null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllMessageAttachments");
			cstm.registerOutParameter(1, OracleTypes.CURSOR);
			cstm.executeUpdate();
			result = ((OracleCallableStatement)cstm).getCursor(1);
			if(result != null)
			{
				messageTemplateModallist	= new ArrayList<MessageTemplateModal>();
				while(result.next())
				{
					messageTemplateModal = new MessageTemplateModal();
					messageTemplateModallist.add(messageTemplateModal);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		}
		finally
		{
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		
		return messageTemplateModallist;
	}
	
	
	public List<MessageTemplateModal> GetAllFieldsByFeatureID(long FeatureID, long messageTypeId, long templateTypeId) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		//AuthorisedSignatoryModel AuthorisedSignatory;
		MessageTemplateModal messageTemplateModal = null;
		List<MessageTemplateModal>	messageTemplateModallist = null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllFieldsbyFeatureID(?,?,?)");
			cstm.setLong(1, FeatureID);
			cstm.setLong(2, messageTypeId);
			cstm.setLong(3, templateTypeId);
			cstm.registerOutParameter(4, OracleTypes.CURSOR);
			cstm.executeUpdate();
			result = ((OracleCallableStatement)cstm).getCursor(4);
			if(result != null)
			{
				messageTemplateModallist	= new ArrayList<MessageTemplateModal>();
				while(result.next())
				{
					messageTemplateModal = new MessageTemplateModal();
					messageTemplateModallist.add(messageTemplateModal);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		}
		finally
		{
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		return messageTemplateModallist;
	}
	
	public List<MessageTemplateModal> GetAllVariablesByFieldName(String FieldName) throws Exception
	{
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		//AuthorisedSignatoryModel AuthorisedSignatory;
		MessageTemplateModal messageTemplateModal = null;
		List<MessageTemplateModal>	messageTemplateModallist = null;
		try
		{
			conn   		= ResourceManager.getConnection();
			cstm 		= conn.prepareCall("call spGetAllVariablesByFieldName(?)");
			cstm.setString(1, FieldName);
			cstm.registerOutParameter(2, OracleTypes.CURSOR);
			cstm.executeUpdate();
			result = ((OracleCallableStatement)cstm).getCursor(2);
			if(result != null)
			{
				messageTemplateModallist	= new ArrayList<MessageTemplateModal>();
				while(result.next())
				{
					messageTemplateModal = new MessageTemplateModal();
					messageTemplateModallist.add(messageTemplateModal);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e.getMessage(), e);	
		}
		finally
		{
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;		
		}
		return messageTemplateModallist;
	}*/
	
}
