package com.LIC.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class TaxStructureModal implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	@Override
	public String toString() {
		return "TaxStructureModal [TaxStructureID=" + TaxStructureID + ", ParentTax=" + ParentTax + ", Description="
				+ Description + ", TaxStructureName=" + TaxStructureName + ", TaxStructureDetailsName="
				+ TaxStructureDetailsName + ", ParentTaxStructure=" + ParentTaxStructure
				+ ", ParentTaxStructureDetailsName=" + ParentTaxStructureDetailsName + ", ModeID=" + ModeID
				+ ", ModeName=" + ModeName + ", Value=" + Value + ", HierarchyID=" + HierarchyID + ", FromDate="
				+ FromDate + ", ToDate=" + ToDate + ", CreatedBy=" + CreatedBy + ", CreatedOn=" + CreatedOn
				+ ", IsActive=" + IsActive + ", RowNumber=" + RowNumber + ", ExemptedInID=" + ExemptedInID
				+ ", TaxProcessID=" + TaxProcessID + ", TaxMappingID=" + TaxMappingID + ", TaxStructureDetailID="
				+ TaxStructureDetailID + ", ModifiedBy=" + ModifiedBy + ", ModifiedOn=" + ModifiedOn + ", DeleteBy="
				+ DeleteBy + ", FromDateStr=" + FromDateStr + ", ToDateStr=" + ToDateStr + ", taxStructureDetails="
				+ taxStructureDetails + "]";
	}
	private long 		TaxStructureID;
	private String 		ParentTax;
	private String 		Description;
	private String 		TaxStructureName;
	private String 		TaxStructureDetailsName;
	private long 		ParentTaxStructure;
	private String 		ParentTaxStructureDetailsName;
	private long 		ModeID;
	private String 		ModeName;
	private double 		Value;
	private long 		HierarchyID;
	private Timestamp 	FromDate;
	private Timestamp 	ToDate;
	private long 		CreatedBy;
	private Timestamp 	CreatedOn;
	private short 		IsActive;
	private long 		RowNumber;
	private String 		ExemptedInID;
	private long 		TaxProcessID;
	private long 		TaxMappingID ;
	private long 		TaxStructureDetailID;
	private long 		ModifiedBy;
	private Timestamp 	ModifiedOn;
	private long 		DeleteBy;
	private String 		FromDateStr;
	private String 		ToDateStr;
	
	private List<TaxStructureModal> taxStructureDetails;
	
	public String getFromDateStr() {
		return FromDateStr;
	}
	public String getToDateStr() {
		return ToDateStr;
	}
	public void setFromDateStr(String fromDateStr) {
		FromDateStr = fromDateStr;
	}
	public void setToDateStr(String toDateStr) {
		ToDateStr = toDateStr;
	}
	public long getDeleteBy() {
		return DeleteBy;
	}
	public void setDeleteBy(long deleteBy) {
		DeleteBy = deleteBy;
	}
	public Timestamp getModifiedOn() {
		return ModifiedOn;
	}
	public void setModifiedOn(Timestamp modifiedOn) {
		ModifiedOn = modifiedOn;
	}
	public long getModifiedBy() {
		return ModifiedBy;
	}
	public void setModifiedBy(long modifiedBy) {
		ModifiedBy = modifiedBy;
	}
	public Timestamp getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(Timestamp createdOn) {
		CreatedOn = createdOn;
	}
	
	public long getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(long createdBy) {
		CreatedBy = createdBy;
	}
	
	public long getTaxStructureID() {
		return TaxStructureID;
	}
	public String getParentTax() {
		return ParentTax;
	}
	public String getDescription() {
		return Description;
	}
	public String getTaxStructureName() {
		return TaxStructureName;
	}
	public String getTaxStructureDetailsName() {
		return TaxStructureDetailsName;
	}
	public long getParentTaxStructure() {
		return ParentTaxStructure;
	}
	public String getParentTaxStructureDetailsName() {
		return ParentTaxStructureDetailsName;
	}
	public long getModeID() {
		return ModeID;
	}
	public double getValue() {
		return Value;
	}
	public long getHierarchyID() {
		return HierarchyID;
	}
	public Timestamp getFromDate() {
		return FromDate;
	}
	public Timestamp getToDate() {
		return ToDate;
	}
	public short getIsActive() {
		return IsActive;
	}
	public long getRowNumber() {
		return RowNumber;
	}
	public String getExemptedInID() {
		return ExemptedInID;
	}
	public long getTaxProcessID() {
		return TaxProcessID;
	}
	public long getTaxMappingID() {
		return TaxMappingID;
	}
	public long getTaxStructureDetailID() {
		return TaxStructureDetailID;
	}
	public void setTaxStructureID(long taxStructureID) {
		TaxStructureID = taxStructureID;
	}
	public void setParentTax(String parentTax) {
		ParentTax = parentTax;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public void setTaxStructureName(String taxStructureName) {
		TaxStructureName = taxStructureName;
	}
	public void setTaxStructureDetailsName(String taxStructureDetailsName) {
		TaxStructureDetailsName = taxStructureDetailsName;
	}
	public void setParentTaxStructure(long parentTaxStructure) {
		ParentTaxStructure = parentTaxStructure;
	}
	public void setParentTaxStructureDetailsName(String parentTaxStructureDetailsName) {
		ParentTaxStructureDetailsName = parentTaxStructureDetailsName;
	}
	public void setModeID(long ModeID) {
		this.ModeID = ModeID;
	}
	public void setValue(double value) {
		Value = value;
	}
	public void setHierarchyID(long hierarchyID) {
		HierarchyID = hierarchyID;
	}
	public void setFromDate(Timestamp fromDate) {
		FromDate = fromDate;
	}
	public void setToDate(Timestamp toDate) {
		ToDate = toDate;
	}
	public void setIsActive(short isActive) {
		IsActive = isActive;
	}
	public void setRowNumber(long rowNumber) {
		RowNumber = rowNumber;
	}
	public void setExemptedInID(String exemptedInID) {
		ExemptedInID = exemptedInID;
	}
	public void setTaxProcessID(long taxProcessID) {
		TaxProcessID = taxProcessID;
	}
	public void setTaxMappingID(long taxMappingID) {
		TaxMappingID = taxMappingID;
	}
	public void setTaxStructureDetailID(long taxStructureDetailID) {
		TaxStructureDetailID = taxStructureDetailID;
	}
	public String getModeName() {
		return ModeName;
	}
	public void setModeName(String modeName) {
		ModeName = modeName;
	}
	public List<TaxStructureModal> getTaxStructureDetails() {
		return taxStructureDetails;
	}
	public void setTaxStructureDetails(List<TaxStructureModal> taxStructureDetails) {
		this.taxStructureDetails = taxStructureDetails;
	}
	
	
}
