package com.LIC.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class CityModal  implements Serializable {
	
	private static final long serialVersionUID = 1L;
	 
	    private long 			cityId ; 
		private long 	     	countryID;
	    private String 		 	description;
	    private long 		 	createdBy;
	    private Timestamp 	 	createdOn; 
	    private long 			modifiedBy;
	    private Timestamp 	 	modifiedOn;
	    private short 		 	isActive;
		private Timestamp   	deletedOn;
	    private long         	deletedBy;
	    private String 			code;
	    private long 			stateId;
		
	   
	    public long getCityId() {
			return cityId;
		}
		public void setCityId(long cityId) {
			this.cityId = cityId;
		}
		public long getCountryID() {
			return countryID;
		}
		public void setCountryID(long countryID) {
			this.countryID = countryID;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public long getStateId() {
			return stateId;
		}
		public void setStateId(long stateId) {
			this.stateId = stateId;
		}
}
