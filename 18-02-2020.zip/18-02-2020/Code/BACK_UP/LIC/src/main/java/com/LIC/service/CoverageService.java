package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import com.LIC.bl.CoverageBL;
import com.LIC.constant.Constant;
import com.LIC.dao.CoverageDao;
import com.LIC.entity.CoverageExclusionNewModal;
import com.LIC.entity.CoverageModal;
import com.LIC.entity.CoverageUINMapModal;
import com.LIC.utils.dataobject.ValueObject;

@Service
public class CoverageService {

	CoverageBL 			coverageBL 			= new CoverageBL();
	CoverageDao 		coverageDao 		= new CoverageDao();
	
	private static final Logger logger = Logger.getLogger(CoverageService.class);
	
	public ValueObject InsertOrUpdateCoverage(ValueObject coverageObject) throws Exception {
		
		CoverageModal			coverage			= null;
		ValueObject				outObject			= null;
		
		try {
			outObject	= new ValueObject();
			coverage = coverageBL.createCoverageModalDto(coverageObject, outObject);
			if(outObject.containsKey(Constant.ERROR)) {
				return outObject;
			}
			System.out.println("coveragevvv >>"+coverage);
			if(coverage != null) {
				outObject	= coverageDao.InsertOrUpdateCoverage(coverage, coverage.getCoverageUINMapModalList());
			}
			//return "Success. Id : " + coverageID;
		} catch(Exception ex) {
			outObject.put(Constant.ERROR, ex.getLocalizedMessage());
			logger.info(ex.getLocalizedMessage());
		}
		return outObject;
	}
	
	//API not creted
	public ValueObject InsertOrUpdateCoverageNew(ValueObject coverageObject)throws Exception {
		
		CoverageModal	coverage		= null;
		ValueObject		outObject		= null;
		
		try {
			outObject	= new ValueObject();
			coverage = coverageBL.createCoverageModalDto(coverageObject, outObject);
			if(outObject.containsKey(Constant.ERROR)) {
				return outObject;
			}
			if(coverage != null) {
				outObject.put("CoverageID", coverageDao.InsertOrUpdateCoverageNew(coverage, null));;
			}
		} catch(Exception ex) {
			outObject.put(Constant.ERROR, ex.getLocalizedMessage());
            logger.info(ex.getLocalizedMessage());
		}
		
		return outObject;
	}
	
	public String InsertOrUpdateCoverageUINMap(ValueObject coverageObject)throws Exception {
		
		CoverageUINMapModal		coverageUINMapModal		= null;
		
		try {
			
			coverageUINMapModal		= coverageBL.createCoverageUINMapModalDto(coverageObject, null);
			
			if(coverageUINMapModal != null) {
				coverageDao.InsertOrUpdateCoverageUINMap(coverageUINMapModal, null);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			logger.info(ex.getLocalizedMessage());
			return "Error";
		}
		return "Success";
	}
	
	
	public boolean IsCoverageExistNew(ValueObject coverageObject) throws Exception {
		
		CoverageModal	coverage		= null;
		
		try {
			coverage = coverageBL.createCoverageModalDto(coverageObject, null);
			
			if(coverage != null) {
				
				return coverageDao.IsCoverageExistNew(coverage.getCoverageID(), coverage.getDescription(), coverage.getLineOfBusinessID());
			}
		
		} catch(Exception ex) {
			logger.info(ex.getLocalizedMessage());
			logger.info("-- Error :"+ex.getMessage());
		}
		return false;
	}
	
	public List<CoverageExclusionNewModal> GetCoverageExclusionByCoverageID(long CoverageID) throws Exception {
		
		try {
			
			return coverageDao.GetCoverageExclusionByCoverageID(CoverageID);
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	public List<CoverageUINMapModal> GetAllCoverageUINMapByCoverageID(long CoverageID) throws Exception {
		
		try {
		
			return  coverageDao.GetAllCoverageUINMapByCoverageID(CoverageID);
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	public String DeleteCoverage(long CoverageID , long DeletedBy) throws Exception {
		
		try {
		
			return  coverageDao.DeleteCoverage(CoverageID, DeletedBy);
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return "Error";
	}
	
	public String DeleteCoverageExclusionNew(long CoverageID) throws Exception {
		
		try {
			
			return  coverageDao.DeleteCoverageExclusionNew(CoverageID);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return "Error";
	}
	
	public String DeleteCoverageUINMap(long CoverageID) throws Exception {
		
		try {
			
			return  coverageDao.DeleteCoverageUINMap(CoverageID, null);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return "Error";
	}
	
}
