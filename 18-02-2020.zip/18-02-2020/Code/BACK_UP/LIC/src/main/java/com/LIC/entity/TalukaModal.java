package com.LIC.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class TalukaModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	 
	    private long 			talukId ; 
		private long 	     	districtId;
	    private String 		 	description;
	    private long 		 	createdBy;
	    private Timestamp 	 	createdOn; 
	    private long 			modifiedBy;
	    private Timestamp 		modifiedOn;
	    private short 		 	isActive;
	    private Timestamp   	deletedOn;
	    private long         	deletedBy;
	    private String     		zipCode;
	    
		public long getTalukId() {
			return talukId;
		}
		public long getDistrictId() {
			return districtId;
		}
		public void setDistrictId(long districtId) {
			this.districtId = districtId;
		}
		public String getDescription() {
			return description;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public long getModifiedBy() {
			return modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public String getZipCode() {
			return zipCode;
		}
		public void setTalukId(long talukId) {
			this.talukId = talukId;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}

}
