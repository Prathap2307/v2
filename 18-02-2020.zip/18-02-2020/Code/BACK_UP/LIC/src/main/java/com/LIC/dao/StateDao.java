package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.entity.StateModal;
import com.LIC.resource.ResourceManager;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class StateDao {

	
	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(StateDao.class);

	public List<StateModal> getAllStatesByCountryId(long countryID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		StateModal				stateModal			= null;
		List<StateModal>		stateList			= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			 
			cstm 		= conn.prepareCall("call spGetAllStates(?,?) ");
			
			cstm.setLong(1, countryID); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {
		    	
		    	stateList	= new ArrayList<StateModal>();
		    	
		    	while (result.next ()) {
		    		stateModal = new StateModal();
		    		
		    		stateModal.setStateID(result.getLong("StateID"));
		    		stateModal.setDescription(result.getString("Description"));
		    		stateModal.setCountryID(result.getLong("CountryID"));
		    		
		    		stateList.add(stateModal);
		    	}
		    }
		
		    return stateList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return null;
	}
}
