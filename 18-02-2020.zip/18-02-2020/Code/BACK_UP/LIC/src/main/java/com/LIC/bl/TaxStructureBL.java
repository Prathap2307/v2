package com.LIC.bl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.LIC.entity.TaxStructureModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

/**
 * @author Pradip/Rahul 
 *
 *2019
 */
public class TaxStructureBL  {
	
	private static final Logger logger = Logger.getLogger(TaxStructureBL.class);
	
	@SuppressWarnings("unchecked")
	public TaxStructureModal createTaxStructureModal(ValueObject object) {
		
		List<Object> 				exemptedIDList			= null;
		List<Object> 				taxStructureDetails		= null;
		ValueObject					objectMapper			= null;
		List<TaxStructureModal>		taxDetailsList			= null;
		TaxStructureModal			taxDetails				= null;
		String		 				exemptedIDs				= "";
		
		try {
			
			TaxStructureModal		 taxStructureInfo	= new TaxStructureModal();
			taxStructureInfo.setTaxStructureID(object.getLong("taxStructureID",0));
			taxStructureInfo.setDescription(object.getString("description",""));
			taxStructureInfo.setTaxStructureName(object.getString("taxStructureName",""));
			taxStructureInfo.setTaxStructureDetailsName(object.getString("taxStructureDetailsName",""));
			taxStructureInfo.setParentTaxStructure(object.getLong("parentTaxStructure",0));
			taxStructureInfo.setParentTaxStructureDetailsName(object.getString("parentTaxStructureDetailsName",""));
			taxStructureInfo.setModeID(object.getLong("modeID",0));
			taxStructureInfo.setModeName(object.getString("modeName",""));
			taxStructureInfo.setValue(object.getDouble("value",0));
			taxStructureInfo.setHierarchyID(object.getLong("hierarchyID",0));
			taxStructureInfo.setCreatedBy(object.getLong("createdBy",0));
			
			if(object.get("fromDate") != null && !object.get("fromDate").equals("")) {
				taxStructureInfo.setFromDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("fromDate")));
			} 
			if(object.get("toDate") != null  && !object.get("toDate").equals("")) {
				taxStructureInfo.setToDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("toDate")));
			} 
			
			if(object.get("createdOn") != null  && !object.get("createdOn").equals("")) {
				taxStructureInfo.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				taxStructureInfo.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			taxStructureInfo.setIsActive(object.getShort("isActive",(short)0));
			taxStructureInfo.setRowNumber(object.getLong("rowName",0));
			taxStructureInfo.setExemptedInID("");
			taxStructureInfo.setTaxProcessID(object.getLong("taxprocessID",0));
			taxStructureInfo.setTaxMappingID(object.getLong("taxmappingID",0));
			taxStructureInfo.setTaxStructureDetailID(object.getLong("TtxStructureDetailID",0));
			taxStructureInfo.setModifiedBy(object.getLong("modifiedBy",0));
			
			if(object.get("modifiedOn") != null && !object.get("modifiedOn").equals("")) {
				taxStructureInfo.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("modifiedOn")));
			}
			
			taxStructureInfo.setDeleteBy(object.getLong("deleteBy",0));
			
			exemptedIDList			= (List<Object>) object.get("exemptedInID",null);
			taxStructureDetails		= (List<Object>) object.get("taxDetails",null);
			
			if(exemptedIDList != null) {
				
				for(Object obj : exemptedIDList) {
					
					objectMapper = new ValueObject((HashMap<Object, Object>) obj);
					System.out.println("objectMapper >>"+objectMapper);
					if(objectMapper != null && exemptedIDs.equals("") ) {
						
						exemptedIDs	= objectMapper.getString("Id","");
					} else {
						
						exemptedIDs	+= objectMapper.getString("Id") + ",";
					}
				}
			}
			
			taxStructureInfo.setExemptedInID(exemptedIDs);
			
			if(taxStructureDetails != null) {
				
				taxDetailsList	= new ArrayList<TaxStructureModal>();
				
				for(Object obj : taxStructureDetails) {
					
					objectMapper = new ValueObject((HashMap<Object, Object>) obj);
					
					if(objectMapper != null) {
						
						taxDetails		= new TaxStructureModal();
						taxDetails.setTaxStructureDetailsName(objectMapper.getString("taxStructureDetailsName",""));
						taxDetails.setParentTaxStructure(objectMapper.getLong("parentTaxStructure",0));
						taxDetails.setModeID(objectMapper.getLong("modeID",0));
						taxDetails.setValue(objectMapper.getDouble("value",0));
						taxDetails.setHierarchyID(objectMapper.getLong("hierarchyID",0));
						taxDetails.setParentTax(objectMapper.getString("parentTax",""));
						taxDetails.setCreatedBy(objectMapper.getLong("createdBy",0));
						if(objectMapper.get("createdOn") != null  && !objectMapper.get("createdOn").equals("")) {
							taxDetails.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(objectMapper.getString("createdOn")));
						} else {
							taxDetails.setCreatedOn(new Timestamp(System.currentTimeMillis()));
						}
						taxDetails.setIsActive(object.getShort("isActive",(short)0));
						taxDetails.setRowNumber(objectMapper.getLong("rowNumber",0));
						taxDetailsList.add(taxDetails);
					}
				}
			}
			
			taxStructureInfo.setTaxStructureDetails(taxDetailsList);
			System.out.println("taxStructureInfo >>>"+taxStructureInfo);
			return taxStructureInfo;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	

}


