package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.bl.MessageTemplateBL;
import com.LIC.dao.MessageTemplateDao;
import com.LIC.entity.MessageTemplateModal;
import com.LIC.utils.dataobject.ValueObject;
@Service
public class MessageTemplateService {
	
	MessageTemplateBL		messageTemplateBL	 	= new MessageTemplateBL();
	MessageTemplateDao 		messageTemplateDao 		= new MessageTemplateDao();
	
	private static final Logger logger = Logger.getLogger(MessageTemplateService.class);
	
	public String InsertOrUpdatemMessageTemplateObject(ValueObject messageTemplateObject) {
		
		MessageTemplateModal 		messageTemplateModal 			= null;
		int 						insertUpdateFlag				= 0;
		
        try {
        	messageTemplateModal 	= messageTemplateBL.createMessageTemplateDto(messageTemplateObject);
           
           if(messageTemplateModal != null) {
        	   insertUpdateFlag	= messageTemplateDao.InsertOrUpdateMessageTemplates(messageTemplateModal);
           }
       
           return insertUpdateFlag == 1 ? "Inserted": insertUpdateFlag == 2 ? "Updated" : "Error While inserting";
        } catch (Exception ex) {
        	ex.printStackTrace();
            logger.info(ex.getLocalizedMessage());
        }
		return "Error";
    }
	
	public List<MessageTemplateModal>  GetAllMessageTemplates() throws Exception{
	
		try {
	   		
			return messageTemplateDao.GetAllMessageTemplates();
	   	  } catch(Exception e) {
	   		  e.printStackTrace();
	   		  logger.info("-- Error :"+e.getMessage());
	   	  }
	   	  
   	  return null;
    }

	 public List<MessageTemplateModal>  GetAllFeaturesForSMSEmail() throws Exception{
   	  	  
   	 	try {
   		
   		  return  messageTemplateDao.GetAllFeaturesForSMSEmail();
   	 	} catch(Exception e) {
   		  e.printStackTrace();
   		  logger.info("-- Error :"+e.getMessage());
   	  }
   	  
   	  return null;
     }
	 
	 public List<MessageTemplateModal>  GetAllMessageTemplatesByTemplateID(long templateID) throws Exception{
	   	  
	   	try {                      	  
	   		
	   		return messageTemplateDao.GetAllMessageTemplatesByTemplateID(templateID);
	   	  } catch(Exception e) {
	   		  e.printStackTrace();
	   		  logger.info("-- Error :"+e.getMessage());
	   	  }
	   	return null;
	 } 
	 
	 public List<MessageTemplateModal>  GetAllMessageTemplatesByFeatureID(long featureID) throws Exception{
	   	  
   	  	try {          	  
   		
   	  		return messageTemplateDao.GetAllMessageTemplatesByFeatureID(featureID);
       	   		  
   	  	} catch(Exception e) {
   	  		e.printStackTrace();
   	  		logger.info("-- Error :"+e.getMessage());
   	  	}	
   	  	
   	  return null;
     }
	 
	 
	/* public List<MessageTemplateModal>  GetAllMessageAttachments() throws Exception{
	   	  	
		 try {
			 return messageTemplateDao.GetAllMessageAttachments();
	       	  
	   	  } catch(Exception e) {
	   		  e.printStackTrace();
	   		  logger.info("-- Error :"+e.getMessage());
	   	  }	   	  
	   	  return null;
	     }
	 
	 public List<MessageTemplateModal>  GetAllFieldsByFeatureID(long FeatureID, long messageTypeId, long templateTypeId) throws Exception{
	   	  try {	   		  	   		                        	  
	   		return messageTemplateDao.GetAllFieldsByFeatureID(FeatureID,messageTypeId,templateTypeId);
	       
	   		  
	   	  } catch(Exception e) {
	   		  e.printStackTrace();
	   		  logger.info("-- Error :"+e.getMessage());
	   	  }
	   	  
	   	  return null;
	     }
	 
	 
	 public List<MessageTemplateModal>  GetAllVariablesByFieldName(String FieldName) throws Exception{
	   	  
	   	  try {
	   		  
	   		  return  messageTemplateDao.GetAllVariablesByFieldName(FieldName);
	       
	   	  } catch(Exception e) {
	   		  e.printStackTrace();
	   		  logger.info("-- Error :"+e.getMessage());
	   	  }
	   	  
	   	  return null;
	}*/
    
}


