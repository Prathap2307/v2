package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.dao.RegionDao;
import com.LIC.entity.RegionModal;

/**
 * @author Ashish/Parth
 *
 *2019
 */
@Service
public class RegionService

{

	RegionDao 		regionDao = new RegionDao();
	
	private static final Logger logger = Logger.getLogger(RegionService.class);
	
	public List<RegionModal>  getAllRegion() throws Exception{

	List<RegionModal>	regionList			= null;
		
		try {
			
			regionList=regionDao.getAllRegions();
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		
		return regionList;
	}
  
  
}