package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.bl.AuthorisedSignatoryBL;
import com.LIC.dao.AuthorisedSignatoryDao;
import com.LIC.entity.AuthorisedSignatoryModal;
import com.LIC.entity.ModuleModal;
import com.LIC.utils.dataobject.ValueObject;

@Service
public class AuthorisedSignatoryService {

	AuthorisedSignatoryDao 		authorisedSignatoryDao 	= new AuthorisedSignatoryDao();
	AuthorisedSignatoryBL 		authSignatoryBL 		= new AuthorisedSignatoryBL();
	
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryService.class);
	
	public List<AuthorisedSignatoryModal> GetAllAuthorisedSignatories() throws Exception {
		try {
		
			return  authorisedSignatoryDao.GetAllAuthorisedSignatories();
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	
	public int InsertOrUpdateAuthorisedSignatory(ValueObject authorisedSignatoryObject) throws Exception {
		
		AuthorisedSignatoryModal	authorisedsignatory	= null;
		
        try {
        	
        	authorisedsignatory = authSignatoryBL.createAuthorisedSignatoryModal(authorisedSignatoryObject);
           
           if(authorisedsignatory != null) {
        	   authorisedSignatoryDao.InsertOrUpdateAuthorisedSignatory(authorisedsignatory);
           }
           
        } catch (Exception ex) {
        	ex.printStackTrace();
            logger.info(ex.getLocalizedMessage());
            return 1;
        }
		return 0;
    }
    
	public List<AuthorisedSignatoryModal> GetAllAuthorisedSignatory(ValueObject authorisedSignatoryObject) throws Exception {
	
		AuthorisedSignatoryModal	authorisedsignatory	= null;
		
		try {
			
			authorisedsignatory = authSignatoryBL.createAuthorisedSignatoryModal(authorisedSignatoryObject);
			
			return  authorisedSignatoryDao.GetAllAuthorisedSignatory(authorisedsignatory);
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	public String IsAuthorisedSignatoryExist(ValueObject authorisedSignatoryObject) throws Exception {
		
		AuthorisedSignatoryModal	authorisedsignatory	= null;
		
		try {
			
			authorisedsignatory = authSignatoryBL.createAuthorisedSignatoryModal(authorisedSignatoryObject);
		 
			return authorisedSignatoryDao.IsAuthorisedSignatoryExist(authorisedsignatory);
		 
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return "Error";
	}
	
	public String DeleteAuthorisedSignatory(ValueObject authorisedSignatoryObject) throws Exception {
	
		AuthorisedSignatoryModal	authorisedsignatory	= null;
		
		try {
			
			authorisedsignatory = authSignatoryBL.createAuthorisedSignatoryModal(authorisedSignatoryObject);
			
			return authorisedSignatoryDao.DeleteAuthorisedSignatory(authorisedsignatory);
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return "Error";
	}
	
	public List<ModuleModal> GetAllModules() throws Exception {

		try {
			
			return authorisedSignatoryDao.GetAllModules();
		 
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());	
		}
		return null;
	}
}
