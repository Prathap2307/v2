package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.entity.RegionModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class RegionDao 
{

	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(RegionDao.class);
	
	public List<RegionModal> getAllRegions() throws Exception {

		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		RegionModal			   regionModal		          = null;
		List<RegionModal>		RegionModalList			= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			
			cstm 		= conn.prepareCall("call spGetAllRegion(?) ");
			
			cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(1);

		    if(result != null) {
		    	
		    	RegionModalList	= new ArrayList<RegionModal>();
		    	
		    	while (result.next ()) {
		    		regionModal = new RegionModal();
		    		
		    		regionModal.setRegionId(result.getLong("RegionID"));
		    		regionModal.setDescription(result.getString("Description"));
		    
		    		
		    		RegionModalList.add(regionModal);
		    	}
		    }
		
		    return RegionModalList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} finally {
			cstm.close();
			cstm	= null;
			ResourceManager.freeConnection(conn);
			conn	= null;
		}
		return null;
	}
	
}
