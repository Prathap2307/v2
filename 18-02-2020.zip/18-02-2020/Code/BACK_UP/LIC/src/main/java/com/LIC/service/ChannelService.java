package com.LIC.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.bl.ChannelBL;
import com.LIC.dao.ChannelDao;
import com.LIC.entity.BranchModal;
import com.LIC.entity.ChannelModal;
import com.LIC.entity.SubChannelModal;
import com.LIC.utils.dataobject.ValueObject;

@Service
public class ChannelService {

	private static final Logger logger = Logger.getLogger(ChannelService.class);
	
	ChannelDao 		channelDao 	= new ChannelDao();
	ChannelBL 		channelBL 	= new ChannelBL();
	
	public List<ChannelModal> GetMainChannel() throws Exception {
        
		try {
        	
        	return channelDao.getMainChannel();
       
        } catch (Exception ex) {
        	ex.printStackTrace();
            logger.info(ex.getMessage());
        }
        return null;

    }
	
	public List<SubChannelModal> GetAllChannel(ValueObject channelObject) throws Exception {
		
		ChannelModal 	objChannelInfo	= null;
		
		try {
			
			objChannelInfo	= channelBL.createChannelInfoDto(channelObject);
			return channelDao.GetAllChannel(objChannelInfo);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.info(ex.getMessage());
		}
		return null;
		
	}

    public ArrayList<BranchModal> GetAllBranchesByOrgId(long OrganisationID) throws Exception {
        
    	try {
        
    		return channelDao.GetAllBranches(OrganisationID);
       
    	} catch (Exception ex) {
    		ex.printStackTrace();
        	 logger.info(ex.getMessage());
        }
        return null;
    }
    
    public long InsertOrUpdateChannel(ValueObject channelObject) throws Exception {
    		
    	ChannelModal 	objChannelInfo	= null;

        try {
        	
        	objChannelInfo	= channelBL.createChannelInfoDto(channelObject);
        	
        	channelDao.InsertOrUpdateChannel(objChannelInfo);
        
        } catch (Exception ex) {
        	ex.printStackTrace();
        	 logger.info(ex.getMessage());
        	 return 1;
        }
		return 0;
    }
    
    public long InsertChannel(ValueObject channelObject) throws Exception {
    		
    	ChannelModal 	objChannelInfo	= null;
        
    	try {
          
			objChannelInfo	= channelBL.createChannelInfoDto(channelObject);
			
			channelDao.InsertChannel(objChannelInfo);
        
        } catch (Exception ex) {
        	ex.printStackTrace();
        	logger.info(ex.getMessage());
        	return 1;
        }
		return 0;
    }
    
    public String IsChannelExist(ValueObject channelObject) throws Exception {
		long 		ChannelID			= 0;
		String 		ChannelName			= null;
		String 		ChannelCode			= null;
       
    	try  {
    		
    		ChannelID 		= channelObject.getLong("ChannelID",0);
    		ChannelName		= channelObject.getString("ChannelName",null);
    		ChannelCode 	= channelObject.getString("ChannelCode",null);
    		
    		return channelDao.IsChannelExist(ChannelID, ChannelName, ChannelCode);
           
        } catch (Exception ex){
        	ex.printStackTrace();
        	logger.info(ex.getMessage());
        	return "ERROR";
        }
    }
    
    public String DeleteChannel(ValueObject channelObject) throws Exception {
    	
    	ChannelModal 	objChannelInfo	= null;
    	
    	try  {
    		
    		objChannelInfo	= channelBL.createChannelInfoDto(channelObject);
    		
    		return channelDao.DeleteChannel(objChannelInfo);
    		
    	} catch (Exception ex){
    		ex.printStackTrace();
    		logger.info(ex.getMessage());
    		return "ERROR";
    	}
    }
    
    public String IsSubChannelExist(ValueObject channelObject) {
    	
    	SubChannelModal 	subChannelModal	= null;
       
    	try {
    		
    		subChannelModal	= channelBL.createSubChannelInfoDto(channelObject);
            
    		return channelDao.IsSubChannelExist(subChannelModal.getSubChannelID(), subChannelModal.getChannelName(), 
            		subChannelModal.getChannelCode(), subChannelModal.getMainChannelID(), subChannelModal.getPolicyHolderCode());
        
        } catch (Exception ex){
        	ex.printStackTrace();
    		logger.info(ex.getMessage());
    		return "ERROR";
    	}
    }
 
    public int InsertSubChannel(ValueObject channelObject)  {
        
    	SubChannelModal 	subChannelModal	= null;
    	
    	try  {
    		
    		subChannelModal	= channelBL.createSubChannelInfoDto(channelObject);
    		
        	channelDao.InsertSubChannel(subChannelModal);
        
        } catch (Exception ex){
        	ex.printStackTrace();
    		logger.info(ex.getMessage());
    		return 1;
    	}
        return 0;
    }
  
    public List<SubChannelModal> GetChannelById(long channelID) throws Exception {
    	
    	try {
    		
    		return channelDao.GetChannelById(channelID);
    		
    	} catch (Exception ex) {
    		ex.printStackTrace();
    		logger.info(ex.getMessage());
    	}
    	return null;
    	
    }
    
    public List<SubChannelModal> GetAllSubChannelByChannelID(long mainChannelID) throws Exception {
    	
    	try {
    		
    		return channelDao.GetAllSubChannelByChannelID(mainChannelID);
    		
    	} catch (Exception ex) {
    		ex.printStackTrace();
    		logger.info(ex.getMessage());
    	}
    	return null;
    	
    }
    
    public List<SubChannelModal> GetSubChannelDetailsbySubChannelID(long SubChannelID) throws Exception {
		
		try {
			
			return channelDao.GetSubChannelDetailsbySubChannelID(SubChannelID);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.info(ex.getMessage());
		}
		return null;
		
	}
   
    public String DeleteSubChannel(long subChannelId) throws Exception {
    	
    	try  {
    		
    		return channelDao.DeleteSubChannel(subChannelId);
    		
    	} catch (Exception ex){
    		ex.printStackTrace();
    		logger.info(ex.getMessage());
    		return "ERROR";
    	}
    }

    public List<SubChannelModal> GetSubChannel(ValueObject channelObject) throws Exception {
		
		SubChannelModal 	objChannelInfo	= null;
		
		try {
			
			objChannelInfo	= channelBL.createSubChannelInfoDto(channelObject);
			
			if(objChannelInfo != null) {
				return channelDao.GetSubChannel(objChannelInfo);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.info(ex.getMessage());
		}
		return null;
		
	}

    /*
    public DataTable GetHeadOfficeBranchID()
    {
        try
        {
            DataTable _dt = new ChannelDAL().GetHeadOfficeBranchID();
            return _dt;
        }
        catch (Exception ex)
        {
            Logger.Write(ex.Message.ToString());
        }
        return null;
    }
    #endregion

    public DataTable GetAllChannel(SearchInfo objSearchInfo)
    {
        try
        {
            DataTable _dt = new ChannelDAL().GetAllChannel(objSearchInfo);
            return _dt;
        }

        catch (Exception ex)
        {
            Logger.Write(ex.Message.ToString());
        }
        return null;
    }

    #region "Get Sub Channel Details by Sub ChannelID"
    /// <summary>
    /// Get Sub Channel Details by Sub ChannelID
    /// </summary>
    /// <returns></returns>
    public DataSet GetSubChannelDetailsbySubChannelID(Int32 SubChannelID)
    {
        try
        {
            DataSet _ds = new ChannelDAL().GetSubChannelDetailsbySubChannelID(SubChannelID);
            return _ds;
        }

        catch (Exception ex)
        {
            Logger.Write(ex.Message.ToString());
        }
        return null;
    }
   
    #endregion

    #region "Delete Channel Details"
    /// <summary>
    /// Delete Channel Details
    /// </summary>
    /// <param name="ChannelID">Channel ID Object</param>
    /// <returns></returns>
    public String DeleteChannelNew(Int32 ChannelID)
    {
        try
        {
            String _Status = new ChannelDAL().DeleteChannelNew(ChannelID);
            return _Status;
        }
        catch (Exception ex)
        {
            Logger.Write(ex.Message.ToString());
        }
        return "ERROR";
    }
    #endregion


    #region "GetSalesCategory"
    /// <summary>
    /// Insert Channel Details
    /// </summary>
    /// <param name="objChannelInfo">Channel Info Object</param>
    /// <returns>Return DataSet</returns>

    public DataTable GetSalesCategory()
    {
        try
        {
            DataTable dt = new ChannelDAL().GetSalesCategory();
            return dt;
        }
        catch (Exception ex)
        {
            Logger.Write(ex.Message.ToString());
        }
        return null;
    }
    #endregion

    #region "use to Get All SubChannel"
    /// <summary>
    /// use to retrieve all state details.
    /// </summary>
    /// <returns></returns>
    public DataTable GetAllSubChannelByCDAccount(Int32 ChannelID)
    {
        try
        {
            DataTable _dt = new ChannelDAL().GetAllSubChannelByCDAccount(ChannelID);
            return _dt;
        }
        catch (Exception ex)
        {
            Logger.Write(ex.Message.ToString());
        }
        return null;
    }
    #endregion


    #region "use to Get All SubChannel"
    /// <summary>
    /// use to retrieve all state details.
    /// </summary>
    /// <returns></returns>
    public DataTable GetAllSubChannel(Int32 ChannelID)
    {
        try
        {
            DataTable _dt = new ChannelDAL().GetAllSubChannel(ChannelID);
            return _dt;
        }
        catch (Exception ex)
        {
            Logger.Write(ex.Message.ToString());
        }
        return null;
    }
    #endregion





}
}*/
}
