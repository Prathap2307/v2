package com.LIC.entity;

import java.io.Serializable;

public class CoverageExclusionNewModal implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private long 			coverageExclusionID;
	private CoverageModal 	coverage;
	private String 			description;
	
	public long getCoverageExclusionID() {
		return coverageExclusionID;
	}
	public CoverageModal getCoverage() {
		return coverage;
	}
	public String getDescription() {
		return description;
	}
	public void setCoverageExclusionID(long coverageExclusionID) {
		this.coverageExclusionID = coverageExclusionID;
	}
	public void setCoverage(CoverageModal coverage) {
		this.coverage = coverage;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
