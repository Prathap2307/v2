package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.dao.DistrictDao;
import com.LIC.entity.DistrictModal;

/**
 * @author Ashish/Parth
 *
 *2019
 */
@Service
public class DistrictService {
	
	private static final Logger logger = Logger.getLogger(DistrictService.class);
	
	DistrictDao		districtDao = new DistrictDao();
	
	public List<DistrictModal>  getAllDistrictByStateId(long stateId) throws Exception{
		
		List<DistrictModal>		districtList		= null;
		
		try {
			
			districtList	= districtDao.getAllDistrictsByStateId(stateId);
			
			return districtList;
		} catch (Exception e) {
			
			logger.info(e.getMessage());
		} finally {
			districtList		= null;
		}
		return null;
	}
}


