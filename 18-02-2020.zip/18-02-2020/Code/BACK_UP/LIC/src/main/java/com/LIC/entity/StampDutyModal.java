package com.LIC.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class StampDutyModal implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public StampDutyModal() {
		
	}
	
	public StampDutyModal(long StampDutyID) {
        this.stampDutyID = StampDutyID;
    }
	
	public StampDutyModal(long StampDutyID, double StampDutyAmount, String MudrakNumber, String PayOrderNumber, Timestamp PaymentDate, long createdBy)  {
        this.stampDutyID 		= StampDutyID;
        this.stampDutyAmount 	= StampDutyAmount;
        this.mudrakNumber 		= MudrakNumber;
        this.payOrderNumber 	= PayOrderNumber;
        this.paymentDate 		= PaymentDate;
        this.createdBy 			= createdBy;
    }
	
	private long 			stampDutyID;
	private double 			stampDutyAmount;
	private double 			triggerAmount;
	private String 			mudrakNumber;
	private String 			payOrderNumber;
	private String 			receiptNumber;
	private Timestamp 		paymentDate;
	private double 			balanceStampDutyAmount;
	private long 			productID;
	private long 			coverageID;
	private double 			stampDutyAdvanceDepositAmount;
	private long 			type;
    private Timestamp 		challanEndDate;
    private String 			defaceNumber;
    private Timestamp 		defaceDate;
    private String 			certificateNumber ;
    private Timestamp 		certificateDate ;
    private String 			intimationEmailAddress;
    private String 			intimationMobileNumber;
    private long 			createdBy;
    private double 			advanceDepositAmount;
    private String 			productName;
    private String 			coverageName;
    private long 			status;

    
	public long getStampDutyID() {
		return stampDutyID;
	}

	public double getStampDutyAmount() {
		return stampDutyAmount;
	}

	public double getTriggerAmount() {
		return triggerAmount;
	}

	public String getMudrakNumber() {
		return mudrakNumber;
	}

	public String getPayOrderNumber() {
		return payOrderNumber;
	}

	public String getReceiptNumber() {
		return receiptNumber;
	}

	public Timestamp getPaymentDate() {
		return paymentDate;
	}

	public double getBalanceStampDutyAmount() {
		return balanceStampDutyAmount;
	}

	public long getProductID() {
		return productID;
	}

	public long getCoverageID() {
		return coverageID;
	}

	public double getStampDutyAdvanceDepositAmount() {
		return stampDutyAdvanceDepositAmount;
	}

	public long getType() {
		return type;
	}

	public Timestamp getChallanEndDate() {
		return challanEndDate;
	}

	public String getDefaceNumber() {
		return defaceNumber;
	}

	public Timestamp getDefaceDate() {
		return defaceDate;
	}

	public String getCertificateNumber() {
		return certificateNumber;
	}

	public Timestamp getCertificateDate() {
		return certificateDate;
	}

	public String getIntimationEmailAddress() {
		return intimationEmailAddress;
	}

	public String getIntimationMobileNumber() {
		return intimationMobileNumber;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public double getAdvanceDepositAmount() {
		return advanceDepositAmount;
	}

	public String getProductName() {
		return productName;
	}

	public String getCoverageName() {
		return coverageName;
	}

	public void setStampDutyID(long stampDutyID) {
		this.stampDutyID = stampDutyID;
	}

	public void setStampDutyAmount(double stampDutyAmount) {
		this.stampDutyAmount = stampDutyAmount;
	}

	public void setTriggerAmount(double triggerAmount) {
		this.triggerAmount = triggerAmount;
	}

	public void setMudrakNumber(String mudrakNumber) {
		this.mudrakNumber = mudrakNumber;
	}

	public void setPayOrderNumber(String payOrderNumber) {
		this.payOrderNumber = payOrderNumber;
	}

	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}

	public void setPaymentDate(Timestamp paymentDate) {
		this.paymentDate = paymentDate;
	}

	public void setBalanceStampDutyAmount(double balanceStampDutyAmount) {
		this.balanceStampDutyAmount = balanceStampDutyAmount;
	}

	public void setProductID(long productID) {
		this.productID = productID;
	}

	public void setCoverageID(long coverageID) {
		this.coverageID = coverageID;
	}

	public void setStampDutyAdvanceDepositAmount(double stampDutyAdvanceDepositAmount) {
		this.stampDutyAdvanceDepositAmount = stampDutyAdvanceDepositAmount;
	}

	public void setType(long type) {
		this.type = type;
	}

	public void setChallanEndDate(Timestamp challanEndDate) {
		this.challanEndDate = challanEndDate;
	}

	public void setDefaceNumber(String defaceNumber) {
		this.defaceNumber = defaceNumber;
	}

	public void setDefaceDate(Timestamp defaceDate) {
		this.defaceDate = defaceDate;
	}

	public void setCertificateNumber(String certificateNumber) {
		this.certificateNumber = certificateNumber;
	}

	public void setCertificateDate(Timestamp certificateDate) {
		this.certificateDate = certificateDate;
	}

	public void setIntimationEmailAddress(String intimationEmailAddress) {
		this.intimationEmailAddress = intimationEmailAddress;
	}

	public void setIntimationMobileNumber(String intimationMobileNumber) {
		this.intimationMobileNumber = intimationMobileNumber;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public void setAdvanceDepositAmount(double advanceDepositAmount) {
		this.advanceDepositAmount = advanceDepositAmount;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	public long getStatus() {
		return status;
	}

	public void setStatus(long status) {
		this.status = status;
	}
   
}
