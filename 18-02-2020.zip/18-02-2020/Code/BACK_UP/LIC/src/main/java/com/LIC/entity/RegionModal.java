package com.LIC.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class RegionModal  implements Serializable {

	private static final long serialVersionUID = 1L;
	
	    private long 		 	regionId;
		private long 	     	stateId;
	    private String 		 	description;
	    private String      	shortDescription;
	    private long 		 	createdBy;
	    private Timestamp 	 	createdOn; 
	    private long 			codifiedBy;
	    private Timestamp 	 	modifiedOn;
	    private short 		 	isActive;
	    private long       		deletedBy;
	    private Timestamp   	deletedOn;
	    
	    
	    public long getRegionId() {
			return regionId;
		}
		public long getStateId() {
			return stateId;
		}
		public String getDescription() {
			return description;
		}
		public String getShortDescription() {
			return shortDescription;
		}
		public long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public long getCodifiedBy() {
			return codifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public short getIsActive() {
			return isActive;
		}
		public long getDeletedBy() {
			return deletedBy;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public void setRegionId(long regionId) {
			this.regionId = regionId;
		}
		public void setStateId(long stateId) {
			this.stateId = stateId;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public void setShortDescription(String shortDescription) {
			this.shortDescription = shortDescription;
		}
		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setCodifiedBy(long codifiedBy) {
			this.codifiedBy = codifiedBy;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public void setIsActive(short isActive) {
			this.isActive = isActive;
		}
		public void setDeletedBy(long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
	   
}
