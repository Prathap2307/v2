package com.LIC.bl;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.LIC.entity.MessageTemplateModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

public class MessageTemplateBL {
	
	private static final Logger logger = Logger.getLogger(MessageTemplateBL.class);

	public MessageTemplateModal createMessageTemplateDto(ValueObject object) {
           try {
			
			MessageTemplateModal	messagetemplateInfo	= new MessageTemplateModal();
			 	
			messagetemplateInfo.setMessageTemplatesID(object.getLong("messageTemplatesID",0));
			messagetemplateInfo.setFeatureID(object.getLong("featureID",0));
			messagetemplateInfo.setSmsIsActive(object.getShort("smsIsActive",(short)1));
			messagetemplateInfo.setIsActive(object.getShort("isActive",(short)1));
			messagetemplateInfo.setEmailIsActive(object.getShort("emailIsActive",(short)1));
			messagetemplateInfo.setSmsTemplates(object.getString("smsTemplates",""));
			messagetemplateInfo.setEmailTemplates(object.getString("emailTemplates",""));
			messagetemplateInfo.setSubject(object.getString("subject",""));
			messagetemplateInfo.setTemplateDescription(object.getString("templateDescription",""));
			messagetemplateInfo.setEmailSMSTypeID(object.getLong("emailSMSTypeID",0));
			messagetemplateInfo.setWhatsAppTemplates(object.getString("whatsAppTemplates",""));
			messagetemplateInfo.setWhatsAppIsActive(object.getShort("whatsAppIsActive",(short)1));
			messagetemplateInfo.setTemplateTypeId(object.getLong("templateTypeId",0));
			messagetemplateInfo.setCreatedBy(object.getLong("createdBy",0));
			
			if(object.get("createdOn") != null  && !object.get("createdOn").equals("")) {
				messagetemplateInfo.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("createdOn")));
			} else {
				messagetemplateInfo.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			
			//messagetemplateInfo.setMainMenuID(object.getLong("mainMenuID",0));
			//messagetemplateInfo.setOutParam(object.getLong("OutParam",0));
			//messagetemplateInfo.setFieldName(object.getString("fieldName",""));
			return messagetemplateInfo;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		} 
		return null;
	}
}
