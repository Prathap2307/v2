 package com.LIC.entity;

import java.io.Serializable;

public class CoverageBenefitNewModal implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private long 			coverageBenefitID; 
	private CoverageModal 	coverage; 
	private String 			description;
	
	public long getCoverageBenefitID() {
		return coverageBenefitID;
	}
	public CoverageModal getCoverage() {
		return coverage;
	}
	public String getDescription() {
		return description;
	}
	public void setCoverageBenefitID(long coverageBenefitID) {
		this.coverageBenefitID = coverageBenefitID;
	}
	public void setCoverage(CoverageModal coverage) {
		this.coverage = coverage;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
