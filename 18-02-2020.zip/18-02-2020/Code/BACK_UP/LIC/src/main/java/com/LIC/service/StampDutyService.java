package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.bl.StampDutyBL;
import com.LIC.dao.StampDutyDao;
import com.LIC.entity.StampDutyModal;
import com.LIC.utils.dataobject.ValueObject;

/**
 * @author Admin
 *
 *2020
 */
@Service
public class StampDutyService {
	
	StampDutyDao		stampDutyDao 	= new StampDutyDao();
	StampDutyBL			stampDutyBL	 	= new StampDutyBL();
	
	private static final Logger logger = Logger.getLogger(StampDutyService.class);

	public boolean  IsStampDutyExistForNB(long stampDutyId) throws Exception {
		
		try {
			
			return stampDutyDao.IsStampDutyExistForNB(stampDutyId);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		
		return false;
	}
	
	public boolean  IsStampDutyExist(ValueObject messageTemplateObject) throws Exception {
		
		StampDutyModal  	stampduty		= null;
		
		try {
			stampduty 	= stampDutyBL.createStampDutyDto(messageTemplateObject);
			
			return stampDutyDao.IsStampDutyExist(stampduty);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		
		return false;
	}
	
	public String InsertUpdateStampDuty(ValueObject messageTemplateObject) throws Exception {
		
		StampDutyModal  	stampduty		= null;
		
		try {
			stampduty 	= stampDutyBL.createStampDutyDto(messageTemplateObject);
			
			stampDutyDao.InsertUpdateStampDuty(stampduty);
			
			return "Success";
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
			return "Error";
		}
	}
	
	public List<StampDutyModal> GetStampDuty(long stampDutyId) throws Exception {
		
		try {
			
			return stampDutyDao.GetStampDuty(stampDutyId);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	public List<StampDutyModal> GetAllStampDuty() throws Exception {
		
		try {
			
			return stampDutyDao.GetAllStampDuty();
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	public String DeleteStampDuty(long stampDutyId) throws Exception {
		
		try {
			
			return stampDutyDao.DeleteStampDuty(stampDutyId);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
			return "Error";
		}
	}
}


