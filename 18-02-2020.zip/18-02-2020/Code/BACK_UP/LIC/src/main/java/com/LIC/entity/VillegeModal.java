package com.LIC.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class VillegeModal  implements Serializable {
	
	private static final long serialVersionUID = 1L;
	 
	    private Long 			villageId; 
	    private Long 	     	countryID;
	    private String 		 	description;
	    private Long 		 	createdBy;
	    private Timestamp 	 	createdOn; 
	    private Long 			modifiedBy;
	    private Timestamp 	 	modifiedOn;
	    private Short       	isRural ;
	    private Timestamp   	deletedOn;
	    private Long         	deletedBy;
	    private String 			villageCode;
	    private String     		zipCode;
	    private Long 			talukID;
	    
		public Long getVillageId() {
			return villageId;
		}
		public Long getCountryID() {
			return countryID;
		}
		public String getDescription() {
			return description;
		}
		public Long getCreatedBy() {
			return createdBy;
		}
		public Timestamp getCreatedOn() {
			return createdOn;
		}
		public Long getModifiedBy() {
			return modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return modifiedOn;
		}
		public Short getIsRural() {
			return isRural;
		}
		public Timestamp getDeletedOn() {
			return deletedOn;
		}
		public Long getDeletedBy() {
			return deletedBy;
		}
		public String getVillageCode() {
			return villageCode;
		}
		public String getZipCode() {
			return zipCode;
		}
		public Long getTalukID() {
			return talukID;
		}
		public void setVillageId(Long villageId) {
			this.villageId = villageId;
		}
		public void setCountryID(Long countryID) {
			this.countryID = countryID;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public void setCreatedBy(Long createdBy) {
			this.createdBy = createdBy;
		}
		public void setCreatedOn(Timestamp createdOn) {
			this.createdOn = createdOn;
		}
		public void setModifiedBy(Long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			this.modifiedOn = modifiedOn;
		}
		public void setIsRural(Short isRural) {
			this.isRural = isRural;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			this.deletedOn = deletedOn;
		}
		public void setDeletedBy(Long deletedBy) {
			this.deletedBy = deletedBy;
		}
		public void setVillageCode(String villageCode) {
			this.villageCode = villageCode;
		}
		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}
		public void setTalukID(Long talukID) {
			this.talukID = talukID;
		}
	   
}
