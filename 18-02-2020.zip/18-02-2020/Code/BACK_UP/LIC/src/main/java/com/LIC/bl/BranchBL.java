package com.LIC.bl;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.LIC.entity.BranchModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

/**
 * @author Pradip/Rahul 
 *
 *2019
 */
public class BranchBL  {
	
	private static final Logger logger = Logger.getLogger(BranchBL.class);
	
	public BranchModal createBranchInfoDto(ValueObject object) {
		
		try {
			
			BranchModal		 branchInfo	= new BranchModal();
			 	
			branchInfo.setOrganisationId(object.getLong("OrganisationID",0));
			branchInfo.setBranchId(object.getLong("BranchID",0));
			branchInfo.setShortName(object.getString("ShortName",""));
			branchInfo.setBranchName(object.getString("Description",""));
			if(branchInfo.getBranchName().equals("")) {
				branchInfo.setBranchName(object.getString("branchName",""));
			}
			
			branchInfo.setCreatedBy(object.getLong("CreatedBy"));

			if(object.get("WorkingDate") != null) {
				branchInfo.setWorkingDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("WorkingDate")));
			}
			if(object.get("CreatedOn") != null) {
				branchInfo.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("CreatedOn")));
			} else {
				branchInfo.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			branchInfo.setAddress1(object.getString("Address1",null));
			branchInfo.setAddress2(object.getString("Address2",null));
			branchInfo.setAddress3(object.getString("Address3",null));
			branchInfo.setPhoneNo(object.getString("PhoneNo",null));
			branchInfo.setParentBranchId(object.getLong("ParentBranchID",0));
			branchInfo.setPageTypeID(object.getLong("PageTypeID",0));
			branchInfo.setCountryID(object.getLong("CountryID",0));
			branchInfo.setStateID(object.getLong("StateID",0));
			branchInfo.setDistrictID(object.getLong("DistrictID",0));
			branchInfo.setDivisionID(object.getLong("DivisionID",0));
			branchInfo.setTalukID(object.getLong("TalukID",0));
			branchInfo.setZipCode(object.getString("ZipCode",null));
			branchInfo.setZoneID(object.getLong("ZonalID",0));
			branchInfo.setRegionalID(object.getLong("RegionalID",0));
			branchInfo.setIsActive(object.getShort("IsActive",(short)0));
			branchInfo.setEmail(object.getString("Email",null));
			branchInfo.setGstNo(object.getString("GSTNo",null));
			branchInfo.setPanNo(object.getString("PanNo",null));
			branchInfo.setFaxNo(object.getString("FaxNo",null));
			branchInfo.setLutNo(object.getString("LUTNo",null));
			branchInfo.setMobileNo(object.getString("MobileNo",null));
				
			 return branchInfo;
		} catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	

}


