package com.LIC.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class ChannelModal  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	    private long 		 ChannelID;
	    private String 		 Description;
	    private String       shortDescription;
	    private String       ChannelName;
	    private String       ChannelCode;
        private long     	 CategroyID;
	    private long 		 CreatedBy;
	    private Timestamp 	 CreatedOn; 
	    private long 		 ModifiedBy;
	    private Timestamp 	 ModifiedOn;
	    private short 		 IsActive;
	    private long         DeletedBy;
	    private Timestamp    DeletedOn;
	    private String   	 channelNameWithCode;

	    public long getChannelID() {
			return ChannelID;
		}
		public void setChannelID(long channelID) {
			ChannelID = channelID;
		}
		public String getDescription() {
			return Description;
		}
		public void setDescription(String description) {
			Description = description;
		}
		public String getShortDescription() {
			return shortDescription;
		}
		public void setShortDescription(String shortDescription) {
			this.shortDescription = shortDescription;
		}
		public String getChannelName() {
			return ChannelName;
		}
		public void setChannelName(String channelName) {
			ChannelName = channelName;
		}
		public String getChannelCode() {
			return ChannelCode;
		}
		public void setChannelCode(String channelCode) {
			ChannelCode = channelCode;
		}
		public long getCategroyID() {
			return CategroyID;
		}
		public void setCategroyID(long categroyID) {
			CategroyID = categroyID;
		}
		public long getCreatedBy() {
			return CreatedBy;
		}
		public void setCreatedBy(long createdBy) {
			CreatedBy = createdBy;
		}
		public Timestamp getCreatedOn() {
			return CreatedOn;
		}
		public void setCreatedOn(Timestamp createdOn) {
			CreatedOn = createdOn;
		}
		public long getModifiedBy() {
			return ModifiedBy;
		}
		public void setModifiedBy(long modifiedBy) {
			ModifiedBy = modifiedBy;
		}
		public Timestamp getModifiedOn() {
			return ModifiedOn;
		}
		public void setModifiedOn(Timestamp modifiedOn) {
			ModifiedOn = modifiedOn;
		}
		public short getIsActive() {
			return IsActive;
		}
		public void setIsActive(short isActive) {
			IsActive = isActive;
		}
		public long getDeletedBy() {
			return DeletedBy;
		}
		public void setDeletedBy(long deletedBy) {
			DeletedBy = deletedBy;
		}
		public Timestamp getDeletedOn() {
			return DeletedOn;
		}
		public void setDeletedOn(Timestamp deletedOn) {
			DeletedOn = deletedOn;
		}
		public String getChannelNameWithCode() {
			return channelNameWithCode;
		}
		public void setChannelNameWithCode(String channelNameWithCode) {
			this.channelNameWithCode = channelNameWithCode;
		}
	   
}
