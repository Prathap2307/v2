package com.LIC.bl;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.LIC.entity.AuthorisedSignatoryModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

/**
 * @author Pradip/Rahul 
 *
 *2019
 */
public class AuthorisedSignatoryBL  {
	
	private static final Logger logger = Logger.getLogger(AuthorisedSignatoryBL.class);
	
	public AuthorisedSignatoryModal createAuthorisedSignatoryModal(ValueObject object) {
		
		try {
			
			AuthorisedSignatoryModal AuthorisedSignatoryInfo	= new AuthorisedSignatoryModal();
			AuthorisedSignatoryInfo.setAuthorisedSignatoryID(object.getLong("AuthorisedSignatoryID",0));
			AuthorisedSignatoryInfo.setModuleID(object.getLong("ModuleID",0));
			AuthorisedSignatoryInfo.setName(object.getString("Name",""));
			AuthorisedSignatoryInfo.setDesignation(object.getString("Designation",""));
			AuthorisedSignatoryInfo.setEmail(object.getString("Email",""));
			AuthorisedSignatoryInfo.setContactMobileNo(object.getString("ContactMobileNo",""));
			AuthorisedSignatoryInfo.setSignature(object.getString("Signature",""));
			AuthorisedSignatoryInfo.setCreatedBy(object.getLong("CreatedBy",0));
			
			if(object.get("ModifiedOn") != null && !object.get("CreatedOn").equals("")) {
				AuthorisedSignatoryInfo.setModifiedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("ModifiedOn")));
			}
			if(object.get("DeletedOn") != null && !object.get("CreatedOn").equals("")) {
				AuthorisedSignatoryInfo.setDeletedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("DeletedOn")));
			} 
			if(object.get("CreatedOn") != null && !object.get("CreatedOn").equals("")) {
				AuthorisedSignatoryInfo.setCreatedOn((Timestamp) DateTimeUtility.getTimeStamp(object.getString("CreatedOn")));
			} else {
				AuthorisedSignatoryInfo.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			}
			
			AuthorisedSignatoryInfo.setModifiedBy(object.getLong("ModifiedBy", 0));
			AuthorisedSignatoryInfo.setIsActive(object.getShort("IsActive",(short)1));
			
			 return AuthorisedSignatoryInfo;
		} catch (Exception e) {
			logger.info("error :"+e.getLocalizedMessage());
		}
		return null;
	}
	

}


