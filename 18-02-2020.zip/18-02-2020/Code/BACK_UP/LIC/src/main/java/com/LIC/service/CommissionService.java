package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.bl.CommissionBL;
import com.LIC.dao.CommissionDao;
import com.LIC.entity.CommissionModal;
import com.LIC.utils.dataobject.ValueObject;

@Service
public class CommissionService {
	
	CommissionBL			commissionBL 	= new CommissionBL();
	CommissionDao 			commissionDao 	= new CommissionDao();
	
	private static final Logger logger = Logger.getLogger(CommissionService.class);
	
	public long InsertOrUpdateCommision(ValueObject CommisionObject) {
		
		CommissionModal 		commissionModal 			= null;
		
        try {
        	commissionModal 	= commissionBL.createCommisionInfoDto(CommisionObject);
           
           if(commissionModal != null) {
        	   return commissionDao.InsertorUpdateCommsion(commissionModal);
           }
           
        } catch (Exception ex) {
            logger.info(ex.getLocalizedMessage());
        }
		return 0;
    }
	
	public String IsCommssionDetailExists(ValueObject CommisionObject) {
		
		CommissionModal 		commissionModal 			= null;
		
		try {
			commissionModal 	= commissionBL.createCommisionInfoDto(CommisionObject);
			
			if(commissionModal != null) {
				return commissionDao.IsCommssionDetailExists(commissionModal);
			}
			
		} catch (Exception ex) {
			logger.info(ex.getLocalizedMessage());
		}
		return "Error";
	}
	
	
	 public List<CommissionModal>  GetCommissionDetailsById(long CommisionID) throws Exception{
			
		try {
			
			return commissionDao.GetCommissionDetailsByCommissionID(CommisionID);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		
		return null;
	}

	 
	 public List<CommissionModal>  getAllCommissionDetails() throws Exception {
   	  
   	  List<CommissionModal> 	CommissionModalList		= null;
   	  
   	  try {
   		  
   		CommissionModalList  = commissionDao.GetCommissionDetails();
   		  
   	  } catch(Exception e) {
   		  e.printStackTrace();
   		  logger.info("-- Error :"+e.getMessage());
   	  }
   	  
   	  return CommissionModalList;
     }
	 
	 public String deleteCommission(long commissionID, int deletedby) throws Exception {
         
   	  try {
             commissionDao.DeleteCommission(commissionID, deletedby);
             
             return "Success";
         
         } catch (Exception ex) {
       	  ex.printStackTrace();
   		  logger.info("-- Error :"+ex.getMessage());
         }
         
         return "ERROR";
     }
	 
	 public List<CommissionModal>  getGetCommissionWithSearch(ValueObject CommisionObject) throws Exception {
	   	  
		 CommissionModal 		commissionModal 			= null;
			
			try {
				
				commissionModal 	= commissionBL.createCommisionInfoDto(CommisionObject);
				
				if(commissionModal != null) {
					return  commissionDao.GetCommissionDetailsBySearch(commissionModal);
				}
	   		  
	   	  } catch(Exception e) {
	   		  e.printStackTrace();
	   		  logger.info("-- Error :"+e.getMessage());
	   	  }
	   	  
	   	  return null;
	  }
	 
}


