package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.entity.CountryModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class CountryDao  {

	
	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(CountryDao.class);
	
	public List<CountryModal> getAllCountries() throws Exception {

			CallableStatement		cstm				= null;
			Connection 				conn 				= null;
			ResultSet 				result 				= null;
			CountryModal			countryModal		= null;
			List<CountryModal>		countryList			= null;
			
			try {

				//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
				conn   		= ResourceManager.getConnection();
				
				cstm 		= conn.prepareCall("call spGetAllCountries(?) ");
				
				cstm.registerOutParameter(1, OracleTypes.CURSOR); //REF CURSOR
				cstm.execute();
				
				result = ((OracleCallableStatement)cstm).getCursor(1);

			    if(result != null) {
			    	
			    	countryList	= new ArrayList<CountryModal>();
			    	
			    	while (result.next ()) {
			    		countryModal = new CountryModal();
			    		
			    		countryModal.setCountryId(result.getLong("CountryID"));
			    		countryModal.setCountryCode(result.getString("countryCode"));
			    		countryModal.setDescription(result.getString("description"));
			    		countryModal.setIsDeclined(result.getShort("IsDeclined"));
			    		
			    		countryList.add(countryModal);
			    	}
			    }
			
			    return countryList;
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage(), e);
			} finally {
				cstm.close();
				cstm	= null;
				ResourceManager.freeConnection(conn);
				conn	= null;
			}
			return null;
		}
	
}
