package com.LIC.bl;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.LIC.entity.StampDutyModal;
import com.LIC.utils.dataobject.ValueObject;
import com.LIC.utils.datetime.DateTimeUtility;

public class StampDutyBL {
	
	private static final Logger logger = Logger.getLogger(StampDutyBL.class);

	public StampDutyModal createStampDutyDto(ValueObject object) throws Exception {
           
		try {
			
			StampDutyModal	stampDuty	= new StampDutyModal();
			 	
			stampDuty.setStampDutyID(object.getLong("stampDutyID",0));
			stampDuty.setProductID(object.getLong("productID",0));
			stampDuty.setCoverageID(object.getLong("coverageID",0));
			stampDuty.setStampDutyAmount(object.getDouble("stampDutyAmount",0));
			stampDuty.setMudrakNumber(object.getString("mudrakNumber",""));
			stampDuty.setPayOrderNumber(object.getString("payOrderNumber",""));
			stampDuty.setReceiptNumber(object.getString("receiptNumber",""));
			stampDuty.setBalanceStampDutyAmount(object.getDouble("balanceStampDutyAmount",0));
			stampDuty.setTriggerAmount(object.getDouble("triggerAmount",0));
			stampDuty.setAdvanceDepositAmount(object.getDouble("advanceDepositAmount",0));
			stampDuty.setCreatedBy(object.getLong("createdBy",0));
			stampDuty.setType(object.getLong("type",0));
			
			if(object.get("paymentDate") != null  && !object.get("paymentDate").equals("")) {
				stampDuty.setPaymentDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("paymentDate")));
			} 
			if(object.get("challanEndDate") != null  && !object.get("challanEndDate").equals("")) {
				stampDuty.setChallanEndDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("challanEndDate")));
			} 
			if(object.get("defaceDate") != null  && !object.get("defaceDate").equals("")) {
				stampDuty.setDefaceDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("defaceDate")));
			} 
			if(object.get("certificateDate") != null  && !object.get("certificateDate").equals("")) {
				stampDuty.setCertificateDate((Timestamp) DateTimeUtility.getTimeStamp(object.getString("certificateDate")));
			} 
			stampDuty.setDefaceNumber(object.getString("defaceNumber",""));
			stampDuty.setCertificateNumber(object.getString("certificateNumber",""));
			stampDuty.setIntimationEmailAddress(object.getString("intimationEmailAddress",""));
			stampDuty.setIntimationMobileNumber(object.getString("IntimationMobileNumber",""));
			
			return stampDuty;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("error :"+e.getLocalizedMessage());
		} 
		return null;
	}
}
