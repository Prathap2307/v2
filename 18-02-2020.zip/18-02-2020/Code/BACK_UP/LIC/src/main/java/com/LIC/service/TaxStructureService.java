package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.bl.TaxStructureBL;
import com.LIC.dao.TaxStructureDao;
import com.LIC.entity.TaxStructureModal;
import com.LIC.utils.dataobject.ValueObject;

/**
 * @author Pradip/Rahul
 *
 *2019
 */
@Service
public class TaxStructureService {
	
	TaxStructureBL 				taxStructureBL 			= new TaxStructureBL();
	TaxStructureDao				taxStructureDao 		= new TaxStructureDao();
	
	private static final Logger logger = Logger.getLogger(TaxStructureService.class);
	
	public int InsertOrUpdateTaxStructure(ValueObject taxStructureObject) throws Exception {
		
		TaxStructureModal 			taxStructure			= null;
		
        try {
        	taxStructure = taxStructureBL.createTaxStructureModal(taxStructureObject);
           
           if(taxStructure != null) {
        	   
        	   taxStructureDao.InsertOrUpdate(taxStructure , taxStructure.getTaxStructureDetails());
           }
           
        } catch (Exception ex) {
        	ex.printStackTrace();
            logger.info(ex.getLocalizedMessage());
            return 1;
        }
		return 0;
    }
	
	public List<TaxStructureModal> GetAllTaxStructureBasedonTaxName(String taxStructureName) throws Exception {
		
		try {
			
			return taxStructureDao.GetAllTaxStructureBasedonTaxName(taxStructureName);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());	
		}
		return null;
	}
	
	public String DeleteTaxStructure(long taxStructureID, long deletedBy) throws Exception {
		
		try {
			
			return  taxStructureDao.DeleteTaxStructure(taxStructureID, deletedBy);
            
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());	
		}
		return null;
	}
	
	public String IsTaxStructureExist(ValueObject taxStructureObject) throws Exception {
		
		TaxStructureModal 			taxStructure			= null;
		
		try {
			
			taxStructure = taxStructureBL.createTaxStructureModal(taxStructureObject);
           
           if(taxStructure != null) {
        	   return  taxStructureDao.IsTaxStructureExist(taxStructure);
           }
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());	
		}
		return null;
	}
   
	public List<TaxStructureModal> GetAllTaxStructureDetailsByTaxStructureID(long taxStructureID) {
		
		try {
			
			return taxStructureDao.GetAllTaxStructureDetailsByTaxStructureID(taxStructureID);
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	public List<TaxStructureModal> GetAllTaxStructure() {
		
		try {
			
			return taxStructureDao.GetAllTaxStructure();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());	
		}
		return null;
	}
	 
	

	//pending
	public List<TaxStructureModal> GetTaxStructureById(long taxStructureID) throws Exception {
		try {
			
			return taxStructureDao.GetTaxStructureById(taxStructureID);
		
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
	//pending
	public List<TaxStructureModal> GetAllTaxStructureDetails(long taxStructureID) throws Exception {
		try {
			
			return taxStructureDao.GetAllTaxStructureDetails(taxStructureID);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		return null;
	}
	
}


