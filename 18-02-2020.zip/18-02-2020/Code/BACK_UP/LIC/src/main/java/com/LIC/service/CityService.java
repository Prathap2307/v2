package com.LIC.service;

import org.springframework.stereotype.Service;

/**
 * @author Ashish/Parth
 *
 *2019
 */
@Service
public class CityService

{

}


