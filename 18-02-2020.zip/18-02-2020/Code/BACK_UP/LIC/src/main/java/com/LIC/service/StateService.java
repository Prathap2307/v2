package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.dao.StateDao;
import com.LIC.entity.StateModal;

/**
 * @author Ashish/Parth
 *
 *2019
 */
@Service
public class StateService

{
	
   StateDao		StateMasterDao = new StateDao();
	
	private static final Logger logger = Logger.getLogger(StateService.class);

	public List<StateModal>  getAllStateByCountryId(long countryID) throws Exception{
		
		List<StateModal>		stateList		= null;
		
		try {
			
			stateList  = StateMasterDao.getAllStatesByCountryId(countryID);
			
		} catch(Exception e) {
			e.printStackTrace();
			logger.info("-- Error :"+e.getMessage());
		}
		
		return stateList;
	}
}


