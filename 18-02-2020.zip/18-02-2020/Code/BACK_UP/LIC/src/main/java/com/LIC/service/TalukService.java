package com.LIC.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.LIC.dao.TalukDao;
import com.LIC.entity.TalukaModal;

/**
 * @author Ashish/Parth
 *
 *2019
 */
@Service
public class TalukService {
	
	private static final Logger logger = Logger.getLogger(TalukService.class);
	
	TalukDao		talukDao 	= new TalukDao();
	
	public List<TalukaModal>  getAllTalukasByDistrictId(long districtId) throws Exception{
		
		List<TalukaModal>		talukaList		= null;
		
		try {
			
			talukaList	= talukDao.getAllTalukasByDistrictId(districtId);
			
			return talukaList;
		} catch (Exception e) {
			
			logger.info(e.getMessage());
		} finally {
			talukaList		= null;
		}
		return null;
	}
}


