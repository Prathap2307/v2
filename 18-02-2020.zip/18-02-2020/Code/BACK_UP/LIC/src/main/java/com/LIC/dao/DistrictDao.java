package com.LIC.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.LIC.entity.DistrictModal;
import com.LIC.resource.ResourceManager;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

@Repository
public class DistrictDao
{

	
	@Autowired						JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(DistrictDao.class);

	public List<DistrictModal> getAllDistrictsByStateId(long stateID) throws Exception {
		
		CallableStatement		cstm				= null;
		Connection 				conn 				= null;
		ResultSet 				result 				= null;
		DistrictModal			districtModal		= null;
		List<DistrictModal>		districtList		= null;
		
		try {

			//conn 		= DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
			conn   		= ResourceManager.getConnection();
			 
			cstm 		= conn.prepareCall("call spGetAllDistricts(?,?) ");
			
			cstm.setLong(1, stateID); 
			cstm.registerOutParameter(2, OracleTypes.CURSOR); //REF CURSOR
			cstm.execute();
			
			result = ((OracleCallableStatement)cstm).getCursor(2);

		    if(result != null) {
		    	
		    	districtList	= new ArrayList<DistrictModal>();
		    	
		    	while (result.next()) {
		    		districtModal = new DistrictModal();
		    		
		    		districtModal.setDistrictId(result.getLong("DistrictID"));
		    		districtModal.setStateID(stateID);
		    		districtModal.setZipCode(result.getString("ZipCode"));
		    		districtModal.setDescription(result.getString("Description"));
		    		
		    		districtList.add(districtModal);
		    	}
		    }
		
		    return districtList;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			cstm.close();
			cstm			= null;
			ResourceManager.freeConnection(conn);
			conn			= null;
			districtList	= null;
		}
		return null;
	}
	
}
