﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using firstProject.Models;
namespace firstProject.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/
        public ActionResult Index()
        {


            DL_Employee dal = new DL_Employee();
            List<BE_Employee> employees = dal.Employees.ToList();


            return View(employees);

            //return View();
        }

        private List<BE_Employee> BE_Employee { get; set; }
        public IEnumerable<BE_Employee> Get()
        {

            DL_Employee dal = new DL_Employee();
            List<BE_Employee> employees = dal.Employees.ToList();
            return employees;
        }



       // public IEnumerable<BE_Employee> Name { get; set; }
    }
}