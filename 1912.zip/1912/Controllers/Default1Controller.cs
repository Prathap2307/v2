﻿using firstProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace firstProject.Controllers
{
    [EnableCors(origins: "http://localhost:4200/", headers: "accept,content-type,origin,x-my-header", methods: "*")]

    public class Default1Controller : ApiController
    {
        // GET api/default1
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/default1/5
        //public string Get(int id)
        //{
        //    return "value";
        //}

       // private List<BE_Employee> BE_Employee { get; set; }
        public IEnumerable<BE_Employee> Get()
        {

            DL_Employee dal = new DL_Employee();
            List<BE_Employee> employees = dal.Employees.ToList();

           // dynamic obj = JsonConvert.DeserializeObject(data);  
           // return Request.CreateResponse(HttpStatusCode.OK, employees);
           // return Json(employees);
            //return Request.CreateResponse(HttpStatusCode.OK, Result);

          //  return Request.CreateResponse(HttpStatusCode.OK, model, Configuration.Formatters.JsonFormatter);
         return employees;

           // return Ok(new { employees });
        }
    }
}
