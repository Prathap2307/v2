import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Register } from './registration';
import { RegistrationService } from './registration.service';
import { Hero } from './hero';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
  providers: [ RegistrationService ]
})
export class RegistrationComponent implements OnInit {

  constructor(private RegistrationService: RegistrationService) { }

  registerObj: Register[];
  cityObj: Register[];
  // getHeroes(): void {
  //   this.RegistrationService.getHeroes()
  //     .subscribe(heroes => this.heroes = heroes);
     
  // }


  ngOnInit() {
    this.getCity();
  }


  // phoneNumber = "^(\+\d{1,3}[- ]?)?\d{10}$";

  RegisterForm = new FormGroup({

    Name: new FormControl("", [Validators.required]),
    DateofBirth :new FormControl("", [Validators.required]),
    MobileNumber: new FormControl("", [Validators.required]),
    EmailID: new FormControl("", [Validators.required]),
    Password :new FormControl("", [Validators.required]),
    ConfirmPassword :new FormControl("", [Validators.required]),

  });
 
  onSubmit(){
    //console.log(this.RegisterForm.value);

      // stop here if form is invalid
      if (!this.RegisterForm.invalid) {
            let user = this.RegisterForm.value;
            this.RegistrationService
            .addHero(user)
            .subscribe(user => this.registerObj.push(user));

           // return
        }

      //  console.log(this.RegisterForm.value)
  }

  
  getCity(): void {
    this.RegistrationService.getCity()
      .subscribe(cityObj => this.cityObj = cityObj);
      console.log(this.cityObj);
  }

}



  // "outputPath": "dist/LIC",