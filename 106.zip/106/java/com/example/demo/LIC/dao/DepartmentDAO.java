package com.example.demo.LIC.dao;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.LIC.model.DepartmentModel;

@Repository
public class DepartmentDAO {
	@Autowired
	private EntityManager em;

	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfo() {
		return em.createNamedStoredProcedureQuery("firstProcedure").getResultList();
	}
	

	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfoByID(String input) {
		return em.createNamedStoredProcedureQuery("secondProcedure").setParameter("deptID", input).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfoByDescription(String input) {
		return em.createNamedStoredProcedureQuery("DepartmentInfoByDescription").setParameter("sdescription", input).getResultList();
	}
	
	//@SuppressWarnings("unchecked")
	public void updateDepartmentInfoByID(String id, String shortname) {
		 //em.createNamedStoredProcedureQuery("updateDepartmentInfo").setParameter("pshortname", shortname).getResultList();
		em.createNamedStoredProcedureQuery("updateDepartmentInfo")
		.setParameter("pid", id)
		.setParameter("pshortname", shortname)
		.getResultList();
	}
}
