import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memberupload',
  templateUrl: './memberupload.component.html',
  styleUrls: ['./memberupload.component.css']
})
export class MemberuploadComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
