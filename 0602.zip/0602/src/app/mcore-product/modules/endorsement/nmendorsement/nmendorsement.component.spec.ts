import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NmendorsementComponent } from './nmendorsement.component';

describe('NmendorsementComponent', () => {
  let component: NmendorsementComponent;
  let fixture: ComponentFixture<NmendorsementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NmendorsementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NmendorsementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
