import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memberdeletion',
  templateUrl: './memberdeletion.component.html',
  styleUrls: ['./memberdeletion.component.css']
})
export class MemberdeletionComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
