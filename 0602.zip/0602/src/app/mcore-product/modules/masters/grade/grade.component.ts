import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit {

  submitted = false;
  gradeForm:FormGroup;
  gradeFormAction:FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.gradeForm = this.fb.group({
      searchGrade:[],
      gradeFormAction:this.fb.group({
        grade:
        [
          '',
          [Validators.required]
        ]
      })
    });
  }
  onBtnSaveGrade(){
    this.gradeForm.controls.gradeFormAction.markAllAsTouched();   
    if (this.gradeForm.controls.gradeFormAction.valid) {
      let val = this.gradeForm.controls.gradeFormAction.value;      
    }
  }  
  onBtnSearchClearGrade(){        
    this.gradeForm.reset();
  }
  onBtnClearGrade(){    
    this.gradeForm.controls.gradeFormAction.reset();
  }
}
