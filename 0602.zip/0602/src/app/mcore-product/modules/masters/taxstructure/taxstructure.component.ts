import { Component, OnInit } from '@angular/core';
import { Taxstructure } from '../taxstructure/taxstructure';

@Component({
  selector: 'app-taxstructure',
  templateUrl: './taxstructure.component.html',
  styleUrls: ['./taxstructure.component.css']
})
export class TaxstructureComponent implements OnInit {
  typesOfBrands: string[];
  dummyObj: string[];
  departmentObj: Taxstructure[];
  constructor() { }

  ngOnInit() {
  }
  departmentColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];
}
