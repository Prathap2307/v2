import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FsaleshierarchyComponent } from './fsaleshierarchy.component';

describe('FsaleshierarchyComponent', () => {
  let component: FsaleshierarchyComponent;
  let fixture: ComponentFixture<FsaleshierarchyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FsaleshierarchyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FsaleshierarchyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
