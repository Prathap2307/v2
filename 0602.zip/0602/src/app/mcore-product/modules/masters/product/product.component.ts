import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Product } from 'src/app/mcore-product/mcore-shared/mcore-entity/product';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { TooltipPosition } from '@angular/material/tooltip';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  // Product Variable Declaration
  categories: any = ['Credit Cover', 'Term Cover']
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  productObj: Product[];
  productFilteredObj: Product[] = [];
  productColumns: string[] = ['View', 'Edit', 'Delete', 'productName', 'code'];

  dropDownMode: Boolean;
  productForm: FormGroup;
  productFormAction: FormGroup;
  productHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  dataSource = new MatTableDataSource<Product>(this.productObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private changeDetectorRefs: ChangeDetectorRef
  ) { }

  ngOnInit() {
    // setTimeout(() => this.dataSource.paginator = this.paginator);
    // this.dataSource = new MatTableDataSource<Product>(this.productObj);
    this.productHeading = 'Add New - Product';
    this.btnSaveText = 'Save';
    this.getProductDetails();
    this.ValidateProductDataForm();
    this.ngAfterViewInit();
  }

  // Search Events Product
  onBtnSearchProductClick() {
    this.getProductBySearch();
  }
  onBtnSearchClearProductClick() {
    this.productForm.reset();
    this.getProductDetails();
  }
  // Save Events Product
  onBtnSaveProductClick() {
    this.SaveProductDetailData();
  }
  onBtnClearProductClick() {
    this.ClearProductDetails();
  }
  // Grid View Button Events
  public btngvView_Click(a) {
    this.dropDownMode = true;
    this.productFilteredObj = this.productObj.filter((unit) => unit.productId == a);
    this.productForm = this.fb.group({
      searchProductName: [''],
      productFormAction: this.fb.group({
        productId: { value: this.productFilteredObj[0].productId, disabled: true },
        productName: { value: this.productFilteredObj[0].productName, disabled: true },
        category: { value: this.productFilteredObj[0].category, disabled: true },
        //categoryid: { value: this.productFilteredObj[0].categoryId, disabled: this.dropDownMode },
        code: { value: this.productFilteredObj[0].code, disabled: true }
      })
    });
    this.productHeading = 'View - Product';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.productForm.patchValue({});
  }

  // Grid Edit Button Events
  public btngvEdit_Click(a) {
    this.dropDownMode = false;
    this.productFilteredObj = this.productObj.filter((unit) => unit.productId == a);
    this.productForm = this.fb.group({
      searchProductName: [''],
      productFormAction: this.fb.group({
        productId: { value: this.productFilteredObj[0].productId, disabled: false },
        productName: { value: this.productFilteredObj[0].productName, disabled: false },
        category: { value: this.productFilteredObj[0].category, disabled: false },
        //categoryid: { value: this.productFilteredObj[0].categoryId, disabled: this.dropDownMode },
        code: { value: this.productFilteredObj[0].code, disabled: false }
      })
    });
    this.productHeading = 'Edit - Product';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
  }

  // Grid Delete Button Events
  public btngvDelete_Click(a) {
    console.log(a);
    this.productService.deleteProduct(a).subscribe(result => { this.getProductDetails() });
  }
  // Methods
  public ValidateProductDataForm() {
    this.productForm = this.fb.group({
      searchProductName: [''],
      productFormAction: this.fb.group({
        productId: [''],
        productName:
          [
            '',
            [Validators.required]
          ],
        category:
          [
            '',
          ],
        code:
          [
            '',
            [Validators.required]
          ]
      })
    });
  }
  public SaveProductDetailData() {
    this.productForm.controls.productFormAction.markAllAsTouched();
    if (this.productForm.controls.productFormAction.valid) {
      let a = this.productForm.controls.productFormAction.value;
      this.productService.addProduct(a).subscribe(result => { this.getProductDetails() });
      this.productForm.controls.productFormAction.reset();
    }
  }
  public ClearProductDetails() {
    this.dropDownMode = false;
    this.productForm.controls.productFormAction.reset();
    this.productHeading = 'Add New - Product';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.productForm = this.fb.group({
      searchProductName: [''],
      productFormAction: this.fb.group({
        productId: { value: '', disabled: false },
        productName: { value: '', disabled: false },
        category: { value: '', disabled: false },
        //categoryid: { value: '', disabled: this.dropDownMode },
        code: { value: '', disabled: false },
      })
    });
  }
  // Get Product Details
  public getProductDetails(): void {
    // this.productService.getProductDetails().subscribe(productObj => { this.productObj = productObj; });
    this.productService.getProductDetails().subscribe(
      productObj => {
        this.dataSource = new MatTableDataSource<Product>(this.productObj);
        this.dataSource.data = this.productObj = productObj;
        this.dataSource.paginator = this.paginator;
      })
  }
  // Search Section
  public getProductBySearch(): void {
    if (this.productForm.controls.searchProductName.valid) {
      let searchValue = this.productForm.controls.searchProductName.value;
      this.productService.getProductBySearch(searchValue).subscribe(productObj => this.productObj = productObj);
    }

    // let searchProductName = this.productForm.controls.searchProductName.value;
    // this.productService.getProductBySearch(searchProductName).subscribe(productObj => this.productObj = productObj);    
  }
  // refresh() {
  //   this.changeDetectorRefs.detectChanges();
  // }

  //onBtnUpdateClick(): void {
  // if (this.productForm.controls.productFormAction.valid) {
  //   this.productService.updateProduct(this.productForm.controls.productFormAction.value).subscribe();
  // }
  //}  
}
