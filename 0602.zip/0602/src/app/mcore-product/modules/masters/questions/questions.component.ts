import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Question } from 'src/app/mcore-product/mcore-shared/mcore-entity/question';
import { QuestionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/question.service';
import { MatTableDataSource } from '@angular/material/table';
import { TooltipPosition } from '@angular/material/tooltip';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
  // Question Variables
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  questionObj: Question[];
  questionFilteredObj: Question[] = [];
  questionColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortDescription'];
  questionForm: FormGroup;
  questionFormAction: FormGroup;
  questionHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  dataSource = new MatTableDataSource<Question>(this.questionObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  public ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }  

  constructor(
    private fb: FormBuilder,
    private questionService: QuestionService,
  ) {    
  }

  ngOnInit() {
    // setTimeout(() => this.dataSource.paginator = this.paginator);
    // this.dataSource = new MatTableDataSource<Question>(this.questionObj);
    this.questionHeading = 'Add New - Question';
    this.btnSaveText = 'Save';
    this.getQuestionDetails();
    this.ValidateQuestionForm();
    this.ngAfterViewInit();
  }
  ValidateQuestionForm() {
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: [''],
        description:
          [
            '',
            [Validators.required]
          ],
        shortDescription:
          [
            '',
            [Validators.required]
          ],
        createdOn:
          [
            '',
            []
          ],
      })
    });
  }
  //Search 
  public onBtnSearchQuestionClick() {
    this.getQuestionBySearch();
  }
  public onBtnSearchClearQuestionClick() {
    this.questionForm.reset();
    this.getQuestionDetails();
  }
  // Save
  public onBtnSaveQuestionClick() {
    this.SaveQuestionDetails();
  }
  public onBtnClearQuestionClick() {
    this.ClearquestionDetails();
  }
  public ClearquestionDetails() {
    this.questionForm.controls.questionFormAction.reset();
    this.questionHeading = 'Add New - Question';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        shortDescription: { value: '', disabled: false },       
      })
    });
  }
  public SaveQuestionDetails() {
    this.questionForm.controls.questionFormAction.markAllAsTouched();
    if (this.questionForm.controls.questionFormAction.valid) {
      let a = this.questionForm.controls.questionFormAction.value;
      this.questionService.addQuestion(a).subscribe(result => { this.getQuestionDetails() });
      this.questionForm.controls.questionFormAction.reset();
    }
  }
  // Search Section
  public getQuestionBySearch(): void {
    if (this.questionForm.controls.searchDescription.valid) {
      let searchValue = this.questionForm.controls.searchDescription.value;
      this.questionService.getQuestionBySearch(searchValue).subscribe(questionObj => this.questionObj = questionObj);
    }
  }
  public getQuestionDetails(): void {
    // this.questionService.getQuestionDetails().subscribe(questionObj => { this.questionObj = questionObj; });
    this.questionService.getQuestionDetails().subscribe(
      questionObj => {  
        this.dataSource = new MatTableDataSource<Question>(this.questionObj);          
        this.dataSource.data = this.questionObj = questionObj;        
        this.dataSource.paginator = this.paginator;       
      })
  }
  // Grid View Button Events
  public btngvView_Click(a) {
    this.questionFilteredObj = this.questionObj.filter((unit) => unit.questionId == a);
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: { value: this.questionFilteredObj[0].questionId, disabled: true },
        description: { value: this.questionFilteredObj[0].description, disabled: true },
        shortDescription: { value: this.questionFilteredObj[0].shortDescription, disabled: true },
      })
    });
    this.questionHeading = 'View - Question';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.questionForm.patchValue({});
  }
  // Grid Edit Button Events
  public btngvEdit_Click(a) {
    this.questionFilteredObj = this.questionObj.filter((unit) => unit.questionId == a);
    this.questionForm = this.fb.group({
      searchDescription: [''],
      questionFormAction: this.fb.group({
        questionId: { value: this.questionFilteredObj[0].questionId, disabled: false },
        description: { value: this.questionFilteredObj[0].description, disabled: false },
        shortDescription: { value: this.questionFilteredObj[0].shortDescription, disabled: false },
      })
    });
    this.questionHeading = 'Edit - Question';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
  }
  // Grid Delete Button Events
  public btngvDelete_Click(a) {
    console.log(a);
    this.questionService.deleteQuestion(a).subscribe(result => { this.getQuestionDetails() });
  }    
}

