import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-quotation',
  templateUrl: './quotation.component.html',
  styleUrls: ['./quotation.component.css']
})
export class QuotationComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  dummyObj: string[];
  table2Obj;
  table1Obj;
  tableObj;
  constructor() { }

  ngOnInit() {
  }
  tableColumns: string[] = ['BasePremium', 'NetPremium', 'GSTAmount', 'NetPayableAmount', 'DiscretionaryDiscountLoading'];
  table1Columns: string[] = ['View', 'Edit', 'BasePremium', 'NetPremium', 'GSTAmount', 'NetPayableAmount', 'DiscretionaryDiscountLoading'];

  table2Columns: string[] = [ 'ClientName', 'SumInsured', 'NetInstallmentAmountPayable'];
}
