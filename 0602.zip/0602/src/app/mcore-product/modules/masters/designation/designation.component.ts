import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
import { DesignationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/designation.service';
import { TooltipPosition } from '@angular/material/tooltip';

import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.css']
})
export class DesignationComponent implements OnInit {

  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

  submitted = false;
  saveBtnMode: boolean;
  designationForm: FormGroup;
  designationFormAction: FormGroup;
  
  departmentObj: DepartmentType[];

  constructor(private fb:FormBuilder, private designationService: DesignationService, private departmentService: DepartmentService ) { }

  designationObj: Designation[] = [];
  designationFilteredObj: Designation[] = [];
  designationColumns: string[] = ['View', 'Edit', 'Delete', 'departmentName', 'designationName'];

  designationHeading: string = '';
  dropDownMode: Boolean;
  ngOnInit() {

    this.designationHeading = 'Add New - Designation';
    this.saveBtnMode = true;
    this.getDesignationDetails();
    this.getDepartmentDetails();
    this.designationForm = this.fb.group({
      searchdepartmentName:[''],
      searchdesignationName:[''],
      designationFormAction: this.fb.group({
        designationId: [''],
        id:
        [
          '',
          [Validators.required]
        ],
        designationName:
        [
          '',
          [Validators.required]
        ]
      }) 
    })
  }

  getDetailsInfoBySearch(): void {


    
      //console.log(this.DepartmentForm.controls.SearchDescription.value);
      let searchdesignationName = this.designationForm.controls.searchdesignationName.value;
      let searchDeptId = this.designationForm.controls.searchdepartmentName.value;
      
      this.designationService.getDetailsInfoBySearch(searchdesignationName, searchDeptId)
        .subscribe(designationObj => this.designationObj = designationObj);
    

  }

  onBtnSaveDesignation(){
    this.designationForm.controls.designationFormAction.markAllAsTouched();   
    if (this.designationForm.controls.designationFormAction.valid) {
     
      let a = this.designationForm.controls.designationFormAction.value;      
      console.log(this.designationForm.controls.designationFormAction.value);
      this.designationService.addDesignation(a)
      .subscribe(result => {this.getDesignationDetails()});

      this.designationForm.controls.designationFormAction.reset();

      this.designationHeading = 'Add New - Designation';
    }
  }  
  onBtnSearchClearDesignation(){        
    this.designationForm.reset();

    this.getDesignationDetails();
  }
  onBtnClearDesignation(){    
    this.dropDownMode = false;
    this.designationForm.controls.designationFormAction.reset();
    this.designationHeading = 'Add New - Designation';

    this.designationForm = this.fb.group({
      designationFormAction: this.fb.group({
        designationId: { value: '', disabled: false },
        id: { value: '', disabled: this.dropDownMode },
        designationName: { value: '', disabled: false },

      })


    });

    this.saveBtnMode = true;


  }
  getDesignationDetails(): void {

    this.designationService.getDesignationDetails()
      .subscribe(designationObj => {
        this.designationObj = designationObj;
      
      });

  }

  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => {
        this.departmentObj = departmentObj;
      
      });

  }

  btngvDelete_Click(a){
    this.designationService.deleteDesignation(a).subscribe(result => {this.getDesignationDetails()});
  }
 
  btngvView_Click(a) {
    this.saveBtnMode = false;
    this.dropDownMode = true;

    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({

      designationFormAction: this.fb.group({
        designationId: { value: this.designationFilteredObj[0].designationId, disabled: true },
         id: { value: this.designationFilteredObj[0].id, disabled: this.dropDownMode},
        designationName: { value: this.designationFilteredObj[0].designationName, disabled: true }

      })
    });

    this.designationHeading = 'View - Designation';

  
   
  }

  btngvEdit_Click(a) {
    this.saveBtnMode = true;
    this.dropDownMode = false
    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({

      designationFormAction: this.fb.group({
        designationId: { value: this.designationFilteredObj[0].designationId, disabled: false },
     id: { value: this.designationFilteredObj[0].id, disabled: this.dropDownMode },
        designationName: { value: this.designationFilteredObj[0].designationName, disabled: false }

      })
    });

    this.designationHeading = 'Edit - Designation';
   
  }
  
  disableSelect = new FormControl(false);

  //id = new FormControl(false);
 
  consoleLogFn(val) {
    console.log(val);
  }



  
}
