import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lookup',
  templateUrl: './lookup.component.html',
  styleUrls: ['./lookup.component.css']
})
export class LookupComponent implements OnInit {
  dummyObj: string[];
  constructor() { }

  ngOnInit() {
  }

}
