import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';

import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';

import { TooltipPosition } from '@angular/material/tooltip';
import { Key } from 'protractor';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})

export class DepartmentComponent implements OnInit {

  saveBtnMode: boolean = true;

  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

  


  departmentObj: DepartmentType[];
  departmentFilteredObj: DepartmentType[] = [];

  departmentColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];


  constructor(private departmentService: DepartmentService, private fb: FormBuilder, private changeDetectorRefs: ChangeDetectorRef) { }

 

  DepartmentForm: FormGroup;
  ActionGroupDepartment: FormGroup;

 
  // @ViewChild(MatPaginator, {static: false}) 
  // set paginator(value: MatPaginator) {
  //   this.dataSource.paginator = value;
  // }

  //  dataSource = new MatTableDataSource<DepartmentType>(this.departmentObj);
  //  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;

  departmentHeading: string = '';
  textSaveBtn: string = '';
 


  dataSource = new MatTableDataSource<DepartmentType>(this.departmentObj);

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  ngAfterViewInit(){
    this.dataSource.paginator = this.paginator;
  }

  ngOnInit() {
    setTimeout(() => this.dataSource.paginator = this.paginator);

      this.dataSource = new MatTableDataSource<DepartmentType>(this.departmentObj);
    

    this.departmentHeading = 'Add New - Department';
    this.textSaveBtn = 'Save';
    //setTimeout(() => this.dataSource.paginator = this.paginator);
    this.getDepartmentDetails();
    this.DepartmentForm = this.fb.group({
      SearchDescription: [''],
        ActionGroupDepartment: this.fb.group({
        id: [''],
        description: ['', Validators.required],
        shortName: ['', Validators.required]

      })
    });

   

  
  }
  
   



  onBtnSaveClick() {
    
    this.DepartmentForm.controls.ActionGroupDepartment.markAllAsTouched();

  //  this.DepartmentForm.controls.ActionGroupDepartment = this.fb.group({
  //   id: [''],
  //   description: ['', Validators.required],
  //   shortName: ['', Validators.required]

  // })

  
  //this.DepartmentForm.controls.ActionGroupDepartment.
  
    //this.editHero = undefined;
    // name = name.trim();
    // if (!name) {
    //   return;
    // }

    // The server will generate the id for this new hero
    //const newHero: DepartmentType = { a } as DepartmentType;
    // this.departmentService
    //   .addDepartment(newHero)
    //   .subscribe(hero => this.departmentObj.push(hero));



    if(this.DepartmentForm.controls.ActionGroupDepartment.valid){
      let a = this.DepartmentForm.controls.ActionGroupDepartment.value;
      this.departmentService.addDepartment(a)
      .subscribe(result => {this.getDepartmentDetails()});
      // hero => {
      //   this.departmentObj.push(hero);
      // }

      this.DepartmentForm.controls.ActionGroupDepartment.reset();
      this.departmentHeading = 'Add New - Department';
      this.textSaveBtn = 'Save';
    }
 
     
     
  }

  onBtnUpdateClick(): void {
    if (this.DepartmentForm.controls.ActionGroupDepartment.valid) {

      // console.log(this.DepartmentForm.);


      this.departmentService.updateDepartment(this.DepartmentForm.controls.ActionGroupDepartment.value)
        .subscribe();
       

    }
  }
  onBtnResetClick() {
    // this.DepartmentForm.reset();

    this.DepartmentForm.controls.ActionGroupDepartment.reset();
    this.departmentHeading = 'Add New - Department';
    this.textSaveBtn = 'Save';
    this.saveBtnMode = true;
    this.DepartmentForm = this.fb.group({
      SearchDescription: [''],
      ActionGroupDepartment: this.fb.group({
        id: { value: '', disabled: false },
        description: { value: '', disabled: false },
        shortName: { value: '', disabled: false },

      })


    });



  }

  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => {
        this.departmentObj = departmentObj;
      
      });

  }


  getDepartmentInfoByDescription(): void {

    //debugger
   console.log(this.DepartmentForm.controls.SearchDescription.value);
   this.DepartmentForm.controls['SearchDescription'].setValidators(Validators.required);
   this.DepartmentForm.controls['SearchDescription'].updateValueAndValidity();
   this.DepartmentForm.controls['SearchDescription'].markAsTouched();
  //let a = this.DepartmentForm.controls.SearchDescription.value;
    if (this.DepartmentForm.controls.SearchDescription.valid) {
     // debugger
      //console.log(this.DepartmentForm.controls.SearchDescription.value);
      let searchValue = this.DepartmentForm.controls.SearchDescription.value;

      this.departmentService.getDepartmentInfoByDescription(searchValue)
        .subscribe(departmentObj => this.departmentObj = departmentObj);
    }else{
    // debugger
     // this.DepartmentForm.controls['SearchDescription'].markAsTouched();
     // this.DepartmentForm.controls['SearchDescription'].setValidators(Validators.required);
    }

  }

  clearDepartmentInfoByID() {
    this.DepartmentForm.controls.SearchDescription.reset();
   this.getDepartmentDetails();
  }

  btngvView_Click(a) {

    //this.departmentFilteredObj = new DepartmentType[];
    this.departmentFilteredObj = this.departmentObj.filter((unit) => unit.id == a);

    // console.log(this.departmentFilteredObj[0].description);



    this.DepartmentForm = this.fb.group({

      SearchDescription: [''],

      ActionGroupDepartment: this.fb.group({
        id: { value: this.departmentFilteredObj[0].id, disabled: true },
        description: { value: this.departmentFilteredObj[0].description, disabled: true },
        shortName: { value: this.departmentFilteredObj[0].shortName, disabled: true }

      })


    });

    this.departmentHeading = 'View - Department';

   this.saveBtnMode = false;

    
  }


  btngvEdit_Click(a) {

   
    this.departmentFilteredObj = this.departmentObj.filter((unit) => unit.id == a);

    this.DepartmentForm = this.fb.group({

      SearchDescription: [''],

      ActionGroupDepartment: this.fb.group({
        id: { value: this.departmentFilteredObj[0].id, disabled: false },
        description: { value: this.departmentFilteredObj[0].description, disabled: false },
        shortName: { value: this.departmentFilteredObj[0].shortName, disabled: false }

      })


    });

    this.departmentHeading = 'Edit - Department';
    //this.textSaveBtn = 'Update';
    this.saveBtnMode = true;
  }

  btngvDelete_Click(a) {
   // this.heroes = this.heroes.filter(h => h !== hero);
   console.log(a);
    this.departmentService
      .deleteDepartment(a)
      .subscribe( result => {this.getDepartmentDetails()} );
    /*
    // oops ... subscribe() is missing so nothing happens
    this.heroesService.deleteHero(hero.id);
    */




   this.getDepartmentDetails();
  }

  consoleLogFn(val) {
    console.log(val);
  }


}
