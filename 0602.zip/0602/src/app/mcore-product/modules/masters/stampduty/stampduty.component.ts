import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stampduty',
  templateUrl: './stampduty.component.html',
  styleUrls: ['./stampduty.component.css']
})
export class StampdutyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
