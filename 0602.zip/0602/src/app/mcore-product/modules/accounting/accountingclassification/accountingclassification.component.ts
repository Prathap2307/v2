import { Component, OnInit, ViewChild, Input  } from '@angular/core';
import { AccountingClassification } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingclassificatin';

import { AccountingClassificationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingclassification.service';

import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-accountingclassification',
  templateUrl: './accountingclassification.component.html',
  styleUrls: ['./accountingclassification.component.css']
})
export class AccountingclassificationComponent implements OnInit {
 


  createBtn: boolean;

  accountingclassificatinObj: AccountingClassification[] = [];
  accountingclassificatinFilterObj: AccountingClassification[] = [];
  saveBtnMode: boolean;
  textSaveBtn: string = '';
  dataSource = new MatTableDataSource<AccountingClassification>(this.accountingclassificatinObj);
  
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  constructor(private fb:FormBuilder, private accountingService: AccountingClassificationService) { }
  AccountingClassificationForm: FormGroup;
  AccountingClassificationAction: FormGroup;
  actionHeading: string = '';


  ngOnInit() {
    this.saveBtnMode = true;

    this.textSaveBtn = 'Save';
    this.actionHeading = 'Add New - Accounting Classification Details';
    this.dataSource = new MatTableDataSource<AccountingClassification>(this.accountingclassificatinObj);
    this.getAccountingClassificationDetails();

    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: [''],
        code: ['',[Validators.required]],
        description:  ['',[Validators.required]],
        createdBy: ['']
       
      }) 
    })


  }

  AccountingClassificationtableColumns: string[] = ['View', 'Edit', 'code', 'description'];

  getAccountingClassificationDetails(): void{
    this.accountingService.getAccountingClassificationDetails().subscribe(a => {

      this.accountingclassificatinObj = a;
      this.dataSource = new MatTableDataSource<AccountingClassification>(this.accountingclassificatinObj);
      this.dataSource.data = this.accountingclassificatinObj = a;
      this.dataSource.paginator = this.paginator;                            


    });
  }
 
  onBtnSaveAccountingClassification(){
   
  
    if(this.createBtn){
        this.AccountingClassificationForm.get('AccountingClassificationAction').patchValue({
          accountClassificationID: '0'
        });
    } 


		this.AccountingClassificationForm.get('AccountingClassificationAction').markAllAsTouched();
		if (this.AccountingClassificationForm.get('AccountingClassificationAction').valid) {

			let a = this.AccountingClassificationForm.get('AccountingClassificationAction').value;
			console.log(a);
			this.accountingService.createAC(a)
				.subscribe(result => { this.getAccountingClassificationDetails() });
		}
   
  }


	btngvView_Click(a) {
    this.saveBtnMode = false;
    this.accountingclassificatinFilterObj = this.accountingclassificatinObj.filter((unit) => unit.accountClassificationID == a);
    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: { value: this.accountingclassificatinFilterObj[0].accountClassificationID, disabled: true },
        code: { value: this.accountingclassificatinFilterObj[0].code, disabled: true },
        description:  { value: this.accountingclassificatinFilterObj[0].description, disabled: true },
        createdBy: { value: this.accountingclassificatinFilterObj[0].createdBy, disabled: true }
       
      }) 
    });
	
    this.actionHeading = 'View - Accounting Classification Details';
	}

  btngvEdit_Click(a) {
    this.createBtn = false;
    this.saveBtnMode = true;
    this.accountingclassificatinFilterObj = this.accountingclassificatinObj.filter((unit) => unit.accountClassificationID == a);
    
    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: { value: this.accountingclassificatinFilterObj[0].accountClassificationID, disabled: false },
        code: { value: this.accountingclassificatinFilterObj[0].code, disabled: false },
        description:  { value: this.accountingclassificatinFilterObj[0].description, disabled: false },
        createdBy: { value: this.accountingclassificatinFilterObj[0].createdBy, disabled: false }
       
      }) 
    });
    this.actionHeading = 'Edit - Accounting Classification Details';
		this.textSaveBtn = 'Update';
	}
	onBtnClearAction() {
    this.actionHeading = 'Add New - Accounting Classification Details';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save';
    this.AccountingClassificationForm = this.fb.group({
      AccountingClassificationAction: this.fb.group({
        accountClassificationID: { value: '', disabled: false },
        code: { value: '', disabled: false },
        description:  { value: '', disabled: false },
        createdBy: { value: '', disabled: false }
       
      }) 
    });
  }
  
  cfn(a){
    console.log(a);
  }

}
