import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-accountinghead',
  templateUrl: './accountinghead.component.html',
  styleUrls: ['./accountinghead.component.css']
})
export class AccountingheadComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  elements: string;
  tableObj;
  accountingHeadColumns: string[] = ['View', 'Edit', 'headcode', 'headname','accountingclassification','accountinggroup','iscontrolAC','Ismanualvoucher'];
  constructor() { }

  ngOnInit() {
  }

}
