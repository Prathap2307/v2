import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TooltipPosition } from '@angular/material';

@Component({
  selector: 'app-accountinggroup',
  templateUrl: './accountinggroup.component.html',
  styleUrls: ['./accountinggroup.component.css']
})
export class AccountinggroupComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  accountingGroupColumns: string[] = ['View', 'Edit', 'code', 'description'];
  elements: string[];
  tableObj;
  constructor() { }

  ngOnInit() {
  }

}
