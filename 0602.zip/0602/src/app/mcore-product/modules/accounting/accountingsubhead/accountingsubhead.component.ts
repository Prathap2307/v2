import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-accountingsubhead',
  templateUrl: './accountingsubhead.component.html',
  styleUrls: ['./accountingsubhead.component.css']
})
export class AccountingsubheadComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  elements: string;
  tableObj;
  accountingSubHeadColumns: string[] = ['View', 'Edit', 'accounthead', 'subaccountheadcode','subaccountheadname'];
  constructor() { }

  ngOnInit() {
  }

}
