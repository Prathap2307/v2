export interface BankMaster{
    bankId: number;
	searchBank: string;
    bankName: string;
    bankShortName: string;
    createdBy: number;
    createdOn: Date;
    deletedBy:  number;
    deletedOn:  Date;
}