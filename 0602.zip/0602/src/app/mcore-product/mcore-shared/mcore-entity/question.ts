export interface Question {
	questionId: number;
	description: string;
	shortDescription: string;
	// lob: number;
	// orderId: number;
	// weightage: number;
	// createdBy: number;
	createdOn: Date;
	// createdTime: Date;
	// modifiedBy: number;
	// modifiedOn: Date;
	// deletedBy: number;
	// deletedOn: Date;
	// isActive: boolean;
}
