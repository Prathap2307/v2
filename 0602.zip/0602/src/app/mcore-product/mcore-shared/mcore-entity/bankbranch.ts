export class BankBranch{
    branchId: number;    
    bankName: number;
    bankCity: number;
    bankAddress: string;
    ifscCode: string;
    micrCode: string;
}