export interface AccountingClassification {
    accountClassificationID: number;
    code: string;
    description: string;
    createdBy: number;
    isactive: number;
}