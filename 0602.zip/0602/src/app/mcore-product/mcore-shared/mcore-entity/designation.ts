export interface Designation {
    designationId: number;
    departmentName: string;
	id: number;
    designationName: string;
    // searchdepartmentName: string;
}	