export interface Product {
	productId: number;
    productName: string;      
    code: string;
    categoryId: number;
    category: string;    
}	