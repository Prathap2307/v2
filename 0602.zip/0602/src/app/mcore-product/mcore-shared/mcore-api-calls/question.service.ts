import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Question } from 'src/app/mcore-product/mcore-shared/mcore-entity/question';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }
  questionUrl = this.baseUrl + '/question';
  // Get Question 
  getQuestionDetails(): Observable<Question[]> {
    // console.log(this.questionUrl);
    return this.http.get<Question[]>(this.questionUrl).pipe();
  }
  // Create Question
  createquestionUrl = this.baseUrl + '/createquestion';
  addQuestion(question: Question): Observable<Question> {
    //console.log(this.createquestionUrl);    
    return this.http.post<Question>(this.createquestionUrl, question);
  }
  // Delete Product 
  deleteQuestion(QuestionId: number): Observable<{}> {
    const deleteQuestionUrl = this.baseUrl + `/questionDelete/${QuestionId}`;
    console.log(deleteQuestionUrl);
    return this.http.delete(deleteQuestionUrl).pipe();
    //return this.http.delete(`${this.baseUrl}/productDelete/${productId}`);    
  }
  getQuestionBySearch(description: string): Observable<Question[]> {
    console.log(description);
    const questionByNameUrl = this.baseUrl + `/question/${description}`;
    console.log(questionByNameUrl);
    return this.http.get<Question[]>(questionByNameUrl).pipe();
  }
}
