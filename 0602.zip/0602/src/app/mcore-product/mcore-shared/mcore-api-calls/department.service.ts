import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {
  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }


  departmentUrl = this.baseUrl + '/department';

  /* GET Department */
  getDepartmentDetails(): Observable<DepartmentType[]> {
    console.log(this.departmentUrl);
    return this.http.get<DepartmentType[]>(this.departmentUrl)
      .pipe();
  }


  /* GET Department by ID */
  getDepartmentInfoByDescription(description: string): Observable<DepartmentType[]> {

    const departmentByIDUrl = this.baseUrl + `/department/${description}`;

    // return this.http.get<Hero>(url).pipe(
    //   tap(_ => this.log(`fetched hero id=${id}`)),
    //   catchError(this.handleError<Hero>(`getHero id=${id}`))
    // );

    console.log(departmentByIDUrl);
    return this.http.get<DepartmentType[]>(departmentByIDUrl)
      .pipe();
  }

  /** PUT: update the hero on the server */

  updateDepartment(departmentRow: DepartmentType): Observable<void> {
    console.log(departmentRow);
    const departmentUpdateUrl = this.baseUrl + `/departmentUpdate/${departmentRow.id}`;
    console.log(departmentUpdateUrl);
    return this.http.put<void>(this.departmentUrl, departmentRow).pipe(
      catchError(this.handleError)
    );


    // return this.http.put(this.heroesUrl, hero, this.httpOptions).pipe(
    //   tap(_ => this.log(`updated hero id=${hero.id}`)),
    //   catchError(this.handleError<any>('updateHero'))
    // );
  }


  // log(arg0: string): void {
  //   throw new Error("Method not implemented.");
  // }
  handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput<any> {
    throw new Error("Method not implemented.");
  }
  consoleLogFn(val) {
    console.log(val);
  }

  createdepartmentUrl = this.baseUrl + '/createdepartment';
  addDepartment(departmentRow: DepartmentType): Observable<DepartmentType> {
    console.log(this.createdepartmentUrl);
    console.log(departmentRow);
    return this.http.post<DepartmentType>(this.createdepartmentUrl, departmentRow);
  }


  // log(arg0: string): void {
  //   throw new Error("Method not implemented.");
  // }

    /** DELETE: delete the hero from the server */
    deleteDepartment (id: number): Observable<{}> {
      
      const deleteDepartmentUrl = this.baseUrl + `/departmentDelete/${id}`;
     return this.http.delete(deleteDepartmentUrl)
     .pipe(
      //tap(HttpResponse => console.log("status: " + HttpResponse)),
      // tap(status => console.log("status: " + status)),
         //catchError(this.handleError)
      );

    }



}
