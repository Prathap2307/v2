import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Product } from 'src/app/mcore-product/mcore-shared/mcore-entity/product';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  baseUrl = environment.API_URL;

  constructor(
    private http: HttpClient
  ) { }

  productUrl = this.baseUrl + '/product';

  // Get Product
  getProductDetails(): Observable<Product[]> {
    console.log(this.productUrl);
    return this.http.get<Product[]>(this.productUrl).pipe();
  }

  // Create a Product
  createproductUrl = this.baseUrl + '/createproduct';
  addProduct(product: Product): Observable<Product> {
    // console.log(this.createproductUrl);
    // console.log(productRow);
    return this.http.post<Product>(this.createproductUrl, product);
  }

  // Delete Product 
  public deleteProduct(productId: number): Observable<{}> {
     const deleteProductUrl = this.baseUrl + `/productDelete/${productId}`;
     console.log(deleteProductUrl);
     return this.http.delete(deleteProductUrl).pipe();
    //return this.http.delete(`${this.baseUrl}/productDelete/${productId}`);    
  } 

  // public deleteProduct(productId: number): Observable<{}> {
  //   return this.http.delete(`${this.baseUrl}/deleteproduct/${productId}`);
  // }

  // Update the Product
  // updateProduct(product: Product): Observable<void> {
  //   //console.log(product);
  //   const updateProductUrl = this.baseUrl + `/createproduct/${product.productId}`;
  //   console.log(updateProductUrl);
  //   return this.http.put<void>(this.productUrl, product).pipe(catchError(this.handleError));
  // }  

  // getProductBySearch(productId: number): Observable<Product[]> {
  //   console.log(productId);
  //   const productByIDUrl = this.baseUrl + `/product/${productId}`;
  //   console.log(productByIDUrl);
  //   return this.http.get<Product[]>(productByIDUrl).pipe();
  // }

  getProductBySearch(pName: string): Observable<Product[]> {
    console.log(pName);
    const productByNameUrl = this.baseUrl + `/product/${pName}`;
    console.log(productByNameUrl);
    return this.http.get<Product[]>(productByNameUrl).pipe();
  }  
 
  // Error Handling
  handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput <any> {
    throw new Error("Method not implemented.");
  }
  consoleLogFn(val) {
    console.log(val);
  }
}
