import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountingprocessComponent } from './accountingprocess.component';

describe('AccountingprocessComponent', () => {
  let component: AccountingprocessComponent;
  let fixture: ComponentFixture<AccountingprocessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountingprocessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountingprocessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
