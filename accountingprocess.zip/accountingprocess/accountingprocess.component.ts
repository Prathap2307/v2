import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TooltipPosition } from '@angular/material';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { UserData } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingclassificatin';
@Component({
  selector: 'app-accountingprocess',
  templateUrl: './accountingprocess.component.html',
  styleUrls: ['./accountingprocess.component.css']
})
export class AccountingprocessComponent implements OnInit {
  displayedColumns = ['id', 'name', 'progress'];
 dataSourcez: MatTableDataSource<UserData>;
  users: UserData[] = [];
ngOnInit(){
  //this.dataSourcez = new MatTableDataSource(this.users);
}
  constructor() {
    this.dataSourcez = new MatTableDataSource(this.users);
  }

  // Creates new user.
  createNewUser(id: number): UserData {
    return {
      id: id,
      name: "prathap",
      progress: "100"
    };
  }

  // Adds new user.
  addRow() {
    this.dataSourcez.data.push(this.createNewUser(this.dataSourcez.data.length + 1));
    this.dataSourcez.filter = "";
    //console.log( this.dataSourcez);
  }

  onSaveClick(){
    console.log(this.dataSourcez.data);
  }

  cfn(a){
    console.log(a);
  }

}





