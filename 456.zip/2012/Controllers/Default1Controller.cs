﻿using firstProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace firstProject.Controllers
{
   

    public class Default1Controller : ApiController
    {
        // GET api/default1
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/default1/5
        //public string Get(int id)
        //{
        //    return "value";
        //}

       // private List<BE_Employee> BE_Employee { get; set; }
        public IEnumerable<BE_Employee> Get()
        {

            DL_Employee dal = new DL_Employee();
            List<BE_Employee> employees = dal.Employees.ToList();

           // dynamic obj = JsonConvert.DeserializeObject(data);  
           // return Request.CreateResponse(HttpStatusCode.OK, employees);
           // return Json(employees);
            //return Request.CreateResponse(HttpStatusCode.OK, Result);

          //  return Request.CreateResponse(HttpStatusCode.OK, model, Configuration.Formatters.JsonFormatter);
         return employees;

           // return Ok(new { employees });
        }


        // POST api/default1
        //public void Post([FromBody]string value)
        //{

        //    using (TESTEntities entities = new TESTEntities())
        //    {
        //        entities.employeesDatas.Add(employee);
        //        entities.SaveChanges();
        //    }  
        //}

        //public void Post([FromBody] Employee employee)
        //{
        //    using (EmployeeDBContext dbContext = new EmployeeDBContext())
        //    {
        //        dbContext.Employees.Add(employee);
        //        dbContext.SaveChanges();
        //    }
        //}


        //creating the object of EmpRepository class  
        static DL_Employee repository = new DL_Employee();


        public string AddEmployees(BE_Users userObj)
        {
            //calling EmpRepository Class Method and storing Repsonse   
            var response = repository.AddUsers(userObj);
            return response;

        }  




        //static DL_Employee repository = new DL_Employee();


        //public string AddEmployees(BE_Users Emp)
        //{
        //    //calling EmpRepository Class Method and storing Repsonse   
        //    var response = repository.AddEmployees(Emp);
        //    return response;

        //}  


        // GET api/default2/5
        //public string Get(int id)
        //{
        //    return "value";
        //}
    }
}
