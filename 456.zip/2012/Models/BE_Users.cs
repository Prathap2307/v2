﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace firstProject.Models
{
    public class BE_Users
    {
        public string FirstName { get; set; }
        public int MobileNumber { get; set; }
        public string EmailID { get; set; }
        public string UserPassword { get; set; }  
    }
}