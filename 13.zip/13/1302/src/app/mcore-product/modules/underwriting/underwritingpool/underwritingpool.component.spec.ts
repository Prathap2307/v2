import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderwritingpoolComponent } from './underwritingpool.component';

describe('UnderwritingpoolComponent', () => {
  let component: UnderwritingpoolComponent;
  let fixture: ComponentFixture<UnderwritingpoolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnderwritingpoolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderwritingpoolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
