import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderwritingmedicalComponent } from './underwritingmedical.component';

describe('UnderwritingmedicalComponent', () => {
  let component: UnderwritingmedicalComponent;
  let fixture: ComponentFixture<UnderwritingmedicalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnderwritingmedicalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderwritingmedicalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
