import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { TooltipPosition } from '@angular/material/tooltip';
import { MatPaginator } from '@angular/material/paginator';
import { AddressStructure } from 'src/app/mcore-product/mcore-shared/mcore-entity/addressstructure';
import { AddressstructureService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/addressstructure.service';

@Component({
  selector: 'app-addressstructure',
  templateUrl: './addressstructure.component.html',
  styleUrls: ['./addressstructure.component.css']
})
export class AddressstructureComponent implements OnInit {
  //#region "ALL VARIABLES"
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  addressStructureColumns: string[] = ['View', 'Edit', 'description'];
  addressStructureObj: AddressStructure[];
  addressStructureFilteredObj: AddressStructure[];
  AddressStructureFrom: FormGroup;
  AddressStructureFromAction: FormGroup;
  addressStructureHeading: string = '';
  btnSavetext: string = '';
  btnModeSave: boolean = true;
  dataSource = new MatTableDataSource<AddressStructure>(this.addressStructureObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  //#endregion

  //#region "COMMON Constructor Method"
  constructor(
    private fb: FormBuilder,
    private addressStructureService: AddressstructureService,
  ) { }
  //#endregion

  //#region "COMMON OnInit Events"
  ngOnInit() {
    this.addressStructureHeading = 'Add New - Address Structure';
    this.btnSavetext = 'Save';
    this.getAddressStructureDetails();
    this.ValidateAddressStructure();
    this.ngAfterViewInit();
    this.onChanges();
  }
  //#endregion

  //#region "Button Events"
  public onBtnSaveAddressStructureClick() {
    this.SaveAddressStructureDetails();
  }
  public onBtnClearAddressStructureClick() {
    this.ClearAddressStructureDetails();
  }
  btngvView_Click(a) {
    this.addressStructureFilteredObj = this.addressStructureObj.filter((unit) => unit.structureId == a);
    this.AddressStructureFrom = this.fb.group({
      structureId: { value: this.addressStructureFilteredObj[0].structureId, disabled: true },
      description: { value: this.addressStructureFilteredObj[0].description, disabled: true },
      createdBy: { value: this.addressStructureFilteredObj[0].createdBy, disabled: true },
      createdOn: { value: this.addressStructureFilteredObj[0].createdOn, disabled: true },
      isActive: { value: this.addressStructureFilteredObj[0].isActive, disabled: true },
    })
    this.addressStructureHeading = 'View - Address Structure';
    this.btnModeSave = false;
    this.btnSavetext = '';
    //this.AddressStructureFrom.patchValue({});
  }
  btngvEdit_Click(a) {
    this.addressStructureFilteredObj = this.addressStructureObj.filter((unit) => unit.structureId == a);
    this.AddressStructureFrom = this.fb.group({
      structureId: { value: this.addressStructureFilteredObj[0].structureId, disabled: false },
      description: { value: this.addressStructureFilteredObj[0].description, disabled: false },
      createdBy: { value: this.addressStructureFilteredObj[0].createdBy, disabled: false },
      createdOn: { value: this.addressStructureFilteredObj[0].createdOn, disabled: false },
      isActive: { value: this.addressStructureFilteredObj[0].isActive, disabled: false },
    })
    this.addressStructureHeading = 'Edit - Address Structure';
    this.btnSavetext = 'Update';
    this.btnModeSave = true;
  }
  btngvDelete_Click() {
    this.addressStructureService.deleteAddressStructureDetails().subscribe(result => { console.log(result); this.getAddressStructureDetails() });
  }
  //#endregion

  //#region "ALL METHODS"
  onChanges() {
    this.AddressStructureFrom.valueChanges.subscribe(val => {
      //console.log(val);
    });
  }
  public ValidateAddressStructure() {
    this.AddressStructureFrom = this.fb.group({
      structureId: [''],
      description: ['', [Validators.required],],
      createdBy: [1],
      createdOn: [new Date()],
      modifiedBy: [1],
      modifiedOn: [new Date()],
      deletedBy: [1],
      deletedOn: [new Date()],
      isActive: [1]
    })
  }
  public SaveAddressStructureDetails() {
    this.AddressStructureFrom.patchValue({
      createdBy: '1',
      createdOn: new Date(),
      isActive: '1'
    });
    this.AddressStructureFrom.markAllAsTouched();
    if (this.AddressStructureFrom.valid) {
      let val = this.AddressStructureFrom.value;
      this.addressStructureService.addAddressStructureDetails(val).subscribe(result => { console.log(result); this.getAddressStructureDetails() });
      this.AddressStructureFrom.reset();
    }
  }
  public getAddressStructureDetails(): void {
    this.addressStructureService.getAddressStructureDetails().subscribe(
      addressStructureObj => {
        this.dataSource = new MatTableDataSource<AddressStructure>(this.addressStructureObj);
        this.dataSource.data = this.addressStructureObj = addressStructureObj;
        this.dataSource.paginator = this.paginator;
      });
  }
  public ClearAddressStructureDetails() {
    this.AddressStructureFrom.reset();
    this.addressStructureHeading = 'Add New - Address Structure';
    this.btnSavetext = 'Save';
    this.btnModeSave = true;
  }
  //#endregion
}
