import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Organization } from 'src/app/mcore-product/mcore-shared/mcore-entity/organization';
// import { OrganizationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/organization.service';

@Component({
  selector: 'app-organization',
  templateUrl: './organization.component.html',
  styleUrls: ['./organization.component.css']
})
export class OrganizationComponent implements OnInit {
  dummyObj: string[];
  submitted = false;
  organizationForm: FormGroup;
  countrys: any = ['IND']
  states: any = ['Tamilnadu']
  districts: any = ['Chennai']
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.organizationForm = this.fb.group({
      shortName:[],
      address2:[],
      address3:[],
      postOffice:[],
      phoneNumber:[],
      mobileNumber:[],
      faxNumber:[],
      conferenceNumber:[],
      emailID:[],
      gstIn:[],
      id: [''],
      organizationName:
        [
          '',
          [Validators.required]
        ],
      address1:
        [
          '',
          [Validators.required]
        ],
      pinCode:
        [
          '',
          []
        ],
      country:
        [
          '',
          [Validators.required]
        ],
      state:
        [
          '',
          [Validators.required]
        ],
      district:
        [
          '',
          [Validators.required]
        ],
      panNumber:
        [
          '',
          [Validators.required]
        ],
      sacCode:
        [
          '',
          [Validators.required]
        ]
    })    
  }
  onBtnClickSaveOrganization(){
    this.submitted = true;    
    this.organizationForm.markAllAsTouched();   
    if (this.organizationForm.valid) {
      let val = this.organizationForm.value;      
    }    
  }
  onBtnClickClearOrganization(){
    this.organizationForm.reset();
  }
}
