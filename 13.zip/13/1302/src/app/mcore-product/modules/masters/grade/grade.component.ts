import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GradeService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/grade.service';
import { Grade } from 'src/app/mcore-product/mcore-shared/mcore-entity/grade';

import { Key } from 'protractor';
import {MatTableDataSource} from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import {MatPaginator} from '@angular/material/paginator';
import {MatPaginatorModule} from '@angular/material/paginator';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit {
  submitted = false;
  gradeForm:FormGroup;
  gradeFormAction:FormGroup;

  gradeObj: Grade[];
  gradeFilteredObj: Grade[] = [];

  gradeColumns: string[] = ['View', 'Edit', 'Delete', 'description'];
  gradeHeading: string = '';
  textSaveBtn: string = '';
  saveBtnMode: boolean = true;

  constructor(private gradeService: GradeService, private fb: FormBuilder, private changeDetectorRefs: ChangeDetectorRef) { }

  dataSource = new MatTableDataSource<Grade>(this.gradeObj);
  
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  ngOnInit() {
    this.dataSource = new MatTableDataSource<Grade>(this.gradeObj);
		this.gradeHeading = 'Add New - Grade';  
		this.textSaveBtn = 'Save';
		this.getGradeDetails();  
		
		this.gradeForm = this.fb.group({
			searchGrade:[],
			gradeFormAction:this.fb.group({
				gradeId: [''],  
				organisationId: ['1'],  
				description:
				[
				  '',
				  [Validators.required]
				],
				createdBy: ['1'],
				createdOn: [new Date()],
				deletedBy: ['1'],
				deletedOn: [new Date()]
			})
		});
  }

  getGradeDetails(): void {

		this.gradeService.getGradeDetails()
		  .subscribe(gradeObj => {
			  this.dataSource = new MatTableDataSource<Grade>(this.gradeObj);
			  this.dataSource.data = this.gradeObj = gradeObj;
			this.dataSource.paginator = this.paginator;		  
		});

	}
	
	getGradeInfoByDescription(): void {


		if (this.gradeForm.controls.searchGrade.valid) {
		  let searchValue = this.gradeForm.controls.searchGrade.value;

		  this.gradeService.getGradeInfoByDescription(searchValue)
			.subscribe(gradeObj => this.gradeObj = gradeObj);
		}
	

  }
  
  btngvView_Click(a) {

		//this.departmentFilteredObj = new DepartmentType[];
		this.gradeFilteredObj = this.gradeObj.filter((unit) => unit.gradeId == a);

		// console.log(this.departmentFilteredObj[0].description);



		 this.gradeForm = this.fb.group({
			searchGrade:[],
			gradeFormAction:this.fb.group({
				gradeId: { value: this.gradeFilteredObj[0].gradeId, disabled: true },
				organisationId: { value: this.gradeFilteredObj[0].organisationId, disabled: true },
				description: { value: this.gradeFilteredObj[0].description, disabled: true },
				createdBy: { value: this.gradeFilteredObj[0].createdBy, disabled: true },
				createdOn: { value: this.gradeFilteredObj[0].createdOn, disabled: true }

			})


		});

		this.gradeHeading = 'View - Grade';
		this.saveBtnMode = false;
	}
	
	btngvEdit_Click(a) {

		//this.departmentFilteredObj = new DepartmentType[];
		this.gradeFilteredObj = this.gradeObj.filter((unit) => unit.gradeId == a);

		// console.log(this.departmentFilteredObj[0].description);



		this.gradeForm = this.fb.group({
			searchGrade:[],
			gradeFormAction:this.fb.group({
				gradeId: { value: this.gradeFilteredObj[0].gradeId, disabled: false },
				organisationId: { value: this.gradeFilteredObj[0].organisationId, disabled: false },
				description: { value: this.gradeFilteredObj[0].description, disabled: false },
				createdBy: { value: this.gradeFilteredObj[0].createdBy, disabled: false },
				createdOn: { value: this.gradeFilteredObj[0].createdOn, disabled: false }

			})


		});

		this.gradeHeading = 'Edit - Grade';
		this.textSaveBtn = 'Update';
		this.saveBtnMode = true;
	}
	
	
	btngvDelete_Click(a) {
    this.gradeForm = this.fb.group({
			searchGrade: [''],
			gradeFormAction: this.fb.group({
        		gradeId: { value: a, disabled: false },
				organisationId: { value: '', disabled: false },
				description: { value: '', disabled: false },
				createdBy: { value: '', disabled: false },
				createdOn: { value: '', disabled: false },
				deletedBy: '2',
				deletedOn: '2020-02-06'
			})
		});

    let c = this.gradeForm.get('gradeFormAction').value;

	   // this.heroes = this.heroes.filter(h => h !== hero);
	   console.log(c);
		this.gradeService
		  .deleteGrade(c)
		  .subscribe( result => {this.getGradeDetails()} );
		/*
		// oops ... subscribe() is missing so nothing happens
		this.heroesService.deleteHero(hero.id);
		*/




	   this.getGradeDetails();
	}

  onBtnSaveGrade(){
    this.gradeForm.get('gradeFormAction').patchValue({
      createdBy:  '1',
      organisationId: '1',
			createdOn: new Date()
		});

    this.gradeForm.controls.gradeFormAction.markAllAsTouched();
		if(this.gradeForm.controls.gradeFormAction.valid){
			let a = this.gradeForm.controls.gradeFormAction.value;
			console.log(a);
			this.gradeService.addGrade(a)
			.subscribe(result => {this.getGradeDetails()});

			

		}
  }  
  onBtnSearchClearGrade(){        
    //this.gradeForm.reset();
  }
  onBtnClearGrade(){    
    this.gradeHeading = 'Add New - Grade';
		 this.textSaveBtn = 'Save';
		this.saveBtnMode = true;
		this.gradeForm = this.fb.group({
			searchBank: [''],
			gradeFormAction: this.fb.group({
				gradeId: { value: '', disabled: false },
				organisationId: { value: '', disabled: false },
				description: { value: '', disabled: false },
				createdBy: { value: '', disabled: false },
				createdOn: { value: '', disabled: false }
			})
		});
		//this.gradeForm.controls.gradeFormAction.reset();
  }
}
