import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BankBranch } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';
import { BankbranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/bankbranch.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { typeWithParameters } from '@angular/compiler/src/render3/util';

@Component({
  selector: 'app-bankbranch',
  templateUrl: './bankbranch.component.html',
  styleUrls: ['./bankbranch.component.css']
})
export class BankbranchComponent implements OnInit {
  BankBranchForm: FormGroup;
  BankBranchFormAction: FormGroup;
  bankBranchObj: BankBranch[];
  bankBranchFilteredObj: BankBranch[] = [];
  bankBranchHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  bankBranchColumns: string[] = ['View', 'Edit', 'Delete', 'bankName', 'bankCityName', 'description', 'ifscCode', 'micrCode'];
  bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.bankBranchdataSource.paginator = this.paginator;
  }
  // bankName: any = ['IND', 'PNB', 'HDFC']
  // bankCity: any = ['Koramangala', 'Indiranagar', 'Madiwala']
  constructor(
    private fb: FormBuilder,
    private bankBranchService: BankbranchService
  ) { }

  ngOnInit() {
    // this.getBankBranchNameDetails();
    // this.getBankBranchCitydetails();
    this.getBankBranchDetails();
    this.onChanges();  
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        branchId: [''],
        bankId: [''],
        bankCityId: [''],
        bankName:
          [
            '',
            // [Validators.required]
          ],
        bankCityName:
          [
            '',
            //[Validators.required]
          ],
        description:
          ['',
            //[Validators.required]
          ],
        ifscCode:
          [
            '',
            //[Validators.required]
          ],
        micrCode:
          [
            '',
            //[Validators.required]
          ],
        createdBy: [1],
        createdOn: [new Date()],
      })
    });
  }
  onChanges() {
    // this.BankBranchForm.get('BankBranchFormAction').valueChanges.subscribe(val => {
    //   console.log(val);
    // });
  }
  getBankBranchDetails(): void {
    // let branchId = this.BankBranchFormAction.controls.BranchId.value;
    // let bankId = this.BankBranchFormAction.controls.BankId.value;
    // let bankCityId = this.BankBranchFormAction.controls.BankCityId.value;
    // let description = this.BankBranchFormAction.controls.Description.value;
    // let ifscCode = this.BankBranchFormAction.controls.IFSCCode.value;
    // let micrCode = this.BankBranchFormAction.controls.MICRCode.value;
    this.bankBranchService.getBankBranchdetails(0, 0, 0, '', '', '').subscribe(
      bankBranchObj => {
        this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
        this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
        this.bankBranchdataSource.paginator = this.paginator;
      });
  }
  getBankBranchCitydetails() {
    let bankId = this.BankBranchFormAction.controls.bankId.value;
    this.bankBranchService.getBankBranchCityDetails(bankId).subscribe(bankBranchObj => this.bankBranchObj = bankBranchObj);
  }
  getBankBranchNameDetails() {
    let bankId = this.BankBranchFormAction.controls.bankId.value;
    this.bankBranchService.getBankBranchNameDetails(bankId).subscribe(bankBranchObj => this.bankBranchObj = bankBranchObj);
  }

  onBtnSaveBankBranchClick() {
    this.BankBranchForm.controls.BankBranchFormAction.markAllAsTouched();
    if (this.BankBranchForm.controls.BankBranchFormAction.valid) {
      let val = this.BankBranchForm.controls.BankBranchFormAction.value;
    }
  }
  onBtnClearBankBranchClick() {
    this.BankBranchForm.controls.BankBranchFormAction.reset();
  }
  onBtnSearchClearBankBranch() {
    this.BankBranchForm.reset();
  }
}
