import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commission',
  templateUrl: './commission.component.html',
  styleUrls: ['./commission.component.css']
})
export class CommissionComponent implements OnInit {
  dummyObj: string[];
  departmentObj: string[];
  constructor() { }

  ngOnInit() {
  }

  departmentColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];

}
