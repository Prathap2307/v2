import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fchannel',
  templateUrl: './fchannel.component.html',
  styleUrls: ['./fchannel.component.css']
})
export class FchannelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
