import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientorganizationComponent } from './clientorganization.component';

describe('ClientorganizationComponent', () => {
  let component: ClientorganizationComponent;
  let fixture: ComponentFixture<ClientorganizationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientorganizationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientorganizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
