import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advancedepositreceipting',
  templateUrl: './advancedepositreceipting.component.html',
  styleUrls: ['./advancedepositreceipting.component.css']
})

export class AdvancedepositreceiptingComponent implements OnInit {
  dummyObj: string;
	displayedColumns: string[] = ['View', 'Edit', 'ClientName', 'ClientId', 'CoreBusiness' , 'ContactPersonName'  ];
  dataSource = ELEMENT_DATA;

  constructor() { }

  ngOnInit() {
  }

}

export interface PeriodicElement {
  ClientName: string;
  ClientId: number;
  CoreBusiness: string;
  ContactPersonName: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {ClientName: 'CitiFootballGroup' , ClientId: 2012 , CoreBusiness: 'Sports' , ContactPersonName: 'Pep Joe' },
  {ClientName: 'ArsenalGunners' , ClientId: 1996 , CoreBusiness: 'Sports' , ContactPersonName: 'Mikel Arteta' }
];