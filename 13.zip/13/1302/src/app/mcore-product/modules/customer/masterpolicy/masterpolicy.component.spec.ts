import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterpolicyComponent } from './masterpolicy.component';

describe('MasterpolicyComponent', () => {
  let component: MasterpolicyComponent;
  let fixture: ComponentFixture<MasterpolicyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterpolicyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterpolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
