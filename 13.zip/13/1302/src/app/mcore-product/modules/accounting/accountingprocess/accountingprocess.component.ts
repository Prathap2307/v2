import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TooltipPosition } from '@angular/material';

@Component({
  selector: 'app-accountingprocess',
  templateUrl: './accountingprocess.component.html',
  styleUrls: ['./accountingprocess.component.css']
})
export class AccountingprocessComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  dummyObj: string;
  tableObj;

  tableColumns: string[] = ['View', 'Edit', 'description', 'shortName'];
  constructor() { }

  ngOnInit() {
  }

}
