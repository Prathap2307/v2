import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voucherreport',
  templateUrl: './voucherreport.component.html',
  styleUrls: ['./voucherreport.component.css']
})
export class VoucherreportComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
