import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dayclosemonitor',
  templateUrl: './dayclosemonitor.component.html',
  styleUrls: ['./dayclosemonitor.component.css']
})
export class DayclosemonitorComponent implements OnInit {
	dataSource;
	displayedColumns: string[] = ['DayCloseItem', 'Status', 'VerificationStatus', 'ProcessStatus', 'StartTime', 'EndTime' ];

  constructor() { }

  ngOnInit() {
  }

}
