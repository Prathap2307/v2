export class  DestinationDocumentUpload{
    clientName: string;
    process: string;
}