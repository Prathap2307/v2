export interface Designation {
    designationId: number;
    shortname: string;
	id: number;
    description: string;
    createdBy: number;
    createdOn: Date;
    deletedBy:  number;
    deletedOn:  Date;
    // searchdepartmentName: string;
}	