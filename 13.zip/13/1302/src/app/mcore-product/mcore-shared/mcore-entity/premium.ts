export class Premium {
	variant: string;
    type: string;
    benefitsRiders: string;
}	