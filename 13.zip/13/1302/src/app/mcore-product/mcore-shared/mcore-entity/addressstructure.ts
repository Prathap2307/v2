export interface AddressStructure {
    structureId: number;
    description: string;
    createdBy: number;
    createdOn: Date;
    modifiedBy: number;
    modifiedOn: Date;
    deletedBy: number;
    deletedOn: Date;
    isActive: number;
}