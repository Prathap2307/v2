export interface Insurer {
    insurerName: string;
    schemeCategory: string;
    shortName: string;
	dateOfCommencement: string;
	geographicalPresence: string;
	addressOne: number;
	addressTwo: number;
	addressThree: number;
	
	
	emailId: string;
	phoneNumber: number;
	mobileNumber: number;
	conferenceNumber: number;
	faxNumber: number;
	triggerLimitforStampDuty: string;
	intimationEmailAddressStampDuty: string;
	intimationMobileNumberStampDuty: string;
	panNumber: string;
	gstNumebr: string;
	logo: string;
	description: string;


}