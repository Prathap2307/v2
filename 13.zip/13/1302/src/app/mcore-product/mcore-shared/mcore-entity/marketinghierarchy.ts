export class MarketingHierarchy {
	firstName: string;
	lastName: string;
	marketingOfficerCode: string;
	mainChannel: string;
	subChannel: string;
	reportingTo: string;
	applicationeDate: string;
	dateOfJoining: string;
	marketingOfficeLocation: string;
	organization: string;
	gender: string;
	dateOfBirth: string;
	panNumber: string;
	registeredUnder: string;
	registrationDate: string;
	miaAgreementDate: string;
	codeInsuranceDate: string;
	codeExpiryDate: string;
	renewalDate: string;
	effectiveDate: string;
	expireDate: string;
	employee: string;
	department: string;
	designation: string;
	branchInOperating: string;
	payableWhenFeature: string;
	activeStatus: string;
	remarks: string;
	remarksDate: string;
	addressOne: number;
	addressTwo: number;
	addressThree: number;
	addressType: number;
	zipCode: number;
	country: string;
	state: string;
	district: string;
	landlineNumber: number;
	mobileNumber: number;
	conferenceNumber: number;
	faxNumber: number;
	officeEmailId: string;
	
}	

