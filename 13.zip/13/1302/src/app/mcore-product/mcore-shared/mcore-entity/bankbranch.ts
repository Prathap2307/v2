export interface BankBranch{
    branchId: number;
    bankId: number;
    bankCityId: number;
    bankName: string;
    bankCityName: string;       
    description: string;   
    ifscCode: string;
    micrCode: string;
    createdBy: number;
    createdOn: Date;
}