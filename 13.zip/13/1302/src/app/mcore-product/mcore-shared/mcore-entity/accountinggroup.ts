export interface AccountingGroup {
    accountingGroupId: number;
    code: string;
    groupName: string;
    createdBy: number;
    createdOn: Date;
    modifiedBy: number;
    modifiedOn: number;
    deletedBy: number;
    deletedOn: Date;
    isActive: number;
}

