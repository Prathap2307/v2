export class PremiumPaymentFrequency {
	variant: string;
	premiumPaymentFrequency: string;
    modalFactor: string;
    gracePeriod: string;
    noticeePeriod: string;
}	