export class SubChannel {
	subChannelName: string;
	subChannelCode: string;
	mainChannelName: string;
	physicalCategorization: string;
	branchInOperating: string;
	advanceDeposit: string;
	policyHolderCode: string;
	triggerLimit: string;
	blanketSubChannel: string;
}	

