import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BankBranch } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';
@Injectable({
  providedIn: 'root'
})
export class BankbranchService {
  baseUrl = environment.API_URL;
  constructor(
    private http: HttpClient
  ) { }
  //bankBranchUrl = this.baseUrl + '/'  ;

  getBankBranchdetails(branchId: number, bankId: number, bankCityId: number, description: string, ifscCode: string, micrCode: string): Observable<BankBranch[]> {
    //console.log(bankId); console.log(branchId); console.log(bankCityId); console.log(description); console.log(ifscCode); console.log(micrCode);
    const BankBranchUrl = this.baseUrl + `/bankBranch/${branchId}/${bankId}/${bankCityId}/${description}/${ifscCode}/${micrCode}`;
    //console.log(BankBranchUrl);
    return this.http.get<BankBranch[]>(BankBranchUrl).pipe();
  }
  getBankBranchNameDetails(bankId: number): Observable<BankBranch[]> {
    //console.log(bankId);
    const BankBranchByNameUrl = this.baseUrl + `/bankBranchBank/${bankId}`;
    //console.log(BankBranchByNameUrl);
    return this.http.get<BankBranch[]>(BankBranchByNameUrl).pipe();
  }
  getBankBranchCityDetails(bankId: number): Observable<BankBranch[]> {
    //console.log(bankId);
    const BankBranchCityNameByUrl = this.baseUrl + `/bankBranchCity/${bankId}`;
    //console.log(BankBranchCityNameByUrl);
    return this.http.get<BankBranch[]>(BankBranchCityNameByUrl).pipe();
  }
}
