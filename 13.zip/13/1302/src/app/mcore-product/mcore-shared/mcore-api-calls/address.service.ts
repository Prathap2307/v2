import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Insurer } from 'src/app/mcore-product/mcore-shared/mcore-entity/insurer';

import { Address } from 'src/app/mcore-product/mcore-shared/mcore-entity/address';
@Injectable({
  providedIn: 'root'
})
export class AddressService {

  
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addressUrl = this.baseUrl + '/address';

   /* GET Address by ZIPCODE */
   getAddressByIDzipCode(zipCode: string): Observable<Address[]> {

    const departmentByIDUrl = this.baseUrl + `/address/${zipCode}`;

    console.log(departmentByIDUrl);
    return this.http.get<Address[]>(departmentByIDUrl)
      .pipe();
  }


  
  getAllCountries(): Observable<Address[]> {
   const addressCountryUrl = this.baseUrl + '/addressCountry';
    return this.http.get<Address[]>(addressCountryUrl)
      .pipe();
  }
    
   getAllStates(a: number): Observable<Address[]> {

      const stateUrl = this.baseUrl + `/addressState/${a}`;
    
      return this.http.get<Address[]>(stateUrl)
        .pipe();
    }

        
   getAllDistricts(a: number): Observable<Address[]> {

    const districtUrl = this.baseUrl + `/addressDistrict/${a}`;
  
    return this.http.get<Address[]>(districtUrl)
      .pipe();
  }


  
}
