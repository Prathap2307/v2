﻿

$(document).on('ready', function () {
	
//alert($(window).width());
	// SELECT DESIGN	
    var select_box = $(".select-option");
    if (select_box.length) {
        $(".select-option").select2();
    }
	
	
	
		// FORM MAIN ACCORDION
    var acc_acc = $(".acc-arrow");
    if (acc_acc.length) {
		 $('.acc-arrow').on('click', function() {
			var $this = $(this);
			var $i = $(this).find("i");
			if($i.hasClass("fa-minus")){
				
				$i.removeClass("fa-minus");
				$i.addClass("fa-plus");
				
			}else {
				$i.removeClass("fa-plus");
				$i.addClass("fa-minus");
				
			} 
			 $this.next(".acc-content").stop().slideToggle();
		});
    }
	

	 
	 // trigger.removeClass('is-closed');
       // trigger.addClass('is-open');
	  //$('#wrapper').addClass('toggled');

/*     trigger.click(function () {
      hamburger_cross();      
    });

function hamburger_cross() {

      if (isClosed == true) {          
        overlay.hide();
       // trigger.removeClass('is-open');
        //trigger.addClass('is-closed');
        isClosed = false;
      } else {   
        overlay.show();
        //trigger.removeClass('is-closed');
       // trigger.addClass('is-open');
        isClosed = true;
      }
  } */
  
 
//   //MENU ACCORDION
// 	var first_menu = $(".first-menu");
// 	if(first_menu.length){
// 		alert("load");
// 	 $('.sub-menu .first-link').on('click', function() {
// 			alert("hi");
// 			var $this = $(this);
			
// 			$( ".first-menu" ).slideUp();
// 			$( ".second-menu" ).slideUp();
// 			if ( $this.next().css("display") == "none" ) {
// 				$this.next().slideToggle();
// 			}
// 		});
// 	}	
	
// 	var second_menu = $(".second-menu");
// 	if(second_menu.length){
// 	$('.first-menu .second-link').on('click', function() {
// 			var $this = $(this);
		
// 			$( ".second-menu" ).slideUp();
// 			if ( $this.next().css("display") == "none" ) {
// 				$this.next().slideToggle();
// 			}
// 		});
// 	}
	


	
	

	return false;


});