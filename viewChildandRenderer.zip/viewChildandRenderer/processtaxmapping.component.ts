import { Component, OnInit, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TooltipPosition } from '@angular/material';

@Component({
  selector: 'app-processtaxmapping',
  templateUrl: './processtaxmapping.component.html',
  styleUrls: ['./processtaxmapping.component.css']
})
export class ProcesstaxmappingComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  dummyObj: string[];
  tableObj;
  tableColumns: string[] = [ 'Edit', 'TaxStructure', 'Description'];
  constructor(private elRef: ElementRef, private renderer: Renderer2) { }

  ngOnInit() {
  }

  @ViewChild('addButton', {static: true}) private animateThis: ElementRef;	
  addBtn() {
    
    const button = this.renderer.createElement('button'); 
    const buttonText = this.renderer.createText('This is a button');
    const comment = this.renderer.createComment('createComment? Comment Created!');
    const parent = this.elRef.nativeElement.parentNode;
   
    const reference = this.elRef.nativeElement;
    console.log(reference);
    this.renderer.appendChild(button, buttonText);
    this.renderer.insertBefore(parent, comment, reference )
    this.renderer.appendChild(this.animateThis.nativeElement, button);
    this.renderer.setAttribute(this.animateThis.nativeElement, 'disabled', 'disabled');
  }

  checked: boolean = false;
  // @ViewChild('ref') ref;

  @ViewChild('ref', {static: true}) ref;

  onClick(event) {
      event.preventDefault();
   //  console.log('onClick event.checked ' + event.checked);
    // console.log('onClick event.target.checked '+event.target.checked);
      console.log('onClick this.ref._checked '+ this.ref._checked);

      this.ref._checked = !this.ref._checked;
  }

  onChange(event) {
    // can't event.preventDefault();
    console.log( this.ref)
    //console.log('onChange event.checked '+event.checked);
  }

}
