import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MastersRoutingModule } from './masters-routing.module';
import { InsurerComponent } from './insurer/insurer.component';
import { ZoneComponent } from './zone/zone.component';
import { DivisionComponent } from './division/division.component';
import { BranchComponent } from './branch/branch.component';
import { OrganizationComponent } from './organization/organization.component';
import { DesignationComponent } from './designation/designation.component';
import { GradeComponent } from './grade/grade.component';

@NgModule({
  declarations: [InsurerComponent, ZoneComponent, DivisionComponent, BranchComponent, OrganizationComponent, DesignationComponent, GradeComponent],
  imports: [
    CommonModule,
    MastersRoutingModule
  ]
})
export class MastersModule { }
