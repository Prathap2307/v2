package com.example.demo.LIC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.LIC.dao.DepartmentDAO;
import com.example.demo.LIC.model.DepartmentModel;



@RestController
public class DepartmentController {
	@Autowired
	private DepartmentDAO dao;

	@GetMapping("/department")
	public List<DepartmentModel> getDepartment() {
		return dao.getDepartmentInfo();
	}
	
//	@GetMapping("/department/{id}")
//	public List<DepartmentModel> findDepartment(@PathVariable String id) {
//		return dao.getDepartmentInfoByID(id);
//	}
	
	@GetMapping("/department/{description}")
	public List<DepartmentModel> findDepartmentByDescription(@PathVariable String description) {
		return dao.getDepartmentInfoByDescription(description);
	}
	
	
	/*
	 * @RequestMapping(method = RequestMethod.PUT,value="/departmentUpdate/{id}")
	 * public void updateDepartment(@PathVariable String id,@RequestBody String
	 * shortname) { dao.updateDepartmentInfoByID(id, shortname);
	 * //topicService.updateTopic(id,topic); }
	 */
	
	@RequestMapping(method = RequestMethod.PUT,value="/departmentUpdate/{id}")
	public void updateDepartment(@PathVariable String id,@RequestBody String shortname) {
		dao.updateDepartmentInfoByID(id, shortname);
		//topicService.updateTopic(id,topic);
	}
	
	@PostMapping("/createdepartment")
	public void postDepartment(@RequestBody DepartmentModel singleDept) {
		dao.createDepartmentInfo(singleDept);
		//return "controller success";
	//	return "ticket booked : " + singleDept.getDescription();
	}
	
	@RequestMapping(method = RequestMethod.DELETE,value="/departmentDelete/{id}")
	public void deleteDepartment(@PathVariable Integer id) {
		
		dao.deleteDepartmentByID(id);
	}
}
