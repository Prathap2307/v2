package com.example.demo.LIC.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.LIC.model.DepartmentModel;

@Repository

public class DepartmentDAO {
	@Autowired
	private EntityManager em;

	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfo() {
		return em.createNamedStoredProcedureQuery("getDepartmentInfoProcedure").getResultList();
	}
	

	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfoByID(String input) {
		return em.createNamedStoredProcedureQuery("secondProcedure").setParameter("deptID", input).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfoByDescription(String input) {
		return em.createNamedStoredProcedureQuery("DepartmentInfoByDescription").setParameter("sdescription", input).getResultList();
	}
	
	//@SuppressWarnings("unchecked")
	public void updateDepartmentInfoByID(String id, String shortname) {
		 //em.createNamedStoredProcedureQuery("updateDepartmentInfo").setParameter("pshortname", shortname).getResultList();
		em.createNamedStoredProcedureQuery("updateDepartmentInfo")
		.setParameter("pid", id)
		.setParameter("pshortname", shortname)
		.getResultList();
	}
	
	public void createDepartmentInfo(DepartmentModel singleDept) {
		
		/*
		 * em.createNamedStoredProcedureQuery("createDepartment")
		 * .setParameter("pdescription", singleDept.getDescription())
		 * .setParameter("pshortname", singleDept.getShortName()) .getResultList();
		 */
		
		
		/*
		 * String dummydescription = "prathap.a"; String dummyshortname = "ap";
		 */
		
		// Getting the named stored procedure from the persistence unit and settting the parameters values.
		StoredProcedureQuery query = em.createNamedStoredProcedureQuery("createDepartment").setParameter("pid", singleDept.getId())
				.setParameter("pdescription", singleDept.getDescription()).setParameter("pshortname", singleDept.getShortName());
		 
		 //Execute query
	        query.execute();
		/* addDepartmentStoredProcedure.setParameter("pid", singleDept.getId()); */
	//	addDepartmentStoredProcedure.setParameter("pdescription", dummydescription);
		//addDepartmentStoredProcedure.setParameter("pshortname", dummyshortname);
		//addDepartmentStoredProcedure.getResultList();
		// Stored procedure call
		//Integer createdBookId = (Integer) addDepartmentStoredProcedure.getSingleResult();
		//return "DAO success";
		//return createdBookId.toString();
	}
	
	
	public void deleteDepartmentByID(Integer id) {
		 //StoredProcedureQuery query =
		StoredProcedureQuery query = em.createNamedStoredProcedureQuery("deleteDepartmentByID").setParameter("pid", id);
		
		query.execute();
	}
}
