import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-premiumpaymentfrequency',
  templateUrl: './premiumpaymentfrequency.component.html',
  styleUrls: ['./premiumpaymentfrequency.component.css']
})
export class PremiumpaymentfrequencyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
