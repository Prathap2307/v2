import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginMasterComponent } from './login-master/login-master.component';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule, MatRippleModule} from '@angular/material/core';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatTableModule} from '@angular/material/table';
import {MatRadioModule} from '@angular/material/radio';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MastersComponent } from './masters/masters.component';
import { MasterPageComponent } from './master-page/master-page.component';
import { DepartmentComponent } from './masters/department/department.component';
import { InsurerComponent } from './masters/insurer/insurer.component';
import { ValidationComponent } from './master-page/validation/validation.component';
import { ZoneComponent } from './masters/zone/zone.component';
import { DivisionComponent } from './masters/division/division.component';
import { BranchComponent } from './masters/branch/branch.component';
import { OrganizationComponent } from './masters/organization/organization.component';
import { DesignationComponent } from './masters/designation/designation.component';
import { GradeComponent } from './masters/grade/grade.component';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import { ProductComponent } from './masters/product/product.component';
import { VariantComponent } from './masters/variant/variant.component';
import { PremiumComponent } from './masters/premium/premium.component';
import { PremiumpaymentfrequencyComponent } from './masters/premiumpaymentfrequency/premiumpaymentfrequency.component';
import { LoadinganddiscountComponent } from './masters/loadinganddiscount/loadinganddiscount.component';
import { FchannelComponent } from './masters/fchannel/fchannel.component';
import { FsaleshierarchyComponent } from './masters/fsaleshierarchy/fsaleshierarchy.component';
import { UserComponent } from './masters/user/user.component';
import { GroupComponent } from './masters/group/group.component';
import { PrivilegesComponent } from './masters/privileges/privileges.component';
import {MatPaginatorModule} from '@angular/material/paginator';
@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    LoginMasterComponent,
    MasterPageComponent,
    MastersComponent,
    DepartmentComponent,
    InsurerComponent,
    ValidationComponent,
    ZoneComponent,
    DivisionComponent,
    BranchComponent,
    OrganizationComponent,
    DesignationComponent,
    GradeComponent,
    ProductComponent,
    VariantComponent,
    PremiumComponent,
    PremiumpaymentfrequencyComponent,
    LoadinganddiscountComponent,
    FchannelComponent,
    FsaleshierarchyComponent,
    UserComponent,
    GroupComponent,
    PrivilegesComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRippleModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatTableModule,
    MatRadioModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatPaginatorModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
