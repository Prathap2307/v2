export interface UsersType {
    FirstName: string;
    MobileNumber: number;
    EmailID: string;
    UserPassword: string;
}