import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MastersRoutingModule } from './masters-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MastersRoutingModule
  ]
})
export class MastersModule { }
