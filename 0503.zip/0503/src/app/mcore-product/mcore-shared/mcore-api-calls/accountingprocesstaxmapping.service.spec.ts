import { TestBed } from '@angular/core/testing';

import { AccountingprocesstaxmappingService } from './accountingprocesstaxmapping.service';

describe('AccountingprocesstaxmappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AccountingprocesstaxmappingService = TestBed.get(AccountingprocesstaxmappingService);
    expect(service).toBeTruthy();
  });
});
