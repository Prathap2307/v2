import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Question } from 'src/app/mcore-product/mcore-shared/mcore-entity/question';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }
  // Get Question 
  questionUrl = this.baseUrl + '/getQuestions';
  getQuestionDetails(): Observable<Question[]> {
    return this.http.get<Question[]>(this.questionUrl).pipe();
  }
  // Create Question
  createquestionUrl = this.baseUrl + '/createQuestion';
  addQuestion(question: Question): Observable<Question[]> {
    return this.http.post<Question[]>(this.createquestionUrl, question);
  }
  // Delete Question
  deleteQuestion(questionRow: Question): Observable<Question> {
    const deleteQuestionUrl = this.baseUrl + `/deleteQuestion`;
    return this.http.put<Question>(deleteQuestionUrl, questionRow)
      .pipe();
  }
  // Search Question
  getQuestionBySearch(questionId: number, description: string): Observable<Question[]> {
    const questionByNameUrl = this.baseUrl + `/Questions/${questionId}/${description}`;
    return this.http.get<Question[]>(questionByNameUrl).pipe();
  }
}
