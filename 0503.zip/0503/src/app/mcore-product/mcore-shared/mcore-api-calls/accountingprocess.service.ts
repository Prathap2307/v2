import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { AccountingProcess } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingprocess';

@Injectable({
    providedIn: 'root'
})

export class AccountingProcessService {
    baseUrl = environment.API_URL;

    constructor(private http: HttpClient) { }
	
	
/* GET Accounting Process */
   getAccountingProcessDetails(): Observable<AccountingProcess[]> {
    const accountingProcessUrl = this.baseUrl + `/SearchAccountProcess/0/0/0`;
    return this.http.get<AccountingProcess[]>(accountingProcessUrl)
      .pipe();
  }

  getAccountingProcessSearchDetails(accountProcessID: number, code: number, groupName: number): Observable<AccountingProcess[]> {
    const accountingProcessUrl = this.baseUrl + `/SearchAccountProcess/${accountProcessID}/${code}/${groupName}`;
    return this.http.get<AccountingProcess[]>(accountingProcessUrl)
      .pipe();
  }
  
   /* POST Designation */
	createProcessUrl = this.baseUrl + `/createAccount`;
	addAccountingProcess(processRow: AccountingProcess): Observable<AccountingProcess[]> {  
		return this.http.post<AccountingProcess[]>(this.createProcessUrl, processRow);
	}
	
	/* GET by ID */
   getAccountingProcessBySearch(code: number , groupName: number): Observable<AccountingProcess[]> {
    const processByIDUrl = this.baseUrl + `/SearchAccountProcess/0/${code}/${groupName}`;
    console.log(processByIDUrl);
    return this.http.get<AccountingProcess[]>(processByIDUrl)
      .pipe();
  }

}