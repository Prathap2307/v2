import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

import { HttpClient, HttpResponse } from '@angular/common/http';

import { Insurer } from 'src/app/mcore-product/mcore-shared/mcore-entity/insurer';
import { tap, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class InsurerService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  addressUrl = this.baseUrl + '/address';

   /* GET Address by ZIPCODE */
   getAddressByIDzipCode(zipCode: string): Observable<Insurer[]> {

    const departmentByIDUrl = this.baseUrl + `/address/${zipCode}`;

    // return this.http.get<Hero>(url).pipe(
    //   tap(_ => this.log(`fetched hero id=${id}`)),
    //   catchError(this.handleError<Hero>(`getHero id=${id}`))
    // );

    console.log(departmentByIDUrl);
    return this.http.get<Insurer[]>(departmentByIDUrl)
      .pipe();
  }
  
    /* GET Address by ZIPCODE */
    getDepartmentInfoByDescription(zipCode: number): Observable<Insurer[]> {

      const departmentByIDUrl = this.baseUrl + `/address/${zipCode}`;
  
      // return this.http.get<Hero>(url).pipe(
      //   tap(_ => this.log(`fetched hero id=${id}`)),
      //   catchError(this.handleError<Hero>(`getHero id=${id}`))
      // );
  
      console.log(departmentByIDUrl);
      return this.http.get<Insurer[]>(departmentByIDUrl)
        .pipe();
    }
    getAllInsurer(): Observable<any> {
      return this.http.get(this.baseUrl + '/getAllInsurer').pipe(tap((response) => response));
    }
    GetInsurerByID(id): Observable<any> {
      return this.http.get(this.baseUrl + '/GetInsurerByID?InsurerID='+id).pipe(tap((response) => response));
    }
    DeleteInsurer(data): Observable<any> {
      return this.http.post(this.baseUrl + '/DeleteInsurer',data).pipe(tap((response) => response));
    }
    IsInsurerExist(data): Observable<any> {
      console.log("URL :",this.baseUrl + '/IsInsurerExist?InsurerID='+data.insurerID+'&InsurerName='+data.insurerName)
      return this.http.post(this.baseUrl + '/IsInsurerExist?',data).pipe(tap((response) => response));
    }
    InsertOrUpdateInsurer(data): Observable<any> {
      console.log("data >>",data)
      return this.http.post(this.baseUrl + '/InsertOrUpdateInsurer',data).pipe(tap((response) => response));
    }


}
