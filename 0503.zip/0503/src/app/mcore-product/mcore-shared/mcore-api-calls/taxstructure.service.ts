import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class TaxstructureService {


  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }


  

   GetAllTaxStructure(): Observable<any>{
      return this.http.get(this.baseUrl + '/GetAllTaxStructure' ).pipe(tap((response) => response));
    }

    GetAllTaxStructureBasedonTaxName(name:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetAllTaxStructureBasedonTaxName?TaxStructureName=' + name).pipe(tap((response) => response));
    }

    GetTaxStructureDetailsByID(id:any): Observable<any>{
      console.log(id)
      return this.http.get(this.baseUrl + '/GetAllTaxStructureDetailsByTaxStructureID?TaxStructureID=' + id).pipe(tap((response) => response));
    }

    InsertOrUpdateTaxStructure(data:any): Observable<any>{
      return this.http.post(this.baseUrl + '/InsertOrUpdateTaxStructure' , data).pipe(tap((response) => response));
    }

    InsertTaxStructureDetails(data:any): Observable<any>{
      return this.http.get(this.baseUrl + '/InsertTaxStructureDetails' + data).pipe(tap((response) => response));
    }

    DeleteTaxStructure(id:any): Observable<any>{
      console.log(id)
      return this.http.get(this.baseUrl + '/DeleteTaxStructure?TaxStructureID='+ id+'&DeletedBy=1').pipe(tap((response) => response));
    }
    IsTaxStructureExist (data:any): Observable<any>{
      return this.http.post(this.baseUrl + '/IsTaxStructureExist ' , data).pipe(tap((response) => response));
    }
    DeleteTaxStructureDetails(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/DeleteTaxStructureDetails' + id).pipe(tap((response) => response));
    }


    
}
