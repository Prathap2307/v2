import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { BankMaster } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankmaster';
import { tap, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class BankmasterService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  bankUrl = this.baseUrl + '/bank';

    /* GET Bank */
    getBankDetails(): Observable<BankMaster[]> {
      return this.http.get<BankMaster[]>(this.bankUrl)
        .pipe();
    }


    getBankDetailsByDescription(description: string): Observable<BankMaster[]> {

    const BankMasterUrl = this.baseUrl + `/bank/${description}`;
      console.log(BankMasterUrl);
    return this.http.get<BankMaster[]>(BankMasterUrl)
      .pipe();
  }

	createbankUrl = this.baseUrl + '/createBank';
		addBank(bankRow: BankMaster): Observable<BankMaster>{
		return this.http.post<BankMaster>(this.createbankUrl, bankRow);
	}
	
	 handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput<any> {
    throw new Error("Method not implemented.");
  }


	// deleteBank (bankrow: BankMaster): Observable<{}> {
      
	// 	const deletebankUrl = this.baseUrl + `/deleteBank`;
	// 	return this.http.delete(deletebankUrl).pipe();

  // }
  

  deleteBank (bankRow: BankMaster): Observable<BankMaster> {
    const deletebankUrl = this.baseUrl + `/deleteBank`;
    return this.http.put<BankMaster>(deletebankUrl, bankRow)
      .pipe();
  }
  
// 	updateBank (bankrow: BankMaster): Observable<void> {
// 		const bankUpdateUrl = this.baseUrl + `/createBank`;
// 		return this.http.put<void>(this.bankUrl, bankrow).pipe(
// 		  catchError(this.handleError)
//     );
// }

    // return this.http.put(this.heroesUrl, hero, this.httpOptions).pipe(
    //   tap(_ => this.log(`updated hero id=${hero.id}`)),
    //   catchError(this.handleError<any>('updateHero'))
    // );
  
 
}
