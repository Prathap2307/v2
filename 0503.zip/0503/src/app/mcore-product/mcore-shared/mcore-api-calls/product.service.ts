import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Product, ProductCategory } from 'src/app/mcore-product/mcore-shared/mcore-entity/product';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  baseUrl = environment.API_URL;

  constructor(
    private http: HttpClient
  ) { }

  getProductBySearch(searchPlanName: string): Observable<Product[]> {   
    const productByNameUrl = this.baseUrl + `/product/${searchPlanName}`;     
    return this.http.get<Product[]>(productByNameUrl).pipe();
  }

  // Get Product
  productUrl = this.baseUrl + '/product';
  getProductDetails(): Observable<Product[]> {
    console.log(this.productUrl);
    return this.http.get<Product[]>(this.productUrl).pipe();
  }

  GetAllCategory(lobId: number): Observable<ProductCategory[]> {   
    const getCategoryUrl = this.baseUrl + `/category/${lobId}`;    
    return this.http.get<ProductCategory[]>(getCategoryUrl).pipe();
  }

  // Create a Product
  createproductUrl = this.baseUrl + '/createProduct';
  addProduct(product: Product): Observable<Product> {
    // console.log(this.createproductUrl);
    // console.log(productRow);
    return this.http.post<Product>(this.createproductUrl, product);
  }

  // Delete Product 
  // public deleteProduct(productId: number): Observable<{}> {
  //   const deleteProductUrl = this.baseUrl + `/productDelete/${productId}`;
  //   console.log(deleteProductUrl);
  //   return this.http.delete(deleteProductUrl).pipe();
  //   //return this.http.delete(`${this.baseUrl}/productDelete/${productId}`);    
  // }

  deleteProduct(productRow: Product): Observable<Product> {
    const deleteProductUrl = this.baseUrl + `/deleteProduct`;
    return this.http.put<Product>(deleteProductUrl, productRow)
      .pipe();
  }

  // public deleteProduct(productId: number): Observable<{}> {
  //   return this.http.delete(`${this.baseUrl}/deleteproduct/${productId}`);
  // }

  // Update the Product
  // updateProduct(product: Product): Observable<void> {
  //   //console.log(product);
  //   const updateProductUrl = this.baseUrl + `/createproduct/${product.productId}`;
  //   console.log(updateProductUrl);
  //   return this.http.put<void>(this.productUrl, product).pipe(catchError(this.handleError));
  // }  

  // getProductBySearch(productId: number): Observable<Product[]> {
  //   console.log(productId);
  //   const productByIDUrl = this.baseUrl + `/product/${productId}`;
  //   console.log(productByIDUrl);
  //   return this.http.get<Product[]>(productByIDUrl).pipe();
  // }  

  // Error Handling
  handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput <any> {
    throw new Error("Method not implemented.");
  }
  consoleLogFn(val) {
    console.log(val);
  }
}
