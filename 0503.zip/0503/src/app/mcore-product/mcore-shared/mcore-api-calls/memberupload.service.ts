import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
@Injectable({
  providedIn: 'root'
})
export class MemberuploadService {


  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }

  getGroupDetails(a: any): Observable<MemberUpload[]> {
    const url = this.baseUrl + `/GetGroupDetails`;
     return this.http.post<MemberUpload[]>(url, a)
       .pipe();
   }

   getmasterPolicyDetails(Groupid: number): Observable<MemberUpload[]> {
    const url = this.baseUrl + `/GetMasterPolicyDetails/${Groupid}`;
     return this.http.get<MemberUpload[]>(url)
       .pipe();
   }
   getAllAuthorisedSignatories(a: number): Observable<MemberUpload[]> {
    const url = this.baseUrl + `/GetAllAuthorisedSignatories/${a}`;
     return this.http.get<MemberUpload[]>(url)
       .pipe();
   }
  
   postFile(a: any): Observable<any> {
   const url = this.baseUrl + '/NewBusinessExcelupload';
     return this.http.post<any>(url, a);
   }
 

//    postFile(fileToUpload: File): Observable<any> {
//     const endpoint = 'your-destination-url';
//     const formData: FormData = new FormData();
//     formData.append('fileKey', fileToUpload, fileToUpload.name);
//     return this.http.post(endpoint, formData);
// }
}
