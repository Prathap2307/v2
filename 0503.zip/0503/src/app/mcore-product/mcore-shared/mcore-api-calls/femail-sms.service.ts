import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class FemailSmsService {
  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }

  insert(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/InsertOrUpdateMessageTemplate', data).pipe(tap((response) => response));
  }
  GetAllMessageTemplatesByFeatureID(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllMessageTemplatesByFeatureID?FeatureId=12').pipe(tap((response) => response));
  }
  GetAllMessageTemplates(): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllMessageTemplates').pipe(tap((response) => response));
  }
  GetAllFeaturesForSMSEmail(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllFeaturesForSMSEmail').pipe(tap((response) => response));
  }
  GetAllMessageTemplatesByTemplateID(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllMessageTemplatesByTemplateID?TemplateId=' +id).pipe(tap((response) => response));
  }
}
