import { TestBed } from '@angular/core/testing';

import { AccountinggroupService } from './accountinggroup.service';

describe('AccountinggroupService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AccountinggroupService = TestBed.get(AccountinggroupService);
    expect(service).toBeTruthy();
  });
});
