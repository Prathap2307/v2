import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
@Injectable({
  providedIn: 'root'
})
export class DesignationService {

  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }



   /* GET Designation */
   getDesignationDetails(designationId: number , description : string): Observable<Designation[]> {
    const designationUrl = this.baseUrl + `/designation/${designationId}/${description}`;
    return this.http.get<Designation[]>(designationUrl)
      .pipe();
  }

   /* GET by ID */
   getDetailsInfoBySearch( designationId: number , description: string): Observable<Designation[]> {
    const designationByIDUrl = this.baseUrl + `/designation/${designationId}/${description}`;
    console.log(designationByIDUrl);
    return this.http.get<Designation[]>(designationByIDUrl)
      .pipe();
  }

  /* POST Designation */
  createDesignationUrl = this.baseUrl + `/createDesignation`;
  addDesignation(designationRow: Designation): Observable<Designation[]> {
  
    return this.http.post<Designation[]>(this.createDesignationUrl, designationRow);
  }


  /** DELETE */
	deleteDesignation (designationRow: Designation): Observable<Designation[]> {
      
    const deleteDesignationUrl = this.baseUrl + `/deleteDesignation`;
   return this.http.put<Designation[]>(deleteDesignationUrl, designationRow).pipe();

  }

}
