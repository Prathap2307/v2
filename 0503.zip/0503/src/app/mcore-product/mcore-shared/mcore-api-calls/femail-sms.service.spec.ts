import { TestBed } from '@angular/core/testing';

import { FemailSmsService } from './femail-sms.service';

describe('FemailSmsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FemailSmsService = TestBed.get(FemailSmsService);
    expect(service).toBeTruthy();
  });
});
