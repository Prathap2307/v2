import { TestBed } from '@angular/core/testing';

import { CommisionService } from './commision.service';

describe('CommisionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CommisionService = TestBed.get(CommisionService);
    expect(service).toBeTruthy();
  });
});
