import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LookupService {

  private _baseUrl = environment.API_URL;

  //LookUp
  private _getLookup =  this._baseUrl + 'lookup/lookup/get';
  
  // Address Type
  private _addAddress =  this._baseUrl + 'lookup/address-type/update';
  private _getAddress =  this._baseUrl + 'lookup/address-type/get';
  private _getSingleAddress = this._baseUrl + 'lookup/address-type/get';
  private _deleteAddress = this._baseUrl + 'lookup/address-type/delete';
  private _searchAddress = this._baseUrl + 'lookup/address-type/search';

  //Account Type
  private _addAccount = this._baseUrl + 'lookup/account-type/update';
  private _getAccount =  this._baseUrl + 'lookup/account-type/get';
  private _getSingleAccount =  this._baseUrl + 'lookup/account-type/get';
  private _deleteAccount =  this._baseUrl + 'lookup/account-type/delete';
  private _searchAccount =  this._baseUrl + 'lookup/account-type/search';

  //Annual Income
  private _addAnnual = this._baseUrl + 'lookup/annual-income/update';
  private _getAnnual =  this._baseUrl + 'lookup/annual-income/get';
  private _getSingleAnnual =  this._baseUrl + 'lookup/annual-income/get';
  private _deleteAnnual =  this._baseUrl + 'lookup/annual-income/delete';
  private _searchAnnual =  this._baseUrl + 'lookup/annual-income/search';

  //Bank City
  private _addBankCity = this._baseUrl + 'lookup/bankcity/update';
  private _getBankCity =  this._baseUrl + 'lookup/bankcity/getbydistrict';
  private _getSingleBankCity =  this._baseUrl + 'lookup/bankcity/get';
  private _deleteBankCity =  this._baseUrl + 'lookup/bankcity/delete';
  private _searchBankCity =  this._baseUrl + 'lookup/bankcity/search';

   //Benefit Type
   private _addBenefit = this._baseUrl + 'lookup/benefit-type/update';
   private _getBenefit =  this._baseUrl + 'lookup/benefit-type/get';
   private _getSingleBenefit =  this._baseUrl + 'lookup/benefit-type/get';
   private _deleteBenefit =  this._baseUrl + 'lookup/benefit-type/delete';
   private _searchBenefit =  this._baseUrl + 'lookup/benefit-type/search'; 

   //Document Category
   private _addDocumentCategory = this._baseUrl + 'lookup/document-category/update';
   private _getDocumentCategory =  this._baseUrl + 'lookup/document-category/get';
   private _getSingleDocumentCategory =  this._baseUrl + 'lookup/document-category/get';
   private _deleteDocumentCategory =  this._baseUrl + 'lookup/document-category/delete';
   private _searchDocumentCategory =  this._baseUrl + 'lookup/document-category/search'; 

   //Document
   private _addDocument = this._baseUrl + 'lookup/document-type/update';
   private _getDocument =  this._baseUrl + 'lookup/document-type/get';
   private _getSingleDocument =  this._baseUrl + 'lookup/document-type/get';
   private _deleteDocument =  this._baseUrl + 'lookup/document-type/delete';
   private _searchDocument =  this._baseUrl + 'lookup/document-type/search'; 

   //Martial Status
   private _addMartialStatus = this._baseUrl + 'lookup/marital-status/update';
   private _getMartialStatus =  this._baseUrl + 'lookup/marital-status/get';
   private _getSingleMartialStatus =  this._baseUrl + 'lookup/marital-status/get';
   private _deleteMartialStatus =  this._baseUrl + 'lookup/marital-status/delete';
   private _searchMartialStatus =  this._baseUrl + 'lookup/marital-status/search'; 

//Country
private _addCountry = this._baseUrl + 'lookup/country/update';
private _getCountry =  this._baseUrl + 'lookup/country/get';
private _getSingleCountry =  this._baseUrl + 'lookup/country/get';
private _deleteCountry =  this._baseUrl + 'lookup/country/delete';
private _searchCountry =  this._baseUrl + 'lookup/country/search';

   //Occupation Risk Category Code
   private _addOccupation = this._baseUrl + 'lookup/occupation/update';
   private _getOccupation =  this._baseUrl + 'lookup/occupation/get';
   private _getSingleOccupation =  this._baseUrl + 'lookup/occupation/get';
   private _deleteOccupation =  this._baseUrl + 'lookup/occupation/delete';
   private _searchOccupation =  this._baseUrl + 'lookup/occupation/search';  

   // Payment Mode

   private _addPayment = this._baseUrl + 'lookup/paymentMode/update';
   private _getPayment = this._baseUrl + 'lookup/paymentMode/get';
   private _deletePayment = this._baseUrl + 'lookup/paymentMode/delete';
   private _getSinglePayment = this._baseUrl + 'lookup/paymentMode/get';
   private _searchPayment = this._baseUrl + 'lookup/paymentMode/search';

   // Region

   private _addRegion = this._baseUrl + 'lookup/region/update';
   private _getRegion = this._baseUrl + 'lookup/region/get';
   private _deleteRegion = this._baseUrl + 'lookup/region/delete';
   private _getSingleRegion = this._baseUrl + 'lookup/region/get';
   private _searchRegion = this._baseUrl + 'lookup/region/search';

   //Relationship

   private _addRelationship = this._baseUrl + 'lookup/relationship/update';
   private _getRelationship = this._baseUrl + 'lookup/relationship/get';
   private  _getSingleRelationship = this._baseUrl + 'lookup/relationship/get';
   private _deleteRelationship = this._baseUrl + 'lookup/relationship/delete';
   private _searchRelationship = this._baseUrl + 'lookup/relationship/search';

   //Residence Type

   private _addResidence = this._baseUrl + 'lookup/residence-type/update';
   private _getResidence = this._baseUrl + 'lookup/residence-type/get';
   private  _getSingleResidence = this._baseUrl + 'lookup/residence-type/get';
   private _deleteResidence = this._baseUrl + 'lookup/residence-type/delete';
   private _searchResidence = this._baseUrl + 'lookup/residence-type/search';

   //Profession

   private _addProfession = this._baseUrl + 'lookup/profession/update';
   private _getProfession = this._baseUrl + 'lookup/profession/get';
   private  _getSingleProfession = this._baseUrl + 'lookup/profession/get';
   private _deleteProfession = this._baseUrl + 'lookup/profession/delete';
   private _searchProfession = this._baseUrl + 'lookup/profession/search';

   //Medical Test

   private _addMedicalTest = this._baseUrl + 'lookup/medicaltest/update';
   private _getMedicalTest = this._baseUrl + 'lookup/medicaltest/get';
   private  _getSingleMedicalTest = this._baseUrl + 'lookup/medicaltest/get';
   private _deleteMedicalTest = this._baseUrl + 'lookup/medicaltest/delete';
   private _searchMedicalTest = this._baseUrl + 'lookup/medicaltest/search';

  //payment-frequency

   private _addFrequency = this._baseUrl + 'lookup/payment-frequency/update';
   private _getFrequency = this._baseUrl + 'lookup/payment-frequency/get';
   private  _getSingleFrequency = this._baseUrl + 'lookup/payment-frequency/get';
   private __deleteFrequency = this._baseUrl + 'lookup/payment-frequency/delete';
   private _searchFrequency = this._baseUrl + 'lookup/payment-frequency/search';

//Type of Business

private _addBusiness = this._baseUrl + 'lookup/business-type/update';
private _getBusiness = this._baseUrl + 'lookup/business-type/get';
private  _getSingleBusiness = this._baseUrl + 'lookup/business-type/get';
private __deleteBusiness = this._baseUrl + 'lookup/business-type/delete';
private _searchBusiness = this._baseUrl + 'lookup/business-type/search';

//State

private _addState = this._baseUrl + 'lookup/state/update';
private _getState = this._baseUrl + 'lookup/state/getbycountry';
private  _getSingleState = this._baseUrl + 'lookup/state/get';
private __deleteState = this._baseUrl + 'lookup/state/delete';
private _searchState = this._baseUrl + 'lookup/state/search';

//district

private _addDistrict = this._baseUrl + 'lookup/district/update';
private _getDistrict = this._baseUrl + 'lookup/district/getbystate';
private  _getSingleDistrict = this._baseUrl + 'lookup/district/get';
private __deleteDistrict = this._baseUrl + 'lookup/district/delete';
private _searchDistrict = this._baseUrl + 'lookup/district/search';

//Post Office

private _addPostOffice = this._baseUrl + 'lookup/postoffice/update';
private _getPostOffice = this._baseUrl + 'lookup/postoffice/getbydistrict';
private  _getSinglePostOffice = this._baseUrl + 'lookup/postoffice/get';
private __deletePostOffice = this._baseUrl + 'lookup/postoffice/delete';
private _searchPostOffice = this._baseUrl + 'lookup/postoffice/search';

  //City
  private _addCity = this._baseUrl + 'lookup/city/update';
  private _getCity =  this._baseUrl + 'lookup/city/getbydistrict';
  private _getSingleCity =  this._baseUrl + 'lookup/city/get';
  private _deleteCity =  this._baseUrl + 'lookup/city/delete';
  private _searchCity =  this._baseUrl + 'lookup/city/search';

  //Salutation
  private _addSalutation = this._baseUrl + 'lookup/salutation/update';
  private _getSalutation =  this._baseUrl + 'lookup/salutation/get';
  private _getSingleSalutation =  this._baseUrl + 'lookup/salutation/get';
  private _deleteSalutation =  this._baseUrl + 'lookup/salutation/delete';
  private _searchSalutation =  this._baseUrl + 'lookup/salutation/search';

   //Currency
   private _addCurrency = this._baseUrl + 'lookup/currency/update';
   private _getCurrency =  this._baseUrl + 'lookup/currency/get';
   private _getSingleCurrency =  this._baseUrl + 'lookup/currency/get';
   private _deleteCurrency =  this._baseUrl + 'lookup/currency/delete';
   private _searchCurrency =  this._baseUrl + 'lookup/currency/search';

  constructor(
    private http:HttpClient
  ) { }

  //Lookup
  getLookup(){
    return this.http.get<any>(this._getLookup);
  }


  // Address Type
  addAddress(data){
    return this.http.post<any>(this._addAddress, data);
  }

  getAddress(){
    return this.http.get<any>(this._getAddress);
  }

  getSingleAddress(id){
    return this.http.get<any>(this._getSingleAddress + '/' + id);
  }

  deleteAddress(id, deletedBy){
    return this.http.delete<any>(this._deleteAddress + '/' + id + '/' + deletedBy);
  }

  searchAddress(data){
    return this.http.post<any>(this._searchAddress, data);
  }

    // Account Type

    addAccount(data){
      return this.http.post<any>(this._addAccount, data);
    }

    getAccount(){
      return this.http.get<any>(this._getAccount);
    }

    getSingleAccount(id){
      return this.http.get<any>(this._getSingleAccount + '/' + id);
    }

    deleteAccount(id, deletedBy){
      return this.http.delete<any>(this._deleteAccount + '/' + id + '/' + deletedBy);
    }
  
    searchAccount(data){
      return this.http.post<any>(this._searchAccount, data);
    }

    //Annual Income

    addAnnual(data){
      return this.http.post<any>(this._addAnnual, data);
    }

    getAnnual(){
      return this.http.get<any>(this._getAnnual);
    }

    getSingleAnnual(id){
      return this.http.get<any>(this._getSingleAnnual + '/' + id);
    }

    deleteAnnual(id, deletedBy){
      return this.http.delete<any>(this._deleteAnnual + '/' + id + '/' + deletedBy);
    }
  
    searchAnnual(data){
      return this.http.post<any>(this._searchAnnual, data);
    }

    //Bank City

    addBankCity(data){
      return this.http.post<any>(this._addBankCity, data);
    }
  
    getBankCity(id){
      return this.http.get<any>(this._getBankCity + '/' + id);
    }
  
    getSingleBankCity(id){
      return this.http.get<any>(this._getSingleBankCity + '/' + id);
    }
  
    deleteBankCity(id, deletedBy){
      return this.http.delete<any>(this._deleteBankCity + '/' + id + '/' + deletedBy);
    }
    
    searchBankCity(data){
      return this.http.post<any>(this._searchBankCity, data);
    }

    //Benefit Type

    addBenefit(data){
      return this.http.post<any>(this._addBenefit, data);
    }
  
    getBenefit(){
      return this.http.get<any>(this._getBenefit);
    }
  
    getSingleBenefit(id){
      return this.http.get<any>(this._getSingleBenefit + '/' + id);
    }
  
    deleteBenefit(id, deletedBy){
      return this.http.delete<any>(this._deleteBenefit + '/' + id + '/' + deletedBy);
    }
    
    searchBenefit(data){
      return this.http.post<any>(this._searchBenefit, data);
    }

    //Document Category

    addDocumentCategory(data){
      return this.http.post<any>(this._addDocumentCategory, data);
    }
  
    getDocumentCategory(){
      return this.http.get<any>(this._getDocumentCategory);
    }
  
    getSingleDocumentCategory(id){
      return this.http.get<any>(this._getSingleDocumentCategory + '/' + id);
    }
  
    deleteDocumentCategory(id, deletedBy){
      return this.http.delete<any>(this._deleteDocumentCategory + '/' + id + '/' + deletedBy);
    }
    
    searchDocumentCategory(data){
      return this.http.post<any>(this._searchDocumentCategory, data);
    }

    //Document

    addDocument(data){
      return this.http.post<any>(this._addDocument, data);
    }
  
    getDocument(){
      return this.http.get<any>(this._getDocument);
    }
  
    getSingleDocument(id){
      return this.http.get<any>(this._getSingleDocument + '/' + id);
    }
  
    deleteDocument(id, deletedBy){
      return this.http.delete<any>(this._deleteDocument + '/' + id + '/' + deletedBy);
    }
    
    searchDocument(data){
      return this.http.post<any>(this._searchDocument, data);
    }

    // Martial Status

    addMaritalStatus(data){
      return this.http.post<any>(this._addMartialStatus, data);
    }
  
    getMaritalStatus(){
      return this.http.get<any>(this._getMartialStatus);
    }
  
    getSingleMaritalStatus(id){
      return this.http.get<any>(this._getSingleMartialStatus + '/' + id);
    }
  
    deleteMaritalStatus(id, deletedBy){
      return this.http.delete<any>(this._deleteMartialStatus + '/' + id + '/' + deletedBy);
    }
    
    searchMaritalStatus(data){
      return this.http.post<any>(this._searchMartialStatus, data);
    }

//Country

addCountry(data){
  return this.http.post<any>(this._addCountry, data);
}

getCountry(){
  return this.http.get<any>(this._getCountry);
}

getSingleCountry(id){
  return this.http.get<any>(this._getSingleCountry + '/' + id);
}

deleteCountry(id, deletedBy){
  return this.http.delete<any>(this._deleteCountry + '/' + id + '/' + deletedBy);
}

searchCountry(data){
  return this.http.post<any>(this._searchCountry, data);
}

    //Occupation Risk Category Code

    addOccupation(data){
      return this.http.post<any>(this._addOccupation, data);
    }

    getOccupation(){
      return this.http.get<any>(this._getOccupation);
    }

    getSingleOccupation(id){
      return this.http.get<any>(this._getSingleOccupation + '/' + id);
    }

    deleteOccupation(id, deletedBy){
      return this.http.delete<any>(this._deleteOccupation + '/' + id + '/' + deletedBy);
    }

    searchOccupation(data){
      return this.http.post<any>(this._searchOccupation, data);
    }

    // Payment mode

    addPayment(data)
    {
      return this.http.post<any>(this._addPayment, data);
    }

    getPayment()
    {
      return this.http.get<any>(this._getPayment)
    }

    getSinglePayment(id)
    {
      return this.http.get<any>(this._getSinglePayment + '/' + id);
    }

    deletePayment(id, deletedBy){
      return this.http.delete<any>(this._deletePayment + '/' + id + '/' + deletedBy);
    }

    searchPayment(data){
      return this.http.post<any>(this._searchPayment, data);
    }

   //Region

   addRegion(data){
    return this.http.post<any>(this._addRegion, data);
  }

  getRegion(){
    return this.http.get<any>(this._getRegion);
  }

  getSingleRegion(id){
    return this.http.get<any>(this._getSingleRegion + '/' + id);
  }

  deleteRegion(id, deletedBy){
    return this.http.delete<any>(this._deleteRegion + '/' + id + '/' + deletedBy);
  }

  searchRegion(data){
    return this.http.post<any>(this._searchRegion, data);
  }

  //Relationship

  addRelationship(data)
  {
    return this.http.post<any>(this._addRelationship, data);
  }

  getRelationship()
  {
    return this.http.get<any>(this._getRelationship)
  }

  getSingleRelationship(id)
  {
    return this.http.get<any>(this._getSingleRelationship + '/' + id);
  }

  deleteRelationship(id,deletedBy)
  {
    return this.http.delete<any>(this._deleteRelationship + '/' + id + '/' + deletedBy);
  }

  searchRelationship(data)
  {
    return this.http.post<any>(this._searchRelationship, data);
  }

    //Residence Type

    addResidence(data){
      return this.http.post<any>(this._addResidence, data);
    }
  
    getResidence(){
      return this.http.get<any>(this._getResidence);
    }
  
    getSingleResidence(id){
      return this.http.get<any>(this._getSingleResidence + '/' + id);
    }
  
    deleteResidence(id, deletedBy){
      return this.http.delete<any>(this._deleteResidence + '/' + id + '/' + deletedBy);
    }
  
    searchResidence(data){
      return this.http.post<any>(this._searchResidence, data);
    }

    //Residence Type

    addProfession(data){
      return this.http.post<any>(this._addProfession, data);
    }
  
    getProfession(){
      return this.http.get<any>(this._getProfession);
    }
  
    getSingleProfession(id){
      return this.http.get<any>(this._getSingleProfession + '/' + id);
    }
  
    deleteProfession(id, deletedBy){
      return this.http.delete<any>(this._deleteProfession + '/' + id + '/' + deletedBy);
    }
  
    searchProfession(data){
      return this.http.post<any>(this._searchProfession, data);
    }

//Medical Test

addMedicalTest(data){
  return this.http.post<any>(this._addMedicalTest, data);
}

getMedicalTest(){
  return this.http.get<any>(this._getMedicalTest);
}

getSingleMedicalTest(id){
  return this.http.get<any>(this._getSingleMedicalTest + '/' + id);
}

deleteMedicalTest(id, deletedBy){
  return this.http.delete<any>(this._deleteMedicalTest + '/' + id + '/' + deletedBy);
}

searchMedicalTest(data){
  return this.http.post<any>(this._searchMedicalTest, data);
}

//payment-frequency

addFrequency(data)
  {
    return this.http.post<any>(this._addFrequency, data);
  }

  getFrequency()
  {
    return this.http.get<any>(this._getFrequency)
  }

  getSingleFrequency(id)
  {
    return this.http.get<any>(this._getSingleFrequency + '/' + id);
  }

  deleteFrequency(id,deletedBy)
  {
    return this.http.delete<any>(this.__deleteFrequency + '/' + id + '/' + deletedBy);

  }

  searchFrequency(data)
  {
    return this.http.post<any>(this._searchFrequency, data);
  }

  //Type of Business

  addBusiness(data)
  {
    return this.http.post<any>(this._addBusiness, data);
  }

  getBusiness()
  {
    return this.http.get<any>(this._getBusiness)
  }

  getSingleBusiness(id)
  {
    return this.http.get<any>(this._getSingleBusiness + '/' + id);
  }

  deleteBusiness(id,deletedBy)
  {
    return this.http.delete<any>(this.__deleteBusiness + '/' + id + '/' + deletedBy);

  }

  searchBusiness(data)
  {
    return this.http.post<any>(this._searchBusiness, data);
  }

  //State

addState(data){
  return this.http.post<any>(this._addState, data);
}

getState(id){
  return this.http.get<any>(this._getState + '/' + id);
}

getSingleState(id){
  return this.http.get<any>(this._getSingleState + '/' + id);
}

deleteState(id, deletedBy){
  return this.http.delete<any>(this.__deleteState + '/' + id + '/' + deletedBy);
}

searchState(data){
  return this.http.post<any>(this._searchState, data);
}

//district

addDistrict(data){
  return this.http.post<any>(this._addDistrict, data);
}

getDistrict(id){
  return this.http.get<any>(this._getDistrict + '/' + id);
}

getSingleDistrict(id){
  return this.http.get<any>(this._getSingleDistrict + '/' + id);
}

deleteDistrict(id, deletedBy){
  return this.http.delete<any>(this.__deleteDistrict + '/' + id + '/' + deletedBy);
}

searchDistrict(data){
  return this.http.post<any>(this._searchDistrict, data);
}

//Post Office

addPostOffice(data){
  return this.http.post<any>(this._addPostOffice, data);
}

getPostOffice(id){
  return this.http.get<any>(this._getPostOffice + '/' + id);
}

getSinglePostOffice(id){
  return this.http.get<any>(this._getSinglePostOffice + '/' + id);
}

deletePostOffice(id, deletedBy){
  return this.http.delete<any>(this.__deletePostOffice + '/' + id + '/' + deletedBy);
}

searchPostOffice(data){
  return this.http.post<any>(this._searchPostOffice, data);
}

    //City

    addCity(data){
      return this.http.post<any>(this._addCity, data);
    }
  
    getCity(id){
      return this.http.get<any>(this._getCity + '/' + id);
    }
  
    getSingleCity(id){
      return this.http.get<any>(this._getSingleCity + '/' + id);
    }
  
    deleteCity(id, deletedBy){
      return this.http.delete<any>(this._deleteCity + '/' + id + '/' + deletedBy);
    }
    
    searchCity(data){
      return this.http.post<any>(this._searchCity, data);
    }

// Salutation

addSalutation(data){
  return this.http.post<any>(this._addSalutation, data);
}

getSalutation(){
  return this.http.get<any>(this._getSalutation);
}

getSingleSalutation(id){
  return this.http.get<any>(this._getSingleSalutation + '/' + id);
}

deleteSalutation(id, deletedBy){
  return this.http.delete<any>(this._deleteSalutation + '/' + id + '/' + deletedBy);
}

searchSalutation(data){
  return this.http.post<any>(this._searchSalutation, data);
}

// Currency

addCurrency(data){
  return this.http.post<any>(this._addCurrency, data);
}

getCurrency(){
  return this.http.get<any>(this._getCurrency);
}

getSingleCurrency(id){
  return this.http.get<any>(this._getSingleCurrency + '/' + id);
}

deleteCurrency(id, deletedBy){
  return this.http.delete<any>(this._deleteCurrency + '/' + id + '/' + deletedBy);
}

searchCurrency(data){
  return this.http.post<any>(this._searchCurrency, data);
}

  // Error handling 
  errorMgmt(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
