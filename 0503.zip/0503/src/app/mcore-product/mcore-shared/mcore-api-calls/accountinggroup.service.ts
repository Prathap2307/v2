import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { AccountingGroup } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountinggroup';
@Injectable({
  providedIn: 'root'
})
export class AccountinggroupService {

  constructor(private http: HttpClient) { }


  baseUrl = environment.API_URL;

  getAGGridDetailsBySearch(accountGroupId: number, code: number, groupName: number, name: string): Observable<AccountingGroup[]> {
    const AGridUrl = this.baseUrl + `/details/${accountGroupId}/${code}/${groupName}/${name}`;
    return this.http.get<AccountingGroup[]>(AGridUrl)
      .pipe();
  }

  getAccountingGroupGridDetails(Type: string): Observable<AccountingGroup[]> {
   const allAGUrl = this.baseUrl + `/code/${Type}`;
    return this.http.get<AccountingGroup[]>(allAGUrl)
      .pipe();
  }


  createAGroupUrl = this.baseUrl + '/createAccountGroup';
  createAccountingGroup(a: AccountingGroup): Observable<AccountingGroup> {
    return this.http.post<AccountingGroup>(this.createAGroupUrl, a);
  }
}
