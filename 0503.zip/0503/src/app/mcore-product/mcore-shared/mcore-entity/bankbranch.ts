export interface BankBranch {
    searchbankId: number;
    searchbankCityId: number;
    // searchbankId: number;
    // searchbankCityId: number;
    searchifscCode: string;
    searchmicrCode: string;
    branchId: number;
    bankId: number;
    bankCityId: number;
    BankName: string;
    BankCityName: string;    
    description: string;
    ifscCode: string;
    micrCode: string;
    createdBy: number;
    createdOn: Date;
}

export interface BankName {
    bankId: number;
    description: string;
}

export interface BankCity {
    bankId: number;
    bankCityId: number;
    description: string;
}