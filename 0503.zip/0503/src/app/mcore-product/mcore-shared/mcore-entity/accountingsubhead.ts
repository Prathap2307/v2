export interface Accountingsubhead {
    SearchAccountHead: number;
    SearchAccountHeadCode: number;
    SearchAccountHeadDescription: number;
    subAccountHeadId: number;
    accountHeadId: number;
    accountHeadName: string;
    accountHeadCode: string;
    subAccountHeadName: string;
    subAccountHeadCode: string;
    createdBy: number;
    createdOn: Date;
    isactive: number;
}

export interface AccountHead{
    accountHeadId: number;
    accountHeadName: string;
}

