export class AdvanceDepositReceipt {
	clientName: string;
	masterPolicyNumber: string;	
	agreementNumber: number;
	receiptNumber: string;
	fromDate: Date;
	toDate: Date;
}