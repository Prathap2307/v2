export interface AccountingProcess {
    processID: number;
    accountProcessID: number;
    code: string;
    groupName: number;
    description: string;
    processName: string;
	isGSTApplicable: number;
	isTaxApplicable: number;
    gstType: number;
    gstTypeID: number;
    isActive: number;
    createdBy: number;
    createdOn: Date;
    modifiedBy:  number;
    modifiedOn:  Date;
}	

export interface AccountTypeDropDown {
   AccountTypeDropDownID: number;
    AccountTypeDropDownText: string;
}