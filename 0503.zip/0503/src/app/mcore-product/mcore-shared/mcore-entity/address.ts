export interface Address {

    zipCode: string;
	country: string;
	state: string;
	district: string;
	postOffice: string;
	taulkName: string;
	
	stateName: string;
	stateId: number;
	countryId: number;
    countryName: string;
    districtId: number;
    districtName: string;
}	

export interface country {
	countryId: number;
	description: string;
}	

export interface state {
	stateId: number;
	description: string;
}	

export interface district {
	districtId: number;
	description: string;
}	

export interface postOffice {
	postOfficeId: number;
	description: string;
}	