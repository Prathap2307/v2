export interface AccountingGroup {
    accountClassificationID: number;
    code: string;
    description: string;
    accountGroupID: number;
}

export interface AccountingType {
    accountHeadId: number;
    code: string;
  
}


export interface AccountingGrid {
    accountHeadId: number;
    code: string;
    accountHeadName: string;
    classification: string;
    groupName: string;
    accountClassificationID: number;
    accountGroupID: number;
    accountTypeID: number;
    isControlAC: number;
    createdBy: number;
    isactive: number;
    isManualVoucher: number;
}

export interface AccountTypeDropDown {
    AccountTypeDropDownID: number;
    AccountTypeDropDownText: string;
}