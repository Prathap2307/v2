export interface Product {
	productid: number;
    productName: string;
    code: number;
    category: string;
}	