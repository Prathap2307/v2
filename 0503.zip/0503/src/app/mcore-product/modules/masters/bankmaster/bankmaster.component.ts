import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { BankMaster } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankmaster';
import { BankmasterService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/bankmaster.service';
import { Key, until } from 'protractor';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';

@Component({
	selector: 'app-bankmaster',
	templateUrl: './bankmaster.component.html',
	styleUrls: ['./bankmaster.component.css']
})
export class BankmasterComponent implements OnInit {




	bankObj: BankMaster[];
	bankFilterObj: BankMaster[];

	bankmasterForm: FormGroup;
	bankmasterFormAction: FormGroup;
	bankColumns: string[] = ['View', 'Edit', 'Delete', 'bankName', 'bankShortName'];
	bankmasterHeading: string = '';
	textSaveBtn: string = '';
	saveBtnMode: boolean = true;
	dataSource = new MatTableDataSource<BankMaster>(this.bankObj);
  
	@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
	constructor(
		private fb: FormBuilder, private bankmasterService: BankmasterService
	) { }



	ngOnInit() {
		this.dataSource = new MatTableDataSource<BankMaster>(this.bankObj);
		this.bankmasterHeading = 'Add New - Bank';
		this.textSaveBtn = 'Save';
		this.getBankDetails();
		this.bankmasterForm = this.fb.group({
			searchBank: [''],
			bankmasterFormAction: this.fb.group({
				bankId: [''],
				bankName: ['', [Validators.required]],
				bankShortName:['', [Validators.required]],
				createdBy: ['1'],
				createdOn: [new Date()],
				deletedBy: ['1'],
				deletedOn: [new Date()]
			})
		});


		this.onChanges();
	}

	onChanges(): void {
		this.bankmasterForm.get('bankmasterFormAction').valueChanges.subscribe(val => {
		//	console.log(val);
		});
	  }

	onBtnSearchClearBankMasterClick() {
	//	this.bankmasterForm.controls.searchBank.reset();
		this.getBankDetails();
		this.bankmasterForm.controls['searchBank'].setValue('');
		this.bankmasterForm.controls['searchBank'].clearValidators();
		this.bankmasterForm.controls['searchBank'].updateValueAndValidity();
		this.bankmasterForm.controls['searchBank'].markAsUntouched();
	}

	getBankDetailsByDescription() {

		this.bankmasterForm.controls['searchBank'].setValidators(Validators.required);
		this.bankmasterForm.controls['searchBank'].updateValueAndValidity();
		this.bankmasterForm.controls['searchBank'].markAsTouched();
		if (this.bankmasterForm.controls.searchBank.valid) {
			let searchValue = this.bankmasterForm.controls.searchBank.value;

			this.bankmasterService.getBankDetailsByDescription(searchValue)
				.subscribe(a =>{
					 this.bankObj = a;
					 this.dataSource = new MatTableDataSource<BankMaster>(this.bankObj);
					 this.dataSource.data = this.bankObj = a;
					 this.dataSource.paginator = this.paginator;  
				});


		} else {
		}

	}

	getBankDetails(): void {
		this.bankmasterService.getBankDetails()
			.subscribe(bankObj => {
				this.bankObj = bankObj;
				this.dataSource = new MatTableDataSource<BankMaster>(this.bankObj);
				this.dataSource.data = this.bankObj = bankObj;
				this.dataSource.paginator = this.paginator;  
			});
	}


	onBtnSaveBank() {

	this.bankmasterForm.get('bankmasterFormAction').patchValue({
			createdBy:  '1',
			createdOn: new Date()
		});
	//	console.log(bankU);
		this.bankmasterForm.controls.bankmasterFormAction.markAllAsTouched();
		if (this.bankmasterForm.controls.bankmasterFormAction.valid) {

			let a = this.bankmasterForm.controls.bankmasterFormAction.value;
			console.log(a);
			this.bankmasterService.addBank(a)
				.subscribe(result => { this.getBankDetails() });

		
			this.onBtnClearBank();
			
		}
	}

	onBtnClearBank() {
		this.bankmasterHeading = 'Add New - Bank';
		this.textSaveBtn = 'Save';
		this.saveBtnMode = true;
		this.bankmasterForm = this.fb.group({
			searchBank: [''],
			bankmasterFormAction: this.fb.group({
				bankId: { value: '', disabled: false },
				bankName: { value: '', disabled: false },
				bankShortName: { value: '', disabled: false },
				createdBy: { value: '', disabled: false },
				createdOn: { value: '', disabled: false }

			})


		});

	}

	btngvView_Click(a) {
		this.saveBtnMode = false;

		this.bankFilterObj = this.bankObj.filter((unit) => unit.bankId == a);

		this.bankmasterForm = this.fb.group({
			searchBank: [''],
			bankmasterFormAction: this.fb.group({
				bankId: { value: this.bankFilterObj[0].bankId, disabled: true },
				bankName: { value: this.bankFilterObj[0].bankName, disabled: true },
				bankShortName: { value: this.bankFilterObj[0].bankShortName, disabled: true },
				createdBy: { value: this.bankFilterObj[0].createdBy, disabled: true },
				createdOn: { value: this.bankFilterObj[0].createdOn, disabled: true }

			})
		});

		this.bankmasterHeading = 'View - Bank';
	
	}

	btngvEdit_Click(a) {

		this.bankFilterObj = this.bankObj.filter((unit) => unit.bankId == a);
		this.bankmasterForm = this.fb.group({
			searchBank: [''],
			bankmasterFormAction: this.fb.group({
				bankId: { value: this.bankFilterObj[0].bankId, disabled: false },
				bankName: { value: this.bankFilterObj[0].bankName, disabled: false },
				bankShortName: { value: this.bankFilterObj[0].bankShortName, disabled: false },
				createdBy: { value: this.bankFilterObj[0].createdBy, disabled: false },
				createdOn: { value: this.bankFilterObj[0].createdOn, disabled: false }
			})


		});

		this.bankmasterHeading = 'Edit - Bank';
		this.textSaveBtn = 'Update';
		this.saveBtnMode = true;
	}


	btngvDelete_Click(a) {
		//console.log(a)

		this.bankmasterForm = this.fb.group({
			searchBank: [''],
			bankmasterFormAction: this.fb.group({
				bankId: { value: a, disabled: false },
				bankName: { value: '', disabled: false },
				bankShortName: { value: '', disabled: false },
				createdBy: { value: '', disabled: false },
				createdOn: { value: '', disabled: false },
				deletedBy: '2',
				deletedOn: '2020-01-30'
			})
		});


		// console.log(this.bankmasterForm.get('bankmasterFormAction').value);

		let c = this.bankmasterForm.get('bankmasterFormAction').value;

		console.log(c);
		this.bankmasterService
			.deleteBank(c)
			.subscribe(result => { this.getBankDetails() });


	}


}
