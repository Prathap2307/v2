import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
@Component({
  selector: 'app-fchannel',
  templateUrl: './fchannel.component.html',
  styleUrls: ['./fchannel.component.css']
})
export class FchannelComponent implements OnInit {
  SearchChannel: FormGroup;
  submitted: boolean;
  channelHeading: string = 'Add New - Main Channel';
  saveBtnMode: boolean = true;
  textSaveBtn: string = 'Save';
  view: boolean = false;
  display: string = 'none';
  allbranch: any;
  allchannel: any;
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  submit: boolean;
  channelObj: any;
  id: any;
  transaction: string;
  success: boolean;
  exist: boolean;
  present: any;
  constructor(private fb: FormBuilder, private FchannelService: FchannelService, ) { }
  ChannelForm: FormGroup;
  ngOnInit() {
    this.getallbranches()
    this.getallchannel()
    this.SearchChannel = this.fb.group({
      ChannelName: ['',],
      ChannelCode: ['',],
    })
    this.ChannelForm = this.fb.group({
      ChannelID: [''],
      ChannelName: ['', Validators.required],
      ChannelCode: ['', Validators.required],
      CreatedBy: ['',],
      CreatedOn: ['',]

    })
  }
  get f() { return this.ChannelForm.controls; }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  IsChannelExist(data: any) {
    this.FchannelService.IsChannelExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === "NOTEXIST") {
          this.submit = true
          console.log(this.submit)
          this.FchannelService.addfchannel(this.ChannelForm.value)
            .subscribe(result => {
              console.log(result)
              this.success = true
              if (this.textSaveBtn === 'Save') {
                this.transaction = "Created"
              }else{
                this.transaction = "Updated"
              }
         
              this.getallchannel()
              this.openModalDialog()
              this.cancel() 
            });
        }
        else {
          this.exist = true
          this.present = result.data
          this.openModalDialog()
        }

      });
  }
  onBtnSaveClick() {
    this.submitted = true
    console.log(this.ChannelForm.value)
    this.ChannelForm.value['CategroyID'] = 1
    this.ChannelForm.value['CreatedBy'] = 1
    if (this.id && this.textSaveBtn === 'Update') {
      console.log(this.id)
      this.ChannelForm.value["ChannelID"] = this.id
    }
    else {
      this.ChannelForm.value['ChannelID'] = 0
    }
    this.IsChannelExist(this.ChannelForm.value)

  }
  deletechannel(data) {
    console.log(data)
    let d = {
      "ChannelID": data.channelID,
      "DeletedBy": "1",
      "DeletedOn": "26-01-2020"
    }
    this.FchannelService.DeleteChannel(d)
      .subscribe(result => {
        console.log(result)
        this.getallchannel()
      });

  }
  clearSearch() {
    this.SearchChannel.value["ChannelName"] = " "
    this.SearchChannel.value["ChannelCode"] = " "
    this.SearchChannel.reset();
    this.getallchannel()
  }
  getallbranches() {
    this.FchannelService.GetAllBranchesbyorgID(1)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
        console.log(this.allbranch)

      });
  }
  getallchannel() {
    this.FchannelService.GetAllMainChannel()
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        console.log(this.allchannel)
        if (this.allchannel) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allchannel.length
          }
        }
      });
  }
  btngEdit_Click(a) {

    this.channelHeading = 'Edit -  Main Channel';
    this.saveBtnMode = true;
    this.view = false
    this.textSaveBtn = 'Update'
    this.id = a
    this.getchannelById(a)
  }
  getchannelById(a: any) {
    this.FchannelService.GetChannelById(a)
      .subscribe(result => {
        console.log(result)
        this.channelObj = result.data[0]
        console.log(this.channelObj)
        if (this.channelObj) {
          this.ChannelForm = this.fb.group({
            ChannelID: [{ value: this.channelObj.channelID, disabled: false }],
            ChannelName: [{ value: this.channelObj.channelName, disabled: false }, Validators.required],
            ChannelCode: [{ value: this.channelObj.channelCode, disabled: false }, Validators.required],

          })
          console.log(this.ChannelForm.value)
        }

      })
  }
  Search() {
    console.log(this.SearchChannel.value)
    this.FchannelService.GetChannel(this.SearchChannel.value)
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        if (this.allchannel) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allchannel.length
          }
        }
      });
  }
  btngView_Click(a) {
    this.channelHeading = 'View -  Main Channel';
    this.view = true
    this.saveBtnMode = false;
    this.getchannelById(a)
  }
  nameCodeValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if ((keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)
        event.preventDefault();
      }
    }
  }
  CodeValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 3) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          //event.preventDefault();
        }
      }
      else { 
        //event.preventDefault();
      }

    }
  }
  
  cancel() {
    this.ChannelForm.reset()
    console.log(this.submitted)
    this.submitted = false
    this.channelHeading = 'Add New - Main Channel';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }

  }
  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.exist = false
    this.success = false

  }
}
