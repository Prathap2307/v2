import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from "moment"
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { StampdutyService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/stampduty.service';

// import { StampdutyService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/group.service';
@Component({
  selector: 'app-stampduty',
  templateUrl: './stampduty.component.html',
  styleUrls: ['./stampduty.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },
    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class StampdutyComponent implements OnInit {
  SearchStampDuty: FormGroup;
  AddStampDuty: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  SubchannelHeading: string = "Add New - Stamp Duty";
  saveBtnMode: boolean = true;
  view: boolean = false;
  textSaveBtn: string = "Save";
  display: string;
  invalidDate: boolean = false;
  validform: boolean;
  allstamp: any;
  Stampdutyobj: any;
  success: boolean;
  transaction: string;
  exist: boolean;

  constructor(private fb: FormBuilder, private StampdutyService: StampdutyService) { }

  ngOnInit() {
    this.getallstamp()
    this.SearchStampDuty = this.fb.group({
      receiptNumber: ['', Validators.required],
      stampDutyAmount: ['', Validators.required]
    })
    this.forminit()
  }

  forminit() {

    this.AddStampDuty = this.fb.group({
      stampDutyID:[],
      receiptNumber: ['', Validators.required],
      challanDate: ['', Validators.required],
      challanEndDate: ['', Validators.required],
      defaceNumber: ['', Validators.required],
      defaceDate: ['', Validators.required],
      certificateNumber: ['', Validators.required],
      certificateDate: ['', Validators.required],
      stampDutyAdvanceDepositAmount: ['', Validators.required],
      triggerAmount: ['', Validators.required],
      intimationEmailaddress: ['', [Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
      intimationMobileNumber: ['', Validators.required],
    })
  }

  get d() { return this.SearchStampDuty.controls; }

  onBtnSearchClick() {
    this.submitted = true;
    console.log(this.SearchStampDuty.value)
  }

  get a() { return this.AddStampDuty.controls; }

  onBtnSave() {
    this.submitted1 = true;
    let fromvalue = moment(new Date(this.AddStampDuty.value["challanDate"])).format('YYYY/MM/DD')
    let tovalue = moment(new Date(this.AddStampDuty.value["challanEndDate"])).format('YYYY/MM/DD')
    let challanDate = moment(fromvalue);
    let challanEndDate = moment(tovalue);

    // let challanDate = moment(this.AddStampDuty.value["challanDate"]._i.year + '/' + this.AddStampDuty.value["challanDate"]._i.month + '/' + this.AddStampDuty.value["challanDate"]._i.date);
    // let challanEndDate = moment(this.AddStampDuty.value["challanEndDate"]._i.year + '/' + this.AddStampDuty.value["challanEndDate"]._i.month + '/' + this.AddStampDuty.value["challanEndDate"]._i.date);
    let result = challanDate.diff(challanEndDate, 'days');
    console.log(this.invalidDate)
    console.log(result)
    if (result >= 0) {
      this.openModalDialog()
      this.invalidDate = true
      console.log("Challan End Date should be greater than Challan Date")
    }
    else {
      this.invalidDate = false
    }
    console.log(this.AddStampDuty.value)
    console.log(this.AddStampDuty.controls)
    if (this.AddStampDuty.valid && !this.invalidDate) {
      this.IsStampdutyExist(this.AddStampDuty.value)
    }

  }
  clear() {
    this.AddStampDuty.reset()
    this.SubchannelHeading = 'Add - Stamp Duty';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    this.submitted1 = false
    console.log(this.submitted)
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  getallstamp() {
    this.StampdutyService.GetAllStampduty()
      .subscribe(result => {
        console.log(result)
        this.allstamp = result.data
      });
  }

  btngEdit_Click(id) {

    this.SubchannelHeading = 'Edit - Stamp Duty';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.GetStampdutybyId(id)
  }

  GetStampdutybyId(id) {

    // ===========get tax detail by id===================

    this.StampdutyService.GetStampdutybyId(id)
      .subscribe(result => {
        console.log(result)
        this.Stampdutyobj = result.data[0]
        console.log(this.Stampdutyobj)
        if (this.Stampdutyobj) {
          this.AddStampDuty = this.fb.group({
            stampDutyID:[{value: this.Stampdutyobj.stampDutyID, disabled: false}],
            receiptNumber: [{ value: this.Stampdutyobj.receiptNumber, disabled: false }, Validators.required],
            challanDate: [{ value: this.Stampdutyobj.paymentDate, disabled: false }, Validators.required],
            challanEndDate: [{ value: this.Stampdutyobj.challanEndDate, disabled: false }, Validators.required],
            defaceNumber: [{ value: this.Stampdutyobj.defaceNumber, disabled: false }, Validators.required],
            defaceDate: [{ value: this.Stampdutyobj.defaceDate, disabled: false }, Validators.required],
            certificateNumber: [{ value: this.Stampdutyobj.certificateNumber, disabled: false }, Validators.required],
            certificateDate: [{ value: this.Stampdutyobj.certificateDate, disabled: false }, Validators.required],
            stampDutyAdvanceDepositAmount: [{ value: this.Stampdutyobj.stampDutyAdvanceDepositAmount, disabled: false }, Validators.required],
            triggerAmount: [{ value: this.Stampdutyobj.triggerAmount, disabled: false }, Validators.required],
            intimationEmailaddress: [{ value: this.Stampdutyobj.intimationEmailAddress, disabled: false }, [Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
            intimationMobileNumber: [{ value: this.Stampdutyobj.intimationMobileNumber, disabled: false }, Validators.required],
          })
        }
      });
  }
  IsStampdutyExist(data: any) {
    if (this.textSaveBtn === 'Save') {
      this.AddStampDuty.value["stampDutyID"] = 0
    }
    this.AddStampDuty.value["productID"] = 2
    this.AddStampDuty.value["coverageID"] = 2
    this.AddStampDuty.value["mudrakNumber"] = 12
    this.AddStampDuty.value["payOrderNumber"] = 121
    this.AddStampDuty.value["createdBy"] = 1
    this.StampdutyService.IsStampdutyExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === false) {
          this.StampdutyService.InsertOrUpdateStampduty(data)
            .subscribe(result => {
              console.log(result)
              if (result.data = "Success") {
                this.success = true
                this.validform = true
                if (this.textSaveBtn === 'Save') {
                  let transaction = "Stampduty Created Successfully"
                  this.openModalDialog1(transaction)
                }
                else {
                  let transaction = "Stampduty Updated Successfully"
                  this.openModalDialog1(transaction)
                }
              }
              this.getallstamp()
              this.clear()
            });
        }
        else {
          this.exist = true
        }

      });
  }
  btngView_Click(id) {
    this.SubchannelHeading = 'View - Stamp Duty';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.GetStampdutybyId(id)
  }
  delete(id) {
    // ============delete tax structure========//
    console.log(id)
    this.StampdutyService.DeleteStampDuty(id)
      .subscribe(result => {
        console.log(result)
        let module = result.data
      });
  }
  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    this.invalidDate = false
    console.log(this.invalidDate)


  }
  openModalDialog1(msg) {
    this.display = 'block'; //Set block css
    this.submitted = false
    this.transaction = msg

  }

  NumValidate(event: any) {
    var a = event.target.value;
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.validform = false
    this.exist = false

  }
  get EmailError() {
    if (this.AddStampDuty.controls['intimationEmailaddress'].hasError('required')) {
      return 'Please enter the Intimation Email address for Stamp Duty.';
    } else if (this.AddStampDuty.controls['intimationEmailaddress'].hasError('pattern')) {
      return 'Please Enter Valid Intimation Email address for Stamp Duty.';
    }
  }
}
