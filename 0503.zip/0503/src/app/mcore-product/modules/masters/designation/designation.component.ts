import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
import { DesignationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/designation.service';
import { TooltipPosition } from '@angular/material/tooltip';

import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.css']
})
export class DesignationComponent implements OnInit {

  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

  submitted = false;
  saveBtnMode: boolean;
  designationForm: FormGroup;
  createBtn: boolean;
  get designationFormSearch() {
    return this.designationForm.get('designationFormSearch') as FormGroup;
  }
  get designationFormAction() {
    return this.designationForm.get('designationFormAction') as FormGroup;
  }
  departmentObj: DepartmentType[];
  fieldDisable: Boolean;

  constructor(private fb: FormBuilder, private designationService: DesignationService, private departmentService: DepartmentService) { }

  designationObj: Designation[] = [];
  designationDDObj: Designation[] = [];
  designationGridObj: Designation[] = [];
  designationFilteredObj: Designation[] = [];
  designationColumns: string[] = ['View', 'Edit', 'Delete', 'department', 'description'];

  designationHeading: string = '';
  dataSource = new MatTableDataSource<Designation>(this.designationGridObj);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;


  ngOnInit() {

    this.dataSource = new MatTableDataSource<Designation>(this.designationGridObj);
    this.fieldDisable = false;
    this.createBtn = true;
    this.designationForm = this.fb.group({
      designationFormSearch: this.fb.group({

        searchdesignationName: [''],
        searchdepartmentName: [''],
      }),

      designationFormAction: this.fb.group({
        designationId: [''],
        description:
          [
            '',
            [Validators.required]
          ],
        departmentId:
          [
            '',
            [Validators.required]
          ]

      })
    });

    this.designationHeading = 'Add New - Designation';
    this.saveBtnMode = true;
    this.getDesignationDetails();
    this.getDepartmentDetails();
  }

  getDetailsInfoBySearch(): void {



    let a = this.designationFormSearch.get('searchdepartmentName').value;
   
    if(a == '' || a == 'null'){
        a = 0;
    }
    let r = this.designationGridObj.filter((unit) => unit.designationId == a);
    let b;
    if (r.length > 0) {
      b = r[0].description;
    } else {
      b = null;
    }

    this.designationService.getDetailsInfoBySearch(a, b)
      .subscribe(s => {

        this.designationObj = s;
        this.designationGridObj = s;
        this.dataSource = new MatTableDataSource<Designation>(this.designationGridObj);
        this.dataSource.data = this.designationGridObj = s;
        this.dataSource.paginator = this.paginator;

      });


  }

  removeSaveFormControls(){
    this.designationFormAction.removeControl('createdBy');
    this.designationFormAction.removeControl('createdOn');
    this.designationFormAction.removeControl('shortName');
  }

  onBtnSaveDesignation() {


    if (this.createBtn) {
      this.designationFormAction.get('designationId').patchValue('');
      this.designationFormAction.addControl('createdBy', new FormControl(1));
      this.designationFormAction.addControl('createdOn', new FormControl(new Date()));
      this.designationFormAction.addControl('shortName', new FormControl(''));
    } else {

      this.designationFormAction.addControl('createdOn', new FormControl(new Date()));
      this.designationFormAction.addControl('shortName', new FormControl(''));
    }


    this.designationFormAction.markAllAsTouched();
    if (this.designationFormAction.valid) {

      let a = this.designationFormAction.value;
      console.log(a);
      this.designationService.addDesignation(a)
        .subscribe(result => { this.getDesignationDetails() });

      this.designationHeading = 'Add New - Designation';

      this.onBtnClearDesignation();
      this.removeSaveFormControls();

    }
  }
  onBtnSearchClearDesignation() {
    this.designationFormSearch.reset();

    this.getDesignationDetails();
  }
  onBtnClearDesignation() {
    this.fieldDisable = false;
    this.designationForm.controls.designationFormAction.reset();
    this.designationHeading = 'Add New - Designation';

    this.designationFormAction.reset({

      designationId: ''
    });

    // this.designationForm = this.fb.group({
    //   designationFormSearch: this.fb.group({

    //     searchdesignationName: [''],
    //     searchdepartmentName: [''],
    //   }),
    //   designationFormAction: this.fb.group({
    //     designationId: '',
    //     departmentId: '',
    //     description: ''

    //   })

    // });

    this.saveBtnMode = true;


  }
  getDesignationDetails(): void {

    this.designationService.getDesignationDetails(0, null)
      .subscribe(a => {
        this.designationDDObj = a;
        this.designationObj = a;
        this.designationGridObj = a;
        this.dataSource = new MatTableDataSource<Designation>(this.designationGridObj);
        this.dataSource.data = this.designationGridObj = a;
        this.dataSource.paginator = this.paginator;

      });

  }

  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => {
        this.departmentObj = departmentObj;

      });

  }
  removeDeleteFormControls(){
    this.designationFormAction.removeControl('deletedBy');
    this.designationFormAction.removeControl('deletedOn');
  }
  btngvDelete_Click(a) {

    this.designationFormAction.get('designationId').patchValue(a);
    this.designationFormAction.addControl('deletedBy', new FormControl(2));
    this.designationFormAction.addControl('deletedOn', new FormControl(new Date()));

    let c = this.designationFormAction.value;

    this.designationService.deleteDesignation(c).subscribe(result => { this.getDesignationDetails() });

    this.removeDeleteFormControls();
  }

  btngvView_Click(a) {
    this.saveBtnMode = false;
    this.fieldDisable = true;

    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);


    this.designationFormAction.patchValue({
      designationId: this.designationFilteredObj[0].designationId,
      departmentId: this.designationFilteredObj[0].departmentId,
      description: this.designationFilteredObj[0].description,
      createdBy: this.designationFilteredObj[0].createdBy,
      createdOn: this.designationFilteredObj[0].createdOn

    });


    this.designationHeading = 'View - Designation';



  }

  btngvEdit_Click(a) {
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.createBtn = false;
    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationFormAction.patchValue({
      designationId: this.designationFilteredObj[0].designationId,
      departmentId: this.designationFilteredObj[0].departmentId,
      description: this.designationFilteredObj[0].description,
      createdBy: this.designationFilteredObj[0].createdBy,
      createdOn: this.designationFilteredObj[0].createdOn

    });

    this.designationHeading = 'Edit - Designation';

  }

  //disableSelect = new FormControl(false);

  //id = new FormControl(false);

  cfn(val) {
    console.log(val);
  }




}
