import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Organization } from 'src/app/mcore-product/mcore-shared/mcore-entity/organization';
import { OrganizationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/organization.service';
import { AddressService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/address.service';
import { Address, country, state, district, postOffice } from 'src/app/mcore-product/mcore-shared/mcore-entity/address';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
@Component({
  selector: 'app-organization',
  templateUrl: './organization.component.html',
  styleUrls: ['./organization.component.css']
})
export class OrganizationComponent implements OnInit {
 
  organizationForm: FormGroup;
  get organizationFormAction() {
    return this.organizationForm.get('organizationFormAction') as FormGroup;
  }
  constructor(private fb: FormBuilder, private addressService: AddressService, private organizationService: OrganizationService) { }
  organizationGridObj: Organization[];
  organizationFilterGridObj: Organization[];
  addressObj: Address[];
  countryObj: country[];
  stateObj: state[];
  districtObj: district[];
  talukObj: postOffice[];
  selectedValue: number;
  createBtn: boolean;
  actionHeading: string;
  saveBtnMode: boolean;
  fieldDisable: Boolean;
  textSaveBtn: string;
  organizationColumns: string[] = ['View', 'Edit', 'shortName', 'organisationName'];
  dataSource = new MatTableDataSource<Organization>(this.organizationGridObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngOnInit() {
     this.dataSource = new MatTableDataSource<Organization>(this.organizationGridObj);
    this.actionHeading = 'Add New - Organization';
    this.saveBtnMode = true;
    this.createBtn = true;
    this.textSaveBtn = 'Save';
    this.getOrganizationGridDetails();
    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({

        organisationId: [''],
        shortName: ['', [Validators.required]],
        organisationName: ['', [Validators.required]],
        address1: ['', [Validators.required]],
        address2: [''],
        address3: [''],
        countryId: ['', [Validators.required]],
        stateId: [''],
        districtId: [''],
        talukId: [''],
        zipCode: ['', [Validators.required]],
        phoneNo: [''],
        mobileNo: [''],
        conferenceNo: [''],
        faxNo: [''],
        email: ['' , [Validators.email]],
        gstNo: [''],
        panNo: ['', [Validators.required, Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$'), Validators.minLength]],
        sacCode: ['', [Validators.required]]

      })

    });



    this.getAllCountries();
  }

  allowNumberFn(event) {
    const keyCode = event.keyCode;
    //console.log(keyCode);
    const excludedKeys = [8, 37, 39, 46];

    if (!((keyCode >= 48 && keyCode <= 57) ||
      (keyCode >= 96 && keyCode <= 105) ||
      (excludedKeys.includes(keyCode)))) {

      event.preventDefault();
    }
  }
  getOrganizationGridDetails(): void {
    this.organizationService.getOrganizationGridDetails().subscribe(a => {
      this.organizationGridObj = a;

      this.dataSource = new MatTableDataSource<Organization>(this.organizationGridObj);
      this.dataSource.data = this.organizationGridObj = a;
      this.dataSource.paginator = this.paginator;
    });

  }
  btngvView_Click(a) {
    // this.getAllCountries();
    this.actionHeading = 'View - Organization';
    this.saveBtnMode = false;
    this.fieldDisable = true;
    this.organizationFilterGridObj = this.organizationGridObj.filter((unit) => unit.organisationId == a);

    console.log(this.organizationFilterGridObj[0]);

    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({

        organisationId: this.organizationFilterGridObj[0].organisationId,
        shortName: this.organizationFilterGridObj[0].shortName,
        organisationName: this.organizationFilterGridObj[0].organisationName,
        address1: this.organizationFilterGridObj[0].address1,
        address2: this.organizationFilterGridObj[0].address2,
        address3: this.organizationFilterGridObj[0].address3,
        countryId: this.organizationFilterGridObj[0].countryId,
        stateId: this.organizationFilterGridObj[0].stateId,
        districtId: this.organizationFilterGridObj[0].districtId,
        talukId: this.organizationFilterGridObj[0].talukId,
        zipCode: this.organizationFilterGridObj[0].zipCode,
        phoneNo: this.organizationFilterGridObj[0].phoneNo,
        mobileNo: this.organizationFilterGridObj[0].mobileNo,
        conferenceNo: this.organizationFilterGridObj[0].conferenceNo,
        faxNo: this.organizationFilterGridObj[0].faxNo,
        email: this.organizationFilterGridObj[0].email,
        gstNo: this.organizationFilterGridObj[0].gstNo,
        panNo: this.organizationFilterGridObj[0].panNo,
        sacCode: this.organizationFilterGridObj[0].sacCode

      })

    });

  }

  btngvEdit_Click(a) {
    this.actionHeading = 'Edit - Organization';
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.createBtn = false;
    this.organizationFilterGridObj = this.organizationGridObj.filter((unit) => unit.organisationId == a);

    console.log(this.organizationFilterGridObj[0]);

    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({
        organisationId: this.organizationFilterGridObj[0].organisationId,
        shortName: this.organizationFilterGridObj[0].shortName,
        organisationName: this.organizationFilterGridObj[0].organisationName,
        address1: this.organizationFilterGridObj[0].address1,
        address2: this.organizationFilterGridObj[0].address2,
        address3: this.organizationFilterGridObj[0].address3,
        countryId: this.organizationFilterGridObj[0].countryId,
        stateId: this.organizationFilterGridObj[0].stateId,
        districtId: this.organizationFilterGridObj[0].districtId,
        talukId: this.organizationFilterGridObj[0].talukId,
        zipCode: this.organizationFilterGridObj[0].zipCode,
        phoneNo: this.organizationFilterGridObj[0].phoneNo,
        mobileNo: this.organizationFilterGridObj[0].mobileNo,
        conferenceNo: this.organizationFilterGridObj[0].conferenceNo,
        faxNo: this.organizationFilterGridObj[0].faxNo,
        email: this.organizationFilterGridObj[0].email,
        gstNo: this.organizationFilterGridObj[0].gstNo,
        panNo: this.organizationFilterGridObj[0].panNo,
        sacCode: this.organizationFilterGridObj[0].sacCode

      })

    });

  }
  getAddressDetails(e) {
    // zipcode = 625203;
    console.log(e.target.value);
    this.addressService.getAddressByIDzipCode(e.target.value)
      .subscribe(addressObj => {
        this.addressObj = addressObj;

      });


  }

  getAllCountries() {
    this.addressService.getAllCountries()
      .subscribe(a => {
        this.countryObj = a;
        //console.log(countryObj);
      });
      let c = this.organizationForm.get('organizationFormAction.countryId').value;
      this.getAllStates(c);
  }

  change_country_fn() {
    let a = this.organizationForm.get('organizationFormAction.countryId').value;
    this.getAllStates(a);

  }

  getAllStates(a) {
    this.addressService.getAllStates(a)
      .subscribe(b => {
        this.stateObj = b;

      });


  }

  getAllDistricts(a) {
    this.addressService.getAllDistricts(a)
      .subscribe(districtObj => {
        this.districtObj = districtObj;
      });


  }
  getAllTaluk(a) {
    this.addressService.getAllTaluk(a)
      .subscribe(a => {
        this.talukObj = a;
      });


  }
  change_state_fn() {
    let a = this.organizationForm.get('organizationFormAction.stateId').value;
console.log(a);
    this.getAllDistricts(a);
  }


  change_district_fn() {
    let a = this.organizationForm.get('organizationFormAction.districtId').value;

    this.getAllTaluk(a);
  }

  

  onBtnSaveOrganization() {
    this.organizationForm.get('organizationFormAction').markAllAsTouched();
    if (this.organizationForm.get('organizationFormAction').valid) {
      if (this.createBtn) {
        console.log("create");
        this.organizationForm.get('organizationFormAction').patchValue({
          organisationId: '0'
        });
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('noOfDays', new FormControl(1));
        this.organizationFormAction.addControl('isActive', new FormControl(1));
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('createdOn', new FormControl(new Date()));
      }else{
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('noOfDays', new FormControl(1));
        this.organizationFormAction.addControl('isActive', new FormControl(1));
        this.organizationFormAction.addControl('createdBy', new FormControl(1));
        this.organizationFormAction.addControl('createdOn', new FormControl(new Date()));
      }

      let a = this.organizationForm.get('organizationFormAction').value;
      console.log(a)
      this.organizationService.createOrganization(a).subscribe(a => {

        this.getOrganizationGridDetails();
      });
      this.onBtnClearAction();
    }
  }

  onBtnClearAction() {
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.actionHeading = 'Add New - Organization';

    this.organizationForm = this.fb.group({
      organizationFormAction: this.fb.group({

        organisationId: '',
        shortName: '',
        organisationName: '',
        address1: '',
        address2: '',
        address3: '',
        countryId: '',
        stateId: '',
        districtId: '',
        talukId: '',
        zipCode: '',
        phoneNo: '',
        mobileNo: '',
        conferenceNo: '',
        faxNo: '',
        email: ['' , [Validators.email]],
        gstNo: '',
        panNo: '',
        sacCode: '',

      })

    });

  }

  cfn(a) {
    console.log(a);
  }


}
