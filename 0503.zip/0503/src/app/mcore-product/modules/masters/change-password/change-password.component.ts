import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MustMatch } from 'src/app/mcore-product/mcore-shared/mcore-helpers/must-matchvalidator';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  account: FormGroup;
  submitted1: boolean
  display: string;
  constructor(private fb:FormBuilder, private user: UserService) { }


  ngOnInit() {

    this.account = this.fb.group({

    OldPassword  :['',[Validators.required]],
    NewPassword :['',[Validators.required, Validators.pattern('(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$')]] ,    
    ConfirmPassword :['',[Validators.required]]

     },
     {
      validator: MustMatch('NewPassword', 'ConfirmPassword')
  } )
  }

  onsubmit()
  {
    console.log(this.account.value);
    this.submitted1=true
    if(this.account.value)
    {     this.user.InsertUserAndEmployeeDetails(this.account.value)
      .subscribe(result => {
        console.log(result)
   
      });
      console.log(this.account.value);
      this.openModalDialog()
    }
  }
  

  get am() { return this.account.controls; }
  
  get passwordError() {

    if (this.account.controls['NewPassword'].hasError('required')) {
      return 'Please enter the Password';
    } 
    else if (this.account.controls['NewPassword'].hasError('pattern')) {
        return 'Password must contain Minimum 8 Characters,Minimum 1 Alphabet,Minimum 1 Numeric,Minimum 1 Special Character and No Spaces';
      }
    }

    get confirmpasswordError() {

      if (this.account.controls['ConfirmPassword'].hasError('required')) {
        return 'Please confirm  the Password';
      } 
   else if (this.account.controls['ConfirmPassword'].hasError('mustMatch')) {
          return ' confirm password must match password';
        }
      }

      openModalDialog() {
        this.display = 'block'; //Set block css
        this.submitted1 = false
        this.account.reset()
    
    
      }
    
      closeModalDialog() {
        this.display = 'none'; //set none css after close dialog
      }


}
