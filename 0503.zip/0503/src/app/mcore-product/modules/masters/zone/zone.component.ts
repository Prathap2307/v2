import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';

@Component({
  selector: 'app-zone',
  templateUrl: './zone.component.html',
  styleUrls: ['./zone.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class ZoneComponent implements OnInit {
  ZoneForm: FormGroup;
  data_v =
    [{
      id: "1",
      Description: "xyz",
      // ParentZoneID: "1",
      WorkingDate: this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd'),
      // WorkingDate: new Date().toISOString().split('T')[0],
      ShortName: "company",
      Address1: "malad",
      Address2: "mumbai",
      Address3: "maharashtra",
      CountryID: 1,
      StateID: 1,
      DistrictID: 2,
      TalukID: 2,
      ZipCode: "400068",
      PhoneNo: "9852563569",
      MobileNo: "9652563569",
      Email: "lic@gmail.com",
      ZonalID: 12,
    }]



  saveBtnMode: boolean = true;
  ZoneHeading: string;
  textSaveBtn: string;
  ZoneFilteredObj: any;
  submitted: boolean;
  Taluka: any[];
  District: any[];
  state: any[];
  country: any[];
  SearchZForm: FormGroup;
  display: string = "none";
  view: boolean;
  allzone: any[];
  config: { itemsPerPage: number; currentPage: number; totalItems: number; };
  id: any;
  transact: string;
  transaction: string;
  region: any;



  constructor(private datePipe: DatePipe, private BranchService: BranchService, private fb: FormBuilder, ) { }

  ngOnInit() {
    this.getallbranches()
    this.GetAllcountries()
    this.GetAllregion()
    this.ZoneHeading = 'Add New - Zone';
    this.textSaveBtn = 'Save';
    this.formInit()
    this.SearchZForm = this.fb.group({
      PageTypeID: ['1'],
      Description: [''],
      ShortName: [''],

    })

  }
  get f() { return this.ZoneForm.controls; }
  formInit() {
    this.ZoneForm = this.fb.group({
      Description: ['', Validators.required],
      WorkingDate: ['', Validators.required],
      ShortName: ['', [Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
      Address1: ['', Validators.required],
      Address2: ['',],
      Address3: ['',],
      CountryID: ['', Validators.required],
      StateID: ['', Validators.required],
      DistrictID: ['', Validators.required],
      TalukID: ['',],
      ZipCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
      PhoneNo: ['',],
      MobileNo: ['', Validators.pattern("[0-9 -()+]+$")],
      Email: ['', [Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
      RegionalID: [''],
    })
  }

  onBtnSaveClick() {
    this.ZoneForm.value["CreatedBy"] = 1
    this.ZoneForm.value["CreatedOn"] = null
    this.ZoneForm.value["OrganisationID"] = 1
    this.ZoneForm.value["IsActive"] = 1
    this.ZoneForm.value["PageTypeID"] = 1
    // this.ZoneForm.value["RegionalID"] = 1
    this.ZoneForm.value["FaxNo"] = null
    if (this.textSaveBtn === 'Update') {
      this.ZoneForm.value["BranchID"] = this.id
    }
    this.submitted = true;
    console.log(this.ZoneForm.value)
    if (this.ZoneForm.valid) {
      this.BranchService.add(this.ZoneForm.value)
        .subscribe(result => {
          console.log(result)
          if (result.data == 0) {
            this.transaction = "Created"
          }
          else {
            this.transaction = "Updated"
          }
          this.openModalDialog()
        });
    }
  }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }
  getallbranches() {
    let branch = {
      "OrganisationID": 1,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 1
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allzone = result.data
        if (this.allzone && this.allzone.length > 0) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allzone.length
          }
        }
      });
  }
  Search() {
    console.log(this.SearchZForm.value)
    this.SearchZForm.value["PageTypeID"]=1
    this.BranchService.GetAllBranches(this.SearchZForm.value)
      .subscribe(result => {
        console.log(result)
        this.allzone = result.data
        if (this.allzone) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allzone.length
          }
        }
      });
  }
  clearSearch() {
    this.SearchZForm.value["Description"] = " "
    this.SearchZForm.value["ShortName"] = " "
    this.SearchZForm.reset();
    this.getallbranches()
  }
  onChange(value, id) {
    console.log(value)
    let activate_d = {
      "OrganisationID": 1,
      "BranchID": id,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 1
    }
    if (value.checked === true) {
      activate_d["isActive"] = 1
      console.log(1);
    } else {
      activate_d["isActive"] = 0
      console.log(0);
    }
  }
  getBranchById(a) {
    this.BranchService.get_branchByid(a)
      .subscribe(result => {
        console.log(result)
        this.ZoneFilteredObj = result.data
        console.log(this.ZoneFilteredObj)
        if (this.ZoneFilteredObj) {
          this.GetAllStates(this.ZoneFilteredObj.countryID)
          this.GetAllDistricts(this.ZoneFilteredObj.stateID)
          this.GetTaluk(this.ZoneFilteredObj.districtID)
          console.log(this.ZoneForm.value)
          this.ZoneForm = this.fb.group({
            BranchID: [{ value: this.ZoneFilteredObj.branchId, disabled: false }],
            ParentBranchID: { value: this.ZoneFilteredObj.parentBranch, disabled: false },
            Description: [{ value: this.ZoneFilteredObj.branchName, disabled: false }, Validators.required],
            WorkingDate: [{ value: this.ZoneFilteredObj.workingDate, disabled: false }, Validators.required],
            ShortName: [{ value: this.ZoneFilteredObj.shortName, disabled: false },[Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
            Address1: [{ value: this.ZoneFilteredObj.address1, disabled: false }, Validators.required],
            Address2: [{ value: this.ZoneFilteredObj.address2, disabled: false }],
            Address3: [{ value: this.ZoneFilteredObj.address3, disabled: false }],
            CountryID: [{ value: this.ZoneFilteredObj.countryID, disabled: false },Validators.required],
            StateID: [{ value: this.ZoneFilteredObj.stateID, disabled: false },Validators.required],
            DistrictID: [{ value: this.ZoneFilteredObj.districtID, disabled: false },Validators.required],
            TalukID: { value: this.ZoneFilteredObj.talukID, disabled: false },
            ZipCode: [{ value: this.ZoneFilteredObj.zipCode, disabled: false }, [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
            PhoneNo: [{ value: this.ZoneFilteredObj.phoneNo, disabled: false }],
            MobileNo: [{ value: this.ZoneFilteredObj.mobileNo, disabled: false }],
            Email: [{ value: this.ZoneFilteredObj.email, disabled: false },[Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
            ZonalID: { value: this.ZoneFilteredObj.zoneID, disabled: false },
            DivisionID: { value: this.ZoneFilteredObj.divisionID, disabled: false },     
            RegionalID: { value: this.ZoneFilteredObj.regionalID, disabled: false },       
            
          })
        }
      })
  }

  btngEdit_Click(a) {
    console.log(a);
    this.ZoneHeading = 'Edit - Zone';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update'
    this.view = false
    this.id = a
    this.getBranchById(a)
  }
  btngView_Click(a) {
    this.view = true
    this.ZoneHeading = 'View - Zone';
    this.saveBtnMode = false;
    this.getBranchById(a)
  }

  cancel() {
    this.ZoneForm.reset()
    this.formInit()
    console.log(this.submitted)
    this.submitted = false
    this.ZoneHeading = 'Add New - Zone';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  Select_country(event: any) {
    console.log(event.target.value)

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)

    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)

    this.GetTaluk(event.target.value);
  }

  GetAllregion() {
    this.BranchService.getAllregion()
      .subscribe(result => {
        console.log(result)
        this.region = result.data

        console.log(this.country)
      });
  }
  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }
  pinValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  shortnumValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 3) {
        console.log(l)
      }
      else {
        event.preventDefault();
      }
    }
  }
  mobValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  allowNumberFn(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      // State code
      if (l <= 1) {
        console.log(l)

        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN alphabets
      else if (l >= 2 && l <= 6) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN numeric
      else if (l > 6 && l <= 10) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      } // PAN alphabet
      else if (l >= 11 && l < 12) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 12 && l < 13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // alphabet
      else if (l >= 13 && l < 14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 14 && l < 15) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 15) {

        event.preventDefault();

      }

    }
  }
  get MobNoError() {
    if (this.ZoneForm.controls['MobileNo'].hasError('required')) {
      return 'Mobile Number is required';
    } else if (this.ZoneForm.controls['MobileNo'].hasError('pattern')) {
      return 'Please enter valid Mobile Number';
    } else if (this.ZoneForm.controls['MobileNo'].hasError('minlength')) {
      return 'Please enter valid 10 digits Mobile Number';
    }
  }
  get ShortNameError() {
    if (this.ZoneForm.controls['ShortName'].hasError('required')) {
      return 'Please enter the Zone Code.';
    } else if (this.ZoneForm.controls['ShortName'].hasError('pattern')) {
      return 'Zone Code should not be less 4 digits.';
    }
  }
  get EmailError() {
    if (this.ZoneForm.controls['Email'].hasError('required')) {
      return 'Please enter the E-Mail ID.';
    } else if (this.ZoneForm.controls['Email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }
  openModalDialog() {
    this.display = 'block'; //Set block css
    console.log(this.display)
    this.submitted = false
    this.ZoneForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.cancel()
    this.getallbranches()
  }




}
