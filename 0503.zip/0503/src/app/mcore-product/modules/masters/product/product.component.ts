import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Product, ProductCategory } from 'src/app/mcore-product/mcore-shared/mcore-entity/product';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { TooltipPosition } from '@angular/material/tooltip';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  // Product Variable Declaration
  fieldDisable: boolean;
  Categoryname: string;
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  productObj: Product[];
  ProductCategoryObj: ProductCategory[];
  productFilteredObj: Product[] = [];
  productColumns: string[] = ['View', 'Edit', 'Delete', 'planName', 'shortName'];
  dropDownMode: Boolean;
  productForm: FormGroup;
  productFormAction: FormGroup;
  productHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  productSource = new MatTableDataSource<Product>(this.productObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.productSource.paginator = this.paginator;
  }
  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private changeDetectorRefs: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.productHeading = 'Add New - Product';
    this.btnSaveText = 'Save';
    this.getAllCategory(1);
    this.getProductDetails();
    this.ValidateProductDataForm();
    this.ngAfterViewInit();
  }
  getAllCategory(lobId: number) {
    this.productService.GetAllCategory(lobId).subscribe(categoryNameVal => this.ProductCategoryObj = categoryNameVal)
  }
  // Search Events Product
  onBtnSearchProductClick() {
    this.getProductBySearch();
  }
  onBtnSearchClearProductClick() {
    this.productForm.reset();
    this.getProductDetails();
  }
  // Save Events Product
  onBtnSaveProductClick() {
    this.SaveProductDetailData();
  }
  onBtnClearProductClick() {
    this.ClearProductDetails();
  }
  // Grid View Button Events
  btngvView_Click(a) {
    this.productHeading = 'View - Product';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.productFilteredObj = this.productObj.filter((unit) => unit.planId == a);
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: this.productFilteredObj[0].planId,
        planName: this.productFilteredObj[0].planName,
        shortName: this.productFilteredObj[0].shortName,
        category: this.productFilteredObj[0].category,
        productTypeId: this.productFilteredObj[0].productTypeId,
        description: this.productFilteredObj[0].description,
        createdBy: this.productFilteredObj[0].createdBy,
        createdOn: this.productFilteredObj[0].createdOn,
        isActive: this.productFilteredObj[0].isActive,
      })
    });
  }
  // Grid Edit Button Events
  btngvEdit_Click(a) {
    this.productHeading = 'Edit - Product';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.productFilteredObj = this.productObj.filter((unit) => unit.planId == a);
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: this.productFilteredObj[0].planId,
        planName: this.productFilteredObj[0].planName,
        shortName: this.productFilteredObj[0].shortName,
        category: this.productFilteredObj[0].category,
        productTypeId: this.productFilteredObj[0].productTypeId,
        description: this.productFilteredObj[0].description,
        createdBy: this.productFilteredObj[0].createdBy,
        createdOn: this.productFilteredObj[0].createdOn,
        isActive: this.productFilteredObj[0].isActive,
      })
    });
  }
  // Grid Delete Button Events
  btngvDelete_Click(a) {
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: { value: a, disabled: false },
        planName: { value: '', disabled: false },
        shortName: { value: '', disabled: false },
        category: { value: '', disabled: false },
        productTypeId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        createdBy: 1,
        createdOn: new Date(),
        deletedBy: 1,
        deletedOn: new Date(),
        isActive: 0,
      })
    });
    let v = this.productForm.get('productFormAction').value;
    console.log(v);
    this.productService.deleteProduct(v).subscribe(result => { console.log(result); this.getProductDetails() });
  }
  // Methods
  ValidateProductDataForm() {
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        organizationId: [''],
        lobId: [''],
        planId: [''],
        planName:
          [
            '',
            [Validators.required]
          ],
        shortName:
          [
            '',
            [Validators.required]
          ],
        category: [''],
        productTypeId: ['',
          [Validators.required]],
        description: [''],
        createdBy: [1],
        createdOn: [new Date()],
        isActive: [1],
      })
    });
  }
  SaveProductDetailData() {
    this.productForm.get('productFormAction').patchValue({
      lobId: '1',
      createdBy: '1',
      createdOn: new Date(),
      isActive: '1',
    });
    this.productForm.controls.productFormAction.markAllAsTouched();
    if (this.productForm.controls.productFormAction.valid) {
      let a = this.productForm.controls.productFormAction.value;
      this.productService.addProduct(a).subscribe(result => { this.getProductDetails() });
      //this.productForm.controls.productFormAction.reset();
      this.ClearProductDetails();
    }
  }
  ClearProductDetails() {
    this.dropDownMode = false;
    this.productForm.controls.productFormAction.reset();
    this.productHeading = 'Add New - Product';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.productForm = this.fb.group({
      searchPlanName: [''],
      productFormAction: this.fb.group({
        planId: { value: '', disabled: false },
        planName: { value: '', disabled: false },
        shortName: { value: '', disabled: false },
        category: { value: '', disabled: false },
        productTypeId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
        isActive: { value: '', disabled: false },
      })
    });
  }
  // Get Product Details
  getProductDetails(): void {
    this.productService.getProductDetails().subscribe(
      productObj => {
        this.productSource = new MatTableDataSource<Product>(this.productObj);
        this.productSource.data = this.productObj = productObj;
        this.productSource.paginator = this.paginator;
      })
  }
  // Search Section
  getProductBySearch(): void {
    if (this.productForm.controls.searchPlanName.valid) {
      let searchValue = this.productForm.controls.searchPlanName.value;
      console.log(searchValue);
      this.productService.getProductBySearch(searchValue).subscribe(
        productObj => {
          this.productSource = new MatTableDataSource<Product>(this.productObj);
          this.productSource.data = this.productObj = productObj;
          this.productSource.paginator = this.paginator;
        });
      // val => { this.productObj = val });
    }
    else {
    }
  }
}
