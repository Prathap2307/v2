import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
// import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/mcore-product/mcore-shared/mcore-communication/format_datepicker';
import { DatePipe } from '@angular/common';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    {provide: MAT_DATE_LOCALE, useValue: 'en-gb'},

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],

})
export class BranchComponent implements OnInit {
  BranchForm: FormGroup;
  data_v =
    [{
      OrganisationID: 1,
      BranchID: 55,
      ShortName: "123",
      Description: "bengluru",
      ParentBranchID: "1",
      CreatedBy: 1,
      CreatedOn: null,
      IsActive: 1,
      WorkingDate: this.datePipe.transform(new Date().toDateString(), 'yyyy-MM-dd'),
      Address1: "karnataka",
      Address2: "bengluru",
      Address3: "india",
      CountryID: 1,
      StateID: 1,
      DistrictID: 2,
      TalukID: 2,
      ZipCode: "400068",
      PhoneNo: "9852563569",
      MobileNo: "9652563569",
      Email: "lic@gmail.com",
      ZonalID: 12,
      DivisionID: 13,
      GSTNo: "22abcde1234p2z5",
      PanNo: "abcde1234p",
      LUTNo: "5234534",
      PageTypeID: 1,
      RegionalID: 1,
      FaxNo: null,
    },

    ]

  saveBtnMode: boolean = true;
  branchHeading: string;
  textSaveBtn: string;
  departmentFilteredObj: any;
  submitted: boolean = false;
  Taluka: any[];
  District: any[];
  state: any[];
  country: any[];
  branchFilteredObj: any;
  SearchBForm: FormGroup;
  display: string = 'none';
  allbranch: any[];
  view: boolean;
  dBranch: any[];
  pBranch: any[];
  config: { itemsPerPage: number; currentPage: number; totalItems: any; };
  zBranch: any;
  temp: any[];
  id: any;
  transaction: string;
  error: boolean;
  success: boolean;
  errormsg: any;
  allDivision: any;


  constructor(private datePipe: DatePipe, private BranchService: BranchService, private fb: FormBuilder, ) {

  }

  ngOnInit() {
    this.GetAllcountries()
    this.getallbranches()
    this.Get_zBranch(1)
    this.Get_pBranch()
    //this.Get_dBranch(1)
    this.formInit()
    this.SearchBForm = this.fb.group({
      Description: [''],
      ShortName: [''],
      PageTypeID: ['3']
    })

    this.branchHeading = 'Add New - Branch';
    this.textSaveBtn = 'Save';

  }
  formInit(){
    this.BranchForm = this.fb.group({
      ShortName: ['', [Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
      branchName: ['', [Validators.required]],
      WorkingDate: ['', Validators.required],
      ParentBranchID: ['5',],
      CreatedBy: [1,],
      CreatedOn: [null,],
      IsActive: [1,],
      Address1: ['', Validators.required],
      Address2: ['',],
      Address3: [null,],
      CountryID: ['', Validators.required],
      StateID: ['', Validators.required],
      DistrictID: ['', Validators.required],
      TalukID: ['',],
      ZipCode: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
      PhoneNo: ['',],
      MobileNo: ['', ],
      // ConferenceNo: ['null', ],
      Email: ['', [Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
      DivisionID: [0,],
      ZonalID: [0,],
      GSTNo: ['', [Validators.required, Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
      // PanNo: [{ value: 'ABCDE1234P', disabled: true }, Validators.required],
      PanNo: ['ABCDE1234P', Validators.required],
      LUTNo: ['', Validators.required],

    })
  }
  get f() { return this.BranchForm.controls; }
  //  convert(str) {
  //   var date = new Date(str),
  //     mnth = ("0" + (date.getMonth() + 1)).slice(-2),
  //     day = ("0" + date.getDate()).slice(-2);
  //   return [ day, mnth,date.getFullYear()].join("/");
  // }
  //   transformDate() {
  //     this.currentDate = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd');  // 2018-11-23
  // }
  pageChanged(event: number) {
    this.config.currentPage = event;
  }

  onBtnSaveClick() {
    // console.log(new Date().toDateString())
    // console.log(new Date().toISOString())
    // console.log(new Date().toISOString().split('T')[0])
    // console.log( this.BranchForm.value["WorkingDate"].toISOString().split('T')[0])
    this.BranchForm.value["CreatedBy"] = 1
    this.BranchForm.value["CreatedOn"] = null
    this.BranchForm.value["OrganisationID"] = 1
    this.BranchForm.value["IsActive"] = 1
    this.BranchForm.value["PageTypeID"] = 3
    this.BranchForm.value["RegionalID"] = 1
    this.BranchForm.value["BranchID"] = 0
    this.BranchForm.value["FaxNo"] = null
    if (this.id && this.textSaveBtn === 'Update') {
      console.log(this.id)
      this.BranchForm.value["BranchID"] =this.id
    }
    this.submitted = true;
    console.log(this.BranchForm.value)

    if (this.BranchForm.valid) {
      this.BranchService.add(this.BranchForm.value)
        .subscribe(result => {
          this.success=true
          console.log(result)
          if(result.data==0){
            this.transaction="Created"
          }
          else{
            this.transaction="Updated"
          }
          this.openModalDialog()
        },
        error => {
          console.log(error)
          this.error = true;
          this.errormsg=error
          this.openModalDialog()      
      });
    }

  }
  getallbranches() {
    let branch = {
      "OrganisationID": 1,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
        if (this.allbranch) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allbranch.length
          }
        }
      },error => {
        console.log(error)
        this.error = true;
        this.errormsg=error
     
    });
  }
  Search() {
    console.log(this.SearchBForm.value)
    this.SearchBForm.value["PageTypeID"]=3
    this.BranchService.GetAllBranches(this.SearchBForm.value)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data
        if (this.allbranch) {
          this.config = {
            itemsPerPage: 10,
            currentPage: 1,
            totalItems: this.allbranch.length
          }
        }
      });
  }

  getBranchById(a) {
    this.BranchService.get_branchByid(a)
      .subscribe(result => {
        console.log(result)
        this.branchFilteredObj = result.data
        console.log(this.branchFilteredObj)
        if (this.branchFilteredObj) {
          this.GetAllStates(this.branchFilteredObj.countryID)
          this.GetAllDistricts(this.branchFilteredObj.stateID)
          this.GetTaluk(this.branchFilteredObj.districtID)
          console.log(this.BranchForm.value)
          console.log(this.branchFilteredObj.branchName)
          this.BranchForm = this.fb.group({
            BranchID: [{ value: this.branchFilteredObj.branchId, disabled: false }],
            branchName: [{ value: this.branchFilteredObj.branchName, disabled: false }, Validators.required],
            ParentBranchID: [{ value: this.branchFilteredObj.parentBranchId, disabled: false }],
            WorkingDate: [{ value: this.branchFilteredObj.workingDate, disabled: false }, Validators.required],
            ShortName: [{ value: this.branchFilteredObj.shortName, disabled: false },[Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
            Address1: [{ value: this.branchFilteredObj.address1, disabled: false }, Validators.required],
            Address2: [{ value: this.branchFilteredObj.address2, disabled: false }],
            Address3: [{ value: this.branchFilteredObj.address3, disabled: false }],
            CountryID: [{ value: this.branchFilteredObj.countryID, disabled: false },Validators.required],
            StateID: [{ value: this.branchFilteredObj.stateID, disabled: false },Validators.required],
            DistrictID: [{ value: this.branchFilteredObj.districtID, disabled: false },Validators.required],
            TalukID: { value: this.branchFilteredObj.talukID, disabled: false },
            ZipCode: [{ value: this.branchFilteredObj.zipCode, disabled: false }, [Validators.required, Validators.pattern('^[1-9][0-9]{5}$')]],
            PhoneNo: [{ value: this.branchFilteredObj.phoneNo, disabled: false }],
            MobileNo: [{ value: this.branchFilteredObj.mobileNo, disabled: false }],
            Email: [{ value: this.branchFilteredObj.email, disabled: false },[Validators.required, Validators.pattern("[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*")]],
            ZonalID: { value: this.branchFilteredObj.zoneID, disabled: false },
            DivisionID: { value: this.branchFilteredObj.divisionID, disabled: false },
            GSTNo: [{ value: this.branchFilteredObj.gstNo, disabled: false },[Validators.required, Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
            // PanNo: [{ value: this.branchFilteredObj.panNo, disabled: false }, Validators.required],
            PanNo: ['ABCDE1234P', Validators.required],
            LUTNo:[ { value: this.branchFilteredObj.lutNo, disabled: false },Validators.required]

          })
          console.log(this.BranchForm.value)
        }

      })
  }

  btngEdit_Click(a) {
    console.log(a);
    this.branchHeading = 'Edit - Branch';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update'
    this.view = false
    this.id=a
    this.getBranchById(a)
  }
  btngView_Click(a) {
    this.view = true
    this.branchHeading = 'View - Branch';
    this.saveBtnMode = false;
    this.getBranchById(a)
  }

  activate(a) {
   
    this.BranchService.Activate(a)
    .subscribe(result => {
      console.log(result)
      })
      this.getallbranches() 
    console.log(a)

  }

  onChange(value: { checked: boolean; }, id: any) {
    console.log(value)
    if (value.checked === true) {
      console.log(1);
    } else {
      console.log(0);
    }
    this.BranchService.Activate(id)
    .subscribe(result => {
      console.log(result)
      })
      this.getallbranches() 
    console.log(id)
  }

  cancel() {
    this.BranchForm.reset()
    this.formInit()
    console.log(this.submitted)
    this.submitted = false
    this.branchHeading = 'Add New - Branch';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  clearSearch() {
    this.SearchBForm.value["Description"] = " "
    this.SearchBForm.value["ShortName"] = " "
    this.SearchBForm.reset();
    this.getallbranches()
  }
  Select_country(event: any) {
    console.log(event.target.value)

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)

    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)

    this.GetTaluk(event.target.value);
  }


  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }


  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    this.formInit()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.cancel()
    this.getallbranches()
  }
  Select_pBranch(event: any) {
    console.log(event.target.value)

    this.Get_zBranch(event.target.value);
  }
  Select_zBranch(event: any) {
    console.log(event.target.value)

    this.Get_dBranch(event.target.value);
  }



  // Get_pBranch() {
  //   this.BranchService.get_pBranch()
  //     .subscribe(result => {
  //       console.log(result)
  //       this.pBranch = result
  //     });
  // }
  Get_zBranch(ZonalID: any) {
    console.log(ZonalID)
    this.BranchService.get_zBranch(ZonalID)
      .subscribe(result => {
        console.log(result)
        this.zBranch = result.data
      });
  }
  Get_dBranch(DivisionID: any) {
    console.log("DivisionID", DivisionID)
    this.BranchService.get_dBranch(DivisionID)
      .subscribe(result => {
        console.log(result)
        this.dBranch = result.data
      });
  }
  Get_pBranch() {
    console.log("call p branch")
    this.BranchService.get_pBranch()
      .subscribe(result => {
        console.log(result)
        this.pBranch = result.data
      });
  }
  // btngvEdit_Click(a) {


  //   this.departmentFilteredObj = this.departmentObj.filter((unit) => unit.id == a);

  //   this.DepartmentForm = this.fb.group({

  //     SearchDescription: [''],

  //     ActionGroupDepartment: this.fb.group({
  //       id: { value: this.departmentFilteredObj[0].id, disabled: false },
  //       description: { value: this.departmentFilteredObj[0].description, disabled: false },
  //       shortName: { value: this.departmentFilteredObj[0].shortName, disabled: false }

  //     })


  //   });

  //   this.departmentHeading = 'Edit - Department';
  //   this.textSaveBtn = 'Update';
  //   this.saveBtnMode = true;
  // }
  shortnumValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 3) {
        console.log(l)
      }
      else {
        event.preventDefault();
      }
    }
  }
mobValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    var l = a.length;
    if (l >= 0) {
      if (l <= 9) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  CodeValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 3) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else { 
        event.preventDefault();
      }

    }
  }
  pinValidate(event: any) {
    //console.log(event.target.value);
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 5) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }
  GstnValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      // State code
      if (l <= 1) {
        console.log(l)

        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN alphabets
      else if (l >= 2 && l <= 6) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN numeric
      else if (l > 6 && l <= 10) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      } // PAN alphabet
      else if (l >= 11 && l < 12) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 12 && l < 13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // alphabet
      else if (l >= 13 && l < 14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 14 && l < 15) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 15) {

        event.preventDefault();

      }

    }
  }
  get MobNoError() {
    if (this.BranchForm.controls['MobileNo'].hasError('required')) {
      return 'Mobile Number is required';
    } else if (this.BranchForm.controls['MobileNo'].hasError('pattern')) {
      return 'Please enter valid Mobile Number';
    } else if (this.BranchForm.controls['MobileNo'].hasError('minlength')) {
      return 'Please enter valid 10 digits Mobile Number';
    }
  }
  get ShortNameError() {
    if (this.BranchForm.controls['ShortName'].hasError('required')) {
      return 'Please enter the Branch Code.';
    } else if (this.BranchForm.controls['ShortName'].hasError('pattern')) {
      return 'Branch Code should not be less 4 digits.';
    }
  }
  get EmailError() {
    if (this.BranchForm.controls['Email'].hasError('required')) {
      return 'Please enter the E-Mail ID.';
    } else if (this.BranchForm.controls['Email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }
  get GstnError() {
    if (this.BranchForm.controls['GSTNo'].hasError('required')) {
      return 'Please enter the GSTIN .';
    }
    else if (this.BranchForm.controls['GSTNo'].hasError('pattern')) {
      return 'GSTIN should be 15 digits Master.';
    }

    else if ((this.BranchForm.value["PanNo"].length>0)) {
      if (this.BranchForm.value["PanNo"] != this.BranchForm.value["GSTNo"].slice(2, 12).toUpperCase()) {
        console.log(this.BranchForm.value["PanNo"])
        console.log(this.BranchForm.value["GSTNo"].slice(2, 12).toUpperCase())
        return 'PAN Mismatch in GSTIN.';
      }
    }

  }


}

