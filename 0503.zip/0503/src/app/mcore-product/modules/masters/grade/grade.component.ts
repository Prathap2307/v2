import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { GradeService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/grade.service';
import { Grade } from 'src/app/mcore-product/mcore-shared/mcore-entity/grade';

import { Key } from 'protractor';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatPaginatorModule } from '@angular/material/paginator';

@Component({
	selector: 'app-grade',
	templateUrl: './grade.component.html',
	styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit {
	submitted = false;
	gradeForm: FormGroup;

	get gradeFormAction() {
		return this.gradeForm.get('gradeFormAction') as FormGroup;
	  }

	  get gradeFormSearch() {
		return this.gradeForm.get('gradeFormSearch') as FormGroup;
	  }

	gradeObj: Grade[];
	gradeSearchObj: Grade[];
	gradeFilteredObj: Grade[] = [];

	gradeColumns: string[] = ['View', 'Edit', 'Delete', 'description'];
	gradeHeading: string = '';
	textSaveBtn: string = '';
	saveBtnMode: boolean = true;

	createBtn: boolean;

	constructor(private gradeService: GradeService, private fb: FormBuilder, private changeDetectorRefs: ChangeDetectorRef) { }

	dataSource = new MatTableDataSource<Grade>(this.gradeObj);

	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

	fieldDisable: Boolean;

	ngOnInit() {
		this.createBtn = true;
		this.dataSource = new MatTableDataSource<Grade>(this.gradeObj);
		this.gradeHeading = 'Add New - Grade';
		this.textSaveBtn = 'Save';
		

		this.gradeForm = this.fb.group({

			gradeFormSearch: this.fb.group({
				searchGrade: ['']
			}),
			gradeFormAction: this.fb.group({
				gradeId: [''],
				description:
					[
						'',
						[Validators.required]
					]
			
			})
		});

		this.getGradeDetails();
	}

	getGradeDetails(): void {
		let d = this.gradeFormSearch.get('searchGrade').value;
		// console.log(d);
		if(d == ''){
			d = '';
		}
		let obj = {
			"organisationId": 1,
			"description": d
		}

		this.gradeService.getGradeDetails(obj)
			.subscribe(a => {
				this.dataSource = new MatTableDataSource<Grade>(this.gradeObj);
				this.dataSource.data = this.gradeObj = a;
				this.dataSource.paginator = this.paginator;
				this.gradeSearchObj = a;
			});

	}


	btngvView_Click(a) {
		this.fieldDisable = true;
		this.gradeFilteredObj = this.gradeObj.filter((unit) => unit.gradeId == a);

	
			this.gradeFormAction.patchValue({
				gradeId: this.gradeFilteredObj[0].gradeId,
				description: this.gradeFilteredObj[0].description
			})

		this.gradeHeading = 'View - Grade';
		this.saveBtnMode = false;
	}

	btngvEdit_Click(a) {
		this.fieldDisable = false;
		this.createBtn = false;
		this.gradeFilteredObj = this.gradeObj.filter((unit) => unit.gradeId == a);


		 this.gradeFormAction.patchValue({
			gradeId: this.gradeFilteredObj[0].gradeId,
			description: this.gradeFilteredObj[0].description
		});
	

		this.gradeHeading = 'Edit - Grade';
		this.textSaveBtn = 'Update';
		this.saveBtnMode = true;
	}


	btngvDelete_Click(a) {
		this.gradeFormAction.addControl('deletedOn', new FormControl(new Date()));
		this.gradeFormAction.get('gradeId').patchValue(a);

	

		let c = this.gradeForm.get('gradeFormAction').value;

		this.gradeService
			.deleteGrade(c)
			.subscribe(result => { this.getGradeDetails() });
	
	}

	onBtnSearchGrade(){
		this.getGradeDetails();
	}

	onBtnSaveGrade() {
		if (this.createBtn) {
			this.gradeFormAction.get('gradeId').patchValue(0);
			this.gradeFormAction.addControl('organisationId', new FormControl(1));
			this.gradeFormAction.addControl('createdBy', new FormControl(1));
			this.gradeFormAction.addControl('createdOn', new FormControl(new Date()));
			this.gradeFormAction.addControl('isActive', new FormControl(1));
		}else{

			this.gradeFormAction.addControl('createdOn', new FormControl(new Date()));
		}
	

		this.gradeForm.controls.gradeFormAction.markAllAsTouched();
		if (this.gradeForm.controls.gradeFormAction.valid) {
			let a = this.gradeForm.controls.gradeFormAction.value;

			this.gradeService.addGrade(a)
				.subscribe(result => { this.getGradeDetails() });

			this.onBtnClearGrade();
			this.createBtn = true;
		}
	}
	onBtnSearchClearGrade() {
		this.gradeFormSearch.get('searchGrade').patchValue('');
		this.getGradeDetails();
	}
	onBtnClearGrade() {
		this.gradeHeading = 'Add New - Grade';
		this.textSaveBtn = 'Save';
		this.createBtn = true;
		this.fieldDisable = false;
		this.saveBtnMode = true;
	
			this.gradeForm = this.fb.group({
				gradeFormSearch: this.fb.group({
					searchGrade: ['']
				}),
				gradeFormAction: this.fb.group({
					gradeId: '',
					description:''
				
				})
			});
	
		
	}
}
