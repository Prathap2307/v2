import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { FchannelService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/fchannel.service';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
@Component({
  selector: 'app-fsub-channel',
  templateUrl: './fsub-channel.component.html',
  styleUrls: ['./fsub-channel.component.css']
})
export class FsubChannelComponent implements OnInit {
  SubChannelForm: FormGroup;
  submitted: boolean;
  SubchannelHeading: string = 'Add New - Sub Channel';
  saveBtnMode: boolean = true;
  textSaveBtn: string = 'Save';
  SearchSubChannel: FormGroup;
  checked = true
  view: boolean = false;
  isEntity: boolean = false;
  isblanket: boolean = false;
  isCriterion: boolean = true;
  isDeposit: boolean = false;
  display: string = 'none';
  branch = ["kolkata", "mumbai"]
  BRANCH = [

    { branchID: '23', Name: 'Bangalore' },
    { branchID: '3', Name: 'Kolkata' },
    { branchID: '4', Name: 'Mumbai' }
  ]

  dummyObj =
    [

      { Id: '2', Name: 'Agent' },

    ]

  private defaultSelected = 0
  private selection: number
  subChannelFilteredObj: any;
  allchannel: any;
  allsubchannel: any;
  id: any;
  allbranch: any;
  success: boolean;
  transaction: string;
  exist: boolean;
  present: any;
  fail: boolean;

  constructor(private fb: FormBuilder, private BranchService: BranchService, private FchannelService: FchannelService, ) { }

  ngOnInit() {
    this.getallchannel()
    this.getallsubchannel()
    this.getallbranches()
    this.SearchSubChannel = this.fb.group({
      ChannelName: ['',],
      ChannelCode: ['',],
    })

    this.SubchannnelformFunction()

  }


  SubchannnelformFunction() {
    this.SubChannelForm = this.fb.group({
      SubChannelID: [''],
      ChannelName: ['', Validators.required],
      ChannelCode: ['', Validators.required],
      MainChannelID: ['', Validators.required],
      IsPhysicalEntry: [0],
      IsCDAccount: [0],
      branchid: [''],
      BranchID: this.fb.array([]),
      PolicyHolderCode: [''],
      TriggerLimit: [''],
      IsBlanket: ['1'],
      CreatedBy: ['',],
      CreatedOn: ['',]

    })

    this.SubChannelForm.get('IsPhysicalEntry').valueChanges.subscribe((data: string) => {
      console.log(data)
      this.onchangeIsPhysicalentry(data);

    });

    this.SubChannelForm.get('IsCDAccount').valueChanges.subscribe((data: string) => {
      this.onchangeISCDACCOUNT(data);

    });


  }

  onchangeIsPhysicalentry(selected: any) {
    this.isDeposit = false

    console.log(selected);
    const Branchid = this.SubChannelForm.get('branchid')


    if (selected === 1) {
      this.submitted = false

      Branchid.setValidators(Validators.required);

      this.show();
    }
    else {
      Branchid.clearValidators();

      this.hide()
    }
    Branchid.updateValueAndValidity();



  }


  onchangeISCDACCOUNT(selected: any) {



    const TRIGGERLIMIT = this.SubChannelForm.get('TriggerLimit')
    const POLICYHOLDERCODE = this.SubChannelForm.get('PolicyHolderCode')
    // const ISBLANKET =this.SubChannelForm.get('ISBLANKET')

    if (selected === 1) {

      this.submitted = false

      TRIGGERLIMIT.setValidators(Validators.required);
      POLICYHOLDERCODE.setValidators([Validators.required, Validators.minLength(4), Validators.maxLength(4)]);

      this.showDeposit()
    }
    else {

      POLICYHOLDERCODE.clearValidators();
      TRIGGERLIMIT.clearValidators();

      this.hideDeposit()
    }

    TRIGGERLIMIT.updateValueAndValidity();
    POLICYHOLDERCODE.updateValueAndValidity();


  }

  get f() { return this.SubChannelForm.controls; }
  // IsSubChannelExist(data: any) {
  //   this.FchannelService.IsSubChannelExist(this.SubChannelForm.value)
  //     .subscribe(result => {
  //       console.log(result)
  //     });
  // }
  IsSubChannelExist(data: any) {
    this.FchannelService.IsSubChannelExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === "NOTEXIST") {
          this.FchannelService.addfsubchannel(this.SubChannelForm.value)
            .subscribe(result => {
              console.log(result)
              if(result.data.SubChannelId>0){
                this.success = true
                if (this.textSaveBtn === 'Save') {
                  this.transaction = "Created"
                }
                else {
                  this.transaction = "Updated"
                }
                this.getallsubchannel()
                this.openModalDialog()
              }
              else{
                this.fail=true
              }
              this.cancel()
            });
        }
        else {
          this.exist = true
          this.present = result.data
          this.openModalDialog()
        }

      });
  }
  onCheckChange(event: any) {
    console.log(event)
    console.log(event.source.value)
    const formArray: FormArray = this.SubChannelForm.get('BranchID') as FormArray;
    /* Selected */
    if (event.checked) {
      // Add a new control in the arrayForm
      formArray.push(new FormControl(event.source.value));
    }
    /* unselected */
    else {
      // find the unselected element
      let i: number = 0;

      formArray.controls.forEach((ctrl: FormControl) => {
        if (ctrl.value == event.source.value) {
          // Remove the unselected element from the arrayForm
          formArray.removeAt(i);
          return;
        }

        i++;
      });
    }
  }
  onBtnSaveClick() {

    this.submitted = true


    console.log(this.SubChannelForm.controls)
    if (this.SubChannelForm.valid) {

      console.log(this.SubChannelForm.value)

      this.SubChannelForm.value['CategroyID'] = 1
      this.SubChannelForm.value['CreatedBy'] = 1
      this.IsSubChannelExist(this.SubChannelForm.value)
    }

  }
  getallchannel() {
    this.FchannelService.GetAllMainChannel()
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        console.log(this.allchannel)
      });
  }
  search() {
    this.FchannelService.GetAllSubChannel(this.SearchSubChannel.value)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        console.log(this.allsubchannel)
      });
  }
  getallsubchannel() {
    let abc = {
      "ChannelName": "",
      "ChannelCode": ""
    }

    this.FchannelService.GetAllSubChannel(abc)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        console.log(this.allsubchannel)
      });
  }
  getallbranches() {
    let branch = {
      "OrganisationID": 1,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data

      }
      );
  }
  btngEdit_Click(a) {

    this.SubchannelHeading = 'Edit - Sub Channel';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.id = a
    this.getSubChannelById(a)
  }
  btngView_Click(a) {
    this.SubchannelHeading = 'View - Sub Channel';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.getSubChannelById(a)
  }
  cancel() {
    this.SubChannelForm.reset()
    this.SubchannnelformFunction()
    console.log(this.submitted)
    this.submitted = false
    this.SubchannelHeading = 'Add New - Sub Channel';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }

  }
  deleteSubchannel(id) {
    console.log(id)
    this.FchannelService.DeleteSubChannel(id)
      .subscribe(result => {
        console.log(result)
        this.getallsubchannel()
      });
  }

  getSubChannelById(a) {
    this.FchannelService.GetSubChannelById(a)
      .subscribe(result => {
        console.log(result)
        this.subChannelFilteredObj = result.data[0]
        console.log(this.subChannelFilteredObj)
        if (this.subChannelFilteredObj) {
          this.SubChannelForm = this.fb.group({
            SubChannelID: [{ value: this.subChannelFilteredObj.subChannelID, disabled: false }],
            ChannelName: [{ value: this.subChannelFilteredObj.channelName, disabled: false }, Validators.required],
            ChannelCode: [{ value: this.subChannelFilteredObj.channelCode, disabled: false }, Validators.required],
            MainChannelID: [{ value: this.subChannelFilteredObj.mainChannelID, disabled: false }, Validators.required],
            IsPhysicalEntry: [{ value: this.subChannelFilteredObj.isPhysicalEntry, disabled: false }],
            IsCDAccount: [{ value: this.subChannelFilteredObj.isCDAccount, disabled: false }],
            branchid: this.subChannelFilteredObj.branchID,
            PolicyHolderCode: [{ value: this.subChannelFilteredObj.policyHolderCode, disabled: false }],
            TriggerLimit: [{ value: this.subChannelFilteredObj.triggerLimit, disabled: false }],
            IsBlanket: [{ value: this.subChannelFilteredObj.isBlanket, disabled: false }],
          })
          if (this.subChannelFilteredObj.isPhysicalEntry) {
            this.onchangeIsPhysicalentry(this.subChannelFilteredObj.isPhysicalEntry)
          }
          if (this.subChannelFilteredObj.isCDAccount) {
            this.onchangeISCDACCOUNT(this.subChannelFilteredObj.isCDAccount);
          }


          console.log(this.SubChannelForm.value)
        }
      })
  }
  show() {
    this.isEntity = true
    console.log(this.isEntity)
  }
  hide() {
    this.isEntity = false
  }
  showDeposit() {
    this.isDeposit = true
    console.log(this.isEntity)
  }
  hideDeposit() {
    this.isDeposit = false
  }
  cancelSearch() {
    this.SearchSubChannel.reset()
    this.getallsubchannel()
  }
  shortnumValidate(event: any) {

    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 15) {
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(l)
          event.preventDefault();
        }
      }
      else {
        event.preventDefault();
      }
    }
  }

  nameCodeValidate(event: any) {
    var a = event.target.value;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if ((keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
        console.log(l)
        event.preventDefault();
      }
    }
  }

  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.exist = false
    this.success=false
    this.fail=false
  }
  get branches() {
    if (this.SubChannelForm.controls['BranchID'].hasError('required')) {
      return 'Please Select Branch.';
    }
  }

  get trigger() {
    if (this.SubChannelForm.controls['TriggerLimit'].hasError('required')) {
      return 'Please enter the TRIGGER LIMIT.';
    }
  }

  get codeerror() {
    if (this.SubChannelForm.controls['PolicyHolderCode'].hasError('minlength') || this.SubChannelForm.controls['PolicyHolderCode'].hasError('maxlength')) {
      return 'Please enter the 4 digits.';
    }
  }
}
