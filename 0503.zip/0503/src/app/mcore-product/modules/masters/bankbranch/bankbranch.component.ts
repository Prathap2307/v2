import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BankBranch, BankName, BankCity } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';
import { BankbranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/bankbranch.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { typeWithParameters } from '@angular/compiler/src/render3/util';

@Component({
  selector: 'app-bankbranch',
  templateUrl: './bankbranch.component.html',
  styleUrls: ['./bankbranch.component.css']
})
export class BankbranchComponent implements OnInit {
  createBankBranch: boolean;
  fieldDisable: Boolean;
  bankname: any;
  bankcity: any;
  BankBranchForm: FormGroup;
  BankBranchFormAction: FormGroup;
  bankBranchObj: BankBranch[];
  bankNameObj: BankName[];
  bankNameFilteredObj: BankName[] = [];
  BankCityObj: BankCity[];
  bankBranchFilteredObj: BankBranch[] = [];
  bankBranchHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  bankBranchColumns: string[] = ['View', 'Edit', 'Delete', 'bankName', 'bankCityName', 'description', 'ifscCode', 'micrCode'];
  bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.bankBranchdataSource.paginator = this.paginator;
  }
  constructor(
    private fb: FormBuilder,
    private bankBranchService: BankbranchService
  ) { }
  ngOnInit() {
    // setTimeout(() => this.bankBranchdataSource.paginator = this.paginator);
    // this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
    this.createBankBranch = true;
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.getBankBranchNameDetails();   
    this.getBankBranchDetails();
    this.ValidateBankBranchForm();   
  }
  ValidateBankBranchForm() {
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: [''],
        bankId: ['',
          [Validators.required]],
        bankCityId: ['',
          [Validators.required]],
        bankName:
          [
            ''
          ],
        bankCityName:
          [
            '',
            [Validators.required]
          ],
        description:
          [
            '',
            [Validators.required]
          ],
        ifscCode:
          [
            '',
            [Validators.required]
          ],
        micrCode:
          [
            '',
            [Validators.required]
          ],
        createdBy: [1],
        createdOn: [new Date()],
        isActive: 1,
      })
    });
  }  
  onBtnSearchBankBranchDetails() {
    let search: any;
    search = {
      branchId: 0,
      bankId: this.BankBranchForm.get('BankBranchFormSearch.searchbankId').value,
      bankCityId: this.BankBranchForm.get('BankBranchFormSearch.searchbankCityId').value,
      description: '',
      ifscCode: this.BankBranchForm.get('BankBranchFormSearch.searchifscCode').value,
      micrCode: this.BankBranchForm.get('BankBranchFormSearch.searchmicrCode').value,
    }
    console.log(search);
    if (this.BankBranchForm.controls.BankBranchFormSearch.valid) {
      this.bankBranchService.getSearchBankBranchdetails(search).subscribe(
        bankBranchObj => {
          this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
          this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
          this.bankBranchdataSource.paginator = this.paginator;
        });
    }
  }
  getSearchBankBranchDetails() {
  }
  onBtnSearchClearBankBranch() {
    this.BankBranchForm.reset();
    this.getBankBranchDetails();
  }
  onBtnSaveBankBranchClick() {
    this.GetSaveBankBranchDetails();
  }
  GetSaveBankBranchDetails() {
    // this.BankBranchForm.get('BankBranchFormAction').patchValue({
    //   createdBy: '1',
    //   createdOn: new Date(),
    //   isActive: '1',
    // });
    // this.BankBranchForm.controls.BankBranchFormAction.markAllAsTouched();
    // if (this.BankBranchForm.controls.BankBranchFormAction.valid) {
    //   let a = this.BankBranchForm.controls.BankBranchFormAction.value;
    //   console.log(a);
    //   this.bankBranchService.insertbankBranch(a).subscribe(result => { this.getBankBranchDetails() });
    //   this.GetClearBankBranchDetails();
    // }
    this.BankBranchForm.controls.BankBranchFormAction.markAllAsTouched();
    if (this.BankBranchForm.get('BankBranchFormAction').valid) {
      console.log('valid');
      if (this.createBankBranch) {
        this.BankBranchForm.get('BankBranchFormAction').patchValue({
          branchId: '0',
          createdBy: '1',
          createdOn: new Date(),
          isactive: '1',
        });
      }
      else {
        this.BankBranchForm.get('BankBranchFormAction').patchValue({
          createdBy: '1',
          createdOn: new Date(),
        });
      }
      let a = this.BankBranchForm.controls.BankBranchFormAction.value;
      console.log(a);
      this.bankBranchService.insertbankBranch(a).subscribe(result => { this.getBankBranchDetails() });
      this.GetClearBankBranchDetails();
    }
  }
  onBtnClearBankBranchClick() {
    this.GetClearBankBranchDetails();
  }
  GetClearBankBranchDetails() {
    this.BankBranchForm.controls.BankBranchFormAction.reset();
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        bankId: { value: '', disabled: false },
        bankName: { value: '', disabled: false },
        bankCityId: { value: '', disabled: false },
        bankCityName: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
      })
    });
    this.getBankBranchDetails();
  }
  getBankBranchDetails(): void {
    this.bankBranchService.getBankBranchdetails().subscribe(
      bankBranchObj => {
        this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
        this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
        this.bankBranchdataSource.paginator = this.paginator;
      });
  }
  // Grid View Button Events
  btngvView_Click(a) {
    this.bankBranchHeading = 'View - Bank Branch';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.branchId == a);
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: this.bankBranchFilteredObj[0].branchId,
        bankId: this.bankBranchFilteredObj[0].bankId,
        bankName: this.bankBranchFilteredObj[0].BankName,
        bankCityId: this.bankBranchFilteredObj[0].bankCityId,
        bankCityName: this.bankBranchFilteredObj[0].BankCityName,
        description: this.bankBranchFilteredObj[0].description,
        ifscCode: this.bankBranchFilteredObj[0].ifscCode,
        micrCode: this.bankBranchFilteredObj[0].micrCode,
        createdBy: this.bankBranchFilteredObj[0].createdBy,
        createdOn: this.bankBranchFilteredObj[0].createdOn,
      })
    });
    this.change_BranchCity_fn();
  }
  // Grid Edit Button Events
  btngvEdit_Click(a) {
    this.createBankBranch = false;
    this.bankBranchHeading = 'Edit - Bank Branch';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.branchId == a);
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: this.bankBranchFilteredObj[0].branchId,
        bankId: this.bankBranchFilteredObj[0].bankId,
        bankName: this.bankBranchFilteredObj[0].BankName,
        bankCityId: this.bankBranchFilteredObj[0].bankCityId,
        bankCityName: this.bankBranchFilteredObj[0].BankCityName,
        description: this.bankBranchFilteredObj[0].description,
        ifscCode: this.bankBranchFilteredObj[0].ifscCode,
        micrCode: this.bankBranchFilteredObj[0].micrCode,
        createdBy: this.bankBranchFilteredObj[0].createdBy,
        createdOn: this.bankBranchFilteredObj[0].createdOn,
      })
    });
    this.change_BranchCity_fn();
  }
  // Grid Delete Button Events
  btngvDelete_Click(a) {
    this.BankBranchForm = this.fb.group({
      BankBranchFormSearch: this.fb.group({
        searchbankId: [''],
        searchbankCityId: [''],
        searchifscCode: [''],
        searchmicrCode: [''],
      }),
      BankBranchFormAction: this.fb.group({
        branchId: { value: a, disabled: false },
        bankId: { value: '', disabled: false },
        bankName: { value: '', disabled: false },
        bankCityId: { value: '', disabled: false },
        bankCityName: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: 1,
        createdOn: new Date(),
        deletedBy: 1,
        deletedOn: new Date(),
        isActive: 0,
      })
    });
    let v = this.BankBranchForm.get('BankBranchFormAction').value;
    console.log(v);
    this.bankBranchService.deleteBankBranch(v).subscribe(result => { this.getBankBranchDetails(); });
  }
  getBankBranchNameDetails() {
    this.bankBranchService.getBankBranchNameDetails().subscribe(bankNameVal => { this.bankNameObj = bankNameVal });
  }
  Searchchange_BranchCity_fn() {
    let bankId = this.BankBranchForm.get('BankBranchFormSearch.searchbankId').value;
    this.getBankBranchCitydetails(bankId);
  }
  change_BranchCity_fn() {
    let bankId = this.BankBranchForm.get('BankBranchFormAction.bankId').value;
    this.getBankBranchCitydetails(bankId);
  }
  getBankBranchCitydetails(bankId) {
    this.bankBranchService.getBankBranchCityDetails(bankId).subscribe(bankCityNameVal => { this.BankCityObj = bankCityNameVal });
  }
}
