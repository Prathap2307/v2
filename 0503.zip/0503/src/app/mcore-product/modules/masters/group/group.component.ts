import { Component, OnInit } from '@angular/core';
import { Validators,  FormBuilder,FormGroup } from '@angular/forms';
@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
  GroupForm: FormGroup;
  GroupSearch: FormGroup;
  submitted: boolean;
  groupHeading: string='Add New - Group';
  saveBtnMode: boolean=true;
  textSaveBtn: string='Save';
  view: boolean=false;
  selectedPersonArray = [];

  isKeyPressed: boolean= false;
  Users=
  [
    { id: '1', 	First_Name: 'Manufacturer',Last_Name:'abcd',isActive:'2', Group_Name : 'abc'},
    { id: '2', First_Name: 'Distributor ',Last_Name:'abcd',isActive:'1',Group_Name : 'abc' },
    { id: '3', First_Name: 'Importer',Last_Name:'abcd',isActive:'2',Group_Name : 'abc'  },
    { id: '4', First_Name: 'Exporter' ,Last_Name:'abcd',isActive:'2',Group_Name : 'abc' },
    { id: '5', First_Name: 'Stockist',Last_Name:'abcd',isActive:'1',Group_Name : 'abc' },
    { id: '6', First_Name: 'Others' ,Last_Name:'abcd',isActive:'1',Group_Name : 'abc' },
    { id: '7', First_Name: 'Manufacturer',Last_Name:'abcd',isActive:'2',Group_Name : 'abc'  },
    { id: '8', First_Name: 'Distributor ',Last_Name:'abcd',isActive:'1',Group_Name : 'abc'  },
    { id: '9', First_Name: 'Importer',Last_Name:'abcd',isActive:'2' ,Group_Name : 'abc' }
  ]
  FinalSelectedArray=[];
  display: string;

  constructor( private fb: FormBuilder,) { }

  ngOnInit() {

    this.selectedPersonArray=this.Users
    for(let i=0;i<this.Users.length;i++)
    {
      this.selectedPersonArray["isselected"]=false
    }
    
    this.GroupSearch= this.fb.group({
      id: [''],
      GroupName: ['',],
    })
    this.GroupForm= this.fb.group({
      id: [''],
      GroupName: ['', Validators.required],
      Entity: ['Null', Validators.required],
      IsActive:['',],
      CreatedBy: ['', ],
      CreatedOn: ['',]
    })
  }
  get f() { return this.GroupForm.controls; }

  onBtnSaveClick(){

  this.FinalSelectedArray=[]
    this.submitted=true
    console.log(this.GroupForm.value)
    for(let i=0;i<this.selectedPersonArray.length;i++)
{
  if(this.selectedPersonArray[i]["isselected"] == true)
  {
    this.FinalSelectedArray.push(this.selectedPersonArray[i]);
  }

}


this.FinalSelectedArray = this.FinalSelectedArray.filter((id, i, a) => i === a.indexOf(id))

console.log(this.selectedPersonArray)
  console.log(this.FinalSelectedArray)
let result={}
result=this.GroupForm.value
if( this.GroupForm.valid)
{
  result["SelectedUsers"]=this.FinalSelectedArray
console.log(result)
this.openModalDialog()
}

  
}

search()
{
  console.log(this.GroupSearch.value)

}

clearsearch()
{
  this.GroupSearch.reset()
}
  btngEdit_Click() {
    this.view = false
    this.groupHeading = 'Edit - Group';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update'
  }
  btngView_Click() {
    this.groupHeading = 'View - Group';
    this.view = true
    this.saveBtnMode = false;
  }
  Search() {
    console.log(this.GroupSearch.value)

  }
  cancel() {
    this.GroupForm.reset()
    console.log(this.submitted)
    this.submitted = false
    this.groupHeading = 'Add New - Group';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }

  }

  addThisPersonToArray(person){
    console.log(person)
    person.isselected=!person.isselected 
  }

  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
  }
}
