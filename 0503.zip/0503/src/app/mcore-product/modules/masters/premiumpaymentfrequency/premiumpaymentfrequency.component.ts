import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product1.service';
import { LookupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/lookup.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinner } from 'ngx-spinner/lib/ngx-spinner.enum';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-premiumpaymentfrequency',
  templateUrl: './premiumpaymentfrequency.component.html',
  styleUrls: ['./premiumpaymentfrequency.component.css']
})
export class PremiumpaymentfrequencyComponent implements OnInit {

  variantArr:any = [];
  paymentFrequencyArr:any = [];
  paymentObj: any = {};
  paymentArr: any = [];
  paymentHistoryList: any = [];
  deletePayId: any;
  searchPaymentObj: any = {};
  userId: any;
  buttonDisable = false;
  viewRemarkInput = false;
  editRemarkInput = false;
  isReadonly = true;
  paymentErrMsg: string;
  deletePaymentID: any;
  premiumPaymentFrequencyPage : any;

  constructor(
    private _productService:ProductService,
    private _lookupService:LookupService,
    private _snackBar:MatSnackBar,
    private spinner:NgxSpinnerService
  ) {
    for (let i = 1; i <= this.paymentArr.length; i++) {
      this.paymentArr.push(`deal ${i}.0`);
    }
   }

  ngOnInit() {
    this.userId = JSON.parse(localStorage.getItem('userId'));
    this.spinner.show();
    this.getVariant();
    this.getFrequency();
    this.paymentData();
    this.getPayment();
  }

  PaymentForm = new FormGroup({
    planID : new FormControl("", [Validators.required]),
    premPaymentFrequencyID : new FormControl("", [Validators.required]),
    modalFactor : new FormControl("", [Validators.required]),
    gracePeriod : new FormControl("", [Validators.required]),
    noticePeriod : new FormControl("", [Validators.required]),
    remarks : new FormControl(""),
    createdBy : new FormControl(""),
  });
  

  getVariant(){
    this._productService.getConfProduct().subscribe(res =>{
      this.variantArr = res.variantRequestList;
      this.spinner.hide();
      console.log(res);
    },err =>{
      console.log(err);
    })
  }

  getFrequency(){
    this._lookupService.getFrequency().subscribe(res =>{
      console.log(res);
    this.paymentFrequencyArr = res.paymentFrequencyist;
    },err =>{
      console.log(err);
    })
  }

//Payment Frequency
  getPayment()
  {
      this.premiumPaymentFrequencyPage = 1;
      this.paymentErrMsg = '';
      this.PaymentForm.markAsPristine();
      this.PaymentForm.markAsUntouched(); 
      this.paymentObj = {};
      this.searchPaymentObj = {};
      this.paymentHistoryList = [];
      this.buttonDisable = false;
      this.viewRemarkInput = false;
      this.editRemarkInput = false; 
      this.isReadonly = true;
  this._productService.getPayment().subscribe(res =>{
    console.log(res);
    this.paymentArr = res.premiumPaymentFrequencyList;
    if(this.paymentArr.length == 0){
      this.paymentErrMsg = 'Not Found';
    }
    this.spinner.hide();
  },err =>{
    console.log(err);
  })
}

  paymentData()
  {
    console.log(this.PaymentForm);
    if(this.PaymentForm.valid)
    {
      // this.spinner.show();
      this.paymentObj.createdBy = this.userId;
      console.log(this.paymentObj);
      this._productService.savePayment(this.paymentObj).subscribe(res => {
        console.log(res);
        this._snackBar.open(res.message, 'Done', {
          duration: 2000,
        });
        this.getPayment();
      })
    }
  }

  viewPayment(id){
    console.log(id);
    if(this.buttonDisable == false){
    this.spinner.show();
    this.PaymentForm.markAsPristine();
    this.PaymentForm.markAsUntouched(); 
    this.paymentObj = {};
    // this.searchPaymentObj = {};
    this.paymentHistoryList = [];
    this.viewRemarkInput = false;
    this.editRemarkInput = false; 
    this.isReadonly = true;
    this.PaymentForm.addControl('remarks', new FormControl(''));
    this._productService.getSinglePayment(id).subscribe(res =>{
      this.paymentObj = res.premiumPaymentFrequencyObj;
      // this.paymentHistoryList = res.paymentHistoryList;
      console.log(res);
      this.buttonDisable = true;
      this.viewRemarkInput = true;
      this.isReadonly = false;
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
  }

  paymentFormClear(){
    this.spinner.show();
    this.PaymentForm.removeControl('remarks');
    this.getPayment();
  }

  editPayment(editPayId){
    if(this.buttonDisable == false){
    this.spinner.show();
    this.PaymentForm.markAsPristine();
    this.PaymentForm.markAsUntouched(); 
    this.paymentObj = {};
    // this.searchPaymentObj = {};
    this.paymentHistoryList = [];
    this.viewRemarkInput = false;
    this.editRemarkInput = false; 
    this.isReadonly = true;
    this.PaymentForm.addControl('remarks', new FormControl(''));
    this._productService.getSinglePayment(editPayId).subscribe(res =>{
      console.log(res);
      this.paymentObj = res.premiumPaymentFrequencyObj;
      this.buttonDisable = true;
      this.editRemarkInput = true;
      this.isReadonly = true; 
      this.spinner.hide();
    }, err =>{
      console.log(err);
    })
  }
  }

  deletePaymentId(delPayId){
    if(this.buttonDisable == false){
    this.PaymentForm.markAsPristine();
    this.PaymentForm.markAsUntouched(); 
    this.paymentObj = {};
    // this.searchPaymentObj = {};
    this.paymentHistoryList = [];
    this.viewRemarkInput = false;
    this.editRemarkInput = false; 
    this.isReadonly = true;
    this.deletePaymentID = delPayId;
    console.log(this.deletePaymentID);
    }
  }

  deletePayment(){
    if(this.buttonDisable == false){
    this.spinner.show();
    this._productService.deletePayment(this.deletePaymentID, this.userId).subscribe(res =>{
      console.log(res);
      this.getPayment();
    },err =>{
      console.log(err);
    })
  }
  }

  searchPayment(){
    this.spinner.show();
    this.paymentErrMsg = '';
    this.PaymentForm.markAsPristine();
    this.PaymentForm.markAsUntouched(); 
    this.viewRemarkInput = false;
    this.editRemarkInput = false; 
    this.isReadonly = true; 
    this.buttonDisable = false;
    this.paymentObj = {};
    this.paymentHistoryList = [];
    console.log(this.searchPaymentObj);
    this._productService.searchPayment(this.searchPaymentObj).subscribe(res =>{
      console.log(res);
      this.paymentArr = res.list;
      if(this.paymentArr.length == 0){
        this.paymentErrMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  

}
