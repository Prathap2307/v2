import { Component, OnInit, ViewChild } from '@angular/core';
import { ProductService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/product1.service';
import { LookupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/lookup.service';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-premium',
  templateUrl: './premium.component.html',
  styleUrls: ['./premium.component.css']
})
export class PremiumComponent implements OnInit {
  variantArr:any = [];
  benefitRidersArr:any = [];
  variantId: any;
  productPremiumTypeArr:any = [];
  typeId: any;
  productBenefitRidersArr:any = [];
  benefitRidersObj:any = {};
  searchPremiumObj:any = {};
  tableEnable = false;
  premiumRuleDataObj:any = {};
  premiumDataObj:any = {};
  premiumArr:any = [];
  userId: any;
  token: any;
  errMsg: string;
  buttonDisable = false;
  isReadonly = false;
  deletePremiumID: any;
  premiumPage:any;
  errorMsg: string;

  constructor(
    private spinner: NgxSpinnerService,
    private _productService:ProductService,
    private _lookupService:LookupService,
    private _snackBar: MatSnackBar
  ) { 
    for (let i = 1; i <= this.premiumArr.length; i++) {
      this.premiumArr.push(`deal ${i}.0`);
    }
  }

  ngOnInit() {
    this.getVariant();
    this.userId = JSON.parse(localStorage.getItem('userId'));
    this.token = JSON.parse(localStorage.getItem('token'));
  }

  selectValue(data){
    this.variantId = data;
    // this.searchPremiumObj.variantPremiumTypeId = "";
    // this.searchPremiumObj.benefitRiderId = "";
    this.getProductPremiumType();
  }

  selectTypeValue(data){
    this.typeId = data;
    this.getBenefitRiders();
  }

  selectbenefitRidersValue(data)
  {
    this.benefitRidersObj = data;
  }

  getVariant(){
    this.spinner.show();
    this._productService.getConfProduct().subscribe(res =>{
      console.log(res);
      this.variantArr = res.variantRequestList;
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  getProductPremiumType(){
    this._productService.getProductPremiumType(this.variantId).subscribe(res =>{
      console.log(res);
      this.productPremiumTypeArr = res.productTypeList;
    },err =>{
      console.log(err);
    })
  }

  getBenefitRiders(){
    this._productService.getProductBenefitDiders(this.variantId, this.typeId).subscribe(res =>{
      console.log(res);
      this.productBenefitRidersArr = res.productBenefitRiders;
    },err =>{
      console.log(err);
    })
  }

    // Premium

    premiumForm = new FormGroup({
      premiumValue: new FormControl("", [Validators.required]),
      createdBy: new FormControl(""),
      ruleSetName: new FormControl("",[Validators.required]),
      amountTypeId: new FormControl("",[Validators.required]),
      variantId: new FormControl(""),
      variantPremiumTypeId: new FormControl(""),
      benefitRiderId: new FormControl(""),
        premiumDetailsMap : new FormGroup({
            influencingFactorID: new FormControl(""),
            maximumValue: new FormControl("",[Validators.required]),
            maximumValueMonth: new FormControl("",[Validators.required]),
            minimumValue: new FormControl("",[Validators.required]),
            minimumValueMonth: new FormControl("",[Validators.required]),
            specificValuesID: new FormControl(""),      
          })
    });

  addpremium(){
    this.errorMsg = '';
    if(this.premiumForm.value.premiumDetailsMap.minimumValue >= this.premiumForm.value.premiumDetailsMap.maximumValue){
      this.errorMsg = "Your Maximum Value Is Lower Than Or Equal In Minimum Value";
      this._snackBar.open(this.errorMsg, 'Error', {
        duration: 2000,
      });
    }else{
      this.errorMsg = 'true';
    }
    if(this.premiumForm.valid && this.errorMsg == 'true'){
      this.premiumRuleDataObj.influencingFactorID = '1';
      this.premiumRuleDataObj.specificValuesID = '2';
      this.premiumDataObj.premiumDetailsMap = this.premiumRuleDataObj;
      this.premiumDataObj.createdBy = this.userId;
      this.premiumDataObj.variantId = this.searchPremiumObj.variantId;
      this.premiumDataObj.variantPremiumTypeId = this.searchPremiumObj.variantPremiumTypeId;
      this.premiumDataObj.benefitRiderId = this.searchPremiumObj.benefitRiderId;
      console.log(this.premiumDataObj);
      this._productService.addPremium(this.premiumDataObj).subscribe(res =>{
        console.log(res);
        this.premiumDataObj = {};
        this._snackBar.open(res.message, 'Done', {
          duration: 2000,
        });
        this.preminumSearch();
      },err =>{
        console.log(err);
      })
    }
  }

  preminumSearch(){
    this.spinner.show();
    this.errMsg = '';
    this.premiumPage = 1;
    this.premiumDataObj = {};
    this.premiumRuleDataObj = {};
    this.premiumForm.markAsPristine();
    this.premiumForm.markAsUntouched();
    this.isReadonly = false;
    this.buttonDisable = false;
    // var premium = this.searchPremiumObj;
    this._productService.searchPremium(this.searchPremiumObj).subscribe(res =>{
      console.log(res);
      this.premiumArr = res.list;
      this.tableEnable = true;
      if(this.premiumArr == 0){
        this.errMsg = 'Not Found';
      }
      this.spinner.hide();
    },err =>{
      console.log(err);
    })
  }

  clearPremium(){
    this.searchPremiumObj = {};
    // this.variantArr = [];
    this.productPremiumTypeArr = [];
    this.productBenefitRidersArr = [];
    this.tableEnable = false;
    this.premiumDataObj = {};
    this.variantId = "";
    this.typeId = "";
    this.premiumRuleDataObj = {};
    this.premiumForm.markAsPristine();
    this.premiumForm.markAsUntouched();
    this.isReadonly = false;
    this.buttonDisable = false;
    this.premiumPage = 1;
  }

  viewPremium(id){
    if(this.buttonDisable == false){
      this.spinner.show();
      this.premiumDataObj = {};
      this.premiumRuleDataObj = {};
      this.isReadonly = false;
      this.buttonDisable = false;
      this.premiumForm.markAsPristine();
      this.premiumForm.markAsUntouched();
      this._productService.getSinglePremium(id).subscribe(res =>{
        this.premiumDataObj = res.obj;
        this.premiumRuleDataObj = res.obj.premiumDetailsMap;
        this.isReadonly = true;
        this.buttonDisable = true;
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }
  }

  cancelPremium(){
    this.premiumDataObj = {};
    this.premiumRuleDataObj = {};
    this.premiumForm.markAsPristine();
    this.premiumForm.markAsUntouched();
    this.isReadonly = false;
    this.buttonDisable = false;
    this.premiumPage = 1;
  }

  editPremium(editPremiumId){
    if(this.buttonDisable == false){
      this.spinner.show();
      this.premiumDataObj = {};
      this.premiumRuleDataObj = {};
      this.isReadonly = false;
      this.buttonDisable = false;
      this.premiumForm.markAsPristine();
      this.premiumForm.markAsUntouched();
      this._productService.getSinglePremium(editPremiumId).subscribe(res =>{
        console.log(res);
        this.premiumDataObj = res.obj;
        this.premiumRuleDataObj = res.obj.premiumDetailsMap;
        this.buttonDisable = true;
        this.spinner.hide();
      },err =>{
        console.log(err);
      })
    }
  }

  deletePremiumId(deletePremiumId){
    if(this.buttonDisable == false){
      this.premiumDataObj = {};
      this.premiumRuleDataObj = {};
      this.isReadonly = false;
      this.buttonDisable = false;
      this.premiumForm.markAsPristine();
      this.premiumForm.markAsUntouched();
      this.deletePremiumID = deletePremiumId;
    }
  }

  deletePremium(){
    if(this.buttonDisable == false){
    this._productService.deletePremium(this.deletePremiumID, this.userId).subscribe(res =>{
     this.preminumSearch();
   },err =>{
     console.log(err);
   })
    }
  }

}
