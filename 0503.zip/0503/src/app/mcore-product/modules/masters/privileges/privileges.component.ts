import { Component, OnInit } from '@angular/core';
import { MatCheckboxChange } from '@angular/material';
@Component({
  selector: 'app-privileges',
  templateUrl: './privileges.component.html',
  styleUrls: ['./privileges.component.css']
})
export class PrivilegesComponent implements OnInit {
  view: boolean;
  search: boolean;
  add: boolean;
  edit: boolean;
  delete: boolean;
  show: boolean = false;


  constructor() { }

  ngOnInit() {
  }
  onChange(value: { checked: boolean; }, id: any) {
    console.log(value)
    let activate_d = {
      "OrganisationID": 1,
      "BranchID": id,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 2
    }
    if (value.checked === true) {
      activate_d["isActive"] = 1
      console.log(1);
    } else {
      activate_d["isActive"] = 0
      console.log(0);
    }
  }
  allowView(event: MatCheckboxChange): void {
    console.log(event.checked);
    // this.view = event.checked
    if (event.checked) {
      this.view = event.checked
    }
    else {
      this.view = false
      this.search = false
      this.add = false
      this.edit = false
      this.delete = false
    }
  }
  allowSearch(event: MatCheckboxChange): void {
    console.log(event.checked);

    if (event.checked) {
      this.search = event.checked
      this.view = event.checked
    }
    else {
      this.search = false
      this.add = false
      this.edit = false
      this.delete = false

    }
  }
  allowAdd(event: MatCheckboxChange): void {
    console.log(event.checked);

    if (event.checked) {
      this.view = event.checked
      this.search = event.checked
      this.add = event.checked
    }
    else {
      this.add = false
      this.edit = false
      this.delete = false
    }
  }
  allowEdit(event: MatCheckboxChange): void {
    console.log(event.checked);
    if (event.checked) {
      this.view = event.checked
      this.search = event.checked
      this.add = event.checked
      this.edit = event.checked
    }
    else {
      this.edit = false
      this.delete = false
    }
  }
  allowDelete(event: MatCheckboxChange): void {
    console.log(event.checked);

    if (event.checked) {
      this.view = event.checked
      this.search = event.checked
      this.add = event.checked
      this.edit = event.checked
      this.delete = event.checked
    }
    else {
      this.delete = false
    }
  }
  select() {
    console.log(this.show)
    this.show = true
  }
}
