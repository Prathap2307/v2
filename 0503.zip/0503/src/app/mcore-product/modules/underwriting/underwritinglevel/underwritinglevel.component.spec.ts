import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderwritinglevelComponent } from './underwritinglevel.component';

describe('UnderwritinglevelComponent', () => {
  let component: UnderwritinglevelComponent;
  let fixture: ComponentFixture<UnderwritinglevelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnderwritinglevelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderwritinglevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
