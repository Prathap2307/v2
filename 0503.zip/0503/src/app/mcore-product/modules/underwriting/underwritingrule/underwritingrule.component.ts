import { Component, OnInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-underwritingrule',
  templateUrl: './underwritingrule.component.html',
  styleUrls: ['./underwritingrule.component.css']
})
export class UnderwritingruleComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  dataSource;
  elements: string;
  underwritingGridRuleColumns: string[] = ['View', 'Edit', 'Delete', 'rulesetname', 'process'];
  underwritingRuleColumns: string[] = ['InfluencingFactor', 'SpecificValues', 'MinimumValue', 'MaximumValue', 'SpecificValue'];
  constructor() { }

  ngOnInit() {
  } 
}
