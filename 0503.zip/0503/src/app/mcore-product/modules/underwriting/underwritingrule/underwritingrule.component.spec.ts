import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderwritingruleComponent } from './underwritingrule.component';

describe('UnderwritingruleComponent', () => {
  let component: UnderwritingruleComponent;
  let fixture: ComponentFixture<UnderwritingruleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnderwritingruleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderwritingruleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
