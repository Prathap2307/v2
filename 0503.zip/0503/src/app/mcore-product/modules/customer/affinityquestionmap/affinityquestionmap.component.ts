import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-affinityquestionmap',
  templateUrl: './affinityquestionmap.component.html',
  styleUrls: ['./affinityquestionmap.component.css']
})
export class AffinityquestionmapComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
