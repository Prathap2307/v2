import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claimintimation',
  templateUrl: './claimintimation.component.html',
  styleUrls: ['./claimintimation.component.css']
})
export class ClaimintimationComponent implements OnInit {
 dummyObj: string;
 tableColumns: string[] = ['View', 'policyNumber', 'insuredNumber', 'policyStatus', 'sumInsured' ];
 tableColumnsOne: string[] = ['edit', 'delete', 'documentType', 'image' ];
 showColumns: string[] = ['Select', 'masterAgreementNumber', 'masterAgreementNumber', 'certificateNumber', 'certificateHolderName' ];
  constructor() { }

  ngOnInit() {
  }

}
