import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claimsstatusreport',
  templateUrl: './claimsstatusreport.component.html',
  styleUrls: ['./claimsstatusreport.component.css']
})
export class ClaimsstatusreportComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
