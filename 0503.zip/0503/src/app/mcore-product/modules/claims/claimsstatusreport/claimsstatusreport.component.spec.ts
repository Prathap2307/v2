import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsstatusreportComponent } from './claimsstatusreport.component';

describe('ClaimsstatusreportComponent', () => {
  let component: ClaimsstatusreportComponent;
  let fixture: ComponentFixture<ClaimsstatusreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimsstatusreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsstatusreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
