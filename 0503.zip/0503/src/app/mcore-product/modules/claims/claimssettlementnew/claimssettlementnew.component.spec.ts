import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimssettlementnewComponent } from './claimssettlementnew.component';

describe('ClaimssettlementnewComponent', () => {
  let component: ClaimssettlementnewComponent;
  let fixture: ComponentFixture<ClaimssettlementnewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimssettlementnewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimssettlementnewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
