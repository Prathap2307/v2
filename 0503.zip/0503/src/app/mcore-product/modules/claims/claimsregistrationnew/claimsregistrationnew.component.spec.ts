import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsregistrationnewComponent } from './claimsregistrationnew.component';

describe('ClaimsregistrationnewComponent', () => {
  let component: ClaimsregistrationnewComponent;
  let fixture: ComponentFixture<ClaimsregistrationnewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimsregistrationnewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsregistrationnewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
