import { Component, OnInit } from '@angular/core';
import {  ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-claimsregistrationnew',
  templateUrl: './claimsregistrationnew.component.html',
  styleUrls: ['./claimsregistrationnew.component.css']
})
export class ClaimsregistrationnewComponent implements OnInit {

  dummyObj: string;
  tableColumns: string[] = ['Select', 'policynumber', 'claimnumber', 'insuredfullname', 'dateofloss', 'claimcoverages', 'status', 'ageing'];
  tableColumnsOne: string[] = ['edit', 'delete', 'documentType', 'image'];
  tableColumnsThree: string[] = ['claimNumber', 'assessor', 'assessorName', 'assessorBranch', 'assessorExpenses', 'assessmentRemarks'];
  constructor(private activatedRoute: ActivatedRoute) { }

  divAssessorRemarksDetails: boolean;
  divAssessmentHistory: boolean;

  divCoverageDetails: boolean;
  divTotalPayable: boolean;
  divAssessorSelection: Boolean;
  divProcesses: Boolean;

  TypeClaim: string;

  ngOnInit() {
   
    this.activatedRoute.queryParams.subscribe(params => {
      this.TypeClaim = params['Type'];
      this.claimsPageLoad();
    });
   
  
  }

  claimsPageLoad() {
    // if (this.TypeClaim.trim() == 'request') {
    //   this.divAssessorRemarksDetails = false;
    //   this.divAssessmentHistory = false;
    //   this.divCoverageDetails = true;
    //   this.divTotalPayable = true;
    //   this.divAssessorSelection = true;
    //   this.divProcesses = true;
    // }

    if (this.TypeClaim.trim() == 'Assessment') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = false;
      this.divProcesses = true;
    }

    if (this.TypeClaim.trim() == 'Approval') {
      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = false;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = true;
      this.divProcesses = true;
    }

    if (this.TypeClaim.trim() == 'View') {
      this.divAssessorRemarksDetails = true;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = true;
      this.divTotalPayable = true;
      this.divAssessorSelection = false;
      this.divProcesses = false;
    }

    if (this.TypeClaim.trim() == 'Reopen') {
     
      this.divAssessorRemarksDetails = false;
      this.divAssessmentHistory = true;
      this.divCoverageDetails = false;
      this.divTotalPayable = false;
      this.divAssessorSelection = true;
      this.divProcesses = true;
    }
  }

}
