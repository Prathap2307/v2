import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  msg: string;
  error: boolean=false;

  constructor(private router: Router, private user: UserService) { }

  ngOnInit() {
  }

  LoginForm = new FormGroup({

    userName: new FormControl("", [Validators.required]),
    password: new FormControl("", [Validators.required])


  });

  onSubmit() {

    if (this.LoginForm.valid) {
      let userCredential = this.LoginForm.value;
      console.log(userCredential)
      this.user.VerifyLogin(userCredential)
        .subscribe(result => {
          console.log("result",result)
        
          if(result && result.data.message == 'SuccessfullLogin'){
            this.router.navigate(['/account/dashboard']);
            console.log(result.data["UserProfileModal"])
            this.user.fname=result.data.UserProfileModal.firstName
          } else {
            this.error=true
            this.msg=result.data.message
            console.log('mm',result.data.message)
          }
        
        })
      
        
      // console.log(userCredential);
    }
  }


}
