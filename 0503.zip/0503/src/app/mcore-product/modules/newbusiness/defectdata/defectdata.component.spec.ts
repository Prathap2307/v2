import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectdataComponent } from './defectdata.component';

describe('DefectdataComponent', () => {
  let component: DefectdataComponent;
  let fixture: ComponentFixture<DefectdataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefectdataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefectdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
