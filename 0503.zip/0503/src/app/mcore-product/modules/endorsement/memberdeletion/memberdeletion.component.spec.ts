import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberdeletionComponent } from './memberdeletion.component';

describe('MemberdeletionComponent', () => {
  let component: MemberdeletionComponent;
  let fixture: ComponentFixture<MemberdeletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemberdeletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberdeletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
