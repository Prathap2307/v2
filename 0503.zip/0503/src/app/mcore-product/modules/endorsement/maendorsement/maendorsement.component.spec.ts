import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MAEndorsementComponent } from './maendorsement.component';

describe('MAEndorsementComponent', () => {
  let component: MAEndorsementComponent;
  let fixture: ComponentFixture<MAEndorsementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MAEndorsementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MAEndorsementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
