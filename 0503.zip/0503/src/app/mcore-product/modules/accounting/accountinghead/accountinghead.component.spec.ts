import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountingheadComponent } from './accountinghead.component';

describe('AccountingheadComponent', () => {
  let component: AccountingheadComponent;
  let fixture: ComponentFixture<AccountingheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountingheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountingheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
