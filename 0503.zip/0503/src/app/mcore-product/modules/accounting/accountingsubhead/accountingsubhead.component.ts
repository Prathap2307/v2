import { Component, OnInit, ViewChild } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Accountingsubhead, AccountHead } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingsubhead';
import { AccountingsubheadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingsubhead.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-accountingsubhead',
  templateUrl: './accountingsubhead.component.html',
  styleUrls: ['./accountingsubhead.component.css']
})
export class AccountingsubheadComponent implements OnInit {
  fieldDisable: Boolean;
  accountHeads: string;
  accountSubHeads: string;
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  elements: string;
  accountingSubHeadColumns: string[] = ['View', 'Edit', 'accountHeadName', 'subAccountHeadCode', 'subAccountHeadName'];
  accountSubHeadObj: Accountingsubhead[];
  accountSubHeadFilteredObj: Accountingsubhead[] = [];
  AccountHeadObj: AccountHead[];
  accountSubHeadForm: FormGroup;
  AccountSubHeadFormSearch: FormGroup;
  accountSubHeadFormAction: FormGroup;
  accountSubHeadHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  accountSubHeadSource = new MatTableDataSource<Accountingsubhead>(this.accountSubHeadObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.accountSubHeadSource.paginator = this.paginator;
  }
  createSubAccount: boolean;
  constructor(
    private fb: FormBuilder, private accountSubHeadService: AccountingsubheadService,
  ) { }
  ngOnInit() {
    this.createSubAccount = true;
    this.accountSubHeadHeading = 'Add New - Accounting Sub Head';
    this.btnSaveText = 'Save';
    this.getAllAccountingSubHeadDetails(0, 0, 0, 0);
    this.BindgetAllAccountHeadDetails();
    this.ValidateAccountSubHead();   
  }
  BindgetAllAccountHeadDetails() {
    this.accountSubHeadService.getAccountHeadDetails().subscribe(
      accountHeadVal => {
        this.AccountHeadObj = accountHeadVal;
      });
  }
  ValidateAccountSubHead() {
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: [''],
        SearchAccountHeadCode: [''],
        SearchAccountHeadDescription: [''],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: [''],
        accountHeadId: ['', [Validators.required]],
        accountHeadName: [''],
        subAccountHeadName: ['', [Validators.required]],
        subAccountHeadCode: ['', [Validators.required]],
        createdBy: [1],
        createdOn: [new Date()],
        isactive: [1],
      })
    });
  }  
  getAllAccountingSubHeadDetails(a, b, c, d) {
    this.accountSubHeadService.getAccountingSubHeadSearchDetails(a, b, c, d).subscribe(
      accountSubHeadObj => {
        this.accountSubHeadSource = new MatTableDataSource<Accountingsubhead>(this.accountSubHeadObj);
        this.accountSubHeadSource.data = this.accountSubHeadObj = accountSubHeadObj;
        this.accountSubHeadSource.paginator = this.paginator;
      })
  }
  // Grid View Button Events
  btngvView_Click(a) {
    this.accountSubHeadHeading = 'View - Accounting Sub Head';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.accountSubHeadFilteredObj = this.accountSubHeadObj.filter((unit) => unit.subAccountHeadId == a);
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: [''],
        SearchAccountHeadCode: [''],
        SearchAccountHeadDescription: [''],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: this.accountSubHeadFilteredObj[0].subAccountHeadId,
        accountHeadId: this.accountSubHeadFilteredObj[0].accountHeadId,
        accountHeadName: this.accountSubHeadFilteredObj[0].accountHeadName,
        subAccountHeadCode: this.accountSubHeadFilteredObj[0].subAccountHeadCode,
        subAccountHeadName: this.accountSubHeadFilteredObj[0].subAccountHeadName,
        createdBy: this.accountSubHeadFilteredObj[0].createdBy,
        createdOn: this.accountSubHeadFilteredObj[0].createdOn,
        isactive: this.accountSubHeadFilteredObj[0].isactive,
      })
    });
  }
  // Grid Edit Button Events
  btngvEdit_Click(a) {
    this.createSubAccount = false;
    this.accountSubHeadHeading = 'Edit - Accounting Sub Head';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.accountSubHeadFilteredObj = this.accountSubHeadObj.filter((unit) => unit.subAccountHeadId == a);
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: [''],
        SearchAccountHeadCode: [''],
        SearchAccountHeadDescription: [''],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: this.accountSubHeadFilteredObj[0].subAccountHeadId,
        accountHeadId: this.accountSubHeadFilteredObj[0].accountHeadId,
        accountHeadName: this.accountSubHeadFilteredObj[0].accountHeadName,
        subAccountHeadCode: this.accountSubHeadFilteredObj[0].subAccountHeadCode,
        subAccountHeadName: this.accountSubHeadFilteredObj[0].subAccountHeadName,
        createdBy: this.accountSubHeadFilteredObj[0].createdBy,
        createdOn: this.accountSubHeadFilteredObj[0].createdOn,
        isactive: this.accountSubHeadFilteredObj[0].isactive,
      })
    });
  }
  onBtnSearchAccountSubHead() {
    let a = 0;
    let b = this.accountSubHeadForm.get('AccountSubHeadFormSearch.SearchAccountHead').value;
    let c = this.accountSubHeadForm.get('AccountSubHeadFormSearch.SearchAccountHeadCode').value;
    let d = this.accountSubHeadForm.get('AccountSubHeadFormSearch.SearchAccountHeadDescription').value;
    if (b == 0) {
      b = 0;
    }
    if (c == 0) {
      c = 0;
    }
    if (d == 0) {
      d = 0;
    }
    console.log(a, b, c, d);
    this.getAllAccountingSubHeadDetails(a, b, c, d);
  }
  onBtnClearSearchAccountSubHead() {
    this.accountSubHeadForm.reset();
    this.getAllAccountingSubHeadDetails(0, 0, 0, 0);
  }
  onBtnSaveAccountSubHeadClick() {
    this.accountSubHeadForm.controls.accountSubHeadFormAction.markAllAsTouched();
    if (this.accountSubHeadForm.get('accountSubHeadFormAction').valid) {
      console.log('valid');
      if (this.createSubAccount) {
        this.accountSubHeadForm.get('accountSubHeadFormAction').patchValue({
          subAccountHeadId: '0',
          createdBy: '1',
          createdOn: new Date(),
          isactive: '1',
        });
      }
      else {
        this.accountSubHeadForm.get('accountSubHeadFormAction').patchValue({
          createdBy: '1',
          createdOn: new Date(),
          isactive: '1',
        });
      }
      let a = this.accountSubHeadForm.controls.accountSubHeadFormAction.value;
      console.log(a);
      this.accountSubHeadService.addAccountingSubHeadDetails(a).subscribe(result => { this.getAllAccountingSubHeadDetails(0, 0, 0, 0) });
      this.onBtnClearAccountSubHeadClick();
    }
  }
  onBtnClearAccountSubHeadClick() {
    this.accountSubHeadForm.controls.accountSubHeadFormAction.reset();
    this.accountSubHeadHeading = 'Add New - Accounting Sub Head';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.accountSubHeadForm = this.fb.group({
      AccountSubHeadFormSearch: this.fb.group({
        SearchAccountHead: [''],
        SearchAccountHeadCode: [''],
        SearchAccountHeadDescription: [''],
      }),
      accountSubHeadFormAction: this.fb.group({
        subAccountHeadId: { value: '', disabled: false },
        accountHeadId: { value: '', disabled: false },
        accountHeadName: { value: '', disabled: false },
        subAccountHeadCode: { value: '', disabled: false },
        subAccountHeadName: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
        isactive: { value: '', disabled: false },
      })
    });
    this.getAllAccountingSubHeadDetails(0, 0, 0, 0);
  }
}
