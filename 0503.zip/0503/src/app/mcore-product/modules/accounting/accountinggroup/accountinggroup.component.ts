import { Component, OnInit, ViewChild } from '@angular/core';
import { TooltipPosition } from '@angular/material';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';

import { MatPaginator } from '@angular/material/paginator';
import { AccountinggroupService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountinggroup.service';
import { AccountingGroup } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountinggroup';
import { MatTableDataSource } from '@angular/material/table';
@Component({
  selector: 'app-accountinggroup',
  templateUrl: './accountinggroup.component.html',
  styleUrls: ['./accountinggroup.component.css']
})
export class AccountinggroupComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  accountingGroupColumns: string[] = ['View', 'Edit', 'code', 'description'];

  AccountingGroupForm: FormGroup;
  item: any;

  get AccountingGroupFormAction() {
    return this.AccountingGroupForm.get('AccountingGroupFormAction') as FormGroup;
  }
  constructor(private accountingGroupService: AccountinggroupService, private fb: FormBuilder) { }
  accountGroupGridObj: AccountingGroup[];
  accountGroupDDObj: AccountingGroup[];
  accountGridFilterObj: AccountingGroup[];
  fieldDisable: Boolean;
  textSaveBtn: string;

  createBtn: boolean;
  saveBtnMode: boolean;
  actionHeading: string;
  dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngOnInit() {
    this.dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
    this.actionHeading = 'Add New - Accounting Group ';
    this.saveBtnMode = true;
    this.createBtn = true;
    this.textSaveBtn = 'Save';
    this.getAccountingGroupGridDetails();
    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: ['', Validators.required],
        searchGroupName: ['', Validators.required],
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: [''],
        code: ['', Validators.required],
        groupName: ['', Validators.required]
      })
    });

  }

  //  removeExtraControls(){
  //   this.AccountingGroupFormAction.removeControl('createdBy');
  //   this.AccountingGroupFormAction.removeControl('createdOn');
  //   this.AccountingGroupFormAction.removeControl('isActive');
  //   this.AccountingGroupFormAction.removeControl('reMarks');
  //   this.AccountingGroupFormAction.removeControl('statusId');
  //   this.AccountingGroupFormAction.removeControl('WorkFlowId');
  //  }

  onBtnSaveAccountGroup() {
    this.AccountingGroupForm.get('AccountingGroupFormAction').markAllAsTouched();

    if (this.AccountingGroupForm.get('AccountingGroupFormAction').valid) {
      if (this.createBtn) {
        this.AccountingGroupForm.get('AccountingGroupFormAction').patchValue({
          accountHeadId: '0'
        });

        this.AccountingGroupFormAction.addControl('createdBy', new FormControl('1'));
        this.AccountingGroupFormAction.addControl('createdOn', new FormControl(new Date()));
        this.AccountingGroupFormAction.addControl('isActive', new FormControl('1'));
        this.AccountingGroupFormAction.addControl('reMarks', new FormControl(''));
        this.AccountingGroupFormAction.addControl('statusId', new FormControl('1'));
        this.AccountingGroupFormAction.addControl('WorkFlowId', new FormControl('1'));
      }



      let a = this.AccountingGroupForm.get('AccountingGroupFormAction').value;
      //console.log(a)
      this.accountingGroupService.createAccountingGroup(a).subscribe(a => {

        this.getAccountingGroupGridDetails();
      });

      this.onBtnClearAction();
      //  this.removeExtraControls();
    }
  }


  getAccountingGroupGridDetails(): void {
    this.accountingGroupService.getAccountingGroupGridDetails('ALL').subscribe(a => {
      this.accountGroupGridObj = a;
      this.accountGroupDDObj = a;

      this.dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
      this.dataSource.data = this.accountGroupGridObj = a;
      this.dataSource.paginator = this.paginator;
    });

  }

  btngvView_Click(a) {
    this.actionHeading = 'View - Accounting Group ';
    this.saveBtnMode = false;
    this.fieldDisable = true;
    this.accountGridFilterObj = this.accountGroupGridObj.filter((unit) => unit.accountingGroupId == a);

    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: this.accountGridFilterObj[0].accountingGroupId,
        code: this.accountGridFilterObj[0].code,
        groupName: this.accountGridFilterObj[0].groupName,

      })
    });
  }


  btngvEdit_Click(a) {
    this.actionHeading = 'Edit - Accounting Group ';
    this.saveBtnMode = true;

    this.createBtn = false;

    this.fieldDisable = false;
    this.accountGridFilterObj = this.accountGroupGridObj.filter((unit) => unit.accountingGroupId == a);

    this.AccountingGroupFormAction.addControl('createdBy', new FormControl('1'));
    this.AccountingGroupFormAction.addControl('createdOn', new FormControl(''));
    this.AccountingGroupFormAction.addControl('isActive', new FormControl(''));
    this.AccountingGroupFormAction.addControl('reMarks', new FormControl(''));
    this.AccountingGroupFormAction.addControl('statusId', new FormControl(''));
    this.AccountingGroupFormAction.addControl('WorkFlowId', new FormControl(''));



    this.AccountingGroupForm = this.fb.group({

      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: this.accountGridFilterObj[0].accountingGroupId,
        code: this.accountGridFilterObj[0].code,
        groupName: this.accountGridFilterObj[0].groupName,
        createdBy: '1',
        createdOn: new Date(),
        isActive: '1',
        reMarks: '1',
        statusId: '1',
        WorkFlowId: '1',
      })
    });
  }

  onBtnClearAction() {
    this.createBtn = true;
    this.actionHeading = 'Add New - Accounting Group ';
    this.fieldDisable = false;
    this.saveBtnMode = true;

    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: '',
        code: '',
        groupName: ''
      })
    });

  }

  getAccountingGroupBySearch() {
    this.AccountingGroupForm.get('AccountingGroupFormSearch').markAllAsTouched();
    if (this.AccountingGroupForm.get('AccountingGroupFormSearch').valid) {

      let a = this.AccountingGroupForm.get('AccountingGroupFormSearch.searchCode').value;
      let b = 0;
      let c = 0;
      //let d = this.AccountingGroupForm.get('AccountingGroupFormAction.searchGroupName').value;
      let r = this.accountGroupGridObj.filter((unit) => unit.accountingGroupId == a);
      console.log(r.length);
      let d;
      if(r.length){
         d = r[0].groupName;
      }else{
         d = 0;
      }
     // let d = r[0].groupName;
     
      if (a == "") {
        a = 0;
      }



      this.accountingGroupService.getAGGridDetailsBySearch(a, b, c, d).subscribe(s => {

      this.accountGroupGridObj = s;

      this.dataSource = new MatTableDataSource<AccountingGroup>(this.accountGroupGridObj);
      this.dataSource.data = this.accountGroupGridObj = s;
      this.dataSource.paginator = this.paginator;

      });
    }

  }
  clearSearchAccountHead() {
    this.AccountingGroupForm = this.fb.group({
      AccountingGroupFormSearch: this.fb.group({
        searchCode: '',
        searchGroupName: '',
      }),
      AccountingGroupFormAction: this.fb.group({
        accountingGroupId: '',
        code: '',
        groupName: ''
      })
    });
    this.getAccountingGroupGridDetails();
  }
  createItem() {
    return this.fb.group({
      name: ['Jon'],
      surname: ['Doe']
    })
  }


  cfn(a) {
    console.log(a);
  }


}
