import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { MasterPageComponent } from './master-page/master-page.component';
import { MastersComponent } from './masters/masters.component';
import { DepartmentComponent } from './masters/department/department.component';
import { InsurerComponent } from './masters/insurer/insurer.component';
import { ZoneComponent } from './masters/zone/zone.component';
import { DivisionComponent } from './masters/division/division.component';
import { BranchComponent } from './masters/branch/branch.component';
import { OrganizationComponent } from './masters/organization/organization.component';
import { DesignationComponent } from './masters/designation/designation.component';
import { GradeComponent } from './masters/grade/grade.component';
import { ProductComponent } from './masters/product/product.component';
import { VariantComponent } from './masters/variant/variant.component';
import { PremiumComponent } from './masters/premium/premium.component';
import { PremiumpaymentfrequencyComponent } from './masters/premiumpaymentfrequency/premiumpaymentfrequency.component';
import { LoadinganddiscountComponent } from './masters/loadinganddiscount/loadinganddiscount.component';
import { FchannelComponent } from './masters/fchannel/fchannel.component';
import { FsaleshierarchyComponent } from './masters/fsaleshierarchy/fsaleshierarchy.component';
import { UserComponent } from './masters/user/user.component';
import { GroupComponent } from './masters/group/group.component';
import { PrivilegesComponent } from './masters/privileges/privileges.component';
const routes: Routes = [
  {
    path: 'registration',
    component: RegistrationComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'masters',
  
    children: [                         //<---- child components declared here
      {
        path: 'department',
        component: DepartmentComponent
      },
      {
        path: 'insurer',
        component: InsurerComponent
      },
      {
        path: 'organization',
        component: OrganizationComponent
      },
      {
        path: 'designation',
        component: DesignationComponent
      },
      {
        path: 'grade',
        component: GradeComponent
      },
      {
        path: 'grade',
        component: GradeComponent
      },
      {
        path: 'zone',
        component: ZoneComponent
      },
      {
        path: 'division',
        component: DivisionComponent
      },
      {
        path: 'branch',
        component: BranchComponent
      }
      ,
      {
        path: 'product',
        component: ProductComponent
      } ,
      {
        path: 'product',
        component: ProductComponent
      },
      {
        path: 'variant',
        component: VariantComponent
      },
      {
        path: 'premium',
        component: PremiumComponent
      },
      {
        path: 'premiumpaymentfrequency',
        component: PremiumpaymentfrequencyComponent
      }
      ,
      {
        path: 'loadinganddiscount',
        component: LoadinganddiscountComponent
      },
      {
        path: 'fchannel',
        component: FchannelComponent
      },
      {
        path: 'fsaleshierarchy',
        component: FsaleshierarchyComponent
      }
      ,
      {
        path: 'user',
        component: UserComponent
      }
      ,
      {
        path: 'group',
        component: GroupComponent
      }
      ,
      {
        path: 'privileges',
        component: PrivilegesComponent
      }
    ]
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


}
