import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loadinganddiscount',
  templateUrl: './loadinganddiscount.component.html',
  styleUrls: ['./loadinganddiscount.component.css']
})
export class LoadinganddiscountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
