import { Component, OnInit } from '@angular/core';
import { DepartmentType } from './departmentType';

import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DepartmentService } from './department.service';

import {TooltipPosition} from '@angular/material/tooltip';
import { Key } from 'protractor';



@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})

export class DepartmentComponent implements OnInit {

 

tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);


departmentObj: DepartmentType[];
departmentFilteredObj : DepartmentType[] = [];

  departmentColumns: string[] = [  'View', 'Edit', 'Delete','description', 'shortName'];


  constructor( private departmentService: DepartmentService, private fb: FormBuilder) { }

  DepartmentForm: FormGroup;

  ActionGroupDepartment: FormGroup;


 


  ngOnInit() {
    this.getDepartmentDetails();

  
    this.DepartmentForm = this.fb.group({
      SearchDescription: [''],
    ActionGroupDepartment : this.fb.group({
        id: [''],
        description: ['', Validators.required],
        shortName: ['', Validators.required]
  
      })
  
  
  });

     this.onChanges();
  }
  onChanges() {
   // this.DepartmentForm.valueChanges.subscribe(x => console.log(JSON.stringify(x)));
   //console.log("hi");

 
  }

  onBtnSaveClick(): void {
let a = this.DepartmentForm.controls.ActionGroupDepartment.value;
   
    this.departmentService.addDepartment(a)
      .subscribe(a => {
        this.departmentObj.push(a);
      });
  }
 
  onBtnUpdateClick():void {
    if(this.DepartmentForm.controls.ActionGroupDepartment.valid){
     
       // console.log(this.DepartmentForm.);
       
         
        this.departmentService.updateDepartment(this.DepartmentForm.controls.ActionGroupDepartment.value)
          .subscribe();
     
      
    }
  }
  onBtnResetClick(){
   // this.DepartmentForm.reset();
   
    this.DepartmentForm.controls.ActionGroupDepartment.reset();

    this.DepartmentForm = this.fb.group({
  
      ActionGroupDepartment : this.fb.group({
        id: {value:'', disabled: false},
          description: {value:'', disabled: false},
          shortName: {value:'', disabled: false},
  
        })
  
  
    });
   
  }

  getDepartmentDetails(): void {
   
     this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => this.departmentObj = departmentObj);
     
   }


   getDepartmentInfoByDescription(): void {
 

      if(this.DepartmentForm.controls.SearchDescription.valid){
          //console.log(this.DepartmentForm.controls.SearchDescription.value);
          let searchValue = this.DepartmentForm.controls.SearchDescription.value;
         
            this.departmentService.getDepartmentInfoByDescription(searchValue)
              .subscribe(departmentObj => this.departmentObj = departmentObj);
      }

  }

  clearDepartmentInfoByID(){
    this.DepartmentForm.controls.SearchDescription.reset();
    this.getDepartmentDetails();
  }

   btngvView_Click(a){
 
   //this.departmentFilteredObj = new DepartmentType[];
     this.departmentFilteredObj = this.departmentObj.filter( (unit) => unit.id == a );

    // console.log(this.departmentFilteredObj[0].description);
    
 
  
    this.DepartmentForm = this.fb.group({

      SearchDescription: [''],
  
      ActionGroupDepartment : this.fb.group({
          id: {value: this.departmentFilteredObj[0].id, disabled: true},
          description: {value: this.departmentFilteredObj[0].description, disabled: true},
          shortName: {value: this.departmentFilteredObj[0].shortName, disabled: true}
  
        })
  
  
    });

    


     this.DepartmentForm.patchValue({

    //  Description: this.departmentFilteredObj.filter( (unit) => unit.Description.indexOf(id) > -1 )
     });
   }


   btngvEdit_Click(a){
      this.departmentFilteredObj = this.departmentObj.filter( (unit) => unit.id == a );
   
     this.DepartmentForm = this.fb.group({
 
       SearchDescription: [''],
   
       ActionGroupDepartment : this.fb.group({
          id: {value: this.departmentFilteredObj[0].id, disabled: false},
           description: {value: this.departmentFilteredObj[0].description, disabled: false},
           shortName: {value: this.departmentFilteredObj[0].shortName, disabled: false}
   
         })
   
   
     });
    }



   consoleLogFn(val){
    console.log(val);
   }

  
}
