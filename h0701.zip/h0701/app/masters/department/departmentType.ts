export interface DepartmentType {
    id: number;
    description: string;
    shortName: string;
}