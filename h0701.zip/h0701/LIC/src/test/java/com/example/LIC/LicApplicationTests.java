package com.example.LIC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicApplicationTests {

	@Test
	void contextLoads() {
	}

}
