package com.example.LIC.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table
@Getter
@Setter

@NamedStoredProcedureQuery(name = "firstProcedure", procedureName = "spGetAllDepartment", resultClasses = DepartmentModel.class) 

@NamedStoredProcedureQuery(name = "secondProcedure", procedureName = "spgetDepartmentInfoByID",
	parameters = {
			@StoredProcedureParameter(mode = ParameterMode.IN, name = "deptID", type = String.class) } , resultClasses = DepartmentModel.class)

@NamedStoredProcedureQuery(name = "DepartmentInfoByDescription", procedureName = "spgetDepartmentInfoByDescription",
parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "sdescription", type = String.class) } , resultClasses = DepartmentModel.class)

@NamedStoredProcedureQuery(name = "updateDepartmentInfo", procedureName = "spUpdateDepartment",
parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pid", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pdescription", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pshortname", type = String.class)} , resultClasses = DepartmentModel.class)


@NamedStoredProcedureQuery(name = "createDepartment", procedureName = "spcreateDepartment",
parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pid", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pdescription", type = String.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "pshortname", type = String.class)} , resultClasses = DepartmentModel.class)
public class DepartmentModel  {
	@Id
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String description;
	private String shortName;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
}