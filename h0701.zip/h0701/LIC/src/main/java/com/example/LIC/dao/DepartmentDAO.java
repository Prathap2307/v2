package com.example.LIC.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.LIC.model.DepartmentModel;

@Repository
public class DepartmentDAO {
	@Autowired
	private EntityManager em;

	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfo() {
		return em.createNamedStoredProcedureQuery("firstProcedure").getResultList();
	}
	

	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfoByID(String input) {
		return em.createNamedStoredProcedureQuery("secondProcedure").setParameter("deptID", input).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<DepartmentModel> getDepartmentInfoByDescription(String input) {
		return em.createNamedStoredProcedureQuery("DepartmentInfoByDescription").setParameter("sdescription", input).getResultList();
	}
	
	//@SuppressWarnings("unchecked")
	public void updateDepartmentInfoByID(Integer id, DepartmentModel singleDept) {
		 //em.createNamedStoredProcedureQuery("updateDepartmentInfo").setParameter("pshortname", shortname).getResultList();
		em.createNamedStoredProcedureQuery("updateDepartmentInfo")
		.setParameter("pid", id)
		.setParameter("pdescription", singleDept.getDescription())
		.setParameter("pshortname", singleDept.getShortName())
		.getResultList();
	}
	
	public void createDepartmentInfo(DepartmentModel singleDept) {
		
		 
		// Getting the named stored procedure from the persistence unit and settting the parameters values.
		StoredProcedureQuery addDepartmentStoredProcedure = em.createNamedStoredProcedureQuery("createDepartment");
		addDepartmentStoredProcedure.setParameter("pid", singleDept.getId());
		addDepartmentStoredProcedure.setParameter("pdescription", singleDept.getDescription());
		addDepartmentStoredProcedure.setParameter("pshortname", singleDept.getShortName());
		//addDepartmentStoredProcedure.getResultList();
		// Stored procedure call
		//Integer createdBookId = (Integer) addDepartmentStoredProcedure.getSingleResult();
		
		//return createdBookId.toString();
	}
}
