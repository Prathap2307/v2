package com.example.aurora.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;



import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import javax.persistence.ParameterMode;
import javax.persistence.SqlResultSetMapping;
@Entity
@Table
@Getter
@Setter

@RequiredArgsConstructor


  @NamedStoredProcedureQueries({
	  @NamedStoredProcedureQuery(name = "firstProcedure", procedureName = "getTickets", resultClasses = { Ticket.class}
			  
			  ),
  @NamedStoredProcedureQuery(name = "secondProcedure", procedureName =
  "getTicketsByCatagory", parameters = {
  
  @StoredProcedureParameter(mode = ParameterMode.IN, name = "tcatagory", type =
  String.class) }) })
 




//@NamedStoredProcedureQueries({ @NamedStoredProcedureQuery(name = "firstProcedure", procedureName = "getTickets",resultClasses = Ticket.class)})

public class Ticket {
	@Id
	@GeneratedValue
	//@SqlResultSetMapping(name = "firstProcedure")
	private int id;
	private int amount;
	private String catagory;
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
}

/*
 * , parameters = {
 * 
 * @StoredProcedureParameter(mode = ParameterMode.OUT, type = Integer.class,
 * name = "id"),
 * 
 * @StoredProcedureParameter(mode = ParameterMode.OUT, type = Integer.class,
 * name = "amount"),
 * 
 * @StoredProcedureParameter(mode = ParameterMode.OUT, type = String.class, name
 * = "catagory") }
 */

/*
 * parameters={
 * 
 * @StoredProcedureParameter(name="id", type=Integer.class,
 * mode=ParameterMode.OUT),
 * 
 * @StoredProcedureParameter(name="amount", type=Integer.class,
 * mode=ParameterMode.OUT),
 * 
 * @StoredProcedureParameter(name="catagory", type=String.class,
 * mode=ParameterMode.OUT) }
 */
 
