package com.example.aurora.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.stereotype.Repository;

import com.example.aurora.model.Ticket;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class TicketDao {
	@Autowired
	private EntityManager em;

	@SuppressWarnings("unchecked")
	public List<Ticket> getTicketInfo() {
		List<Ticket> alltickets = em.createNamedStoredProcedureQuery("firstProcedure").getResultList();
		//alltickets = em.createNamedStoredProcedureQuery("firstProcedure").getResultList();
		return  alltickets;
		
		//return  em.createNamedStoredProcedureQuery("firstProcedure").getResultList();
		//return (List<Ticket>) em.createNamedStoredProcedureQuery("firstProcedure").getSingleResult();
		
		//return (List<Ticket>) em.createNamedStoredProcedureQuery("firstProcedure").getSingleResult();
		/*
		 * List<Ticket> rows =
		 * em.createNamedStoredProcedureQuery("firstProcedure").getResultList(); return
		 * rows;
		 */
	}

	@SuppressWarnings("unchecked")
	public List<Ticket> getTicketInfoByCatagory(String input) {
		return em.createNamedStoredProcedureQuery("secondProcedure").setParameter("tcatagory", input).getResultList();
	}
}
