package com.example.aurora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuroraApplicationTests {

	@Test
	void contextLoads() {
	}

}
