import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './mcore-product/modules/login/login/login.component';
import { DepartmentComponent } from './mcore-product/modules/masters/department/department.component';
import { InsurerComponent } from './mcore-product/modules/masters/insurer/insurer.component';
import { ZoneComponent } from './mcore-product/modules/masters/zone/zone.component';
import { DivisionComponent } from './mcore-product/modules/masters/division/division.component';
import { BranchComponent } from './mcore-product/modules/masters/branch/branch.component';
import { OrganizationComponent } from './mcore-product/modules/masters/organization/organization.component';
import { DesignationComponent } from './mcore-product/modules/masters/designation/designation.component';
import { GradeComponent } from './mcore-product/modules/masters/grade/grade.component';
import { ProductComponent } from './mcore-product/modules/masters/product/product.component';
import { VariantComponent } from './mcore-product/modules/masters/variant/variant.component';
import { PremiumComponent } from './mcore-product/modules/masters/premium/premium.component';
import { PremiumpaymentfrequencyComponent } from './mcore-product/modules/masters/premiumpaymentfrequency/premiumpaymentfrequency.component';
import { LoadinganddiscountComponent } from './mcore-product/modules/masters/loadinganddiscount/loadinganddiscount.component';
import { FchannelComponent } from './mcore-product/modules/masters/fchannel/fchannel.component';
import { FsaleshierarchyComponent } from './mcore-product/modules/masters/fsaleshierarchy/fsaleshierarchy.component';
import { UserComponent } from './mcore-product/modules/masters/user/user.component';
import { GroupComponent } from './mcore-product/modules/masters/group/group.component';
import { PrivilegesComponent } from './mcore-product/modules/masters/privileges/privileges.component';
import { LookupComponent } from './mcore-product/modules/masters/lookup/lookup.component';
import { BankmasterComponent } from './mcore-product/modules/masters/bankmaster/bankmaster.component';
import { AddressstructureComponent } from './mcore-product/modules/masters/addressstructure/addressstructure.component';
import { DestinationdocumentuploadComponent } from './mcore-product/modules/masters/destinationdocumentupload/destinationdocumentupload.component';
import { BankbranchComponent } from './mcore-product/modules/masters/bankbranch/bankbranch.component';
import { CoveragesComponent } from './mcore-product/modules/masters/coverages/coverages.component';
import { QuestionsComponent } from './mcore-product/modules/masters/questions/questions.component';
import { TaxstructureComponent } from './mcore-product/modules/masters/taxstructure/taxstructure.component';
import { StampdutyComponent } from './mcore-product/modules/masters/stampduty/stampduty.component';
import { CommissionComponent } from './mcore-product/modules/masters/commission/commission.component';
import { AuthorisedsignatoryComponent } from './mcore-product/modules/masters/authorisedsignatory/authorisedsignatory.component';
import { ClientorganizationComponent } from './mcore-product/modules/customer/clientorganization/clientorganization.component';
import { MasterpolicyComponent } from './mcore-product/modules/customer/masterpolicy/masterpolicy.component';
import { AdvancedepositreceiptingComponent } from './mcore-product/modules/customer/advancedepositreceipting/advancedepositreceipting.component';
import { AffinityquestionmapComponent } from './mcore-product/modules/customer/affinityquestionmap/affinityquestionmap.component';
import { AdvancedepositreceiptComponent } from './mcore-product/modules/customer/advancedepositreceipt/advancedepositreceipt.component';
import { MemberuploadComponent } from './mcore-product/modules/newbusiness/memberupload/memberupload.component';
import { DefectdataComponent } from './mcore-product/modules/newbusiness/defectdata/defectdata.component';
import { PolicyviewinformationComponent } from './mcore-product/modules/newbusiness/policyviewinformation/policyviewinformation.component';
import { MAEndorsementComponent } from './mcore-product/modules/endorsement/maendorsement/maendorsement.component';

import { MemberdeletionComponent } from './mcore-product/modules/endorsement/memberdeletion/memberdeletion.component';
import { SumassuredendorsementComponent } from './mcore-product/modules/endorsement/sumassuredendorsement/sumassuredendorsement.component';
import { NmendorsementComponent } from './mcore-product/modules/endorsement/nmendorsement/nmendorsement.component';
import { AccountingprocessComponent } from './mcore-product/modules/accounting/accountingprocess/accountingprocess.component';
import { AccountingclassificationComponent } from './mcore-product/modules/accounting/accountingclassification/accountingclassification.component';
import { ProcesstaxmappingComponent } from './mcore-product/modules/accounting/processtaxmapping/processtaxmapping.component';

import { DayclosemonitorComponent } from './mcore-product/modules/accounting/dayclosemonitor/dayclosemonitor.component';
import { VoucherreportComponent } from './mcore-product/modules/accounting/voucherreport/voucherreport.component';
import { GlconfigurationsComponent } from './mcore-product/modules/accounting/glconfigurations/glconfigurations.component';
import { AccountinggroupComponent } from './mcore-product/modules/accounting/accountinggroup/accountinggroup.component';
import { AccountingheadComponent } from './mcore-product/modules/accounting/accountinghead/accountinghead.component';
import { AccountingsubheadComponent } from './mcore-product/modules/accounting/accountingsubhead/accountingsubhead.component';
import { QuotationComponent } from './mcore-product/modules/masters/quotation/quotation.component';

import { UnderwritinglevelComponent } from './mcore-product/modules/underwriting/underwritinglevel/underwritinglevel.component';
import { UnderwritingruleComponent } from './mcore-product/modules/underwriting/underwritingrule/underwritingrule.component';
import { UnderwritingpoolComponent } from './mcore-product/modules/underwriting/underwritingpool/underwritingpool.component';
import { UnderwritingmedicalComponent } from './mcore-product/modules/underwriting/underwritingmedical/underwritingmedical.component';
import { UnderwritingpendingpaymentComponent } from './mcore-product/modules/underwriting/underwritingpendingpayment/underwritingpendingpayment.component';
import { MasterPageComponent } from './mcore-product/mcore-common/core/master-page/master-page.component';
import { FsubChannelComponent } from './mcore-product/modules/masters/fsub-channel/fsub-channel.component';
import { ChangePasswordComponent } from './mcore-product/modules/masters/change-password/change-password.component';
import { DashboardComponent } from './mcore-product/modules/account/dashboard/dashboard.component';
const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'account',
    component: MasterPageComponent,
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent
      }
    ]
  },

  {
    path: 'masters',
    component: MasterPageComponent,
    children: [   //<---- child components declared here
      {
        path: 'lookup',
        component: LookupComponent
      },
      {
        path: 'bankmaster',
        component: BankmasterComponent
      },
      {
        path: 'bankbranch',
        component: BankbranchComponent
      },
      {
        path: 'addressstructure',
        component: AddressstructureComponent
      },
      {
        path: 'destinationdocumentupload',
        component: DestinationdocumentuploadComponent
      },
      {
        path: 'department',
        component: DepartmentComponent
      },
      {
        path: 'insurer',
        component: InsurerComponent
      },
      {
        path: 'organization',
        component: OrganizationComponent
      },
      {
        path: 'designation',
        component: DesignationComponent
      },
      {
        path: 'grade',
        component: GradeComponent
      },
      {
        path: 'grade',
        component: GradeComponent
      },
      {
        path: 'zone',
        component: ZoneComponent
      },
      {
        path: 'division',
        component: DivisionComponent
      },
      {
        path: 'branch',
        component: BranchComponent
      }
      ,
      {
        path: 'product',
        component: ProductComponent
      },
      {
        path: 'product',
        component: ProductComponent
      },
      {
        path: 'variant',
        component: VariantComponent
      },
      {
        path: 'premium',
        component: PremiumComponent
      },
      {
        path: 'premiumpaymentfrequency',
        component: PremiumpaymentfrequencyComponent
      }
      ,
      {
        path: 'loadinganddiscount',
        component: LoadinganddiscountComponent
      },
      {
        path: 'fchannel',
        component: FchannelComponent
      },
      {
        path: 'fsaleshierarchy',
        component: FsaleshierarchyComponent
      }
      ,
      {
        path: 'user',
        component: UserComponent
      }
      ,
      {
        path: 'group',
        component: GroupComponent
      }
      ,
      {
        path: 'privileges',
        component: PrivilegesComponent
      },
      {
        path: 'branch',
        component: BranchComponent
      },
      {
        path: 'coverages',
        component: CoveragesComponent
      },
      {
        path: 'questions',
        component: QuestionsComponent
      },
      {
        path: 'taxstructure',
        component: TaxstructureComponent
      },
      {
        path: 'stampduty',
        component: StampdutyComponent
      },
      {
        path: 'commission',
        component: CommissionComponent
      },
      {
        path: 'authorisedsignatory',
        component: AuthorisedsignatoryComponent
      },
      {
        path: 'fsubchannel',
        component: FsubChannelComponent
      },

      {
        path: 'quotation',
        component: QuotationComponent
      },
      {
        path: 'changepassword',
        component: ChangePasswordComponent
      }
    ]
  },
  {
    path: 'customer',
    component: MasterPageComponent,
    children: [   //<---- child components declared here
      {
        path: 'clientorganization',
        component: ClientorganizationComponent
      },
      {
        path: 'masterpolicy',
        component: MasterpolicyComponent
      },
      {
        path: 'advacedepositreceipting',
        component: AdvancedepositreceiptingComponent
      },
      {
        path: 'affinityquestionmap',
        component: AffinityquestionmapComponent
      },
      {
        path: 'advancedepositreceipt',
        component: AdvancedepositreceiptComponent
      }
    ]
  },
  {
    path: 'newbusiness',
    component: MasterPageComponent,
    children: [   //<---- child components declared here
      {
        path: 'defectdata',
        component: DefectdataComponent
      },
      {
        path: 'memberupload',
        component: MemberuploadComponent
      },
      {
        path: 'policyviewinformation',
        component: PolicyviewinformationComponent
      }
    ]
  },
  {
    path: 'endorsement',
    component: MasterPageComponent,
    children: [
      {
        path: 'maendorsement',
        component: MAEndorsementComponent
      },
      {
        path: 'memberdeletion',
        component: MemberdeletionComponent
      },
      {
        path: 'sumassuredendorsement',
        component: SumassuredendorsementComponent
      },
      {
        path: 'nmendorsement',
        component: NmendorsementComponent
      }
    ]
  },
  {
    path: 'underwriting',
    component: MasterPageComponent,
    children:
      [
        {
          path: 'underwritinglevel',
          component: UnderwritinglevelComponent
        },
        {
          path: 'underwritingrule',
          component: UnderwritingruleComponent
        },
        {
          path: 'underwritingmedical',
          component: UnderwritingmedicalComponent
        },
        {
          path: 'underwritingpool',
          component: UnderwritingpoolComponent
        },
        {
          path: 'underwritingpendingpayment',
          component: UnderwritingpendingpaymentComponent
        }
      ]
  },
  {
    path: 'accounting',
    component: MasterPageComponent,
    children: [
      {
        path: 'accountingprocess',
        component: AccountingprocessComponent
      },
      {
        path: 'processtaxmapping',
        component: ProcesstaxmappingComponent
      },
      {
        path: 'accountingclassification',
        component: AccountingclassificationComponent
      },
      {
        path: 'accountinggroup',
        component: AccountinggroupComponent
      },
      {
        path: 'accountinghead',
        component: AccountingheadComponent
      },
      {
        path: 'accountingsubhead',
        component: AccountingsubheadComponent
      },

      {
        path: 'glconfigurations',
        component: GlconfigurationsComponent
      },
      {
        path: 'voucherreport',
        component: VoucherreportComponent
      },
      {
        path: 'dayclosemonitor',
        component: DayclosemonitorComponent
      }
    ]
  }
  ,

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


}
