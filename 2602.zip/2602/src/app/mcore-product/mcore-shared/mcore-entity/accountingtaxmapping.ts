

export interface AccountingTaxProcess {
    processID: number;
    processName: string;
}


export interface ModeObjDropDown {
    modeDropDownID: number;
    modeDropDownText: string;
}
export interface BasedOnObjDropDown {
    basedOnDropDownID: number;
    basedOnDropDownText: string;
}

export interface TaxStructure {
    taxStructureID: number;
    taxStructureDetailID: number;
    taxProcessID: number;
    taxStructureName: string;
    taxMappingID: number;
    description: string;
}

export interface AccountingTaxMapping {
    taxStructureName: string;
    parentTax: number;
    taxStructureDetailsName: string;
    taxStructureID: number;
    taxStructureDetailID: number;
    taxProcessID: number;
    taxMappingID: number;
    createdBy: number;

    description: string
    fromDate: Date
    toDate: Date
    exemptedInID: number
    parentsTaxStructure: number
    modes: number
    modeName: string;
    hierarchyID: number;
    taxValue: number;
    isReferred: number;
}
