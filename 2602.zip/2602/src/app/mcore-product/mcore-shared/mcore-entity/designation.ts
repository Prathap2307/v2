export interface Designation {
    designationId: number;
    departmentId: number;
    shortName: string;
	id: number;
	searchId: number;
    description: string;
    createdBy: number;
    createdOn: Date;
    deletedBy:  number;
    deletedOn:  Date;
	searchdepartmentName: string;
	searchdesignationName: string;
}	