export class Division {
    divisionName: string;
    divisionCode: string;
    zone: string;
	workingDate: string;
	addressOne: number;
	addressTwo: number;
	addressThree: number;
	zipCode: number;
	country: string;
	state: string;
	district: string;
	postOffice: string;
	emailId: string;
	phoneNumber: number;
	mobileNumber: number;
}