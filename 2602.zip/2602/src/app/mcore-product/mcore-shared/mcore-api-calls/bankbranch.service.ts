import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BankBranch } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';
@Injectable({
  providedIn: 'root'
})
export class BankbranchService {
  baseUrl = environment.API_URL;
  constructor(
    private http: HttpClient
  ) { }
  //bankBranchUrl = this.baseUrl + '/'  ;
  // getSearchBankBranchdetails(branchId: number, bankId: number, bankCityId: number, description: string, ifscCode: string, micrCode: string): Observable<BankBranch[]> {
  //   const BankBranchSearchUrl = this.baseUrl + `/bankBranch/${branchId}/${bankId}/${bankCityId}/${description}/${ifscCode}/${micrCode}`;
  //   return this.http.get<BankBranch[]>(BankBranchSearchUrl).pipe();
  // }

  // Search Bank Branch

  bankBranchSearchUrl = this.baseUrl + '/bankBranch';
  getSearchBankBranchdetails(bankBranch: BankBranch): Observable<BankBranch[]>{
    return this.http.post<BankBranch[]>(this.bankBranchSearchUrl,bankBranch).pipe();
  }
  // Get Grid Bank Branch
  BankBranchUrl = this.baseUrl + '/allbankbranch';
  getBankBranchdetails(): Observable<BankBranch[]> {
    return this.http.get<BankBranch[]>(this.BankBranchUrl).pipe();
  }
  // Create a Bank Branch
  createBankBranchUrl = this.baseUrl + '/createBankBranch';
  insertbankBranch(bankBranch: BankBranch): Observable<BankBranch> {
    return this.http.post<BankBranch>(this.createBankBranchUrl, bankBranch);
  }
  // Delete Bank Branch
  deleteBankBranch(bankBranchRow: BankBranch): Observable<BankBranch> {
    const deleteBankBranchUrl = this.baseUrl + `/deleteBankBranch`;
    return this.http.put<BankBranch>(deleteBankBranchUrl, bankBranchRow).pipe();
  }
  // Get Bank Select Details
  getBankBranchNameDetails(): Observable<BankBranch[]> {
    const BankBranchByNameUrl = this.baseUrl + `/bankBranchBank`;
    return this.http.get<BankBranch[]>(BankBranchByNameUrl).pipe();
  }
   // Get Bank City Select Details
  getBankBranchCityDetails(bankId: number): Observable<BankBranch[]> {
    const BankBranchCityNameByUrl = this.baseUrl + `/bankBranchCity/${bankId}`;
    return this.http.get<BankBranch[]>(BankBranchCityNameByUrl).pipe();
  }
}
