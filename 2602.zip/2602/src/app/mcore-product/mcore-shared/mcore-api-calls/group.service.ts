import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class GroupService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }


  

  GetAllEmployeesByGroupID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetAllEmployeesByGroupID' + id).pipe(tap((response) => response));
    }

 
  

    GetGroupDetailsSearch(name:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetGroupDetailsSearch' + name).pipe(tap((response) => response));
    }

    GetPopupSearchGroupDetails(data:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetPopupSearchGroupDetails' + data).pipe(tap((response) => response));
    }

    GetGroupDetailsByGroupID(data:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetGroupDetailsByGroupID' + data).pipe(tap((response) => response));
    }

    GetSearchGroupDetailsByGroupName(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetSearchGroupDetailsByGroupName' + id).pipe(tap((response) => response));
    }

    GetUserGroupModulesFeaturesRolesByID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/GetUserGroupModulesFeaturesRolesByID' + id).pipe(tap((response) => response));
    }

    InsertBranchIDBySalesHierarchyID(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/InsertBranchIDBySalesHierarchyID' + id).pipe(tap((response) => response));
    }
    IsExistsGroupByLevelID(name:any): Observable<any>{
      return this.http.get(this.baseUrl + '/IsExistsGroupByLevelID' + name).pipe(tap((response) => response));
    }

    InsertOrUpdateGroupDetailsUserMap(id:any): Observable<any>{
      return this.http.get(this.baseUrl + '/InsertOrUpdateGroupDetailsUserMap' + id).pipe(tap((response) => response));
    }

    DeleteGroupDetailsUserMAp(name:any): Observable<any>{
      return this.http.get(this.baseUrl + '/DeleteGroupDetailsUserMAp' + name).pipe(tap((response) => response));
    }



   


    
}
