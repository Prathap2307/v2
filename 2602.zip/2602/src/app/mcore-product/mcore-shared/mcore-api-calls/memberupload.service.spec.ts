import { TestBed } from '@angular/core/testing';

import { MemberuploadService } from './memberupload.service';

describe('MemberuploadService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MemberuploadService = TestBed.get(MemberuploadService);
    expect(service).toBeTruthy();
  });
});
