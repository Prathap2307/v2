import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { AccountingTaxMapping, AccountingTaxProcess, TaxStructure } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingtaxmapping';
@Injectable({
  providedIn: 'root'
})
export class AccountingprocesstaxmappingService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }


  getAllTaxProcess(): Observable<AccountingTaxProcess[]> {
    const allATMUrl = this.baseUrl + `/GetAllTaxProcess`;
     return this.http.get<AccountingTaxProcess[]>(allATMUrl)
       .pipe();
   }

   
   getAllTaxStructure(a: TaxStructure[]): Observable<TaxStructure[]> {
   const allATSUrl = this.baseUrl + `/GetAllTaxStructureBasedonTaxName`;
     return this.http.post<TaxStructure[]>(allATSUrl, a);
   }

  createPTMUrl = this.baseUrl + '/CreateProcessTaxMap';
  createProcessTaxMap(a: AccountingTaxMapping[]): Observable<AccountingTaxMapping[]> {
    return this.http.post<AccountingTaxMapping[]>(this.createPTMUrl, a);
  }

  getTaxProcessDetailsByID(a: number): Observable<AccountingTaxMapping[]> {
    const allATUrl = this.baseUrl + `/TaxProcessDetailsByID/${a}`;
   // console.log(allATUrl);
    return this.http.get<AccountingTaxMapping[]>(allATUrl)
      .pipe();
  }

}
