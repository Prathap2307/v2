import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { AccountingClassification } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingclassificatin';

@Injectable({
    providedIn: 'root'
})

export class AccountingClassificationService {
    baseUrl = environment.API_URL;

    constructor(private http: HttpClient) { }

    allAccountingClassificationIDUrl = this.baseUrl + '/GetAllClassifications';


    // getAllClassificationdropdownDetails(): Observable<AccountingClassification[]> {
    //     return this.http.get<AccountingClassification[]>(this.accountingclassificationUrl)
    //         .pipe();
    // }

    getAccountingClassificationDetails(): Observable<AccountingClassification[]> {
        //const allAccountingClassificationIDUrl = this.baseUrl + `/GetAllClassifications`;
        return this.http.get<AccountingClassification[]>(this.allAccountingClassificationIDUrl)
          .pipe();
      }

createACUrl = this.baseUrl + '/CreateClassifications';
createAC(ac: AccountingClassification): Observable<AccountingClassification>{
      return this.http.post<AccountingClassification>(this.createACUrl, ac);
  }



  getACDetailsBySearch(a: number, b: number, c: number): Observable<AccountingClassification[]> {

    const acBySearchUrl = this.baseUrl + `/SearchAccountingClassification/${a}/${b}/${c}`;
console.log(acBySearchUrl);
    return this.http.get<AccountingClassification[]>(acBySearchUrl)
      .pipe();
  }

}