import { TestBed } from '@angular/core/testing';

import { FchannelService } from './fchannel.service';

describe('FchannelService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FchannelService = TestBed.get(FchannelService);
    expect(service).toBeTruthy();
  });
});
