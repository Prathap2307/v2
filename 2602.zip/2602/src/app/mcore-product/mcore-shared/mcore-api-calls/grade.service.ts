import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

import { HttpClient, HttpResponse } from '@angular/common/http';

import { Grade } from 'src/app/mcore-product/mcore-shared/mcore-entity/grade';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class GradeService {
  baseUrl = environment.API_URL;

  constructor(private http: HttpClient) { }


  

  /* GET Grade */
  getGradeDetails(a): Observable<Grade[]> {
   const url = this.baseUrl + `/grade/${a}`;
    return this.http.get<Grade[]>(url)
      .pipe();
  }


  /* GET Grade by ID */
  getGradeInfoByDescription(organisationId: number): Observable<Grade[]> {

    const gradeByIDUrl = this.baseUrl + `/grade/${organisationId}`;

    // return this.http.get<Hero>(url).pipe(
    //   tap(_ => this.log(`fetched hero id=${id}`)),
    //   catchError(this.handleError<Hero>(`getHero id=${id}`))
    // );

    console.log(gradeByIDUrl);
    return this.http.get<Grade[]>(gradeByIDUrl)
      .pipe();
  }

 


  // log(arg0: string): void {
  //   throw new Error("Method not implemented.");
  // }
  handleError<T>(arg0: string): (err: any, caught: Observable<any>) => import("rxjs").ObservableInput<any> {
    throw new Error("Method not implemented.");
  }
  consoleLogFn(val) {
    console.log(val);
  }

  creategradeUrl = this.baseUrl + '/createGrade';
  addGrade(gradeRow: Grade): Observable<Grade> {
    //console.log(this.creategradeUrl);
    //console.log(gradeRow);
    return this.http.post<Grade>(this.creategradeUrl, gradeRow);
  }


  // log(arg0: string): void {
  //   throw new Error("Method not implemented.");
  // }

    /** DELETE: delete the hero from the server */
    deleteGrade (gradeRow: Grade): Observable<{}> {      
		const deletegradeUrl = this.baseUrl + `/deleteGrade`;
    return this.http.put<Grade>(deletegradeUrl, gradeRow)
    .pipe();
    }



}
