import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/internal/operators/tap';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl = environment.API_URL;
  constructor(private http: HttpClient) { }
  GetLineofBusinessMapByUserID(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetLineofBusinessMapByUserID' + id).pipe(tap((response) => response));
  }

  GetSearchUser(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetSearchUser' + id).pipe(tap((response) => response));
  }

  GetUserModulesFeatureByUserID(): Observable<any> {
    return this.http.get(' http://demo7634362.mockable.io/getuser').pipe(tap((response) => response));
  }
  GetUserGroupModulesFeaturesRolesByID(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetUserGroupModulesFeaturesRolesByID' + id).pipe(tap((response) => response));
  }
  GetAllUnderWritingUserRuleLevel(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAllUnderWritingUserRuleLevel' + id).pipe(tap((response) => response));
  }
  GetUserRoles(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetUserRoles' + id).pipe(tap((response) => response));
  }


  IsUserExistForDesignation(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/IsUserExistForDesignation' + id).pipe(tap((response) => response));
  }

  InsertOrUpdateGroupDetailsUserMap(data: any): Observable<any> {
    return this.http.get(this.baseUrl + '/InsertOrUpdateGroupDetailsUserMap' + data).pipe(tap((response) => response));
  }

  DeleteGroupDetailsUserMAp(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/DeleteGroupDetailsUserMAp' + id).pipe(tap((response) => response));
  }





  ValidateUserProfile(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/ValidateUserProfile?userName=rahul&password=pal&PasswordCheck=1').pipe(tap((response) => response));
  }
  IsUserEmployeeExist(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/IsUserEmplyeeNoExist?EmployeID=4&EmployeNo=123').pipe(tap((response) => response));
  }
  LoggedOut(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/UpdateAdminIsLoggedOut?UserID=1').pipe(tap((response) => response));
  }
  GetAdminInvalidUser(id: any): Observable<any> {
    return this.http.get(this.baseUrl + '/GetAdminInvalidUser?UserName=' + id).pipe(tap((response) => response));
  }
  InsertUserAndEmployeeDetails(data: any): Observable<any> {
    return this.http.post(this.baseUrl + '/InsertUserAndEmployeeDetails', data).pipe(tap((response) => response));
  }




}
