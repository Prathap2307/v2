import { TestBed } from '@angular/core/testing';

import { AuthorizedsignatoryService } from './authorizedsignatory.service';

describe('AuthorizedsignatoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AuthorizedsignatoryService = TestBed.get(AuthorizedsignatoryService);
    expect(service).toBeTruthy();
  });
});
