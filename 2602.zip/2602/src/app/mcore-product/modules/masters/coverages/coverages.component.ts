import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from "moment"
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { CoveragesService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/coverages.service';

@Component({
  selector: 'app-coverages',
  templateUrl: './coverages.component.html',
  styleUrls: ['./coverages.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class CoveragesComponent implements OnInit {
  SearchBenefitsRidersform: FormGroup;
  AddBenefit: FormGroup;
  uinForm: FormGroup;
  Exclusionform: FormGroup;
  UINArray: any[] = [];
  ExclusionArray = [];
  submitted2: boolean;
  submitted: boolean;
  submitted3: boolean;
  SubchannelHeading: string = "Add - Benefits / Riders";
  saveBtnMode: boolean = true;
  view: boolean = false;
  textSaveBtn: string = "Save";
  display: string;
  uinpush: boolean;
  ExclusionPush: boolean;
  view1: boolean = false;
  saveBtnMode1: boolean = true;
  SubchannelHeading1: string = "UIN";
  message: any;
  invalidDate: boolean;
  validform: boolean;
  invalidage: boolean;
  UINobj: any;
  textSaveBtn1: string = "Add";
  uinIndex: any;
  error: boolean;
  uinIndex2: any;
  exclusion: string = 'Save Exclusion';
  exIndex2: any;
  exobj: any;
  version: boolean = false;
  versionerror: boolean;
  submitted1: boolean;
  success: boolean;
  transaction: any;
  allCoverages: any;
  exist: boolean;

  constructor(private fb: FormBuilder, private CoverageService: CoveragesService) { }

  ngOnInit() {


    this.SearchBenefitsRidersform = this.fb.group({
      benefits: [''],
      description: [''],
    })

    this.AddBenefit = this.fb.group({
      coverageID: [''],
      coverageName: ['', Validators.required],
      description: [''],
      coverCode: [''],
      lineOfBusinessID: [''],
      houseHoldLimitPerYear: [''],
      sectionID: [''],
      createdBy: [''],
      createdOn: [''],
      isActive: [''],
      type: [''],
      amountPercentage: [''],
      uinMapDetails: this.fb.array([]),
      exclusion: this.fb.array([]),
    });

    this.uinForm = this.fb.group({
      uinID: [''],
      description: ['', Validators.required],
      coverageID: [''],
      uinNumber: ['', Validators.required],
      maximumMaturityAge: ['', Validators.required],
      maximumMaturityAgeType: ['', Validators.required],
      uinEffectiveFrom: ['', Validators.required],
      uinEffectiveTo: ['', Validators.required],
      minimumEntryAge: ['', Validators.required],
      minimumEntryAgeType: [],
      maximumEntryAge: ['', Validators.required],
      maximumEntryAgeType: ['', Validators.required],
      minimumSumAssured: ['', Validators.required],
      minimumSumAssuredType: ['', Validators.required],
      maximumSumAssured: ['', Validators.required],
      maximumSumAssuredType: ['', Validators.required],
      minimumFreeCoverLimit: [''],
      maximumFreeCoverLimit: [''],
      isActive: [''],
      versionNo: [''],
    })

    this.Exclusionform = this.fb.group({
      coverageId: [''],
      exclusionId: [''],
      description: ['', Validators.required],
      createdBy: [''],
      createdOn: [''],
      isActive: ['']
    })
  }
  get s() { return this.SearchBenefitsRidersform.controls; }

  SearchBenefit() {
    this.submitted3 = true;
    console.log(this.SearchBenefitsRidersform.value)
  }

  get b() { return this.AddBenefit.controls }

  // getallcoverages() {
  //   this.CoverageService.GetAllCoveragesByLineOfBusiness()
  //     .subscribe(result => {
  //       console.log(result)
  //       this.allCoverages = result.data
  //     });
  // }
  addBenefit() {
    this.submitted = true;
    console.log(this.AddBenefit.value)
    this.result();


  }
  clearBenefit() {
    this.uinpush = false
    this.ExclusionPush = false
    this.submitted = false;
    this.AddBenefit.reset();
    this.SubchannelHeading = 'Add - Benefits / Riders';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }

  get a() { return this.uinForm.controls; }

  adduin() {
    this.submitted1 = true;
    console.log(this.uinForm.value)
    let fromvalue = moment(new Date(this.uinForm.value["uinEffectiveFrom"])).format('YYYY/MM/DD')
    let tovalue = moment(new Date(this.uinForm.value["uinEffectiveTo"])).format('YYYY/MM/DD')
    let uinEffectiveFrom = moment(fromvalue);
    let uinEffectiveTo = moment(tovalue);
    // let uinEffectiveFrom = moment(this.uinForm.value["uinEffectiveFrom"]._i.year + '/' + this.uinForm.value["uinEffectiveFrom"]._i.month + '/' + this.uinForm.value["uinEffectiveFrom"]._i.date);
    // let uinEffectiveTo = moment(this.uinForm.value["uinEffectiveTo"]._i.year + '/' + this.uinForm.value["uinEffectiveTo"]._i.month + '/' + this.uinForm.value["uinEffectiveTo"]._i.date);
    let result = uinEffectiveFrom.diff(uinEffectiveTo, 'days');
    console.log(result)
    if (result >= 0) {
      this.openModalDialog1()
      this.invalidDate = true
      console.log("UIN Effective To Date should not be lesser than UIN Effective From Date")
    }
    console.log(this.uinForm.value["minimumEntryAge"])
    console.log(this.uinForm.value["maximumEntryAge"])
    if (this.uinForm.value["minimumEntryAge"] > this.uinForm.value["maximumEntryAge"]) {
      this.invalidage = true
      this.openModalDialog1()
      console.log("Minimum Entry Age should not be greater than Maximum Entry Age.")
    }

    if (this.uinForm.valid && !this.invalidDate && !this.invalidage) {
      console.log(this.uinForm.value)
      this.UINobj = this.UINArray.find(x => x.uinID == this.uinForm.value["uinID"]);
      console.log(this.uinIndex)
      console.log(this.UINobj)
      if (this.uinIndex == undefined) {
        this.uinForm.value["uinID"] = 0
        this.uinForm.value["coverageID"] = 0
        this.UINArray.push(this.uinForm.value)
        console.log(this.UINArray)
        let message = "UIN Added SuccessFully"
        this.openModalDialog(message)
      }
      else {
        if (this.version) {
          this.UINArray.push(this.uinForm.value)
          this.version = false
        }
        else {
          this.UINArray[this.uinIndex] = this.uinForm.value
        }

        console.log(this.UINArray)
        let message = "UIN Updated SuccessFully"
        this.openModalDialog(message)
        this.uinIndex = undefined
      }
      this.validform = true
      this.uinpush = true
      this.clearUIn()
    }

  }

  deleteUinDetail(index) {
    if (index !== -1) {
      this.UINArray.splice(index, 1);
    }
    console.log()
  }
  deleteExclusionDetail(index) {
    if (index !== -1) {
      this.ExclusionArray.splice(index, 1);
    }
    console.log()
  }
  clearUIn() {
    this.submitted1 = false;
    this.uinForm.reset();
    this.SubchannelHeading1 = 'UIN';
    this.saveBtnMode1 = true;
    this.textSaveBtn1 = 'Add'
    if (this.view1 === true) {
      this.view1 = false
      console.log(this.view1)
    }
  }

  get e() { return this.Exclusionform.controls; }

  onsaveExculsion() {
    this.submitted2 = true;
    console.log(this.Exclusionform.value)
    if (this.Exclusionform.valid) {
      if (this.exIndex2 == undefined) {
        this.ExclusionArray.push(this.Exclusionform.value)
        console.log(this.ExclusionArray)
        let message = "Exclusion Added SuccessFully"
        this.openModalDialog(message)
      }
      else {
        this.ExclusionArray[this.exIndex2] = this.Exclusionform.value
        console.log(this.ExclusionArray)
        let message = "Exclusion Updated SuccessFully"
        this.openModalDialog(message)
        this.exIndex2 = undefined
      }
      this.validform = true
      console.log(this.ExclusionArray)
      this.ExclusionPush = true
      this.clearExculsion()
    }

  }

  btngEdit_Click2(i: any) {
    this.exIndex2 = i
    this.exclusion = 'Update Exclusion'
    this.exobj = this.ExclusionArray[this.exIndex2];
    this.Exclusionform = this.fb.group({
      description: [{ value: this.exobj.description, disabled: false }, Validators.required],
      coverageId: [{ value: this.exobj.description, disabled: false }],
      exclusionId: [{ value: this.exobj.description, disabled: false }],
      createdBy: [{ value: this.exobj.description, disabled: false }],
      createdOn: [{ value: this.exobj.description, disabled: false }],
      isActive: [{ value: this.exobj.description, disabled: false }]
    })

  }
  clearExculsion() {
    this.submitted2 = false;
    this.Exclusionform.reset();
    this.exclusion = 'Save Exclusion'
  }

  btngEdit_Click() {

    this.SubchannelHeading = 'Edit - Benefits / Riders';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
  }
  btngView_Click() {
    this.SubchannelHeading = 'View - Benefits / Riders';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
  }

  btngEdit_Click1(uinID, i) {
    this.uinIndex = i
    this.SubchannelHeading1 = 'Edit - UIN';
    this.saveBtnMode = true;
    this.view1 = false;
    this.textSaveBtn1 = 'Update'
    this.getuin()
  }
  getuin() {
    this.UINobj = this.UINArray[this.uinIndex];
    console.log(this.UINobj)
    if (this.UINobj) {
      this.uinForm = this.fb.group({
        uinID: [{ value: this.UINobj.uinID, disabled: false }],
        description: [{ value: this.UINobj.description, disabled: false }, Validators.required],
        coverageID: [{ value: this.UINobj.coverageID, disabled: false }],
        uinNumber: [{ value: this.UINobj.uinNumber, disabled: false }, Validators.required],
        maximumMaturityAge: [{ value: this.UINobj.maximumMaturityAge, disabled: false }, Validators.required],
        maximumMaturityAgeType: [{ value: this.UINobj.maximumMaturityAgeType, disabled: false }, Validators.required],
        uinEffectiveFrom: [{ value: this.UINobj.uinEffectiveFrom, disabled: false }, Validators.required],
        uinEffectiveTo: [{ value: this.UINobj.uinEffectiveTo, disabled: false }, Validators.required],
        minimumEntryAge: [{ value: this.UINobj.minimumEntryAge, disabled: false }, Validators.required],
        minimumEntryAgeType: [{ value: this.UINobj.minimumEntryAgeType, disabled: false }],
        maximumEntryAge: [{ value: this.UINobj.maximumEntryAge, disabled: false }, Validators.required],
        maximumEntryAgeType: [{ value: this.UINobj.maximumEntryAgeType, disabled: false }, Validators.required],
        minimumSumAssured: [{ value: this.UINobj.minimumSumAssured, disabled: false }, Validators.required],
        minimumSumAssuredType: [{ value: this.UINobj.minimumSumAssuredType, disabled: false }, Validators.required],
        maximumSumAssured: [{ value: this.UINobj.maximumSumAssured, disabled: false }, Validators.required],
        maximumSumAssuredType: [{ value: this.UINobj.maximumSumAssuredType, disabled: false }, Validators.required],
        minimumFreeCoverLimit: [{ value: this.UINobj.minimumFreeCoverLimit, disabled: false }],
        maximumFreeCoverLimit: { value: this.UINobj.maximumFreeCoverLimit, disabled: false },
        isActive: [{ value: this.UINobj.isActive, disabled: false }],

      })
      console.log(this.uinForm.value)
    }
  }
  uinVersion() {
    this.version = true
    console.log(this.UINobj.uinNumber)
    console.log(this.uinForm.value["uinNumber"])
    if (this.uinForm.value["uinNumber"] === this.UINobj.uinNumber) {
      this.adduin()
    }
    else {
      let message = "UIN Number should remains the same during version update."
      this.openModalDialog(message)
      this.error = true
    }

  }
  btngView_Click1() {
    this.SubchannelHeading1 = 'View - UIN';
    this.view1 = true
    console.log(this.view)
    this.saveBtnMode1 = false;
  }

  openModalDialog(data) {
    this.display = 'block'; //Set block css
    this.submitted = false
    this.message = data;
    // this.AddBenefit.reset()


  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    if (this.invalidDate) {
      this.invalidDate = false
    }
    if (this.validform) {
      this.validform = false
    }
    if (this.invalidage) {
      this.invalidage = false
    }
    this.error = false
  }


  openModalDialog1() {
    this.display = 'block'; //Set block css
    this.submitted = false

  }
  result() {

    let result = {}


    if (this.AddBenefit.invalid) {
      console.log("Please fill Riders")
      let message = "Please fill Riders"
      this.openModalDialog(message)
      this.error = true
    }
    else {

      if (this.UINArray && this.UINArray.length === 0) {
        let message = "Please fill UIN details"
        this.openModalDialog(message)
        this.error = true
      }
      else if (this.UINArray && this.UINArray.length > 0) {

        this.AddBenefit.value['uinMapDetails'] = this.UINArray
      }
    }

    if (this.ExclusionArray && this.ExclusionArray.length > 0) {
      this.AddBenefit.value['exclusion'] = this.ExclusionArray
    }


    if (this.AddBenefit.valid && this.UINArray && this.UINArray.length > 0 && this.ExclusionArray && this.ExclusionArray.length > 0) {
      this.validform = true
      this.AddBenefit.value["coverageID"] = 0
      result = this.AddBenefit.value
      console.log(result)
      // if (this.textSaveBtn === 'Save') {
      //   this.IsCoverageExistNew(this.AddBenefit.value)
      // }
      // else {
        this.CoverageService.InsertOrUpdateCoverageNew(this.AddBenefit.value)
          .subscribe(result => {
            console.log(result)
            if (result.data = "Success") {
              this.success = true
              this.validform = true
              let transaction = "Benefits Created Successfully"
              this.openModalDialog(transaction)
            }

            // this.getallstamp()
            // this.clearBenefit()
          });

      // }
      this.AddBenefit.reset()
    }

  }
  IsCoverageExistNew(data: any) {
    this.AddBenefit.value['coverageID'] = 0
    this.AddBenefit.value['lineOfBusinessID'] = 1
    this.AddBenefit.value['sectionID'] = 1
    this.AddBenefit.value['createdBy'] = 1
    this.AddBenefit.value['createdOn'] = null
    this.AddBenefit.value['isActive'] = 1
    this.AddBenefit.value['houseHoldLimitPerYear'] = 12
    this.CoverageService.IsCoverageExistNew(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === false) {
          console.log("data >>", data)
          this.CoverageService.InsertOrUpdateCoverageNew(data)
            .subscribe(result => {
              console.log(result)
              if (result.data = "Success") {
                this.success = true
                this.validform = true
                let transaction = "Benefits Created Successfully"
                this.openModalDialog(transaction)
              }
              //this.clearBenefit()
            });
        }
        else {
          this.exist = true

        }

      });
  }

}
