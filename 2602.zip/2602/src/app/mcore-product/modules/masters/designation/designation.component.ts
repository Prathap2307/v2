import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Designation } from 'src/app/mcore-product/mcore-shared/mcore-entity/designation';
import { DesignationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/designation.service';
import { TooltipPosition } from '@angular/material/tooltip';

import { DepartmentService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/department.service';
import { DepartmentType } from 'src/app/mcore-product/mcore-shared/mcore-entity/departmentType';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.css']
})
export class DesignationComponent implements OnInit {

  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

  submitted = false;
  saveBtnMode: boolean;
  designationForm: FormGroup;
  createBtn: boolean;
  get designationFormAction() {
		return this.designationForm.get('designationFormAction') as FormGroup;
	  }

  departmentObj: DepartmentType[];
  fieldDisable: Boolean;

  constructor(private fb: FormBuilder, private designationService: DesignationService, private departmentService: DepartmentService) { }

  designationObj: Designation[] = [];
  designationGridObj: Designation[] = [];
  designationFilteredObj: Designation[] = [];
  designationColumns: string[] = ['View', 'Edit', 'Delete', 'description', 'shortName'];

  designationHeading: string = '';
  dataSource = new MatTableDataSource<Designation>(this.designationGridObj);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;


  ngOnInit() {

    this.dataSource = new MatTableDataSource<Designation>(this.designationGridObj);
    this.fieldDisable = false;
    this.createBtn = true;
    this.designationForm = this.fb.group({
      searchId: [''],
      searchdesignationName: [''],
      searchdepartmentName: [''],
      designationFormAction: this.fb.group({
        designationId: [''],
        shortName:
          [
            '',
            [Validators.required]
          ],
        description:
          [
            '',
            [Validators.required]
          ]
       
      })
    });

    this.designationHeading = 'Add New - Designation';
    this.saveBtnMode = true;
    this.getDesignationDetails();
    this.getDepartmentDetails();
  }

  getDetailsInfoBySearch(): void {



    //console.log(this.DepartmentForm.controls.SearchDescription.value);
    let searchdescription = this.designationForm.controls.searchdepartmentName.value;

    this.designationService.getDetailsInfoBySearch(searchdescription, null)
      .subscribe(designationObj => this.designationObj = designationObj);


  }

  onBtnSaveDesignation() {
   

    if (this.createBtn) {
			this.designationFormAction.addControl('createdBy', new FormControl(1));
			this.designationFormAction.addControl('createdOn', new FormControl(new Date()));
		}else{

			this.designationFormAction.addControl('createdOn', new FormControl(new Date()));
		}


    this.designationFormAction.markAllAsTouched();
    if (this.designationFormAction.valid) {

      let a = this.designationFormAction.value;
      console.log(a);
      this.designationService.addDesignation(a)
        .subscribe(result => { this.getDesignationDetails() });

      this.designationHeading = 'Add New - Designation';

      this.onBtnClearDesignation();

    }
  }
  onBtnSearchClearDesignation() {
    this.designationForm.reset();

    this.getDesignationDetails();
  }
  onBtnClearDesignation() {
    this.fieldDisable = false;
    this.designationForm.controls.designationFormAction.reset();
    this.designationHeading = 'Add New - Designation';

    this.designationForm = this.fb.group({
      designationFormAction: this.fb.group({
        designationId: '',
        description: '',
        shortName: ''

      })


    });

    this.saveBtnMode = true;


  }
  getDesignationDetails(): void {

    this.designationService.getDesignationDetails(0, null)
      .subscribe(a => {
        this.designationObj = a;
        this.designationGridObj = a;
        this.dataSource = new MatTableDataSource<Designation>(this.designationGridObj);
        this.dataSource.data = this.designationGridObj = a;
        this.dataSource.paginator = this.paginator;

      });

  }

  getDepartmentDetails(): void {

    this.departmentService.getDepartmentDetails()
      .subscribe(departmentObj => {
        this.departmentObj = departmentObj;

      });

  }

  btngvDelete_Click(a) {
    this.designationForm = this.fb.group({
      searchId: [''],
      searchdesignationName: [''],
      searchdepartmentName: [''],
      designationFormAction: this.fb.group({
        searchdesignationName: [''],
        searchdepartmentName: [''],
        designationId: a,
        description: '',
        shortName: '',
        createdBy: '',
        createdOn: '',
        deletedBy: '2',
        deletedOn: '2020-01-30'
      })
    });

    let c = this.designationForm.get('designationFormAction').value;

    this.designationService.deleteDesignation(c).subscribe(result => { this.getDesignationDetails() });
  }

  btngvView_Click(a) {
    this.saveBtnMode = false;
    this.fieldDisable = true;

    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({
      searchId: [''],
      searchdesignationName: [''],
      searchdepartmentName: [''],
      designationFormAction: this.fb.group({
        designationId: this.designationFilteredObj[0].designationId,
        description: this.designationFilteredObj[0].description,
        shortName: this.designationFilteredObj[0].shortName,
        createdBy: this.designationFilteredObj[0].createdBy,
        createdOn: this.designationFilteredObj[0].createdOn

      })
    });

    this.designationHeading = 'View - Designation';



  }

  btngvEdit_Click(a) {
    this.saveBtnMode = true;
    this.fieldDisable = false;
    this.designationFilteredObj = this.designationObj.filter((unit) => unit.designationId == a);

    this.designationForm = this.fb.group({
      searchId: [''],
      searchdesignationName: [''],
      searchdepartmentName: [''],
      designationFormAction: this.fb.group({
        designationId: this.designationFilteredObj[0].designationId,
        description: this.designationFilteredObj[0].description,
        shortName: this.designationFilteredObj[0].shortName

      })
    });

    this.designationHeading = 'Edit - Designation';

  }

  //disableSelect = new FormControl(false);

  //id = new FormControl(false);

  consoleLogFn(val) {
    console.log(val);
  }




}
