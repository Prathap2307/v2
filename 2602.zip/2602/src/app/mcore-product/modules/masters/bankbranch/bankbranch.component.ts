import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BankBranch, BankName, BankCity } from 'src/app/mcore-product/mcore-shared/mcore-entity/bankbranch';
import { BankbranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/bankbranch.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { typeWithParameters } from '@angular/compiler/src/render3/util';

@Component({
  selector: 'app-bankbranch',
  templateUrl: './bankbranch.component.html',
  styleUrls: ['./bankbranch.component.css']
})
export class BankbranchComponent implements OnInit {
  createBtn: boolean;
  fieldDisable: Boolean;
  bankname: any;
  bankcity: any;
  BankBranchForm: FormGroup;
  BankBranchFormAction: FormGroup;
  bankBranchObj: BankBranch[];
  bankNameObj: BankName[];
  bankNameFilteredObj: BankName[] = [];
  BankCityObj: BankCity[];
  bankBranchFilteredObj: BankBranch[] = [];
  bankBranchHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  bankBranchColumns: string[] = ['View', 'Edit', 'Delete', 'bankId', 'BankCityID', 'description', 'ifscCode', 'micrCode'];
  bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.bankBranchdataSource.paginator = this.paginator;
  }
  // bankName: any = ['IND', 'PNB', 'HDFC']
  // bankCity: any = ['Koramangala', 'Indiranagar', 'Madiwala']
  constructor(
    private fb: FormBuilder,
    private bankBranchService: BankbranchService
  ) { }

  ngOnInit() {
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.getBankBranchNameDetails();
    this.getBankBranchCitydetails();
    this.getBankBranchDetails();
    this.ValidateBankBranchForm();
    this.onChanges();
  }

  public ValidateBankBranchForm() {
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        branchId: [''],
        bankId: [''],
        bankCityId: [''],
        bankName:
          [
            '',
            [Validators.required]
          ],
        bankCityName:
          [
            '',
            [Validators.required]
          ],
        description:
          [
            '',
            [Validators.required]
          ],
        ifscCode:
          [
            '',
            [Validators.required]
          ],
        micrCode:
          [
            '',
            [Validators.required]
          ],
        createdBy: [1],
        createdOn: [new Date()],
        isActive: 1,
      })
    });
  }
  onChanges() {
    // this.BankBranchForm.get('BankBranchFormAction').valueChanges.subscribe(val => {
    //   console.log(val);
    // });
  }

  onBtnSearchBankBranchDetails() {
    //this.getSearchBankBranchDetails();    
    // if (this.BankBranchForm.valid) {
    //   let a = this.BankBranchForm.value;
    //   console.log(a);
    //   this.bankBranchService.getSearchBankBranchdetails(a).subscribe(SearchBankBranchval => { this.bankBranchObj = SearchBankBranchval });
    //   //this.bankBranchService.getSearchBankBranchdetails(a).subscribe(result => { this.getBankBranchDetails() });
    // }
    
    //this.BankBranchForm.controls.BankBranchFormAction.markAllAsTouched();
    this.BankBranchForm.get('BankBranchFormAction').patchValue({
      createdBy: '1',
      createdOn: new Date(),
      isActive: '1',
    });
    if (this.BankBranchForm.invalid) {
      let a = this.BankBranchForm.value;
      console.log(a);
      this.bankBranchService.getSearchBankBranchdetails(a).subscribe(SearchBankBranchval => { this.bankBranchObj = SearchBankBranchval });           
    }

    // if (this.BankBranchForm.controls.searchbankName.valid) {
		// 	let searchValue = this.bankmasterForm.controls.searchBank.value;

		// 	this.bankmasterService.getBankDetailsByDescription(searchValue)
		// 		.subscribe(a => this.bankObj = a);
    // }
    // else {
    // }

    // if (this.BankBranchForm.controls.searchbankName.valid || this.BankBranchForm.controls.searchbankCity.valid
    //   || this.BankBranchForm.controls.searchifscCode.valid || this.BankBranchForm.controls.searchmicrCode.valid) {
    //   let searchBankNameVal = this.BankBranchForm.controls.searchbankName.value;
    //   let searchBankCityVal = this.BankBranchForm.controls.searchbankCity.value;
    //   let searchBankIFSCCodeVal = this.BankBranchForm.controls.searchifscCode.value;
    //   let searchBankMICRCodeVal = this.BankBranchForm.controls.searchmicrCode.value;
    //   this.bankBranchService.getSearchBankBranchdetails(a).subscribe(
    //     SearchBankBranchval => { this.bankBranchObj = SearchBankBranchval });
    // }
    // else {
    // }
  }
  public getSearchBankBranchDetails() {


    //  if (this.BankBranchForm.controls.searchbankName.valid || this.BankBranchForm.controls.searchbankCity.valid
    //   || this.BankBranchForm.controls.searchifscCode.valid || this.BankBranchForm.controls.searchmicrCode.valid) {
    //   let searchBankNameVal = this.BankBranchForm.controls.searchbankName.value;
    //   let searchBankCityVal = this.BankBranchForm.controls.searchbankCity.value;
    //   let searchBankIFSCCodeVal = this.BankBranchForm.controls.searchifscCode.value;
    //   let searchBankMICRCodeVal = this.BankBranchForm.controls.searchmicrCode.value;
    //   this.bankBranchService.getSearchBankBranchdetails(0, 0, searchBankNameVal, searchBankCityVal, searchBankIFSCCodeVal, searchBankMICRCodeVal).subscribe(
    //     SearchBankBranchval => { this.bankBranchObj = SearchBankBranchval });
    // }
    // else {
    // }
  }

  onBtnSearchClearBankBranch() {
    this.BankBranchForm.reset();
    this.getBankBranchDetails();
  }

  onBtnSaveBankBranchClick() {
    this.GetSaveBankBranchDetails();
  }
  public GetSaveBankBranchDetails() {
    this.BankBranchForm.get('BankBranchFormAction').patchValue({
      createdBy: '1',
      createdOn: new Date(),
      isActive: '1',
    });
    this.BankBranchForm.controls.BankBranchFormAction.markAllAsTouched();
    if (this.BankBranchForm.controls.BankBranchFormAction.valid) {
      let a = this.BankBranchForm.controls.BankBranchFormAction.value;
      console.log(a);
      this.bankBranchService.insertbankBranch(a).subscribe(result => { this.getBankBranchDetails() });
      //this.BankBranchForm.controls.BankBranchFormAction.reset();
      this.GetClearBankBranchDetails();
    }
  }

  onBtnClearBankBranchClick() {
    this.GetClearBankBranchDetails();
  }
  public GetClearBankBranchDetails() {
    this.BankBranchForm.controls.BankBranchFormAction.reset();
    this.bankBranchHeading = 'Add New - Bank Branch';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        bankId: { value: '', disabled: false },
        bankCityId: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
        isActive: { value: '', disabled: false },
      })
    });
  }

  getBankBranchDetails(): void {
     this.bankBranchService.getBankBranchdetails().subscribe(      
      bankBranchObj => {
        this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
        this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
        this.bankBranchdataSource.paginator = this.paginator;
      });     
  }
  // getBankBranchDetails(): void {    
  //   this.bankBranchService.getSearchBankBranchdetails(0, 0, 0, null, null, null).subscribe(
  //     bankBranchObj => {
  //       this.bankBranchdataSource = new MatTableDataSource<BankBranch>(this.bankBranchObj);
  //       this.bankBranchdataSource.data = this.bankBranchObj = bankBranchObj;
  //       this.bankBranchdataSource.paginator = this.paginator;
  //     });
  // }

  // Grid View Button Events
  public btngvView_Click(a, bn) {
    this.bankBranchHeading = 'View - Bank Branch';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.branchId == a);
    //this.bankNameFilteredObj = this.bankNameObj.filter((unit) => unit.bankId == bn);
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        branchId: this.bankBranchFilteredObj[0].branchId,
        bankId: this.bankBranchFilteredObj[0].bankId,
        bankName: this.bankBranchFilteredObj[0].BankName,
        bankCityId: this.bankBranchFilteredObj[0].bankCityId,
        bankCityName: this.bankBranchFilteredObj[0].BankCityName,
        description: this.bankBranchFilteredObj[0].description,
        ifscCode: this.bankBranchFilteredObj[0].ifscCode,
        micrCode: this.bankBranchFilteredObj[0].micrCode,
        createdBy: this.bankBranchFilteredObj[0].createdBy,
        createdOn: this.bankBranchFilteredObj[0].createdOn,
      })
    });
  }

  // Grid Edit Button Events
  public btngvEdit_Click(a) {
    this.bankBranchHeading = 'Edit - Bank Branch';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.bankBranchFilteredObj = this.bankBranchObj.filter((unit) => unit.branchId == a);
    this.BankBranchForm = this.fb.group({
      ssearchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        branchId: this.bankBranchFilteredObj[0].branchId,
        bankId: this.bankBranchFilteredObj[0].bankId,
        bankName: this.bankBranchFilteredObj[0].BankName,
        bankCityId: this.bankBranchFilteredObj[0].bankCityId,
        bankCityName: this.bankBranchFilteredObj[0].BankCityName,
        description: this.bankBranchFilteredObj[0].description,
        ifscCode: this.bankBranchFilteredObj[0].ifscCode,
        micrCode: this.bankBranchFilteredObj[0].micrCode,
        createdBy: this.bankBranchFilteredObj[0].createdBy,
        createdOn: this.bankBranchFilteredObj[0].createdOn,
      })
    });
  }

  // Grid Delete Button Events
  public btngvDelete_Click(a) {
    this.BankBranchForm = this.fb.group({
      searchbankName: [''],
      searchbankCity: [''],
      searchifscCode: [''],
      searchmicrCode: [''],
      BankBranchFormAction: this.fb.group({
        branchId: { value: a, disabled: false },
        bankId: { value: '', disabled: false },
        bankName: { value: '', disabled: false },
        bankCityId: { value: '', disabled: false },
        bankCityName: { value: '', disabled: false },
        description: { value: '', disabled: false },
        ifscCode: { value: '', disabled: false },
        micrCode: { value: '', disabled: false },
        createdBy: 1,
        createdOn: new Date(),
        deletedBy: 1,
        deletedOn: new Date(),
        isActive: 0,
      })
    });
    let v = this.BankBranchForm.get('BankBranchFormAction').value;
    console.log(v);
    this.bankBranchService.deleteBankBranch(v).subscribe(result => { this.getBankBranchDetails(); });
  }

  getBankBranchCitydetails() {
    //let bankId = this.BankBranchFormAction.controls.bankId.value;
    this.bankBranchService.getBankBranchCityDetails(1).subscribe(bankCityNameVal => { this.BankCityObj = bankCityNameVal });
  }

  getBankBranchNameDetails() {
    //let bankId = this.BankBranchFormAction.controls.bankId.value;
    this.bankBranchService.getBankBranchNameDetails().subscribe(bankNameVal => { this.bankNameObj = bankNameVal });
  }
}
