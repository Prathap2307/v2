import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';

import { MustMatch } from 'src/app/mcore-product/mcore-shared/mcore-helpers/must-matchvalidator';
import { UserService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/user.service';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],

  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class UserComponent implements OnInit {
  Searchuser: FormGroup;
  Adduser: FormGroup;
  UnderWriter: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  submitted3: boolean;
  saveBtnMode: boolean = true;
  view: boolean = false;
  Under_Writers: boolean = false;
  userheading: string = 'Add - New User'
  display: string = 'none';
  Addunderwriter: any = [];
  textSaveBtn: string = 'Save';

  dummyObj =
    [{ Id: '1', Name: 'abc' },
    { Id: '2', Name: 'abcd' },
    { Id: '3', Name: 'abc34' },
    { Id: '4', Name: 'abc4' }
    ]

  userType = [


    { Id: '2', Name: 'Client Organisation User' },
    { Id: '3', Name: 'Agent User' },
    { Id: '4', Name: 'General User' }
  ]

  Reporting_to = [

    { Id: '1', Name: '---select-----' },
  ]

  Gender = [

    { Id: '2', Name: 'Male' },
    { Id: '3', Name: 'Female' },
    { Id: '4', Name: 'Transgender' }
  ]

  Branch = [

    { Id: '2', Name: 'Bangalore' },
    { Id: '3', Name: 'Kolkata' },
    { Id: '4', Name: 'Mumbai' }
  ]
  Department = [

    { Id: '2', Name: 'Technical' },
    { Id: '3', Name: 'Account Taxatio' },
    { Id: '4', Name: 'Accounts Taxation' },
    { Id: '5', Name: 'BSG IT' },
    { Id: '6', Name: 'Head Office' },
    { Id: '7', Name: 'IT' },
    { Id: '7', Name: 'Operational Team' }
  ]

  designation = [
    { Id: '2', Name: 'No Result Found' },

  ]

  Grade = [

    { Id: '2', Name: 'GRADE II' },
    { Id: '3', Name: 'Grade III' },
    { Id: '4', Name: 'Grade IV' },
    { Id: '5', Name: 'Grade V' },
    { Id: '6', Name: 'Grade VI' },
    { Id: '7', Name: 'GRADE VII' },

  ]
  branchFilteredObj: any;
  allbranch: any;


  constructor(private fb: FormBuilder, private BranchService: BranchService, private _adapter: DateAdapter<any>, private user: UserService) {
    this._adapter.setLocale('en-gb');
  }

  ngOnInit() {
    this.getallbranches()
    this.Searchuser = this.fb.group({
      firstName: [],
      lastName: [],
      userName: [],
      ReportingTo: [],
    })
    this.UnderwriterForm()
    this.UserForm()

  }
  UserForm() {
    this.Adduser = this.fb.group({
      firstName: [],
      salutationID: [''],
      lastName: [],
      initial: [],
      gender: [],
      branchID: [],
      departmentID: [],
      designationID: [],
      gradeID: [],
      selectAllBranch: [],
      Reporting_To: [],
      branchToWhichAttached: this.fb.array([]),
      address: [],
      mobileNo: ['', [Validators.pattern('\\d{10}')]],
      conferenceNo: ['', [Validators.pattern('[0-9]{11,12}')]],
      employeeNo: [],
      email: ['', [Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")]],
      isUnderWriter: [],
      photos: [],
      userID: [],
      userName: [],
      isAdmin: [],
      isSuperUser: 1,
      password: ['', [Validators.required, Validators.pattern('(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$')]],
      Confirm_Password: [],
      Under_Writer: this.fb.array([
      ]),
    },
      {
        validator: MustMatch('password', 'Confirm_Password')
      })
  }



  UnderwriterForm() {

    this.UnderWriter = this.fb.group({
      Level: ['', [Validators.required]],
      Module: ['', [Validators.required]],
      LOB: ['', [Validators.required]],
      Plan: ['', [Validators.required]],
      Level_Name: ['', [Validators.required]],

    })
  }

  onCheckChange(event: any) {
    console.log(event)
    console.log(event.source.value)
    const formArray: FormArray = this.Adduser.get('branchToWhichAttached') as FormArray;
    /* Selected */
    if (event.checked) {
      // Add a new control in the arrayForm
      formArray.push(new FormControl(event.source.value));
    }
    /* unselected */
    else {
      // find the unselected element
      let i: number = 0;

      formArray.controls.forEach((ctrl: FormControl) => {
        if (ctrl.value == event.source.value) {
          // Remove the unselected element from the arrayForm
          formArray.removeAt(i);
          return;
        }

        i++;
      });
    }
  }
  getallbranches() {
    let branch = {
      "OrganisationID": 1,
      "BranchID": 0,
      "ShortName": "",
      "Description": "",
      "ParentBranchID": 5,
      "CountryID": 1,
      "StateID": 1,
      "DistrictID": 1,
      "PageTypeID": 3
    }
    this.BranchService.GetAllBranches(branch)
      .subscribe(result => {
        console.log(result)
        this.allbranch = result.data

      })
  }
  getBranchById() {
    this.user.GetUserModulesFeatureByUserID()
      .subscribe(result => {
        console.log(result)
        this.branchFilteredObj = result
        console.log(this.branchFilteredObj)
        if (this.branchFilteredObj) {
          // console.log(this.Adduser.value)
          this.Adduser = this.fb.group({
            firstName: [{ value: this.branchFilteredObj.firstName, disabled: false }],
            salutationID: [{ value: this.branchFilteredObj.salutationID, disabled: false }],
            lastName: [{ value: this.branchFilteredObj.lastName, disabled: false }],
            initial: [{ value: this.branchFilteredObj.initial, disabled: false }],
            gender: [{ value: this.branchFilteredObj.gender, disabled: false }],
            branchID: [{ value: this.branchFilteredObj.branchID, disabled: false }],
            departmentID: [{ value: this.branchFilteredObj.departmentID, disabled: false }],
            designationID: [{ value: this.branchFilteredObj.designationID, disabled: false }],
            gradeID: [{ value: this.branchFilteredObj.gradeID, disabled: false }],
            selectAllBranch: [{ value: this.branchFilteredObj.selectAllBranch, disabled: false }],
            Reporting_To: [{ value: this.branchFilteredObj.Reporting_To, disabled: false }],
            branchToWhichAttached: [{ value: this.branchFilteredObj.branchToWhichAttached, disabled: false }],
            address: [{ value: this.branchFilteredObj.address, disabled: false }],
            mobileNo: [{ value: this.branchFilteredObj.mobileNo, disabled: false }, [Validators.pattern('\\d{10}')]],
            conferenceNo: [{ value: this.branchFilteredObj.conferenceNo, disabled: false }, [Validators.pattern('[0-9]{11,12}')]],
            employeeNo: [{ value: this.branchFilteredObj.employeeNo, disabled: false }],
            email: [{ value: this.branchFilteredObj.email, disabled: false }, [Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")]],
            isUnderWriter: [],
            photos: [{ value: this.branchFilteredObj.photos, disabled: false }],
            userID: [{ value: this.branchFilteredObj.userID, disabled: false }],
            userName: [{ value: this.branchFilteredObj.userName, disabled: false }],
            isAdmin: [{ value: this.branchFilteredObj.isAdmin, disabled: false }],
            isSuperUser: { value: this.branchFilteredObj.isSuperUser, disabled: false },
            password: [{ value: this.branchFilteredObj.password, disabled: false }, [Validators.required, Validators.pattern('(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$')]],
            Confirm_Password: [{ value: this.branchFilteredObj.Confirm_Password, disabled: false }],


          })
        }

        if (this.branchFilteredObj.Is_Under_Writer = true) {
          this.Under_Writers = true

          this.Addunderwriter = this.branchFilteredObj.Under_Writer;
          console.log(this.Addunderwriter)
          console.log(this.Under_Writers)
        }

      })
  }

  Under_Writer() {
    if (this.Under_Writers == false && this.view == false) {
      this.Under_Writers = true
    }
    else {
      this.Under_Writers = false
    }

  }
  get a() { return this.Searchuser.controls; }

  searchUser() {
    this.submitted = true;
    console.log(this.Searchuser.value)
  }

  clearsearch() {
    this.Searchuser.reset();
  }

  get au() { return this.UnderWriter.controls; }


  AddUnderWriters() {

    this.submitted3 = true;
    console.log(this.UnderWriter.value)

    if (this.UnderWriter.valid) {
      this.Addunderwriter.push(this.UnderWriter.value);
      this.UnderWriter.reset();
      this.submitted3 = false;
      console.log(this.UnderWriter.value)
      console.log(this.Addunderwriter)
    }

  }
  cancelUnderWriters() {
    this.UnderWriter.reset();
    this.UnderwriterForm()
    this.submitted3 = false;
  }


  get am() { return this.Adduser.controls; }

  Addusers() {
    this.submitted1 = true;
    console.log(this.Adduser.value)
    this.Adduser.value.Under_Writer = this.Addunderwriter
    console.log(this.Adduser.value)

    if (this.Adduser.valid) {
      this.Adduser.value["salutationID"] = 1
      this.Adduser.value["organisationID"] = 1
      this.Adduser.value["employeeID"] = 0
      this.Adduser.value["createdBy"] = 1
      this.Adduser.value["createdOn"] = null

      this.user.InsertUserAndEmployeeDetails(this.Adduser.value)
        .subscribe(result => {
          console.log(result)
          // this.success = true
          // this.validform = true
          // this.transaction = "Tax Structure Created Successfully"
          // this.openModalDialog(this.transaction)
          // this.getalltaxstructure()
          // this.clearTaxStructure()
        });
      this.openModalDialog();
    }

  }

  CancelAddUser() {
    this.Adduser.reset();
    this.UserForm()
    // console.log(this.submitted)
    this.submitted1 = false
    this.userheading = 'Add - New User';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  btngEdit_Click() {

    this.userheading = 'Edit - User';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.getBranchById()
  }
  btngView_Click() {
    this.userheading = 'View - User';
    this.view = true
    this.Under_Writers = false
    console.log(this.view)
    this.saveBtnMode = false;
  }


  get MobNoError() {
    if (this.Adduser.controls['mobileNo'].hasError('pattern')) {
      return 'Mobile Number Should be 10 Digit';
    }
  }

  get ConferenceNoError() {
    if (this.Adduser.controls['conferenceNo'].hasError('pattern')) {
      return 'Conference Number Should be 11 Digit or 12 Digit';
    }
  }

  get EmailError() {
    if (this.Adduser.controls['email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }

  get passwordError() {

    if (this.Adduser.controls['password'].hasError('required')) {
      return 'Please enter the Password';
    }
    else if (this.Adduser.controls['password'].hasError('pattern')) {
      return 'Password must contain Minimum 8 Characters,Minimum 1 Alphabet,Minimum 1 Numeric,Minimum 1 Special Character and No Spaces';
    }
  }

  get confirmpasswordError() {

    if (this.Adduser.controls['Confirm_Password'].hasError('required')) {
      return 'Please confirm  the Password';
    }
    else if (this.Adduser.controls['Confirm_Password'].hasError('mustMatch')) {
      return ' confirm password must match password';
    }
  }




  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted1 = false
    this.Adduser.reset()


  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
  }



}



// error on password field if entered wrong=====

// error msg

//  Password must contain Minimum 8 Characters,Minimum 1 Alphabet,
// Minimum 1 Numeric,Minimum 1 Special Character and No Spaces


// confirm password copy paste not allowed

// visually increase length of password

// on submit msg User Created Successfully


// mobile number only numbers allowed error  Mobile Number Should be 10 Digit

//   Conference Number Should be 11 Digit or 12 Digit.(number only numbers)

//   Please provide a valid email address


//   on click of Under Writer  UnderWriter form