import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from "moment"
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { CommisionService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/commision.service';

@Component({
  selector: 'app-commission',
  templateUrl: './commission.component.html',
  styleUrls: ['./commission.component.css'],
  providers: [

    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },


    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class CommissionComponent implements OnInit {
  Searchcommission: FormGroup;
  Addcommission: FormGroup;
  submitted: boolean;
  submitted1: boolean;
  display: string;
  saveBtnMode: boolean = true;
  view: boolean = false;
  SubchannelHeading: string = "Add New - Commission";
  textSaveBtn: string = "Save";

  Varient = [

    { Id: 1, Name: 'GPS benefits and rider' },

  ]

  dummyObj =
    [

      { Id: 21, Name: 'Agent' },

    ]
  invalidDate: boolean;
  invalidpolicy: boolean;
  validform: boolean;
  allchannel: any;
  allsubchannel: any;
  success: boolean;
  exist: boolean;
  transaction: string;
  invalidamount: boolean;
  error: boolean;
  msg: any;
  allcommision: any;
  commission: any;


  constructor(private fb: FormBuilder, private CommissionService: CommisionService) { }

  ngOnInit() {

    this.getallchannel()
    this.GetAllCommissionDetail()
    this.Searchcommission = this.fb.group({
      planID: [''],
      mainChannelID: [''],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required]
    })

    this.Addcommission = this.fb.group({
      commissionID: [''],
      // PlanID :[''],
      planID: ['', Validators.required],
      mainChannelID: ['', Validators.required],
      subChannelID: ['', Validators.required],
      salesHierarchyID: [''],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required],
      policyYearTypeID: ['', Validators.required],
      policyTermID: [''],
      rangeFrom: ['', Validators.required],
      rangeTo: ['', Validators.required],
      amount: ['', Validators.required],
      createdBy: [''],
      createdOn: [''],
      // isActive: ['']


      // ModifiedBy:['']
      // ModifiedOn :['']
      // DeletedBy:['']
      // DeletedOn:[''] 


    })



  }

  get d() { return this.Searchcommission.controls; }

  getallchannel() {
    this.CommissionService.GetAllMainChannel()
      .subscribe(result => {
        console.log(result)
        this.allchannel = result.data
        console.log(this.allchannel)
      });
  }
  onBtnSearchClick() {
    this.submitted = true;
    console.log(this.Searchcommission.value)
    this.CommissionService.searchcommision(this.Searchcommission.value)
      .subscribe(result => {
        console.log(result)
        this.allcommision = result['data']
        console.log(this.allcommision)

      });
    console.log(this.Searchcommission.value)
  }
  clearsearch() {
    this.submitted = false;
    this.Searchcommission.reset();
    this.GetAllCommissionDetail()
  }
  get a() { return this.Addcommission.controls; }

  IsCommisionExist(data: any) {
    this.CommissionService.IsCommissionDetailExist(data)
      .subscribe(result => {
        console.log(result)
        if (result.data === "NOTEXIST") {
          this.CommissionService.InsertOrUpdatecommission(this.Addcommission.value)
            .subscribe(result => {
              console.log(result)
              this.success = true
              this.transaction = "Created"
              this.openModalDialog()
              this.GetAllCommissionDetail()
              this.clear()
            });
        }
        else {
          this.exist = true
          //  this.present=result.data
          this.openModalDialog()
        }

      });
  }
  onBtnSave() {
    this.submitted1 = true;
    console.log(this.Addcommission.value)

    if (this.Addcommission.value["fromDate"] && this.Addcommission.value["toDate"]) {
      let fromvalue = moment(new Date(this.Addcommission.value["fromDate"])).format('YYYY/MM/DD')
      let tovalue = moment(new Date(this.Addcommission.value["toDate"])).format('YYYY/MM/DD')
      let fromDate = moment(fromvalue);
      let toDate = moment(tovalue);
      let result = fromDate.diff(toDate, 'days');
      console.log(result)
      if (result >= 0) {
        let msg = "To Date should be greater than From Date."
        this.openModalDialog1(msg)
        this.error = true
        this.invalidDate = true
        console.log(this.invalidDate)
        console.log("To Date should be greater than From Date.")
      }
    }

    let from = this.Addcommission.value["rangeFrom"]
    let to = this.Addcommission.value["rangeTo"]
    console.log(from > to)
    if (from > to) {
      this.invalidpolicy = true
      this.error = true
      console.log(this.invalidpolicy)
      let msg = "Policy Year To should be greater than Policy Year From"
      this.openModalDialog1(msg)
      console.log("Policy Year To should be greater than Policy Year From")
    }
    // console.log(this.Addcommission.value["amount"].toFixed(2));
    if (this.Addcommission.value["amount"] > 100) {
      this.invalidamount = true
      console.log(this.invalidamount)
      this.error = true
      let msg = "Commission cannot be greater than 100%."
      this.openModalDialog1(msg)
      console.log("Commission cannot be greater than 100%.")
    }
    if (this.Addcommission.valid && !this.invalidamount && !this.invalidDate && !this.invalidpolicy) {
      console.log(this.validform)
      this.validform = true
      if (this.textSaveBtn === 'Save') {
        this.IsCommisionExist(this.Addcommission.value)
      }
      else {
        this.CommissionService.InsertOrUpdatecommission(this.Addcommission.value)
          .subscribe(result => {
            this.success = true
            console.log(result)
            this.GetAllCommissionDetail()
            this.transaction = "Updated"
            this.clear()
          });
      }

      this.openModalDialog()
      this.Addcommission.reset()
    }
  }
  clear() {
    this.Addcommission.reset();
    this.SubchannelHeading = 'Add - Commission';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }

  btngEdit_Click(a) {

    this.SubchannelHeading = 'Edit - Commission';
    this.saveBtnMode = true;
    this.view = false;
    this.textSaveBtn = 'Update'
    this.getcommissionById(a)
  }

  getcommissionById(a) {
    console.log(a.commissionID)
    this.CommissionService.GetCommissionDetailByID(a.commissionID)
      .subscribe(result => {
        console.log(result)
        this.commission = result.data[0]
        if (this.commission) {
          console.log(this.Addcommission.value)
          this.Addcommission = this.fb.group({
            commissionID: [{ value: this.commission.commissionID, disabled: false }],
            planID: [{ value: this.commission.planID, disabled: false }, Validators.required],
            mainChannelID: [{ value: this.commission.mainChannelID, disabled: false }, Validators.required],
            subChannelID: [{ value: this.commission.subChannelID, disabled: false }, Validators.required],
            salesHierarchyID: [{ value: this.commission.salesHierarchyID, disabled: false }],
            fromDate: [{ value: this.commission.fromDate, disabled: false }, Validators.required],
            toDate: [{ value: this.commission.toDate, disabled: false }, Validators.required],
            policyYearTypeID: [{ value: this.commission.policyYearTypeID, disabled: false }, Validators.required],
            policyTermID: [{ value: this.commission.policyTermID, disabled: false }],
            rangeFrom: [{ value: this.commission.rangeFrom, disabled: false }, Validators.required],
            rangeTo: [{ value: this.commission.rangeTo, disabled: false }, Validators.required],
            amount: [{ value: this.commission.amount, disabled: false }, Validators.required],
          })
          console.log(this.Addcommission.value)
        }
      });

  }
  delete(a) {
    console.log(a.commissionID)
    this.CommissionService.DeleteCommision(a.commissionID)
      .subscribe(result => {
        console.log(result)
        this.GetAllCommissionDetail()
      });
  }
  btngView_Click(a) {
    this.SubchannelHeading = 'View - Commission';
    this.view = true
    console.log(this.view)
    this.saveBtnMode = false;
    this.getcommissionById(a)
  }
  Select_channel(event: any) {
    console.log(event.target.value)

    this.GetAllSubChannel(event.target.value);
  }
  GetAllCommissionDetail() {
    this.CommissionService.GetAllCommissionDetail()
      .subscribe(result => {
        console.log(result)
        this.allcommision = result.data
        console.log(this.allcommision)
      });
  }
  GetAllSubChannel(id) {
    this.CommissionService.GetSubChannelByChannelID(id)
      .subscribe(result => {
        console.log(result)
        this.allsubchannel = result.data
        console.log(this.allsubchannel)
      });
  }
  policyYearValidate(event: any) {
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    if (l >= 0) {
      if (l <= 1) {
        console.log(l)
      }
      else {
        event.preventDefault();
      }
    }
  }

  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted1 = false

  }
  openModalDialog1(msg) {
    this.display = 'block'; //Set block css
    this.submitted1 = false
    this.msg = msg

  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.invalidpolicy = false
    this.invalidDate = false
    this.success = false
    this.invalidamount = false
    this.error = false
  }

}
