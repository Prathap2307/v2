import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { InsurerService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/insurer.service';
import { Insurer } from 'src/app/mcore-product/mcore-shared/mcore-entity/insurer';
import { BranchService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/branch.service';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
@Component({
  selector: 'app-insurer',
  templateUrl: './insurer.component.html',
  styleUrls: ['./insurer.component.css'],
  providers: [
    // The locale would typically be provided on the root module of your application. We do it at
    // the component level here, due to limitations of our example generation script.
    { provide: MAT_DATE_LOCALE, useValue: 'en-gb' },

    // `MomentDateAdapter` and `MAT_MOMENT_DATE_FORMATS` can be automatically provided by importing
    // `MatMomentDateModule` in your applications root module. We provide it at the component level
    // here, due to limitations of our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ],
})
export class InsurerComponent implements OnInit {
  submitted: boolean;
  SearchIForm: FormGroup;
  insurerHeading: string = 'Add New - Insurer';
  saveBtnMode: boolean = true;
  textSaveBtn: string = 'Save';
  country: any;
  state: any;
  District: any;
  Taluka: any;
  allinsurer: any;
  insurerObj: any;
  view: boolean = false;
  BRANCH = [
    { Id: '2', Name: 'Term Life' },
    { Id: '3', Name: 'Credit Shield' },

  ]
  display: string;
  exist: boolean;
  success: boolean;
  transaction: string;
  present: any;
  submit: boolean;
  id: any;
  constructor(private insurerService: InsurerService, private BranchService: BranchService, private fb: FormBuilder) { }
  dummyObj = ['swdsd', 'asdasd']
  InsurerForm: FormGroup;
  ngOnInit() {
    this.getAllInsurer()
    this.GetAllcountries()
    this.insurerHeading = 'Add New - Insurer'
    this.SearchIForm = this.fb.group({
      InsurerName: ['', [Validators.required]],
      LineOfBusinessID: ['', [Validators.required]],
    })
    this.InsurerForm = this.fb.group({
      createdBy: [1,],
      createdOn: [null,],
      OrganisationID: [1,],
      isActive: [1,],
      insurerID: [],
      insurerName: ['', [Validators.required]],
      collectionGLCode: [],
      paymentGLCode: [],
      freshGLCode: [],
      apOnlineGLCode: [],
      licPremiumPaymentGLCode: [],
      revivalGLCode: [],
      medicalGLCode: [],
      claimGLCode: [],
      triggerLimitforStampDuty: [],
      intimationEmailaddressforStampDuty: [],
      intimationMobileNumberforStampDuty: [],
      lineOfBusinessID: ['', ],
      dateOfCommencement: ['', Validators.required],
      geographicalPresence: ['',  Validators.pattern('[A-Za-z0-9]\\d{3}')],
      distributionID: ['',],
      logo: ['',],
      address1: ['', Validators.required],
      address2: [''],
      address3: [''],
      countryID: ['', Validators.required],
      stateID: ['', Validators.required],
      districtID: ['', Validators.required],
      talukID: [''],
      zipCode: ['', Validators.required],
      phoneNo: ['',],
      faxNumber: ['',],
      conferenceNumber: ['',],
      mobileNo: ['', Validators.pattern("[0-9 -()+]+$")],
      email: ['', [Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")]],
      gstNo: ['', [Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
      panNo: ['', [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]]

    });

  }

  addressObj: Insurer[];
  getAddressDetails(e) {
    // zipcode = 625203;
    console.log(e.target.value);
    this.insurerService.getAddressByIDzipCode(e.target.value)
      .subscribe(addressObj => {
        this.addressObj = addressObj;

      });

  }
  get f() { return this.InsurerForm.controls; }

  getAllInsurer() {
    this.insurerService.getAllInsurer()
      .subscribe(result => {
        console.log(result)
        this.allinsurer = result.data;

      });

  }
  IsInsurerExist(data: any) {
    this.insurerService.IsInsurerExist(data)
      .subscribe(result => {
            debugger;  
        console.log(result)
        if (result.data && result.data === "NOTEXIST") {
          this.submit = true
          console.log(this.submit)
          this.insurerService.InsertOrUpdateInsurer(this.InsurerForm.value)
            .subscribe(result => {
              console.log(result)
              this.success = true
              this.transaction = "Created"
              this.getAllInsurer()
              this.openModalDialog()
              this.InsurerForm.reset()
            });
        }
        else {
          this.exist = true
          this.present = result.data
          this.openModalDialog()
        }

      });
  }
  onSubmit() {
    debugger;
    this.submitted = true;
    console.log(this.InsurerForm.value)
    console.log(this.InsurerForm.controls)
    // console.log(this.ZoneForm.value["GSTNo"].slice(2, 12))

    if (this.id && this.textSaveBtn === 'Update') {
      console.log(this.id)
      this.InsurerForm.value["insurerID"] = this.id
    }
    else {
      this.InsurerForm.value['insurerID'] = 0
      this.InsurerForm.value["createdBy"] = 1
      this.InsurerForm.value["createdOn"] = null
    }
    if (this.InsurerForm.valid && this.textSaveBtn === 'Save') {
      debugger;
      this.IsInsurerExist(this.InsurerForm.value)

    }
    else {
      if (this.InsurerForm.valid) {
        this.insurerService.InsertOrUpdateInsurer(this.InsurerForm.value)
          .subscribe(result => {
            console.log(result)
            this.success = true
            this.transaction = "Updated"
            this.getAllInsurer()
            this.openModalDialog()
            this.InsurerForm.reset()
          });
      }

    }


  }

  btngEdit_Click(a) {
    this.id = a
    this.insurerHeading = 'Edit - Insurer';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Update';
    this.GetInsurerByID(a)
  }
  GetInsurerByID(a) {
    this.insurerService.GetInsurerByID(a)
      .subscribe(result => {
        console.log(result)
        this.insurerObj = result.data
        console.log(this.insurerObj)
        if (this.insurerObj) {
          this.InsurerForm = this.fb.group({
            insurerID: [{ value: this.insurerObj.insurerID, disabled: false },],
            insurerName: [{ value: this.insurerObj.insurerName, disabled: false }, Validators.required],
            collectionGLCode: [{ value: this.insurerObj.collectionGLCode, disabled: false }],
            paymentGLCode: [{ value: this.insurerObj.paymentGLCode, disabled: false }],
            freshGLCode: [{ value: this.insurerObj.freshGLCode, disabled: false }],
            apOnlineGLCode: [{ value: this.insurerObj.apOnlineGLCode, disabled: false }],
            licPremiumPaymentGLCode: [{ value: this.insurerObj.licPremiumPaymentGLCode, disabled: false }],
            revivalGLCode: [{ value: this.insurerObj.revivalGLCode, disabled: false }],
            medicalGLCode: [{ value: this.insurerObj.medicalGLCode, disabled: false }],
            claimGLCode: [{ value: this.insurerObj.claimGLCode, disabled: false }],
            triggerLimitforStampDuty: [{ value: this.insurerObj.triggerLimitforStampDuty, disabled: false }],
            intimationEmailaddressforStampDuty: [{ value: this.insurerObj.intimationEmailaddressforStampDuty, disabled: false }],
            intimationMobileNumberforStampDuty: [{ value: this.insurerObj.intimationMobileNumberforStampDuty, disabled: false }],
            lineOfBusinessID: [{ value: this.insurerObj.lineOfBusinessID, disabled: false }, Validators.required],
            dateOfCommencement: [{ value: this.insurerObj.dateOfCommencement, disabled: false }, Validators.required],
            geographicalPresence: [{ value: this.insurerObj.geographicalPresence, disabled: false }, [Validators.required, Validators.pattern('[A-Za-z0-9]\\d{3}')]],
            distributionID: [{ value: this.insurerObj.distributionID, disabled: false }, [Validators.required]],
            // logo: [{ value: this.insurerObj.logo, disabled: false }, [Validators.required]],
            address1: ['', Validators.required],
            address2: ['',],
            address3: ['',],
            countryID: ['', Validators.required],
            stateID: ['', Validators.required],
            districtID: ['', Validators.required],
            talukID: [''],
            zipCode: ['', Validators.required],
            phoneNo: ['',],
            faxNumber: ['',],
            conferenceNumber: ['',],
            mobileNo: ['', Validators.pattern("[0-9 -()+]+$")],
            email: [{ value: this.insurerObj.email, disabled: false }, [Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*")]],
            gstNo: [{ value: this.insurerObj.gstNo, disabled: false }, [Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]],
            panNo: [{ value: this.insurerObj.panNo, disabled: false }, [Validators.required, Validators.minLength(10), Validators.pattern('^[A-Za-z]{5}[0-9]{4}[A-Za-z]$')]],
            createdBy: [{ value: this.insurerObj.createdBy, disabled: false },],
            createdOn: [{ value: this.insurerObj.createdOn, disabled: false },],
            isActive: [{ value: this.insurerObj.isActive, disabled: false },],
          });


        }

      })
  }
  btngView_Click() {
    this.view = true
    this.insurerHeading = 'View - Insurer';
    this.saveBtnMode = false;

    // this.DivisionService.get_DivisionByid(a)
    // .subscribe(result => { console.log(result) 
    // this.DivisionFilteredObj=result

    // })
  }
  delete(id) {
    let data = {
      "insurerID": id,
      "DeletedBy": 1
    }

    this.insurerService.DeleteInsurer(data)
      .subscribe(result => { console.log(result) });
  }
  cancel() {
    this.InsurerForm.reset()
    console.log(this.submitted)
    this.submitted = false
    this.insurerHeading = 'Add New - Insurer';
    this.saveBtnMode = true;
    this.textSaveBtn = 'Save'
    if (this.view === true) {
      this.view = false
      console.log(this.view)
    }
  }
  openModalDialog() {
    this.display = 'block'; //Set block css
    this.submitted = false
    // this.SubChannelForm.reset()
  }

  closeModalDialog() {
    this.display = 'none'; //set none css after close dialog
    this.exist = false
    this.success = false

  }
  PanValidation(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      if (l <= 4) {
        console.log(l)

        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();

        }
        console.log(event.keyCode)
        // event.target.value = event.target.value.slice(0, 5).replace(/[^a-zA-Z]/g, "");
      }
      else if (l >= 5 && l <= 8) {

        console.log(l)
        console.log(charCode)
        // console.log(event.target.value.slice(5,9))
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }

        // event.target.value= event.target.value.slice(5, 9).replace(/[^0-9]/g, "");
      }
      else if (l > 9) { event.preventDefault() }
    }
  }
  GstnValidate(event: any) {
    //console.log(event.target.value);
    const pattern = /^[a-zA-Z]*$/;
    var a = event.target.value;
    console.log(a)
    var l = a.length;
    var charCode = (event.which) ? event.which : event.keyCode;
    var keychar = String.fromCharCode(charCode)
    if (l >= 0) {
      // State code
      if (l <= 1) {
        console.log(l)

        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN alphabets
      else if (l >= 2 && l <= 6) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // PAN numeric
      else if (l > 6 && l <= 10) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      } // PAN alphabet
      else if (l >= 11 && l < 12) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 12 && l < 13) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // alphabet
      else if (l >= 13 && l < 14) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 48 && charCode <= 61) || (charCode >= 186 && charCode <= 222) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 14 && l < 15) {
        console.log(l)
        console.log(charCode)
        if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (keychar == "." || keychar == "'" || keychar == "`" || keychar == "!" || keychar == "@" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "-" || keychar == "_" || keychar == "+" || keychar == "=" || keychar == "/" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == "," || keychar == ";" || keychar == ":" || keychar == "|" || keychar == "?" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\")) {
          console.log(event.keyCode)
          event.preventDefault();
        }
      }
      // numeric
      else if (l >= 15) {

        event.preventDefault();

      }

    }
  }
  Select_country(event: any) {
    console.log(event.target.value)

    this.GetAllStates(event.target.value);
  }
  Select_state(event: any) {
    console.log(event.target.value)

    this.GetAllDistricts(event.target.value);
  }

  Select_district(event: any) {
    console.log(event.target.value)

    this.GetTaluk(event.target.value);
  }


  GetAllcountries() {
    this.BranchService.get_all_countries()
      .subscribe(result => {
        console.log(result)
        this.country = result.data

        console.log(this.country)
      });
  }
  GetAllStates(countryID: any) {
    this.BranchService.get_states(countryID)
      .subscribe(result => {
        console.log(result)
        this.state = result.data
      });
  }
  GetAllDistricts(stateID: any) {
    this.BranchService.get_districts(stateID)
      .subscribe(result => {
        console.log(result)
        this.District = result.data
      });
  }
  GetTaluk(districtID: any) {
    this.BranchService.get_taluk(districtID)
      .subscribe(result => {
        console.log(result)
        this.Taluka = result.data
      });
  }


  get MobNoError() {
    if (this.InsurerForm.controls['MobileNo'].hasError('required')) {
      return 'Mobile Number is required';
    } else if (this.InsurerForm.controls['MobileNo'].hasError('pattern')) {
      return 'Please enter valid Mobile Number';
    } else if (this.InsurerForm.controls['MobileNo'].hasError('minlength')) {
      return 'Please enter valid 10 digits Mobile Number';
    }
  }

  get EmailError() {
    if (this.InsurerForm.controls['Email'].hasError('required')) {
      return 'Please enter the E-Mail ID.';
    } else if (this.InsurerForm.controls['Email'].hasError('pattern')) {
      return 'Please Enter Valid Email ID.';
    }
  }
  get GstnError() {
    if (this.InsurerForm.controls['gstNo'].hasError('pattern')) {
      return 'GSTIN should be 15 digits Master.';
    }
    else if (this.InsurerForm.value["PanNo"] && this.InsurerForm.value["PanNo"] != this.InsurerForm.value["gstNo"].slice(2, 12).toUpperCase()) {
      console.log(this.InsurerForm.value["PanNo"])
      console.log(this.InsurerForm.value["gstNo"].slice(2, 12).toUpperCase())
      return 'PAN Mismatch in GSTIN.';
    }
  }

  get PanError() {
    // return this.email.hasError('required') ? 'You must enter a value' :
    //     this.email.hasError('email') ? 'Not a valid email' :
    //         '';
    if (this.InsurerForm.controls['panNo'].hasError('required')) {
      return 'PAN Number is required';
    } else if (this.InsurerForm.controls['panNo'].hasError('pattern')) {
      return 'Please enter valid PAN Number';
    } else if (this.InsurerForm.controls['panNo'].hasError('minlength')) {
      return 'Please Enter 10 digits of PAN Number.';
    }
  }


  consoleLogFn(val) {
    console.log(val);
  }

}
