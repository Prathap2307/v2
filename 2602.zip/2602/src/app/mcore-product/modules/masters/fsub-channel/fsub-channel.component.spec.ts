import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FsubChannelComponent } from './fsub-channel.component';

describe('FsubChannelComponent', () => {
  let component: FsubChannelComponent;
  let fixture: ComponentFixture<FsubChannelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FsubChannelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FsubChannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
