import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-destinationdocumentupload',
  templateUrl: './destinationdocumentupload.component.html',
  styleUrls: ['./destinationdocumentupload.component.css']
})
export class DestinationdocumentuploadComponent implements OnInit {

  submitted = false;
  destinationdocumentuploadForm: FormGroup;
  processvalues: any = ['IND', 'PNB', 'HDFC']
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.destinationdocumentuploadForm = this.fb.group({
      clientName: 
      [
        '',
        [Validators.required]
      ],
      precessName: 
      [
        '',
        [Validators.required]
      ]
    })
  }
  onBtnClickUploadDocument(){
    this.submitted = true;
    this.destinationdocumentuploadForm.markAllAsTouched();
    if(this.destinationdocumentuploadForm.valid){
      let val = this.destinationdocumentuploadForm.value;
    }
  }
  onBtnClickClearUploadDocument(){
    this.destinationdocumentuploadForm.reset();
  }

}
