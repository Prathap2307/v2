import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-masterpolicy',
  templateUrl: './masterpolicy.component.html',
  styleUrls: ['./masterpolicy.component.css']
})
export class MasterpolicyComponent implements OnInit {
  dummyObj: string[];
  displayedColumns: string[] = ['View', 'Edit', 'Delete', 'MasterPolicyNumber', 'AgreementNumber', 'MasterPolicyInception' , 'MasterPolicyExpiry', 'TotalMembers', 'SumAssured' , 'MasterPolicyDate', 'Ageing' , 'Status'  ];
  dataSource = ELEMENT_DATA;
  
  displayedColumnsOne: string[] = ['Edit', 'Delete', 'UnitName', 'PANNumber', 'GSTIN' , 'AddressOne', 'AddressTwo', 'AddressThree' , 'Country', 'State' , 'District', 'PostOffice', 'Pincode'  ];
  dataSourceOne = ELEMENTS_DATAS;
  
   displayedColumnsTwo: string[] = ['Edit', 'Delete', 'AddressOne', 'AddressTwo' ];
  dataSourceTwo = ELEMENTS_DATA_ONE;
  
  displayedColumnsThree: string[] = ['View', 'Edit', 'Delete', 'RiderName', 'FreeCoverLimit', 'Description' , 'VariantType', 'SumAssured', 'Grade' , 'MultipleSalaries', 'MinimumCap' , 'MaximumCap', 'BaseBenefit', 'RetirementAge'];
  dataSourceThree;
  displayedColumnsFive: string[] = ['Status','Remarks','CreatedBy','CreatedOn','ModifiedBy','ModifiedOn','ApprovedBy','ApprovedOn'];
  dataSourceFive;
  displayedColumnsFour: string[] = ['RuleSetName','BaseAdditional','InfluentialValue','AmountType','ActualPremiumValue','PremiumValue'];
  dataSourceFour
  /* displayedColumnsThree: string[] = ['View', 'Edit', 'Delete', 'RiderName', 'FreeCoverLimit'];
  
  displayedColumnsFour: string[] = ['RuleSetName', 'BaseAdditional ', 'InfluentialValue'];
  
  
  displayedColumnsFive: string[] = ['Status', 'Remarks', 'CreatedBy', 'CreatedOn']; */
  
  

  constructor() { }

  ngOnInit() {
  }

}

export interface PeriodicElement {
  MasterPolicyNumber: string;
  AgreementNumber: string;
  MasterPolicyInception: string;
  MasterPolicyExpiry: string;
  TotalMembers: number;
  SumAssured: number;
  MasterPolicyDate: string;
  Ageing: number;
  Status: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {MasterPolicyNumber: '120520129311' , AgreementNumber: 'QWERTY2012SF' , MasterPolicyInception: '31/1/2020' , MasterPolicyExpiry: '30/1/2023' , TotalMembers: 100 , SumAssured: 500000000 , MasterPolicyDate: '31/1/2020', Ageing: 81 , Status: 'Approved' },
  {MasterPolicyNumber: '170519960824' , AgreementNumber: 'ASDFG1234F' , MasterPolicyInception: '28/1/2020' , MasterPolicyExpiry: '27/1/2022' , TotalMembers: 100 , SumAssured: 1000000000 , MasterPolicyDate: '28/1/2020', Ageing: 81 , Status: 'Approved' }
];

export interface Address {
  UnitName: string;
  PANNumber: string;
  GSTIN: string;
  AddressOne: string;
  AddressTwo: string;
  AddressThree: string;
  Country: string;
  State: string;
  District: string;
  PostOffice: string;
  Pincode: number;
}

const ELEMENTS_DATAS: Address[] = [
  {UnitName: 'Postal' , PANNumber: 'QWERT9874Y' , GSTIN: '21WERWETR13' , AddressOne: '14, First Floor' , AddressTwo: 'RK Mutt Road' , AddressThree: 'Mylapore' , Country: 'India', State: 'Tamil Nadu' , District: 'Chennai', PostOffice: 'Mylapore' , Pincode: 600004 },
   {UnitName: 'Postal' , PANNumber: 'ZXCVA6548E' , GSTIN: '65QWERTS987' , AddressOne: '104, First Floor' , AddressTwo: 'VC Garden Street' , AddressThree: 'Mylapore' , Country: 'India', State: 'Tamil Nadu' , District: 'Chennai', PostOffice: 'Mandaveli' , Pincode: 600004 }
];


export interface PeriodicElementType {
  AddressOne: string;
  AddressTwo: string;
}

const ELEMENTS_DATA_ONE: PeriodicElementType[] = [
  { AddressOne: '14 First Floor', AddressTwo: 'RK Mutt Road' } ,
  { AddressOne: '104 First Floor', AddressTwo: 'VC Garden Street' }
];