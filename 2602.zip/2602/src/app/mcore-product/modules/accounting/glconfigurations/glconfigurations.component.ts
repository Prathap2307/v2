import { Component, OnInit, ViewChild } from '@angular/core';
import { Accountingglconfiguration, ProcessName, PaymentMode, ProductVariant, DebitName, CreditName, country, state } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingglconfiguration';
import { AccountingglconfigurationService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingglconfiguration.service';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { MatTableDataSource, MatPaginator, TooltipPosition } from '@angular/material';

@Component({
  selector: 'app-glconfigurations',
  templateUrl: './glconfigurations.component.html',
  styleUrls: ['./glconfigurations.component.css']
})
export class GlconfigurationsComponent implements OnInit {
  fieldDisable: Boolean;
  ProcessName: any;
  PaymentModeId: any;
  ProductVariant: any;
  DebitName: any;
  CreditName: any;
  CountryName: any;
  StateName: any;
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);
  GLConfigurationColumns: string[] = ['View', 'Edit', 'paymentMode', 'processName', 'productId', 'creditGlcode', 'debitGlCode', 'creditNarration', 'debitNarration'];
  GLConfigurationForm: FormGroup;
  GLConfigurationFormSearch: FormGroup;
  GLConfigurationFormAction: FormGroup;
  GLConfigurationObj: Accountingglconfiguration[];
  GLConfigurationFilteredObj: Accountingglconfiguration[];
  AccountProcessNameObj: ProcessName[];
  AccountPaymentModeObj: PaymentMode[];
  AccountProductVariantObj: ProductVariant[];
  DebitNameObj: DebitName[];
  CreditNameObj: CreditName[];
  countryObj: country[];
  stateObj: state[];
  GLConfigurationHeading: string = '';
  btnSaveText: string = '';
  btnModeSave: boolean = true;
  GLConfigurationSource = new MatTableDataSource<Accountingglconfiguration>(this.GLConfigurationObj);
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngAfterViewInit() {
    this.GLConfigurationSource.paginator = this.paginator;
  }
  createGLConfig: boolean;
  constructor(
    private fb: FormBuilder,
    private accountGLConfigService: AccountingglconfigurationService
  ) { }

  ngOnInit() {
    this.createGLConfig = true;
    this.GLConfigurationHeading = 'Add New - General Ledger Configuration';
    this.btnSaveText = 'Save';
    this.ValidateGLConfigDetails();
    this.getAllGLConfigTableDataDetails(0, 0, 0);
    this.getAccountProcessDetails();
    this.getPaymentModeDetails();
    this.getProductVariantDetails();
    //this.getCreditandDebitDetails();
    this.getDebitDetails();
    this.getCreditDetails();
    this.getAllCountriesDetails();
    this.getAllStatesDetails(0);
  }
  onBtnSaveGLConfigurationClick() {
    this.GLConfigurationForm.controls.GLConfigurationFormAction.markAllAsTouched();
    if (this.GLConfigurationForm.get('GLConfigurationFormAction').valid) {
      console.log('valid');
      if (this.createGLConfig) {
        this.GLConfigurationForm.get('GLConfigurationFormAction').patchValue({
          glConfigurationId: '0',
          createdBy: '1',
          createdOn: new Date(),
          isActive: '1',          
        });
      }
      else {
        this.GLConfigurationForm.get('GLConfigurationFormAction').patchValue({
          createdBy: '1',
          createdOn: new Date(),
        });
      }
      let a = this.GLConfigurationForm.controls.GLConfigurationFormAction.value;
      console.log(a);
      this.accountGLConfigService.addGLConfigurationDetails(a).subscribe(result => { this.getAllGLConfigTableDataDetails(0, 0, 0) });
      this.onBtnClearGLConfigurationClick();
    }    
  }
  onBtnClearGLConfigurationClick() {
    this.GLConfigurationForm.controls.GLConfigurationFormAction.reset();
    this.GLConfigurationHeading = 'Add New - General Ledger Configuration';
    this.btnSaveText = 'Save';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.GLConfigurationForm = this.fb.group({
      GLConfigurationFormSearch: this.fb.group({
        searchAccountProcess: [''],
        searchAccountVariant: [''],
        searchAccountPayment: [''],
      }),
      GLConfigurationFormAction: this.fb.group({
        glConfigurationId: { value: '', disabled: false },
        paymentMode: { value: '', disabled: false },
        //paymentModeId: { value: '', disabled: false },
        productId: { value: '', disabled: false },
        processId: { value: '', disabled: false },
        processName: { value: '', disabled: false },
        creditGlcode: { value: '', disabled: false },
        creditAccountName: { value: '', disabled: false },
        debitGlCode: { value: '', disabled: false },
        debitAccountName: { value: '', disabled: false },
        creditNarration: { value: '', disabled: false },
        debitNarration: { value: '', disabled: false },
        reMarks: { value: '', disabled: false },
        isActive: { value: '', disabled: false },
        createdBy: { value: '', disabled: false },
        createdOn: { value: '', disabled: false },
        countryId: { value: '', disabled: false },
        stateId: { value: '', disabled: false },
      })
    });
    this.getAllGLConfigTableDataDetails(0, 0, 0);
  }
  onBtnSearchGLConfiguration(){
    let a = this.GLConfigurationForm.get('GLConfigurationFormSearch.searchAccountProcess').value;
    let b = this.GLConfigurationForm.get('GLConfigurationFormSearch.searchAccountVariant').value;
    let c = this.GLConfigurationForm.get('GLConfigurationFormSearch.searchAccountPayment').value;
    if (a == 0) {
      a = 0;
    }
    if (b == 0) {
      b = 0;
    }
    if (c == 0) {
      c = 0;
    }    
    console.log(a, b, c);
    this.getAllGLConfigTableDataDetails(a, b, c);
  }
  onBtnClearSearchGLConfiguration(){
    this.GLConfigurationForm.reset();
    this.getAllGLConfigTableDataDetails(0, 0, 0);
  }
  // Grid View Button Events
  public btngvView_Click(val) {
    this.GLConfigurationHeading = 'View - General Ledger Configuration';
    this.btnModeSave = false;
    this.btnSaveText = '';
    this.fieldDisable = true;
    this.GLConfigurationFilteredObj = this.GLConfigurationObj.filter((unit) => unit.glConfigurationId == val);
    this.GLConfigurationForm = this.fb.group({
      GLConfigurationFormSearch: this.fb.group({
        searchAccountProcess: [''],
        searchAccountVariant: [''],
        searchAccountPayment: [''],
      }),
      GLConfigurationFormAction: this.fb.group({
        glConfigurationId: this.GLConfigurationFilteredObj[0].glConfigurationId,
        paymentMode: this.GLConfigurationFilteredObj[0].paymentMode,
        //paymentModeId: this.GLConfigurationFilteredObj[0].paymentModeId,
        productId: this.GLConfigurationFilteredObj[0].productId,
        processId: this.GLConfigurationFilteredObj[0].processId,
        processName: this.GLConfigurationFilteredObj[0].processName,
        creditGlcode: this.GLConfigurationFilteredObj[0].creditGlcode,
        creditAccountName: this.GLConfigurationFilteredObj[0].creditAccountName,
        debitGlCode: this.GLConfigurationFilteredObj[0].debitGlCode,
        debitAccountName: this.GLConfigurationFilteredObj[0].debitAccountName,
        creditNarration: this.GLConfigurationFilteredObj[0].creditNarration,
        debitNarration: this.GLConfigurationFilteredObj[0].debitNarration,
        reMarks: this.GLConfigurationFilteredObj[0].remark,
        isActive: this.GLConfigurationFilteredObj[0].isActive,
        createdBy: this.GLConfigurationFilteredObj[0].createdBy,
        createdOn: this.GLConfigurationFilteredObj[0].createdOn,
        countryId: this.GLConfigurationFilteredObj[0].countryId,
        stateId: this.GLConfigurationFilteredObj[0].stateId,
      })
    });
  }

  public btngvEdit_Click(a) {
    this.createGLConfig = false;
    this.GLConfigurationHeading = 'Edit - General Ledger Configuration';
    this.btnSaveText = 'Update';
    this.btnModeSave = true;
    this.fieldDisable = false;
    this.GLConfigurationFilteredObj = this.GLConfigurationObj.filter((unit) => unit.glConfigurationId == a);
    console.log(this.GLConfigurationFilteredObj[0]);
    this.GLConfigurationForm = this.fb.group({
      GLConfigurationFormSearch: this.fb.group({
        searchAccountProcess: [''],
        searchAccountVariant: [''],
        searchAccountPayment: [''],
      }),
      GLConfigurationFormAction: this.fb.group({
        glConfigurationId: this.GLConfigurationFilteredObj[0].glConfigurationId,
        paymentMode: this.GLConfigurationFilteredObj[0].paymentMode,
        //paymentModeId: this.GLConfigurationFilteredObj[0].paymentModeId,
        productId: this.GLConfigurationFilteredObj[0].productId,
        processId: this.GLConfigurationFilteredObj[0].processId,
        processName: this.GLConfigurationFilteredObj[0].processName,
        creditGlcode: this.GLConfigurationFilteredObj[0].creditGlcode,
        creditAccountName: this.GLConfigurationFilteredObj[0].creditAccountName,
        debitGlCode: this.GLConfigurationFilteredObj[0].debitGlCode,
        debitAccountName: this.GLConfigurationFilteredObj[0].debitAccountName,
        creditNarration: this.GLConfigurationFilteredObj[0].creditNarration,
        debitNarration: this.GLConfigurationFilteredObj[0].debitNarration,
        reMarks: this.GLConfigurationFilteredObj[0].remark,
        isActive: this.GLConfigurationFilteredObj[0].isActive,
        createdBy: this.GLConfigurationFilteredObj[0].createdBy,
        createdOn: this.GLConfigurationFilteredObj[0].createdOn,
        countryId: this.GLConfigurationFilteredObj[0].countryId,
        stateId: this.GLConfigurationFilteredObj[0].stateId,
      })
    });
  }

  ValidateGLConfigDetails() {
    this.GLConfigurationForm = this.fb.group({
      GLConfigurationFormSearch: this.fb.group({
        searchAccountProcess: [''],
        searchAccountVariant: [''],
        searchAccountPayment: [''],
      }),
      GLConfigurationFormAction: this.fb.group({        
        glConfigurationId: [''],
       // paymentModeId: [''],
        paymentMode: [''],
        productId: [''],
        processId: [''],
        processName: [''],
        creditGlcode: [''],
        creditAccountName: [''],
        debitGlCode: [''],
        debitAccountName: [''],
        creditNarration: [''],
        debitNarration: [''],
        reMarks: [''],
        isActive: ['1'],
        createdBy: [1],
        createdOn: [new Date()],
        countryId: [''],
        stateId: [''],
      })
    });
  }
  getAllGLConfigTableDataDetails(a, b, c) {
    this.accountGLConfigService.getAllGLConfigDetails(a, b, c).subscribe(
      GLConfigurationObj => {
        this.GLConfigurationSource = new MatTableDataSource<Accountingglconfiguration>(this.GLConfigurationObj);
        this.GLConfigurationSource.data = this.GLConfigurationObj = GLConfigurationObj;
        this.GLConfigurationSource.paginator = this.paginator;
      })
  }
  getAllCountriesDetails() {
    this.accountGLConfigService.getAllCountriesDetails().subscribe(CountryVal => { this.countryObj = CountryVal });
    //this.change_country_fn();      
    let c = this.GLConfigurationForm.get('GLConfigurationFormAction.countryId').value;
     // this.getAllStatesDetails(c);
  }
  change_country_fn() {
    let countryId = this.GLConfigurationForm.get('GLConfigurationFormAction.countryId').value;
    this.getAllStatesDetails(countryId);
  }
  getAllStatesDetails(countryId) {
    //let countryId = this.GLConfigurationForm.controls.countryId.value;
    this.accountGLConfigService.getAllStatesDetails(countryId).subscribe(StateVal => { this.stateObj = StateVal });
  }
  getDebitDetails() {
    // let accountHeadId = this.GLConfigurationForm.controls.accountHeadId.value;
    this.accountGLConfigService.getCreditDetails(0).subscribe(debitVal => { this.DebitNameObj = debitVal });
  }
  getCreditDetails() {
    // let accountHeadId = this.GLConfigurationForm.controls.accountHeadId.value;
    this.accountGLConfigService.getCreditDetails(0).subscribe(creditVal => { this.CreditNameObj = creditVal });
  }
  getProductVariantDetails() {
    //let lobId = this.BankBranchFormAction.controls.bankId.value;
    this.accountGLConfigService.getProductVariantDetails(1).subscribe(productVariantNameVal => { this.AccountProductVariantObj = productVariantNameVal });
  }
  getAccountProcessDetails() {
    this.accountGLConfigService.getAccountProcessNameDetails().subscribe(processNameVal => { this.AccountProcessNameObj = processNameVal });
  }
  getPaymentModeDetails() {
    this.accountGLConfigService.getPaymentModeDetails().subscribe(paymentNameVal => { this.AccountPaymentModeObj = paymentNameVal });
  }
}
