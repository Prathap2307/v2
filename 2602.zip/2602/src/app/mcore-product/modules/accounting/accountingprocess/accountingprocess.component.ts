import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AccountingProcessService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/accountingprocess.service';
import { TooltipPosition } from '@angular/material/tooltip';
import { AccountingProcess, AccountTypeDropDown } from 'src/app/mcore-product/mcore-shared/mcore-entity/accountingprocess';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';

@Component({
  selector: 'app-accountingprocess',
  templateUrl: './accountingprocess.component.html',
  styleUrls: ['./accountingprocess.component.css']
})
export class AccountingprocessComponent implements OnInit {
  tooltipPositionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  tooltipPosition = new FormControl(this.tooltipPositionOptions[5]);

  submitted = false;
  saveBtnMode: boolean;
  processForm: FormGroup;
  processFormAction: FormGroup;

  constructor(private fb:FormBuilder, private processService: AccountingProcessService ) { }
  
  tableColumns: string[] = ['View', 'Edit', 'code', 'description'];
  processHeading: string = '';
  processObj: AccountingProcess[] = [];
  processGridObj: AccountingProcess[] = [];
  processFilteredObj: AccountingProcess[] = [];
  fieldDisable: Boolean;
  
  AccountTypeObjDropDown: AccountTypeDropDown[] = [
    {
      "AccountTypeDropDownID": 1, "AccountTypeDropDownText": "CGST"
    },
    {
      "AccountTypeDropDownID": 2, "AccountTypeDropDownText": "SGST"
    },
    {
       "AccountTypeDropDownID": 3, "AccountTypeDropDownText": "IGST"
    }
  ];
  
  isGSTApplicableV: number;
  isTaxApplicableV: number;
  createBtn: boolean;
  dataSource = new MatTableDataSource<AccountingProcess>(this.processGridObj);

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  
	ngOnInit() {
		setTimeout(() => this.dataSource.paginator = this.paginator);
		this.dataSource = new MatTableDataSource<AccountingProcess>(this.processGridObj);
		
		this.processHeading = 'Add New - Accounting Process';
		this.saveBtnMode = true;
		this.getAccountingProcessDetails();
		this.processForm = this.fb.group({
			  searchCode:[''],
			  searchDescription:[''],
			  processFormAction: this.fb.group({
				processID: [''],
				description: [''],
				code:['',[Validators.required]],
				processName:['',[Validators.required]],
				isGSTApplicable:[this.isGSTApplicableV = 0],
				isTaxApplicable:[this.isTaxApplicableV = 0],
				gstTypeID:[''],
				isActive:[''],
				createdBy: ['1'],
				createdOn: [new Date()],
				modifiedBy: ['1'],
				modifiedOn: [new Date()]
			  }) 
		});
	}
	
	isGSTApplicableValue(event) {


		if (event.checked) {
		  this.processForm.get('processFormAction').patchValue({
			isGSTApplicable: this.isGSTApplicableV = 1
		  });
		} else {
		  this.processForm.get('processFormAction').patchValue({
			isGSTApplicable: this.isGSTApplicableV = 0
		  });
		}
	}


	isTaxApplicableValue(event) {

		if (event.checked) {
		  this.processForm.get('processFormAction').patchValue({
			isTaxApplicable: this.isTaxApplicableV = 1
		  });
		} else {
		  this.processForm.get('processFormAction').patchValue({
			isTaxApplicable: this.isTaxApplicableV = 0
		  });
		}
	}
	
	getAccountingProcessDetails(): void {
		this.processService.getAccountingProcessDetails().subscribe(a => {
			this.processObj = a;
			this.processGridObj = a;
			this.dataSource = new MatTableDataSource<AccountingProcess>(this.processGridObj);
			this.dataSource.data = this.processGridObj = a;
			this.dataSource.paginator = this.paginator;  
        
		});
	}
	
	/* getAccountingProcessBySearch(): void{
		this.processService.getAccountingProcessBySearch( 0 , 0 )
        .subscribe(processObj => this.processObj = processObj);
	} */
	
	btngvView_Click(a) {
    this.saveBtnMode = false;
	this.fieldDisable = true;
    this.processFilteredObj = this.processObj.filter((unit) => unit.processID == a);

	this.processForm = this.fb.group({
		searchCode:[''],
		searchDescription:[''],
		processFormAction: this.fb.group({
			processID: { value: this.processFilteredObj[0].processID, disabled: true },
			description: { value: this.processFilteredObj[0].description, disabled: true },
			code: { value: this.processFilteredObj[0].code, disabled: true },
			processName: { value: this.processFilteredObj[0].processName, disabled: true},
			isGSTApplicable: { value: this.processFilteredObj[0].isGSTApplicable, disabled: true},
			isTaxApplicable: { value: this.processFilteredObj[0].isTaxApplicable, disabled: true},
			gstTypeID: { value: this.processFilteredObj[0].gstTypeID},
			isActive: { value: this.processFilteredObj[0].isActive},
			createdBy: { value: this.processFilteredObj[0].createdBy, disabled: true },
			createdOn: { value: this.processFilteredObj[0].createdOn, disabled: true }
			
		})
    });

    this.processHeading = 'View - Accounting Process';   
	}

	btngvEdit_Click(a) {
		this.saveBtnMode = true;
		this.processFilteredObj = this.processObj.filter((unit) => unit.processID == a);
		this.fieldDisable = false;
		this.processForm = this.fb.group({
			searchCode:[''],
			searchDescription:[''],
			processFormAction: this.fb.group({
				processID: { value: this.processFilteredObj[0].processID, disabled: false },
				description: { value: this.processFilteredObj[0].description, disabled: false },
				code: { value: this.processFilteredObj[0].code, disabled: false },
				processName: { value: this.processFilteredObj[0].processName, disabled: false},
				isGSTApplicable: { value: this.processFilteredObj[0].isGSTApplicable, disabled: false},
				isTaxApplicable: { value: this.processFilteredObj[0].isTaxApplicable, disabled: false},
				gstTypeID: { value: this.processFilteredObj[0].gstTypeID},
				isActive: { value: this.processFilteredObj[0].isActive},
				createdBy: { value: this.processFilteredObj[0].createdBy, disabled: false },
				createdOn: { value: this.processFilteredObj[0].createdOn, disabled: false }

			})
		});

		this.processHeading = 'Edit - Accounting Process';
	   
	}
  
    onBtnSaveAccountingProcess(){
		this.processForm.get('processFormAction').patchValue({
			modifiedBy:  1,
			createdBy:  1,
			isActive:  1,
			//description:  "",
			processID: '0',
			createdOn: new Date()
		});

		this.processForm.controls.processFormAction.markAllAsTouched();   
		if (this.processForm.controls.processFormAction.valid) {
		 
		  let c = this.processForm.controls.processFormAction.value;      
		  console.log(this.processForm.controls.processFormAction.value);
		  this.processService.addAccountingProcess(c)
		  .subscribe(result => {this.getAccountingProcessDetails()});

		  this.processHeading = 'Add New - Accounting Process';
		}
		
		
	}  
  

	onBtnClearAccountingProcess(){    
		this.processHeading = 'Add New - Accounting Process';
		this.fieldDisable = false;
		this.processForm = this.fb.group({
			searchCode:[''],
			searchDescription:[''],
			processFormAction: this.fb.group({
				processID: { value: this.processFilteredObj[0].processID, disabled: false },
				description: { value: this.processFilteredObj[0].description, disabled: false },
				code: { value: this.processFilteredObj[0].code, disabled: false },
				processName: { value: this.processFilteredObj[0].processName, disabled: false},
				isGSTApplicable: { value: this.processFilteredObj[0].isGSTApplicable, disabled: false},
				isTaxApplicable: { value: this.processFilteredObj[0].isTaxApplicable, disabled: false},
				gstTypeID: { value: this.processFilteredObj[0].gstTypeID},
				isActive: { value: this.processFilteredObj[0].isActive},
				createdBy: { value: this.processFilteredObj[0].createdBy, disabled: false },
				createdOn: { value: this.processFilteredObj[0].createdOn, disabled: false }

			})
		});

		this.saveBtnMode = true;

		this.processForm.controls.processFormAction.reset();
	}
  
}