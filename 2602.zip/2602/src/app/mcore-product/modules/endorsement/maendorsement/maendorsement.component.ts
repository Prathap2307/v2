import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maendorsement',
  templateUrl: './maendorsement.component.html',
  styleUrls: ['./maendorsement.component.css']
})
export class MAEndorsementComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
