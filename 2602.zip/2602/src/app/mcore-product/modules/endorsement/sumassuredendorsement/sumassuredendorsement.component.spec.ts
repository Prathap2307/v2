import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SumassuredendorsementComponent } from './sumassuredendorsement.component';

describe('SumassuredendorsementComponent', () => {
  let component: SumassuredendorsementComponent;
  let fixture: ComponentFixture<SumassuredendorsementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SumassuredendorsementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SumassuredendorsementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
