import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MemberUpload } from 'src/app/mcore-product/mcore-shared/mcore-entity/memberupload';
import { MemberuploadService } from 'src/app/mcore-product/mcore-shared/mcore-api-calls/memberupload.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
@Component({
  selector: 'app-memberupload',
  templateUrl: './memberupload.component.html',
  styleUrls: ['./memberupload.component.css']
})
export class MemberuploadComponent implements OnInit {

  constructor(private fb: FormBuilder, private memberupload: MemberuploadService) { }

  fileToUpload: File = null;

  uploadFileurl: any;
  uploadFiledata: any;
  uploadFileName: any;
  browseErrorDiv: boolean;
  handleFileInput(event: any) {


    var reader = new FileReader();

    reader.onload = (event: ProgressEvent) => {
      // this.uploadFileurl = (<FileReader>event.target).result;

      // console.log(this.uploadFileurl);
    }
    reader.readAsDataURL(event.target.files[0]);

    console.log(event.target.files[0].path);



    this.uploadFileName = event.target.files[0].name

  }
  uploadFileToActivity() {
    this.memberUploadAction.markAllAsTouched();
    if (this.memberUploadAction.valid) {
      //D:\\Prathap\\LIC\\Upload14-02-2020.xlsx
      //this.uploadFileurl

      console.log(this.uploadFileurl);

      this.uploadFiledata = { 'filePath': 'D:\\' + this.uploadFileName, 'fileName': this.uploadFileName };

      this.memberupload.postFile(this.uploadFiledata).subscribe(data => {
        // do something, if upload success
      }, error => {
        console.log(error);
      });
    }


  }





  url: any;
  readUrl(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.onload = (event: ProgressEvent) => {
        this.url = (<FileReader>event.target).result as string;
        alert(this.url)
        console.log(this.url);
      }

      reader.readAsBinaryString(event.target.files[0]);
    }
  }

  groupNameObj: MemberUpload[];

  mpnObj: MemberUpload[];

  authorizedSignatoryObj: MemberUpload[];

  memberUploadForm: FormGroup;
  get memberUploadAction() {
    return this.memberUploadForm.get('memberUploadAction') as FormGroup;
  }

  ngOnInit() {
    this.browseErrorDiv = false;
    this.memberUploadForm = this.fb.group({
      memberUploadAction: this.fb.group({

        groupID: ['', [Validators.required]],
        masterPolicyNumber: ['', [Validators.required]],
        agreementNumber: ['', [Validators.required]],
        authorizedSignatory: ['', [Validators.required]],
        browseBtn: ['']

      })

    });
    this.getGroupDetails();
  }

  getGroupDetails() {

    this.memberUploadAction.addControl('groupName', new FormControl(''));
    this.memberUploadAction.addControl('contactFirstName', new FormControl(''));
    this.memberUploadAction.addControl('contactLastName', new FormControl(''));
    this.memberUploadAction.addControl('customerGroupID', new FormControl(''));
    this.memberUploadAction.addControl('branchID', new FormControl(242));
    this.memberUploadAction.addControl('userID', new FormControl(1));

    let a = this.memberUploadAction.value;
    console.log(a);
    this.memberupload.getGroupDetails(a).subscribe(a => {
      this.groupNameObj = a;
    });

  }

  getmasterPolicyDetails() {

    let groupID = this.memberUploadAction.get('groupID').value;
    console.log(groupID);
    this.memberupload.getmasterPolicyDetails(groupID).subscribe(a => {
      this.mpnObj = a;
    });

    this.memberupload.getAllAuthorisedSignatories(groupID).subscribe(a => {
      this.authorizedSignatoryObj = a;
    });

  }

  onBtnClearAction() {
    this.memberUploadForm = this.fb.group({
      memberUploadAction: this.fb.group({

        groupID: '',
        masterPolicyNumber: '',
        agreementNumber: '',
        authorizedSignatory: '',
        browseBtn: ''

      })

    });
  }

  cfn(a) {
    console.log(a);
  }

}
