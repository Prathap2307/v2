import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policyviewinformation',
  templateUrl: './policyviewinformation.component.html',
  styleUrls: ['./policyviewinformation.component.css']
})
export class PolicyviewinformationComponent implements OnInit {
  dummyObj: string;
  constructor() { }

  ngOnInit() {
  }

}
